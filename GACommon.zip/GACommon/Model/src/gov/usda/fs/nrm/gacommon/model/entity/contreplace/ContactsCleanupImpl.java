package gov.usda.fs.nrm.gacommon.model.entity.contreplace;


import gov.usda.fs.nrm.framework.model.entity.IWebEntity;

import java.io.PrintStream;
import java.sql.SQLException;
import oracle.jbo.AttributeList;
import oracle.jbo.Key;
import oracle.jbo.server.AttributeDefImpl;
import oracle.jbo.server.EntityDefImpl;
import oracle.jbo.server.EntityImpl;


public class ContactsCleanupImpl
  extends IWebEntity {
    /**
     * AttributesEnum: generated enum for identifying attributes and accessors. DO NOT MODIFY.
     */
    protected enum AttributesEnum {
        Cn,
        NewCn,
        OldCn,
        Status,
        ErrorMessage,
        GaInd,
        ReassignInd,
        OrgCn,
        GrantCn;
        private static AttributesEnum[] vals = null;
        private static final int firstIndex = 0;

        protected int index() {
            return AttributesEnum.firstIndex() + ordinal();
        }

        protected static final int firstIndex() {
            return firstIndex;
        }

        protected static int count() {
            return AttributesEnum.firstIndex() + AttributesEnum.staticValues().length;
        }

        protected static final AttributesEnum[] staticValues() {
            if (vals == null) {
                vals = AttributesEnum.values();
            }
            return vals;
        }
    }
    public static final int CN = AttributesEnum.Cn.index();
    public static final int NEWCN = AttributesEnum.NewCn.index();
    public static final int OLDCN = AttributesEnum.OldCn.index();
    public static final int STATUS = AttributesEnum.Status.index();
    public static final int ERRORMESSAGE = AttributesEnum.ErrorMessage.index();
    public static final int GAIND = AttributesEnum.GaInd.index();
    public static final int REASSIGNIND = AttributesEnum.ReassignInd.index();
    public static final int ORGCN = AttributesEnum.OrgCn.index();
    public static final int GRANTCN = AttributesEnum.GrantCn.index();

    /**
     * This is the default constructor (do not remove).
     */
    public ContactsCleanupImpl() {
    }

    /**
     * @return the definition object for this instance class.
     */
    public static synchronized EntityDefImpl getDefinitionObject() {
        return EntityDefImpl.findDefObject("gov.usda.fs.iweb.contactreplace.model.entity.ContactsCleanup");
    }


    protected void create(AttributeList AttributeList)
  {
    super.create(AttributeList);
    try {
      setCn(createCN("CONT_CLEANUP_CN_SEQ"));
    }
    catch (SQLException e) {
      System.out.println("Exception in create method :" + e);
    }
  }
  



  public String getCn()
  {
    return (String)getAttributeInternal(0);
  }
  
  public void setCn(String value)
  {
    setAttributeInternal(0, value);
  }
  


  public String getNewCn()
  {
    return (String)getAttributeInternal(1);
  }
  
  public void setNewCn(String value)
  {
    setAttributeInternal(1, value);
  }
  


  public String getOldCn()
  {
    return (String)getAttributeInternal(2);
  }
  
  public void setOldCn(String value)
  {
    setAttributeInternal(2, value);
  }
  


  public String getStatus()
  {
    return (String)getAttributeInternal(3);
  }
  
  public void setStatus(String value)
  {
    setAttributeInternal(3, value);
  }
  



  public String getErrorMessage()
  {
    return (String)getAttributeInternal(4);
  }
  
  public void setErrorMessage(String value)
  {
    setAttributeInternal(4, value);
  }
  


  public String getGaInd()
  {
    return (String)getAttributeInternal(5);
  }
  
  public void setGaInd(String value)
  {
    setAttributeInternal(5, value);
  }
  


  public String getReassignInd()
  {
    return (String)getAttributeInternal(6);
  }
  
  public void setReassignInd(String value)
  {
    setAttributeInternal(6, value);
  }
  


  public String getOrgCn()
  {
    return (String)getAttributeInternal(7);
  }
  
  public void setOrgCn(String value)
  {
    setAttributeInternal(7, value);
  }


    public String getGrantCn()
  {
    return (String)getAttributeInternal(8);
  }
  
  public void setGrantCn(String value)
  {
    setAttributeInternal(8, value);
  }

    /**
     * @param cn key constituent

     * @return a Key object based on given key constituents.
     */
    public static Key createPrimaryKey(String cn) {
        return new Key(new Object[] { cn });
    }


}

