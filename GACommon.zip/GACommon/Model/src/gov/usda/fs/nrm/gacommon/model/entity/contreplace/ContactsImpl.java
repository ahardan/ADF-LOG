package gov.usda.fs.nrm.gacommon.model.entity.contreplace;


import gov.usda.fs.nrm.framework.model.entity.IWebEntity;

import oracle.jbo.Key;
import oracle.jbo.RowIterator;
import oracle.jbo.domain.Number;
import oracle.jbo.server.AttributeDefImpl;
import oracle.jbo.server.EntityDefImpl;
import oracle.jbo.server.EntityImpl;


public class ContactsImpl
  extends IWebEntity {
    /**
     * AttributesEnum: generated enum for identifying attributes and accessors. DO NOT MODIFY.
     */
    protected enum AttributesEnum {
        Cn,
        ObjTech,
        ObjName,
        ObjClass,
        Id,
        TransId,
        Name,
        MasterSite,
        Remarks,
        SecurityId,
        AgencyCode,
        AdminOrgInd,
        Ein,
        Duns,
        FaadsCn,
        FfisVendorStatus,
        AlcCode,
        ParentDuns,
        DunsConfidenceCd,
        International,
        AccinstContLinks,
        Addresses;
        private static AttributesEnum[] vals = null;
        private static final int firstIndex = 0;

        protected int index() {
            return AttributesEnum.firstIndex() + ordinal();
        }

        protected static final int firstIndex() {
            return firstIndex;
        }

        protected static int count() {
            return AttributesEnum.firstIndex() + AttributesEnum.staticValues().length;
        }

        protected static final AttributesEnum[] staticValues() {
            if (vals == null) {
                vals = AttributesEnum.values();
            }
            return vals;
        }
    }
    public static final int CN = AttributesEnum.Cn.index();
    public static final int OBJTECH = AttributesEnum.ObjTech.index();
    public static final int OBJNAME = AttributesEnum.ObjName.index();
    public static final int OBJCLASS = AttributesEnum.ObjClass.index();
    public static final int ID = AttributesEnum.Id.index();
    public static final int TRANSID = AttributesEnum.TransId.index();
    public static final int NAME = AttributesEnum.Name.index();
    public static final int MASTERSITE = AttributesEnum.MasterSite.index();
    public static final int REMARKS = AttributesEnum.Remarks.index();
    public static final int SECURITYID = AttributesEnum.SecurityId.index();
    public static final int AGENCYCODE = AttributesEnum.AgencyCode.index();
    public static final int ADMINORGIND = AttributesEnum.AdminOrgInd.index();
    public static final int EIN = AttributesEnum.Ein.index();
    public static final int DUNS = AttributesEnum.Duns.index();
    public static final int FAADSCN = AttributesEnum.FaadsCn.index();
    public static final int FFISVENDORSTATUS = AttributesEnum.FfisVendorStatus.index();
    public static final int ALCCODE = AttributesEnum.AlcCode.index();
    public static final int PARENTDUNS = AttributesEnum.ParentDuns.index();
    public static final int DUNSCONFIDENCECD = AttributesEnum.DunsConfidenceCd.index();
    public static final int INTERNATIONAL = AttributesEnum.International.index();
    public static final int ACCINSTCONTLINKS = AttributesEnum.AccinstContLinks.index();
    public static final int ADDRESSES = AttributesEnum.Addresses.index();

    /**
     * This is the default constructor (do not remove).
     */
    public ContactsImpl() {
    }

    /**
     * @return the definition object for this instance class.
     */
    public static synchronized EntityDefImpl getDefinitionObject() {
        return EntityDefImpl.findDefObject("gov.usda.fs.iweb.contactreplace.model.entity.Contacts");
    }


    public String getCn()
  {
    return (String)getAttributeInternal(0);
  }
  
  public void setCn(String value)
  {
    setAttributeInternal(0, value);
  }
  


  public String getObjTech()
  {
    return (String)getAttributeInternal(1);
  }
  
  public void setObjTech(String value)
  {
    setAttributeInternal(1, value);
  }
  


  public String getObjName()
  {
    return (String)getAttributeInternal(2);
  }
  
  public void setObjName(String value)
  {
    setAttributeInternal(2, value);
  }
  


  public String getObjClass()
  {
    return (String)getAttributeInternal(3);
  }
  
  public void setObjClass(String value)
  {
    setAttributeInternal(3, value);
  }
  


  public String getId()
  {
    return (String)getAttributeInternal(4);
  }
  
  public void setId(String value)
  {
    setAttributeInternal(4, value);
  }
  



  public String getTransId()
  {
    return (String)getAttributeInternal(5);
  }
  
  public void setTransId(String value)
  {
    setAttributeInternal(5, value);
  }
  


  public String getName()
  {
    return (String)getAttributeInternal(6);
  }
  
  public void setName(String value)
  {
    setAttributeInternal(6, value);
  }
  


  public Number getMasterSite()
  {
    return (Number)getAttributeInternal(7);
  }
  
  public void setMasterSite(Number value)
  {
    setAttributeInternal(7, value);
  }
  


  public String getRemarks()
  {
    return (String)getAttributeInternal(8);
  }
  
  public void setRemarks(String value)
  {
    setAttributeInternal(8, value);
  }
  



  public String getSecurityId()
  {
    return (String)getAttributeInternal(9);
  }
  
  public void setSecurityId(String value)
  {
    setAttributeInternal(9, value);
  }
  


  public String getAgencyCode()
  {
    return (String)getAttributeInternal(10);
  }
  
  public void setAgencyCode(String value)
  {
    setAttributeInternal(10, value);
  }
  


  public String getAdminOrgInd()
  {
    return (String)getAttributeInternal(11);
  }
  
  public void setAdminOrgInd(String value)
  {
    setAttributeInternal(11, value);
  }
  


  public String getEin()
  {
    return (String)getAttributeInternal(12);
  }
  
  public void setEin(String value)
  {
    setAttributeInternal(12, value);
  }
  


  public String getDuns()
  {
    return (String)getAttributeInternal(13);
  }
  
  public void setDuns(String value)
  {
    setAttributeInternal(13, value);
  }
  


  public String getFaadsCn()
  {
    return (String)getAttributeInternal(14);
  }
  
  public void setFaadsCn(String value)
  {
    setAttributeInternal(14, value);
  }
  


  public String getFfisVendorStatus()
  {
    return (String)getAttributeInternal(15);
  }
  
  public void setFfisVendorStatus(String value)
  {
    setAttributeInternal(15, value);
  }
  


  public String getAlcCode()
  {
    return (String)getAttributeInternal(16);
  }
  
  public void setAlcCode(String value)
  {
    setAttributeInternal(16, value);
  }
  


  public String getParentDuns()
  {
    return (String)getAttributeInternal(17);
  }
  
  public void setParentDuns(String value)
  {
    setAttributeInternal(17, value);
  }
  


  public String getDunsConfidenceCd()
  {
    return (String)getAttributeInternal(18);
  }
  
  public void setDunsConfidenceCd(String value)
  {
    setAttributeInternal(18, value);
  }
  


  public String getInternational()
  {
    return (String)getAttributeInternal(19);
  }
  
  public void setInternational(String value)
  {
    setAttributeInternal(19, value);
  }


    public RowIterator getAccinstContLinks()
  {
    return (RowIterator)getAttributeInternal(20);
  }
  

  public RowIterator getAddresses()
  {
    return (RowIterator)getAttributeInternal(21);
  }

    /**
     * @param cn key constituent

     * @return a Key object based on given key constituents.
     */
    public static Key createPrimaryKey(String cn) {
        return new Key(new Object[] { cn });
    }


}

