package gov.usda.fs.nrm.gacommon.model.service;


import gov.usda.fs.nrm.framework.model.service.IWebApplicationModule;
import gov.usda.fs.nrm.gacommon.model.dataaccess.contreplace.ContactGrantViewImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.contreplace.ContactsCleanupViewImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.contreplace.ContactsCleanupViewRowImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.contreplace.FilteredGrantViewImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.contreplace.lov.LovContactsImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.contreplace.lov.LovOrgsImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.ffatarejects.FaadsFfataMlogSpreadViewImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.ffatarejects.FfataMessageLogViewImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.gacodeslib.CodeMappingsViewImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.gacodeslib.CodesViewImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.gacodeslib.GACodesListImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.gacodeslib.ZipcodesGeoViewImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.gacodeslib.lov.SetNameCodeMappingLOVImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.AccInstrumentsViewImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.AccInstrumentsViewRowImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.DomainNameViewImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.DomainNameViewRowImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.EmailsViewImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.GaSummaryTabViewImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.GaSummaryTabViewRowImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.GrantViewImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.GrantViewRowImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.HelpURLViewImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.RacaAgmtStatusesViewImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.RacaAgmtStatusesViewRowImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.RacaAgmtViewImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.RacaAgmtViewRowImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.RacaCloseoutReasonsViewImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.RacaReqStatusesViewImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.RacaReqStatusesViewRowImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.RacaReqsViewImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.RacaReqsViewRowImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.RacaSpecBillingReqViewImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.ReportServerImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.ReportServerRowImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.bills.RacaBillLinesViewImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.bills.RacaBillTextLinesViewImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.bills.RacaBillsViewImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.contacts.AddressesViewImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.contacts.ContactsLinksViewImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.contacts.CooperatorsLinksViewImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.contacts.PhoneNumbersViewImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.jobcode.RacaJCNotifStatusesViewImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.jobcode.RacaJCNotifStatusesViewRowImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.jobcode.RacaJobCodeNotifLinesViewImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.jobcode.RacaJobCodeNotifViewImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.jobcode.RacaJobCodeNotifViewRowImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.lov.LovBillingOptionsImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.lov.LovBranchHandlingImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.lov.LovBudgetOrgImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.lov.LovCollectionTypeImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.lov.LovContSubTypeImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.lov.LovFFISVendorsImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.lov.LovFundImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.lov.LovJobCodeFundTypeImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.lov.LovJobCodeSourceImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.lov.LovOrgImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.lov.LovProgramImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.lov.LovSUDSAgmtsImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.lov.LovTransPurposeImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.lov.lovCloseoutReasonImpl;
import gov.usda.fs.nrm.gacommon.model.entity.raca.RacaJobCodeNotifLinesImpl;
import gov.usda.fs.nrm.gacommon.model.service.common.GACommonService;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Iterator;

import oracle.jbo.JboException;
import oracle.jbo.Row;
import oracle.jbo.RowIterator;
import oracle.jbo.RowSetIterator;
import oracle.jbo.ViewCriteria;
import oracle.jbo.ViewCriteriaRow;
import oracle.jbo.ViewObject;
import oracle.jbo.domain.Date;
import oracle.jbo.domain.Number;
import oracle.jbo.server.DBTransaction;
import oracle.jbo.server.ViewLinkImpl;
import oracle.jbo.server.ViewObjectImpl;
import oracle.jbo.server.ViewRowImpl;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
//import java.util.Date;

// ---------------------------------------------------------------------
// ---    File generated by Oracle ADF Business Components Design Time.
// ---    Custom code may be added to this class.
// ---    Warning: Do not modify method signatures of generated methods.
// ---------------------------------------------------------------------
public class GACommonServiceImpl extends IWebApplicationModule implements GACommonService{

    private static Logger log       =LogManager.getLogger(GACommonServiceImpl.class);
    String                appVersion="4.1";

    /**This is the default constructor (do not remove)
     */
    public GACommonServiceImpl(){
    }

    /**
     * calcTotal
     * @param viewName
     * @param columnName
     */
    public String calcTotal(String viewName,String columnName){
        String         totalAmountCurrency="0";
        ViewObject     vo                 =findViewObject(viewName);
        RowSetIterator rowSetIter         =vo.createRowSetIterator(viewName+"RSI");
        String         status             =null;
        Number         amount             =null;
        Number         totalAmount        =new Number(0);
        while(rowSetIter.hasNext()){
            Row row=rowSetIter.next();
            if(row!=null){
                amount=(Number)row.getAttribute(columnName);
                if(amount!=null){
                    totalAmount=totalAmount.add(amount);
                }
            }
        }
        rowSetIter.closeRowSetIterator();
        //log.debug("totalAmount: " + totalAmount);

        NumberFormat currencyFormatter;
        currencyFormatter=NumberFormat.getNumberInstance();
        currencyFormatter.setMinimumFractionDigits(2);
        totalAmountCurrency=currencyFormatter.format(totalAmount.getValue());
        return totalAmountCurrency;
    }

    /**
     * getReportServerName
     * @return
     */
    public String getReportServerName(){
        getReportServer().executeQuery();
        ReportServerRowImpl row =  (ReportServerRowImpl) getReportServer().first();
         if(row!=null){
           return (String)row.getServerName();
         }
         System.out.println("Report Server -->"+row.getServerName());
          return (String)row.getServerName();
      
    }
    
    

    /**
     * getReportDomainName
     * @return
     */
    public String getDomainName(){
       getDomainNameView1().executeQuery();
       DomainNameViewRowImpl row =  (DomainNameViewRowImpl) getDomainNameView1().first();
        if(row!=null){
          return (String)row.getServername();
        }
         return (String)row.getServername();
    }

    /**
     * getHelpURLValue
     * v 3.3
     * @return
     */
    public String getHelpURLValue(){
        return getHelpURLView().first().getAttribute("ProfileValue").toString();
    }


    /**
     * createRacaAgmt
     */
    public void createRacaAgmt(String agmtSubType){
        log.debug("start createRacaAgmt:agmtSubType: "+agmtSubType);
        getDBTransaction().rollback();
        getRacaAgmtView().reset();
        getRacaAgmtView().clearCache();
        getRacaAgmtView().executeQuery();

        RacaAgmtViewRowImpl row=(RacaAgmtViewRowImpl)getRacaAgmtView().createRow();
        row.setAgreementSubtype(agmtSubType);
        getRacaAgmtView().insertRow(row);

        if(row!=null){
            String newCn=row.getCn();
            log.debug("RacaAgmt Cn: "+newCn);
            getRacaAgmtView().setWhereClause("CN='"+newCn.trim()+"'");
        }

        //        String newCn = row.getCn();
        //        log.debug("RacaAgmt Cn: " +  newCn);
        //        getRacaAgmtView().setWhereClause("CN='"+newCn.trim()+"'");

        //        if (row != null){
        //            getRacaAgmtView().insertRow(row);
        //            log.debug("getCn " + row.getCn());
        //            getRacaAgmtView().setWhereClause("CN='"+row.getCn()+"'");
        //            getRacaAgmtView().executeQuery();
        //            RacaAgmtViewRowImpl newRow = (RacaAgmtViewRowImpl)getRacaAgmtView().first();
        //        }
        log.debug("end createRacaAgmt");
    }

    /**
     * setRacaAgmtCurrentRowByCn
     * used by GA only
     * @param Cn
     */
    public void setRacaAgmtCurrentRowByCn(String Cn){
        log.debug("setRacaAgmtCurrentRowByCn:Cn "+Cn);
        getDBTransaction().rollback();
        getRacaAgmtView().reset();
        getRacaAgmtView().clearCache();
        getRacaAgmtView().executeQuery();
        getRacaAgmtView().clearViewCriterias();
        getRacaAgmtView().setWhereClause("CN='"+Cn.trim()+"'");
        getRacaAgmtView().executeQuery();
        RacaAgmtViewRowImpl row=(RacaAgmtViewRowImpl)getRacaAgmtView().first();

        if(row!=null){
            log.debug("setRacaAgmtCurrentRowByCn:row.getId "+row.getId());
            log.debug("setRacaAgmtCurrentRowByCn:row.getSecurityId "+row.getSecurityId());
            log.debug("setRacaAgmtCurrentRowByCn:row.getManagingContCn "+row.getManagingContCn());
            log.debug("setRacaAgmtCurrentRowByCn:row.getProjectTitle "+row.getProjectTitle());

            // set agreement type on session variable
            //JSFUtils.storeOnSession("reportServerName",reportServerName);


            // get ga grant info
            if(row.getProjectTitle()==null){
                row.setStatus("NEW");
                row.setAgreementSubtype("GA");
                row.setAssessOverhead("No"); // default to No
                row.setAssessOverheadDocumented("No");
                getGrantView().setWhereClause("CN='"+Cn.trim()+"'");
                getGrantView().executeQuery();
                GrantViewRowImpl grantRow=(GrantViewRowImpl)getGrantView().first();
                if(grantRow!=null&&row!=null){
                    row.setProjectTitle(grantRow.getProjTitle());
                    row.setExpirationDate(grantRow.getProjExpirationDt());
                    log.debug("setRacaAgmtCurrentRowByCn:grantRow.getProjExecutionDt() "+grantRow.getProjExecutionDt());
                    log.debug("setRacaAgmtCurrentRowByCn:grantRow.getProjStartDt() "+grantRow.getProjStartDt());
                    // Set Agreement Effective Date
                    if(grantRow.getProjStartDt()==null)
                        row.setAgreementEffectiveDate(grantRow.getProjExecutionDt());
                    else if(grantRow.getProjExecutionDt()==null)
                        row.setAgreementEffectiveDate(grantRow.getProjStartDt());
                    else if(grantRow.getProjExecutionDt().compareTo(grantRow.getProjStartDt())<=0)
                        row.setAgreementEffectiveDate(grantRow.getProjExecutionDt());
                    else
                        row.setAgreementEffectiveDate(grantRow.getProjStartDt());

                    // Get Cooperator Cash Contribution from GaSummaryTab NonFSCash
                    RowIterator rowIter=grantRow.getGaSummaryTabView();
                    while(rowIter.hasNext()){
                        GaSummaryTabViewRowImpl rowGaSummary=(GaSummaryTabViewRowImpl)rowIter.next();
                        if(rowGaSummary!=null&&rowGaSummary.getNonFsCash()!=null){
                            log.debug("setRacaAgmtCurrentRowByCn:rowGaSummary.getNonFsCash(): "+
                                      rowGaSummary.getNonFsCash());
                            //rowGaSummary.getNonFsCash().intValue() != 0
                            row.setCooperatorCashContribution(rowGaSummary.getNonFsCash());
                        }
                    }

                }
            }

            getRacaAgmtView().setCurrentRow(row);

            getRacaReqsView().clearCache();
            getRacaReqsView().executeQuery();


            //            try{
            //              //getDBTransaction().postChanges();
            //              getDBTransaction().getRootApplicationModule().sync();
            //              getDBTransaction().commit();
            //              getDBTransaction().getRootApplicationModule().sync();
            //            }
            //            catch (Exception e){
            //              log.debug("setRacaAgmtCurrentRowByCn: " + e.getMessage());
            //              //e.printStackTrace();
            //            }
        } else {
            log.error("setRacaAgmtCurrentRowByCn: RACA Agreement row not found with Cn:"+Cn);
        }
    }

    /**
     *
     * @param param
     */
    public void setRacaAgmtBlankRow(String param){
        getDBTransaction().rollback();
        //        getRacaAgmtView().setWhereClause("1 = 2");
        //        getRacaAgmtView().executeQuery();

        ViewCriteria    vc =getRacaAgmtView().createViewCriteria();
        ViewCriteriaRow row=vc.createViewCriteriaRow();
        row.setAttribute("Cn","= '"+0+"'");
        vc.addElement(row);
        getRacaAgmtView().applyViewCriteria(vc);
        getRacaAgmtView().executeQuery();
    }

    /**
     * setGrantCurrentRowByCn
     * @param Cn
     */
    public void setGrantCurrentRowByCn(String Cn){
        getGrantView().setWhereClause("CN='"+Cn.trim()+"'");
        getGrantView().executeQuery();
        GrantViewRowImpl grantRow=(GrantViewRowImpl)getGrantView().first();
        getGrantView().setCurrentRow(grantRow);
    }

    /**
     * copyGrantFieldsByCn
     * @param Cn
     */
    public void copyGrantFieldsByCn(String Cn){
        setGrantCurrentRowByCn(Cn);
        GrantViewRowImpl    grantRow=(GrantViewRowImpl)getGrantView().getCurrentRow();
        RacaReqsViewRowImpl racaRow =(RacaReqsViewRowImpl)getRacaReqsView().getCurrentRow();
        if(grantRow!=null&&racaRow!=null){
            log.debug("copyGrantFieldsByCn:grantRow.getProjTitle()"+grantRow.getProjTitle());
            racaRow.setExpirationDate(grantRow.getProjExpirationDt());
        }
    }

    public String getRacaReqStatusCode(){
      System.out.println("=======IN RACA SERVICE IMPL====");
      System.out.println("view name"+getRacaReqsView().toString());
       
       log.debug("current row"+getRacaReqsView().getCurrentRow());
       
      // log.debug("status value"+(String)getRacaReqsView().getCurrentRow().getAttribute("Status"));
      return  null != getRacaReqsView().getCurrentRow() ?  (String)getRacaReqsView().getCurrentRow().getAttribute("Status"): null;
    }

    public String getRacaReqObligatingDocNo(){
       log.debug("=======IN RACA SERVICE IMPL====");
       log.debug("view name"+getRacaReqsView().toString());
       log.debug("current row"+getRacaReqsView().getCurrentRow());
       log.debug("ObligatingDocNo value"+(String)getRacaReqsView().getCurrentRow().getAttribute("ObligatingDocNo"));
        return (String)getRacaReqsView().getCurrentRow().getAttribute("ObligatingDocNo");
    }

    public String getFedIdType(){
        if(getGrantView().getCurrentRow()==null){
            String grantCn=(String)getRacaAgmtView().getCurrentRow().getAttribute("Cn");
            setGrantCurrentRowByCn(grantCn);
        }
        GrantViewRowImpl grantRow =(GrantViewRowImpl)getGrantView().getCurrentRow();
        String           FedIdType="";
        if(grantRow!=null){
            FedIdType=grantRow.getFedIdType();
           log.debug("FedIdType value "+FedIdType);
        }
        return FedIdType;
    }

    public String getProgrmResponsibilityType(){
        if(getGrantView().getCurrentRow()==null){
            String grantCn=(String)getRacaAgmtView().getCurrentRow().getAttribute("Cn");
            setGrantCurrentRowByCn(grantCn);
        }
        GrantViewRowImpl grantRow                =(GrantViewRowImpl)getGrantView().getCurrentRow();
        String           ProgrmResponsibilityType="";
        if(grantRow!=null){
            ProgrmResponsibilityType=grantRow.getProgrmResponsibilityType();
           log.debug("ProgrmResponsibilityType value "+ProgrmResponsibilityType);
        }
        return ProgrmResponsibilityType;
    }

    public String getCooperatorAgreementNumber(){
       log.debug("=======IN RACA SERVICE IMPL====");
       log.debug("view name"+getRacaAgmtView().toString());
       log.debug("current row"+getRacaAgmtView().getCurrentRow());
       log.debug("CooperatorAgreementNo value"+
                  (String)getRacaAgmtView().getCurrentRow().getAttribute("CooperatorAgreementNo"));
        return (String)getRacaAgmtView().getCurrentRow().getAttribute("CooperatorAgreementNo");
    }

    /**

    /**
     * executeViewQuery
     * @param viewName
     */
    public void executeViewQuery(String viewName){
        findViewObject(viewName).executeQuery();
    }


    /**
     * setRacaAgmtStatus
     * @param sCn
     * @param sOldStatus
     * @param sNewStatus
     * @param sCommentValue
     */
    public void setRacaAgmtStatus(String sCn,String sOldStatus,String sNewStatus,String sCommentValue){
        getTransaction().postChanges();
        setRacaAgmtStatus(getRacaAgmtView().getCurrentRow(),sCn,sOldStatus,sNewStatus,sCommentValue,null);
        if(log.isDebugEnabled()){
            RacaAgmtViewRowImpl row=(RacaAgmtViewRowImpl)getRacaAgmtView().getCurrentRow();
           log.debug("setRacaAgmtStatus:getCn "+row.getCn());
        }
        //getRacaReqsView().executeQuery();
    }

    /**
     * setRacaAgmtStatus
     * @param row
     * @param sCn
     * @param sOldStatus
     * @param sNewStatus
     * @param sCommentValue
     */
    /* Old Set RACA AGMT */
    /*
    private void setRacaAgmtStatus(Row row, String sCn, String sOldStatus, String sNewStatus, String sCommentValue, Number currentBFYAmount){
        RacaAgmtViewRowImpl rowAgmt =  (RacaAgmtViewRowImpl)row;
          log.debug(" Including RACA expiry Update along with Status ");
        //Check business rule
        if ("CLOSED".equalsIgnoreCase(sNewStatus)){
            RowIterator iter = rowAgmt.getRacaReqsView();
            while (iter.hasNext()){
                RacaReqsViewRowImpl rowReq =  (RacaReqsViewRowImpl)iter.next();
                setRacaRequestStatus(rowReq, sCn, sOldStatus, sNewStatus, sCommentValue);
            }
        }

        if ("ACTIVE".equalsIgnoreCase(sNewStatus)){
//            if (rowAgmt != null && currentBFYAmount != null){
//               log.debug("rowAgmt.getCooperatorCashContribution() " + rowAgmt.getCooperatorCashContribution());
//                if (rowAgmt.getCooperatorCashContribution() == null )
//                    rowAgmt.setCooperatorCashContribution(currentBFYAmount);
//                else
//                    rowAgmt.setCooperatorCashContribution(rowAgmt.getCooperatorCashContribution().add(currentBFYAmount));
//
//               log.debug("rowAgmt.getCooperatorCashContribution() " + rowAgmt.getCooperatorCashContribution());
//            }
        }

        // add new status
        RacaAgmtStatusesViewRowImpl rowStatus = (RacaAgmtStatusesViewRowImpl)getRacaAgmtStatusesView().createRow();
        rowStatus.setRacaAgmtCn(rowAgmt.getCn());
        rowStatus.setStatusCode(sNewStatus);
        rowStatus.setComments(sCommentValue);
        getRacaAgmtStatusesView().insertRow(rowStatus);

        rowAgmt.setStatus(sNewStatus);

        try{
          //getDBTransaction().postChanges();
          getDBTransaction().getRootApplicationModule().sync();
          getDBTransaction().commit();
          getDBTransaction().getRootApplicationModule().sync();
        }
        catch (Exception e){
         log.debug("setRacaAgmtStatus: " + e.getMessage());
          //e.printStackTrace();
        }

        if (log.isDebugEnabled()) {
        log.debug("setRacaAgmtStatus:sNewStatus " + sNewStatus);
        }
    }
*/
    // New
    private void setRacaAgmtStatus(Row row,String sCn,String sOldStatus,String sNewStatus,String sCommentValue,
                                   Number currentBFYAmount){
        RacaAgmtViewRowImpl rowAgmt=(RacaAgmtViewRowImpl)row;
         log.debug(" Including RACA expiry Update along with Status ");
        //Check business rule
        if("CLOSED".equalsIgnoreCase(sNewStatus)||"CUSTOMER CLOSED".equalsIgnoreCase(sNewStatus)){
            RowIterator iter=rowAgmt.getRacaReqsView();
            while(iter.hasNext()){
                RacaReqsViewRowImpl rowReq=(RacaReqsViewRowImpl)iter.next();
                setRacaRequestStatus(rowReq,sCn,sOldStatus,"CLOSED",sCommentValue);
            }
        }

        if("ACTIVE".equalsIgnoreCase(sNewStatus)){
            //            if (rowAgmt != null && currentBFYAmount != null){
            //               log.debug("rowAgmt.getCooperatorCashContribution() " + rowAgmt.getCooperatorCashContribution());
            //                if (rowAgmt.getCooperatorCashContribution() == null )
            //                    rowAgmt.setCooperatorCashContribution(currentBFYAmount);
            //                else
            //                    rowAgmt.setCooperatorCashContribution(rowAgmt.getCooperatorCashContribution().add(currentBFYAmount));
            //
            //               log.debug("rowAgmt.getCooperatorCashContribution() " + rowAgmt.getCooperatorCashContribution());
            //            }
        }

        // add new status
        RacaAgmtStatusesViewRowImpl rowStatus=(RacaAgmtStatusesViewRowImpl)getRacaAgmtStatusesView().createRow();
        rowStatus.setRacaAgmtCn(rowAgmt.getCn());
        rowStatus.setStatusCode(sNewStatus);
        rowStatus.setComments(sCommentValue);
        getRacaAgmtStatusesView().insertRow(rowStatus);

        rowAgmt.setStatus(sNewStatus);

        try{
            //getDBTransaction().postChanges();
            getDBTransaction().getRootApplicationModule().sync();
            getDBTransaction().commit();
            getDBTransaction().getRootApplicationModule().sync();
        } catch(Exception e){
           log.debug("setRacaAgmtStatus: "+e.getMessage());
            //e.printStackTrace();
        }

        if(log.isDebugEnabled()){
           log.debug("setRacaAgmtStatus:sNewStatus "+sNewStatus);
        }
    }

    // 6/8/15 Duk added for
    private void setRacaAgmtStatusRejected(Row row,String sCn,String sOldStatus,String sNewStatus,String sCommentValue,
                                           Number currentBFYAmount){
        RacaAgmtViewRowImpl rowAgmt=(RacaAgmtViewRowImpl)row;
         log.debug(" Including RACA expiry Update along with Status ");
        //Check business rule
        if("CLOSED".equalsIgnoreCase(sNewStatus)||"CUSTOMER CLOSED".equalsIgnoreCase(sNewStatus)){
            RowIterator iter=rowAgmt.getRacaReqsView();
            while(iter.hasNext()){
                RacaReqsViewRowImpl rowReq=(RacaReqsViewRowImpl)iter.next();
                setRacaRequestStatus(rowReq,sCn,sOldStatus,"CLOSED",sCommentValue);
            }
        }

        if("ACTIVE".equalsIgnoreCase(sNewStatus)){
            //            if (rowAgmt != null && currentBFYAmount != null){
            //               log.debug("rowAgmt.getCooperatorCashContribution() " + rowAgmt.getCooperatorCashContribution());
            //                if (rowAgmt.getCooperatorCashContribution() == null )
            //                    rowAgmt.setCooperatorCashContribution(currentBFYAmount);
            //                else
            //                    rowAgmt.setCooperatorCashContribution(rowAgmt.getCooperatorCashContribution().add(currentBFYAmount));
            //
            //               log.debug("rowAgmt.getCooperatorCashContribution() " + rowAgmt.getCooperatorCashContribution());
            //            }
        }

        String status=rowAgmt.getStatus();
        if(!"NEW".equalsIgnoreCase(status)){
            // add new status
            RacaAgmtStatusesViewRowImpl rowStatus=(RacaAgmtStatusesViewRowImpl)getRacaAgmtStatusesView().createRow();
            rowStatus.setRacaAgmtCn(rowAgmt.getCn());
            rowStatus.setStatusCode(sNewStatus);
            rowStatus.setComments(sCommentValue);
            getRacaAgmtStatusesView().insertRow(rowStatus);

            rowAgmt.setStatus(sNewStatus);
        }
        try{
            //getDBTransaction().postChanges();
            getDBTransaction().getRootApplicationModule().sync();
            getDBTransaction().commit();
            getDBTransaction().getRootApplicationModule().sync();
        } catch(Exception e){
           log.debug("setRacaAgmtStatus: "+e.getMessage());
            //e.printStackTrace();
        }

        if(log.isDebugEnabled()){
           log.debug("setRacaAgmtStatus:sNewStatus "+sNewStatus);
        }

    }

    /**
     * setRacaRequestStatus
     * @param sCn
     * @param sOldStatus
     * @param sNewStatus
     * @param sCommentValue
     */
    public void setRacaRequestStatus(String sCn,String sOldStatus,String sNewStatus,String sCommentValue){
        getTransaction().postChanges();
        setRacaRequestStatus(getRacaReqsView().getCurrentRow(),sCn,sOldStatus,sNewStatus,sCommentValue);
    }

    /**
     * setRacaRequestStatus
     * @param row
     * @param sCn
     * @param sOldStatus
     * @param sNewStatus
     * @param sCommentValue
     */
    private void setRacaRequestStatus(Row row,String sCn,String sOldStatus,String sNewStatus,String sCommentValue){

        RacaReqsViewRowImpl rowReq=(RacaReqsViewRowImpl)row;

        // verify current status
        //if (sOldStatus != null && sOldStatus.equals(rowReq.getStatus())){

        //RacaAgmtViewRowImpl rowAgmt = (RacaAgmtViewRowImpl)getRacaAgmtView().getCurrentRow();
        RacaAgmtViewRowImpl rowAgmt=(RacaAgmtViewRowImpl)rowReq.getRacaAgmtView();

        if("REJECTED".equalsIgnoreCase(sNewStatus)){
            rowReq.setVerifiedDate(null);
            rowAgmt.setDateAgreementReceivedAsc(null);
            // 9/2011 CR003928 gpetrake -- When Request Status = Reject Make Agreeement status = Active
            //setRacaAgmtStatus(rowAgmt, sCn, sOldStatus, "ACTIVE", sCommentValue, null);  // 6/8/15 Duk modified
            setRacaAgmtStatusRejected(rowAgmt,sCn,sOldStatus,"ACTIVE",sCommentValue,null);
        }

        if("ACTIVE".equalsIgnoreCase(sNewStatus)){
            //rowReq.getRacaAgmtView().setAttribute("Status","ACTIVE");
            //not used anymore
            //calculateCoopCashContribution(rowAgmt, rowReq.getCurrentBfyAmount);
            //check that Collection Type is not blank
            //validateCollectionType();
            setRacaAgmtStatus(rowAgmt,sCn,sOldStatus,sNewStatus,sCommentValue,rowReq.getCurrentBfyAmount());
        }

        // Moved to last check because if close out request, new req status is set to ACTIVE, and agreement set to CLOSING
        if("SUBMITTED".equalsIgnoreCase(sNewStatus)){
            if(rowReq.getVerifiedDate()==null)
                rowReq.setVerifiedDate(new Date(new java.sql.Date(System.currentTimeMillis())));

            rowAgmt.setDateAgreementReceivedAsc(new Date(new java.sql.Date(System.currentTimeMillis())));
            //if CLOSEOUT REQUEST, set Agreement Status to CLOSING
            if("CLOSEOUT REQUEST".equalsIgnoreCase(rowReq.getTransmittalPurpose())){ // Set agreement to CLOSEOUT REQUEST
                //09/2011 gpetrakes CR003982 changed CLOSING to CLOSEOUT REQUEST
                setRacaAgmtStatus(rowAgmt,sCn,sOldStatus,rowReq.getTransmittalPurpose(),sCommentValue,null);
                // set req status to ACTIVE, override value of sNewStatus
                sNewStatus="ACTIVE";
            }
        }

        // add new status
        RacaReqStatusesViewRowImpl rowStatus=(RacaReqStatusesViewRowImpl)getRacaReqStatusesView().createRow();
        rowStatus.setRacaReqCn(rowReq.getCn());
        rowStatus.setStatusCode(sNewStatus);
        rowStatus.setComments(sCommentValue);
        getRacaReqStatusesView().insertRow(rowStatus);

        rowReq.setStatus(sNewStatus);
        //getRacaReqsView().setCurrentRow(rowReq);
        //}

        try{
            getDBTransaction().postChanges();

            getDBTransaction().getRootApplicationModule().sync();
        } catch(Exception e){
           log.debug("setRacaRequestStatus: "+e.getMessage());
            //e.printStackTrace();
        }

        if(log.isDebugEnabled()){
           log.debug("setRacaRequestStatus:sNewStatus "+sNewStatus);
        }
    }

    public boolean isCloseoutPending(){
        boolean ret=false;
        try{
            String grantCn =(String)getRacaAgmtView().getCurrentRow().getAttribute("Cn");
            String sqlQuery=
                "select cn from  ii_raca_closeout_reasons a  "+"where a.resolved_date is null "+
                "and a.raca_agmt_cn = '"+grantCn+"'";
            ViewObject view=createViewObjectFromQueryStmt("view",sqlQuery);
            view.executeQuery();
            Row row=view.first();
            if(row!=null){
                ret=true;
            }
           log.debug("isCloseoutPending: "+grantCn+":"+ret);
            //          if (row != null){
            //            Number count = (Number) row.getAttribute(0);
            //           log.debug("isContactLinked count: " + count);
            //            if (count != null){
            //               if (count.doubleValue() > 0 )
            //                   ret = false;
            //            }
            //          }
            view.remove();
        } catch(Exception e){
           log.debug("isCloseoutPending Error: "+e.getMessage());
            //e.printStackTrace();
        }
        return ret;


    }

    public boolean isOnePayerYes(String linkTypeName){
        boolean ret=true;
        try{
            String grantCn =(String)getRacaAgmtView().getCurrentRow().getAttribute("Cn");
            String sqlQuery=
                "select cn from II_ACCINST_CONT_LINKS a  "+"where a.link_type_name = '"+linkTypeName+"' "+
                "and nvl(a.payer_ind,'N') = 'Y' "+"and a.accinst_cn = '"+grantCn+"'";
            ViewObject view=createViewObjectFromQueryStmt("view",sqlQuery);
            view.executeQuery();
            Row row=view.first();
            if(row==null){
                ret=false;
            }
           log.debug("isOnePayerYes: "+linkTypeName+":"+ret);
            //          if (row != null){
            //            Number count = (Number) row.getAttribute(0);
            //           log.debug("isContactLinked count: " + count);
            //            if (count != null){
            //               if (count.doubleValue() > 0 )
            //                   ret = false;
            //            }
            //          }
            view.remove();
        } catch(Exception e){
           log.debug("isOnePayerYes Error: "+e.getMessage());
            //e.printStackTrace();
        }
        return ret;


    }

    /**
     * isContactLinked
     * @param type
     * @return
     */
    public boolean isContactLinked(String type){
        boolean ret=true;
        try{
            String grantCn =(String)getRacaAgmtView().getCurrentRow().getAttribute("Cn");
            String sqlQuery=
                "select cn from II_ACCINST_CONT_LINKS a  "+"where a.link_sub_type = '"+type+"' "+"and a.accinst_cn = '"+
                grantCn+"'";
            ViewObject view=createViewObjectFromQueryStmt("view",sqlQuery);
            view.executeQuery();
            Row row=view.first();
            if(row==null){
                ret=false;
            }
           log.debug("isContactLinked : "+type+":"+ret);
            //          if (row != null){
            //            Number count = (Number) row.getAttribute(0);
            //           log.debug("isContactLinked count: " + count);
            //            if (count != null){
            //               if (count.doubleValue() > 0 )
            //                   ret = false;
            //            }
            //          }
            view.remove();
        } catch(Exception e){
           log.debug("isContactLinked Error: "+e.getMessage());
            //e.printStackTrace();
        }
        return ret;
    }

    /**
     * setJobCodeNotifStatus
     * @param sCn
     * @param sOldStatus
     * @param sNewStatus
     * @param sCommentValue
     */
    public void setJobCodeNotifStatus(String sCn,String sOldStatus,String sNewStatus,String sCommentValue){
        getTransaction().postChanges();
        setJobCodeNotifStatus(getRacaJobCodeNotifView().getCurrentRow(),sCn,sOldStatus,sNewStatus,sCommentValue);
    }

    /**
     * setJobCodeNotifStatus
     * @param row
     * @param sCn
     * @param sOldStatus
     * @param sNewStatus
     * @param sCommentValue
     */
    private void setJobCodeNotifStatus(Row row,String sCn,String sOldStatus,String sNewStatus,String sCommentValue){
        RacaJobCodeNotifViewRowImpl rowJCNotif=(RacaJobCodeNotifViewRowImpl)row;

        // add new status
        RacaJCNotifStatusesViewRowImpl rowStatus=
            (RacaJCNotifStatusesViewRowImpl)getRacaJCNotifStatusesView().createRow();
        rowStatus.setJobCodeNotifCn(rowJCNotif.getCn());
        rowStatus.setStatusCode(sNewStatus);
        rowStatus.setComments(sCommentValue);
        getRacaJCNotifStatusesView().insertRow(rowStatus);

        // Update status column
        rowJCNotif.setStatus(sNewStatus);
        try{
            getDBTransaction().postChanges();
            getDBTransaction().getRootApplicationModule().sync();
        } catch(Exception e){
           log.debug("setJobCodeNotifStatus: "+e.getMessage());
            //e.printStackTrace();
        }

        if(log.isDebugEnabled()){
           log.debug("setJobCodeNotifStatus:sNewStatus "+sNewStatus);
        }
    }

    /**
     * isCollectionTypeEmpty
     * @return
     */
    public boolean isCollectionTypeEmpty(){
        boolean             ret    =false;
        RacaReqsViewRowImpl rowReq =(RacaReqsViewRowImpl)getRacaReqsView().getCurrentRow();
        RacaAgmtViewRowImpl rowAgmt=(RacaAgmtViewRowImpl)rowReq.getRacaAgmtView();
       log.debug("rowAgmt.getCollectionType(): "+rowAgmt.getCollectionType());
        if(rowAgmt.getCollectionType()==null){
            ret=true;
        }
        return ret;
    }

    /**
     * isAssessOverheadDocumented
     * @return
     */
    public boolean isAssessOverheadDocumented(){
        boolean             ret    =true;
        RacaReqsViewRowImpl rowReq =(RacaReqsViewRowImpl)getRacaReqsView().getCurrentRow();
        RacaAgmtViewRowImpl rowAgmt=(RacaAgmtViewRowImpl)rowReq.getRacaAgmtView();
       log.debug("rowAgmt.getAssessOverheadDocumented(): "+rowAgmt.getAssessOverheadDocumented());
        if(!"Yes".equalsIgnoreCase(rowAgmt.getAssessOverheadDocumented())){
            ret=false;
        }
        return ret;
    }

    /**
     * calculateCoopCashContribution
     * @param row
     * @param currentBFYAmount
     */
    public void calculateCoopCashContribution(Row row,Number currentBFYAmount){
       log.debug("calculateCoopCashContribution:begin "+currentBFYAmount);
        RacaAgmtViewRowImpl rowAgmt=(RacaAgmtViewRowImpl)row;
        if(rowAgmt!=null&&currentBFYAmount!=null){
           log.debug("rowAgmt.getCooperatorCashContribution() "+rowAgmt.getCooperatorCashContribution());
            if(rowAgmt.getCooperatorCashContribution()==null)
                rowAgmt.setCooperatorCashContribution(currentBFYAmount);
            else
                rowAgmt.setCooperatorCashContribution(rowAgmt.getCooperatorCashContribution().add(currentBFYAmount));

           log.debug("rowAgmt.getCooperatorCashContribution() "+rowAgmt.getCooperatorCashContribution());
        }
    }

    /**
     * getCurrentDateAsString
     * @return
     */
    public static String getCurrentDateAsString(){
        SimpleDateFormat sdf =new SimpleDateFormat("MM/dd/yyyy");
        java.util.Date   dNow=new java.util.Date();
        return sdf.format(dNow);
    }

    //    /**
    //     * getRacaReqEmailBody
    //     * @param subject
    //     * @param emailText
    //     * @param comments
    //     * @return
    //     */
    //    public String getRacaReqEmailBody(String subject, String emailText, String comments)
    //    {
    //        String body = null;
    //        String sCRLF = "<BR>";
    //
    //        String currentDate = getCurrentDateAsString();
    //
    //        RacaAgmtViewRowImpl agmtRow = (RacaAgmtViewRowImpl)getRacaAgmtView().getCurrentRow();
    //        String AgreementType = agmtRow.getObjName();
    //        String AgreementNo = agmtRow.getId();
    //        String AgreementTitle =  agmtRow.getProjectTitle();
    //
    //        RacaReqsViewRowImpl racaReqRow = (RacaReqsViewRowImpl)getRacaReqsView().getCurrentRow();
    //        String RacaRequestNo =  racaReqRow.getRacaReqNo().toString();
    //        String Comments = emailText + " " + comments;
    //
    //        String bodyHeader  = "<body>" +
    //          "<p><b> " + subject + " </b></p>" +
    //          "<table border='0' cellpadding='2' cellspacing='0' style='border-collapse: collapse' bordercolor='#111111' width='100%' id='AutoNumber1'>";
    //        String startLabel  =  "<tr><td width='21%'>";
    //        String endLabel    =  "</td>";
    //        String startField  =  "<td width='79%'><b>";
    //        String endField    =  "</b></td></tr>";
    //        String bodyFooter  =  "</table>" +
    //          "<BR><BR><BR>This is an automated message, please do not reply to sender.<BR>This email address is not monitored. </p>" +
    //          "</body>";
    //        String bodyMain    = startLabel + "Date:"  + endLabel + startField + currentDate + endField +
    //                           startLabel + "Project Title:"  + endLabel + startField + AgreementTitle + endField +
    //                           startLabel + "Agreement Type:"  + endLabel + startField + AgreementType + endField +
    //                           startLabel + "Agreement Number:"  + endLabel + startField + AgreementNo + endField +
    //                           startLabel + "RACA Request Number:"  + endLabel + startField + RacaRequestNo + endField +
    //                           startLabel + "Comments:"  + endLabel + startField + Comments + endField;
    //        body = bodyHeader + bodyMain + bodyFooter;
    //        return body;
    //    }

    /**
     * getRacaEmailBody
     * @param subject
     * @param emailText
     * @param comments
     * @param emailType
     * @return
     */
    public String getRacaEmailBody(String subject,String emailText,String comments,String emailType){
        String body         =null;
        String sCRLF        ="<BR>";
        String RacaRequestNo=null;

        String                    RacaJobCodeNo=null;
        String                    raJobCodeCN  =null;
        RacaJobCodeNotifLinesImpl currRow;

        String currentDate=getCurrentDateAsString();


        RacaAgmtViewRowImpl agmtRow=(RacaAgmtViewRowImpl)getRacaAgmtView().getCurrentRow();

        // String codeCn =   (getRacaJobCodeNotifView()).getCurrentRow().;

        // getRacaService().executeViewQuery("RacaJobCodeNotifView");
        // RacaJobCodeNotifViewRowImpl rowJCNotif =  (RacaJobCodeNotifViewRowImpl)row;


        RacaJobCodeNotifViewRowImpl jobCodeNotifRow=
            (RacaJobCodeNotifViewRowImpl)getRacaJobCodeNotifView().getCurrentRow();


        if(jobCodeNotifRow!=null){
            raJobCodeCN=jobCodeNotifRow.getCn();
             log.debug("Inside GetRacaEmailBody = raJobCodeCN = "+raJobCodeCN);
        }
        /*
         RowIterator rowIter = jobCodeNotifRow.getRacaJobCodeNotif().getRacaJobCodeNotifLines();
         int r =0;
         while (rowIter.hasNext()){
         r++;
           RacaJobCodeNotifLinesImpl rowLine = (RacaJobCodeNotifLinesImpl)rowIter.next();
            log.debug( " Row = "+ r+"; CN= " +rowLine.getCn() + " JobCode = " + rowLine.getJobCode());
         }
          log.debug( "Rows = "+ r);
         */

        if(jobCodeNotifRow!=null){
            currRow=
                (RacaJobCodeNotifLinesImpl)(jobCodeNotifRow.getRacaJobCodeNotif().getRacaJobCodeNotifLines().next());
            RacaJobCodeNo=currRow.getJobCode();
             log.debug(" New JOB Code CN= "+currRow.getCn()+" JobCode = "+currRow.getJobCode());
        }


        String AgreementType =agmtRow.getObjName();
        String AgreementNo   =agmtRow.getId();
        String AgreementTitle=agmtRow.getProjectTitle();
        String Comments      =emailText; // footer from dialog window
        if(comments!=null)
            Comments=Comments+"<BR> "+comments; //comments from dialog window

        if(emailType.equalsIgnoreCase("REQUEST")){
             log.debug(" If email type is REQUEST ");
            RacaReqsViewRowImpl racaReqRow=(RacaReqsViewRowImpl)getRacaReqsView().getCurrentRow();
            RacaRequestNo=racaReqRow.getRacaReqNo().toString();

            // RacaJobCodeNo = racaReqRow.getJobCodes();
            //  log.debug(" RACA JOBCODE = "+ RacaJobCodeNo);

        }

        String bodyHeader=
            "<body>"+"<p><b> "+subject+" </b></p>"+
            "<table border='0' cellpadding='2' cellspacing='0' style='border-collapse: collapse' bordercolor='#111111' width='100%' id='AutoNumber1'>";
        String startLabel="<tr><td width='21%'>";
        String endLabel  ="</td>";
        String startField="<td width='79%'><b>";
        String endField  ="</b></td></tr>";
        String bodyFooter=
            "</table>"+
            "<BR><BR><BR>This is an automated message, please do not reply to sender.<BR>This email address is not monitored. </p>"+
            "</body>";
        String bodyMain=
            startLabel+"Date:"+endLabel+startField+currentDate+endField+startLabel+"Project Title:"+endLabel+startField+
            AgreementTitle+endField+startLabel+"Agreement Type:"+endLabel+startField+AgreementType+endField+startLabel+
            "Agreement Number:"+endLabel+startField+AgreementNo+endField;

        if(emailType.equalsIgnoreCase("REQUEST")){
            bodyMain=bodyMain+startLabel+"RACA Request Number:"+endLabel+startField+RacaRequestNo+endField;
            bodyMain=bodyMain+startLabel+"RACA JOBCODE Number:"+endLabel+startField+RacaJobCodeNo+endField;
        }

        bodyMain=bodyMain+startLabel+"Comments:"+endLabel+startField+Comments+endField;
        body=bodyHeader+bodyMain+bodyFooter;
        return body;
    }

    /**
     * sendRacaReqEmail
     * @param from
     * @param to
     * @param subject
     * @param message
     * @param comments
     */
    //    public void sendRacaReqEmail(String from, String to, String subject, String message, String comments){
    //        RacaReqsViewRowImpl racaReqRow = (RacaReqsViewRowImpl)getRacaReqsView().getCurrentRow();
    //        if (racaReqRow != null)
    //            sendEmail(from, to, subject, getRacaEmailBody(subject, message, comments, "REQUEST"), "II_RACA_REQS", racaReqRow.getCn());
    //    }
    public void sendRacaReqEmail(String from,String to,String subject,String message,String comments,String type,
                                 String racareqcn){
        RacaAgmtViewRowImpl         agmtRow        =(RacaAgmtViewRowImpl)getRacaAgmtView().getCurrentRow();
        String                      agmtcn         =agmtRow.getCn();
        RacaJobCodeNotifViewRowImpl jobCodeNotifRow=
            (RacaJobCodeNotifViewRowImpl)getRacaJobCodeNotifView().getCurrentRow();
        String raJobCodeCN=null;
        if(jobCodeNotifRow!=null){
            raJobCodeCN=jobCodeNotifRow.getCn();
        }


        if("cmdActive".equalsIgnoreCase(type)){
            sendEmailActiveRequest(to,comments,agmtcn,racareqcn);
        } else if("cmdRejected".equalsIgnoreCase(type)){
            sendEmailRejectedRequest(to,comments,agmtcn,racareqcn);
        } else {
            sendEmailPacRequest(to,"REQUEST",comments,racareqcn,agmtcn,raJobCodeCN);
        }
    }

    private void sendEmailRejectedRequest(String to,String comments,String raca_agmt_cn,String raca_req_cn){
       log.debug("Send sendEmailPacRequest ***");
        CallableStatement stmt=
            ((DBTransaction)getTransaction()).createCallableStatement("begin FSDBA.II_GA_RACA_NOTIFICATIONS.RACA_REQUEST_REJECTED(?, ?, ?, ?); end;",
                                                                      -1);
        try{
            stmt.setString(1,to);
            stmt.setString(2,comments);
            stmt.setString(3,raca_agmt_cn);
            stmt.setString(4,raca_req_cn);

            stmt.execute();

            stmt.close();
        } catch(SQLException e){
        //   log.debug("sedRacaReqEmails",e);
            //e.printStackTrace();
        }
    }


    private void sendEmailActiveRequest(String to,String comments,String raca_agmt_cn,String raca_req_cn){
       log.debug("Send sendEmailPacRequest ***");
        CallableStatement stmt=
            ((DBTransaction)getTransaction()).createCallableStatement("begin FSDBA.II_GA_RACA_NOTIFICATIONS.RACA_REQUEST_ACTIVATED (?, ?, ?, ?); end;",
                                                                      -1);
        try{
            stmt.setString(1,to);
            stmt.setString(2,comments);
            stmt.setString(3,raca_agmt_cn);
            stmt.setString(4,raca_req_cn);

            stmt.execute();

            stmt.close();
        } catch(SQLException e){
          // log.debug("sendEmailActiveRequest",e);
            // e.printStackTrace();
        }
    }

    /**
     * sendRacaAgmtEmail
     * @param from
     * @param to
     * @param subject
     * @param message
     * @param comments
     */
    //    public void sendRacaAgmtEmail(String from, String to, String subject, String message, String comments){
    //        RacaAgmtViewRowImpl agmtRow = (RacaAgmtViewRowImpl)getRacaAgmtView().getCurrentRow();
    //        if (agmtRow != null)
    //            sendEmail(from, to, subject, getRacaEmailBody(subject, message, comments, "AGREEMENT"), "II_ACCOMPLISHMENT_INSTRUMENTS", agmtRow.getCn());
    //    }
    public void sendRacaAgmtEmail(String from,String to,String subject,String message,String comments,String type){
        RacaAgmtViewRowImpl agmtRow=(RacaAgmtViewRowImpl)getRacaAgmtView().getCurrentRow();
        String              temp   =System.getProperty("line.separator");
        if(agmtRow!=
           null){
            //RacaReqsViewRowImpl racaReqRow = (RacaReqsViewRowImpl)getRacaReqsView().getCurrentRow();
            //String reqCn = racaReqRow.getCn();
            RacaJobCodeNotifViewRowImpl jobCodeNotifRow=
       (RacaJobCodeNotifViewRowImpl)getRacaJobCodeNotifView().getCurrentRow();
            String raJobCodeCN=null;
            if(jobCodeNotifRow!=null){
                raJobCodeCN=jobCodeNotifRow.getCn();
            }
            if((type.equalsIgnoreCase("cmdClosed"))||(type.equalsIgnoreCase("cmdCustClosed"))){
                sendEmailClose(to,comments,agmtRow.getCn());
            } else {
                sendEmailPacAgreement(to,"AGREEMENT",comments,null,agmtRow.getCn(),raJobCodeCN);
            }
        }
    }

    private void sendEmailClose(String to,String comments,String raca_agmt_cn){
       log.debug("Send sendEmailPacAgreement ***");

        CallableStatement stmt=
            ((DBTransaction)getTransaction()).createCallableStatement("begin fsdba.II_GA_RACA_NOTIFICATIONS.RACA_CLOSED(?, ?, ?); end;",
                                                                      DBTransaction.DEFAULT);
        try{
            stmt.setString(1,to);
            stmt.setString(2,comments);
            stmt.setString(3,raca_agmt_cn);
            stmt.execute();

            stmt.close();
        } catch(SQLException e){
          // log.debug("SendEmailClosing",e);
            //e.printStackTrace();
        }
    }


    /**
     * sendJobCodeNotifEmail
     * @param from
     * @param to
     * @param subject
     * @param message
     * @param comments
     */
    public void sendJobCodeNotifEmail(String from,String to,String subject,String message,String comments){
        RacaJobCodeNotifViewRowImpl jobCodeNotifRow=
            (RacaJobCodeNotifViewRowImpl)getRacaJobCodeNotifView().getCurrentRow();
        if(jobCodeNotifRow!=null)
            sendEmail(from,to,subject,getRacaEmailBody(subject,message,comments,"JOBCODE_NOTIF"),
                      "II_RACA_JOB_CODE_NOTIF",jobCodeNotifRow.getCn());
    }
    // 5/11/15 Duk added
    //public void sendEmailPro(String from, String to, String subject, String message, String tableName, String tableNameCn)
    public void sendEmailPro(String to,String type,String comments,String raca_req_cn,String raca_agmt_cn,
                             String raca_job_codeNotifView_cn){
       log.debug("Send Email ***");
        //log.debug(from+":"+to+":"+message+":"+tableName+":"+tableNameCn);

        CallableStatement stmt=((DBTransaction)getTransaction()).createCallableStatement(
            //"begin fsdba.send_II_GA_RACA_Email (?, ?, ?, ?, ?, ?); end;", DBTransaction.DEFAULT);
            "begin fsdba.send_II_GA_RACA_Email (?, ?, ?, ?, ?, ?); end;",DBTransaction.DEFAULT);
        try{
            stmt.setString(1,to);
            stmt.setString(2,type);
            stmt.setString(3,comments);
            stmt.setString(4,raca_req_cn);
            stmt.setString(5,raca_agmt_cn);
            stmt.setString(6,raca_job_codeNotifView_cn);
            stmt.execute();
            getTransaction().commit();
            stmt.close();
        } catch(SQLException e){
         //  log.debug("SendJobCodentificationEmail",e);
            //            e.printStackTrace();
        }
    }

    public void sendEmailPacAgreement(String to,String type,String comments,String raca_req_cn,String raca_agmt_cn,
                                      String raca_job_codeNotifView_cn){
       log.debug("Send sendEmailPacAgreement ***");

        CallableStatement stmt=
            ((DBTransaction)getTransaction()).createCallableStatement("begin fsdba.II_GA_RACA_NOTIFICATIONS.RACA_AGREEMENT (?, ?, ?); end;",
                                                                      DBTransaction.DEFAULT);
        try{
            stmt.setString(1,to);
            stmt.setString(2,comments);
            stmt.setString(3,raca_agmt_cn);
            stmt.execute();
            getTransaction().commit();
            stmt.close();
        } catch(SQLException e){
          // log.debug("SendEmailPacAgreement",e);
            // e.printStackTrace();
        }
    }

    public void sendEmailPacRequest(String to,String type,String comments,String raca_req_cn,String raca_agmt_cn,
                                    String raca_job_codeNotifView_cn){
       log.debug("Send sendEmailPacRequest ***");
        CallableStatement stmt=
            ((DBTransaction)getTransaction()).createCallableStatement("begin FSDBA.II_GA_RACA_NOTIFICATIONS.RACA_REQUEST (?, ?, ?, ?, ?); end;",
                                                                      DBTransaction.DEFAULT);
        try{
            stmt.setString(1,to);
            stmt.setString(2,comments);
            stmt.setString(3,raca_agmt_cn);
            stmt.setString(4,raca_req_cn);
            stmt.setString(5,raca_job_codeNotifView_cn);
            stmt.execute();
            getTransaction().commit();
            stmt.close();
        } catch(SQLException e){
         //  log.debug("SendEmailPacRequest",e);
            // e.printStackTrace();
        }
    }

    /**
     * sendEmail
     * @param from
     * @param to
     * @param subject
     * @param message
     * @param tableName
     * @param tableNameCn
     */
    public void sendEmail(String from,String to,String subject,String message,String tableName,String tableNameCn){
        if(log.isDebugEnabled()){
           log.debug("Send Email ***");
           log.debug(from+":"+to+":"+message+":"+tableName+":"+tableNameCn);
        }

        try{
            Row row=getEmailsView().createRow();
            row.setAttribute("Recipient",to);
            row.setAttribute("Sender",from);
            row.setAttribute("Subject",subject);
            row.setAttribute("Body",message);
            row.setAttribute("Status","PENDING");
            row.setAttribute("Module","RACA");
            row.setAttribute("TableName",tableName);
            row.setAttribute("TableNameCn",tableNameCn);
            getEmailsView().insertRow(row);
        } catch(Exception e){
           log.debug("Send Email Warning dup email - "+e.getMessage());
            //e.printStackTrace();
        }
    }

    /**Sample main for debugging Business Components code using the tester.
     */
    public static void main(String[] args){
        launchTester("gov.usda.fs.nrm.gacommon.model.service", /* package name */
                     "RacaServiceLocal" /* Configuration Name */);
    }

    /**Container's getter for GrantView
     */
    public GrantViewImpl getGrantView(){
        return (GrantViewImpl)findViewObject("GrantView");
    }

    /**Container's getter for AccInstrumentsView
     */
    public AccInstrumentsViewImpl getAccInstrumentsView(){
        return (AccInstrumentsViewImpl)findViewObject("AccInstrumentsView");
    }


    public void setAppVersion(String appVersion){
        this.appVersion=appVersion;
    }

    public String getAppVersion(){
        return appVersion;
    }

    /**
     * createAI
     */
    public void createAI(){
        AccInstrumentsViewRowImpl aiRow=(AccInstrumentsViewRowImpl)getAccInstrumentsView().createRow();
        //aiRow.setId("NEW");
        //aiRow.setSecurityId("XXXX");
        //aiRow.setObjName("RACA");
        getAccInstrumentsView().insertRow(aiRow);
    }

    /**
     * setAICurrentRowByCn
     * @param Cn
     */
    public void setAICurrentRowByCn(String Cn){
        //        ViewCriteria vc = getAccInstrumentsView().createViewCriteria();
        //        ViewCriteriaRow row = vc.createViewCriteriaRow();
        //        row.setAttribute("Cn", "= '" + Cn.trim() + "'");
        //        vc.addElement(row);
        //        getAccInstrumentsView().applyViewCriteria(vc);
        //        getAccInstrumentsView().executeQuery();
        //        AccInstrumentsViewRowImpl aiRow = (AccInstrumentsViewRowImpl)getAccInstrumentsView().getCurrentRow();
        //       log.debug("setAICurrentRowByCn:aiRow.getId" + aiRow.getId());
        //        getAccInstrumentsView().setCurrentRow(aiRow);

        getAccInstrumentsView().setWhereClause("CN='"+Cn.trim()+"'");
        getAccInstrumentsView().executeQuery();
        AccInstrumentsViewRowImpl aiRow=(AccInstrumentsViewRowImpl)getAccInstrumentsView().first();
       log.debug("setAICurrentRowByCn:aiRow.getId"+aiRow.getId());
        getAccInstrumentsView().setCurrentRow(aiRow);

        getRacaReqsView().clearCache();
        getRacaReqsView().executeQuery();
    }

    //     Not used anymore, Missing IN or OUT parameter.
    //    /**
    //     * validBudgetOrg
    //     * @param value
    //     * @return
    //     */
    //    public boolean validBudgetOrg(String value)
    //    {
    //        boolean retValue = true;
    //        ViewCriteria vc = getLovBudgetOrg().createViewCriteria();
    //        ViewCriteriaRow rowCrt = vc.createViewCriteriaRow();
    //        rowCrt.setAttribute("BudgetOrgCode", value);
    //        vc.addElement(rowCrt);
    //        getLovBudgetOrg().applyViewCriteria(vc);
    //        getLovBudgetOrg().executeQuery();
    //        Row row = getLovBudgetOrg().first();
    //        if (row == null)
    //            retValue = false;
    //        else
    //            retValue = true;
    //
    //        vc.clear();
    //        getLovBudgetOrg().clearViewCriterias();
    //        getLovBudgetOrg().executeQuery();
    //        return retValue;
    //    }

    /**
     * getEmailAddressByQuery
     * @param type
     * @return
     */
    public String getEmailAddressByQuery(String type){
        String emailAddress=null;

        Row    racaAgmtRow=getRacaAgmtView().getCurrentRow();
        String racaAgmtCn =(String)racaAgmtRow.getAttribute("Cn");

        String sqlEmailAddress=
            "select ELECTRONIC_ADDRESS, l.accinst_cn "+"from ii_addresses a, ii_contacts c, ii_accinst_cont_links l "+
            "where a.cont_cn = c.cn "+"and  c.cn = l.cont_cn "+"and l.accinst_cn = '"+racaAgmtCn+"' "+
            " and  a.program_area='GA'"+"and l.link_sub_type = '"+type+"' ";

        ViewObject     emailAddressView=getDBTransaction().createViewObjectFromQueryStmt(sqlEmailAddress);
        RowSetIterator emailAddressIter=emailAddressView.createRowSetIterator(null);
        Row            emailAddressRow =null;

        if(emailAddressIter.hasNext()){
            emailAddressRow=emailAddressIter.next();
            if(emailAddressRow!=null)
                emailAddress=(String)emailAddressRow.getAttribute("ELECTRONIC_ADDRESS");
        }
        emailAddressView.remove();
        return emailAddress;
    }

    /**
     * getEmailAddress
     * @param type
     * @return
     */
    public String getEmailAddress(String type){
        if("REVIEW".equals(type))
            return getEmailAddressByQuery("RW");
        else if("BUDGET".equals(type))
            return getEmailAddressByQuery("BA");
        else if("PA".equals("PA")||"PRC".equals("PRC")||"RAC".equals("RAC")||"GAT".equals("GAT"))
            return getEmailAddressByQuery(type);
        else
            return null;
    }

    /**Container's getter for LovBillingOptions
     */
    public LovBillingOptionsImpl getLovBillingOptions(){
        return (LovBillingOptionsImpl)findViewObject("LovBillingOptions");
    }

    /**Container's getter for LovBranchHandling
     */
    public LovBranchHandlingImpl getLovBranchHandling(){
        return (LovBranchHandlingImpl)findViewObject("LovBranchHandling");
    }

    /**Container's getter for LovCollectionType
     */
    public LovCollectionTypeImpl getLovCollectionType(){
        return (LovCollectionTypeImpl)findViewObject("LovCollectionType");
    }

    /**Container's getter for LovTransPurpose
     */
    public LovTransPurposeImpl getLovTransPurpose(){
        return (LovTransPurposeImpl)findViewObject("LovTransPurpose");
    }

    /**Container's getter for LovFund
     */
    public LovFundImpl getLovFund(){
        return (LovFundImpl)findViewObject("LovFund");
    }


    /**Container's getter for LovProgram
     */
    public LovProgramImpl getLovProgram(){
        return (LovProgramImpl)findViewObject("LovProgram");
    }


    /**Container's getter for EmailsView
     */
    public EmailsViewImpl getEmailsView(){
        return (EmailsViewImpl)findViewObject("EmailsView");
    }


    /**Container's getter for ReportServer
     */
    public ReportServerImpl getReportServer(){
        return (ReportServerImpl)findViewObject("ReportServer");
    }


    /**Container's getter for RacaAgmtView
     */
    public RacaAgmtViewImpl getRacaAgmtView(){
        return (RacaAgmtViewImpl)findViewObject("RacaAgmtView");
    }

    /**Container's getter for RacaReqsView
     */
    public RacaReqsViewImpl getRacaReqsView(){
        return (RacaReqsViewImpl)findViewObject("RacaReqsView");
    }


    /**Container's getter for RacaReqStatusesView
     */
    public RacaReqStatusesViewImpl getRacaReqStatusesView(){
        return (RacaReqStatusesViewImpl)findViewObject("RacaReqStatusesView");
    }

    /**Container's getter for RacaAgmtRacaReqsLk1
     */
    public ViewLinkImpl getRacaAgmtRacaReqsLk1(){
        return (ViewLinkImpl)findViewLink("RacaAgmtRacaReqsLk1");
    }


    /**Container's getter for RacaReqsRacaReqStatusesLk1
     */
    public ViewLinkImpl getRacaReqsRacaReqStatusesLk1(){
        return (ViewLinkImpl)findViewLink("RacaReqsRacaReqStatusesLk1");
    }

    /**Container's getter for RacaAgmtStatusesView
     */
    public RacaAgmtStatusesViewImpl getRacaAgmtStatusesView(){
        return (RacaAgmtStatusesViewImpl)findViewObject("RacaAgmtStatusesView");
    }

    /**Container's getter for RacaAgmtRacaAgmtStatusesLk1
     */
    public ViewLinkImpl getRacaAgmtRacaAgmtStatusesLk1(){
        return (ViewLinkImpl)findViewLink("RacaAgmtRacaAgmtStatusesLk1");
    }


    /**Container's getter for ContactsLinksView
     */
    public ContactsLinksViewImpl getContactsLinksView(){
        return (ContactsLinksViewImpl)findViewObject("ContactsLinksView");
    }

    /**Container's getter for CooperatorsLinksView
     */
    public CooperatorsLinksViewImpl getCooperatorsLinksView(){
        return (CooperatorsLinksViewImpl)findViewObject("CooperatorsLinksView");
    }

    /**Container's getter for RacaAgmtContactsLinksLk1
     */
    public ViewLinkImpl getRacaAgmtContactsLinksLk1(){
        return (ViewLinkImpl)findViewLink("RacaAgmtContactsLinksLk1");
    }

    /**Container's getter for RacaAgmtCooperatorsLinksLk1
     */
    public ViewLinkImpl getRacaAgmtCooperatorsLinksLk1(){
        return (ViewLinkImpl)findViewLink("RacaAgmtCooperatorsLinksLk1");
    }

    /**Container's getter for ContactAddressesView
     */
    public AddressesViewImpl getContactAddressesView(){
        return (AddressesViewImpl)findViewObject("ContactAddressesView");
    }

    /**Container's getter for ContactPhonesView
     */
    public PhoneNumbersViewImpl getContactPhonesView(){
        return (PhoneNumbersViewImpl)findViewObject("ContactPhonesView");
    }

    /**Container's getter for CooperatorAddressesView
     */
    public AddressesViewImpl getCooperatorAddressesView(){
        return (AddressesViewImpl)findViewObject("CooperatorAddressesView");
    }

    /**Container's getter for CooperatorPhoneNumbersView
     */
    public PhoneNumbersViewImpl getCooperatorPhoneNumbersView(){
        return (PhoneNumbersViewImpl)findViewObject("CooperatorPhoneNumbersView");
    }

    /**Container's getter for LovFFISVendors
     */
    public LovFFISVendorsImpl getLovFFISVendors(){
        return (LovFFISVendorsImpl)findViewObject("LovFFISVendors");
    }

    /**Container's getter for ContactsLinksAddressesLk1
     */
    public ViewLinkImpl getContactsLinksAddressesLk1(){
        return (ViewLinkImpl)findViewLink("ContactsLinksAddressesLk1");
    }

    /**Container's getter for ContactsLinksPhoneNumbersLk1
     */
    public ViewLinkImpl getContactsLinksPhoneNumbersLk1(){
        return (ViewLinkImpl)findViewLink("ContactsLinksPhoneNumbersLk1");
    }

    /**Container's getter for CooperatorsLinksAddressesLk1
     */
    public ViewLinkImpl getCooperatorsLinksAddressesLk1(){
        return (ViewLinkImpl)findViewLink("CooperatorsLinksAddressesLk1");
    }

    /**Container's getter for CooperatorsLinksPhoneNumbersLk1
     */
    public ViewLinkImpl getCooperatorsLinksPhoneNumbersLk1(){
        return (ViewLinkImpl)findViewLink("CooperatorsLinksPhoneNumbersLk1");
    }

    /**Container's getter for CooperatorLinksFFISVendorFilterLk1
     */
    public ViewLinkImpl getCooperatorLinksFFISVendorFilterLk1(){
        return (ViewLinkImpl)findViewLink("CooperatorLinksFFISVendorFilterLk1");
    }

    /**Container's getter for RacaSpecBillingReqView
     */
    public RacaSpecBillingReqViewImpl getRacaSpecBillingReqView(){
        return (RacaSpecBillingReqViewImpl)findViewObject("RacaSpecBillingReqView");
    }

    /**Container's getter for RacaAgmtRacaSpecBillingReqLk1
     */
    public ViewLinkImpl getRacaAgmtRacaSpecBillingReqLk1(){
        return (ViewLinkImpl)findViewLink("RacaAgmtRacaSpecBillingReqLk1");
    }

    /**Container's getter for LovSUDSAgmts
     */
    public LovSUDSAgmtsImpl getLovSUDSAgmts(){
        return (LovSUDSAgmtsImpl)findViewObject("LovSUDSAgmts");
    }

    /**Container's getter for GaSummaryTabView
     */
    public GaSummaryTabViewImpl getGaSummaryTabView(){
        return (GaSummaryTabViewImpl)findViewObject("GaSummaryTabView");
    }

    /**Container's getter for GrantGaSummaryLk1
     */
    public ViewLinkImpl getGrantGaSummaryLk1(){
        return (ViewLinkImpl)findViewLink("GrantGaSummaryLk1");
    }

    /**Container's getter for LovBudgetOrg
     */
    public LovBudgetOrgImpl getLovBudgetOrg(){
        return (LovBudgetOrgImpl)findViewObject("LovBudgetOrg");
    }


    /**Container's getter for HelpURLView
     */
    public HelpURLViewImpl getHelpURLView(){
        return (HelpURLViewImpl)findViewObject("HelpURLView");
    }

    /**Container's getter for RacaJobCodeNotifView
     */
    public RacaJobCodeNotifViewImpl getRacaJobCodeNotifView(){
        return (RacaJobCodeNotifViewImpl)findViewObject("RacaJobCodeNotifView");
    }

    /**Container's getter for RacaJobCodeNotifLinesView
     */
    public RacaJobCodeNotifLinesViewImpl getRacaJobCodeNotifLinesView(){
        return (RacaJobCodeNotifLinesViewImpl)findViewObject("RacaJobCodeNotifLinesView");
    }

    /**Container's getter for RacaReqsJobCodeNotifLk1
     */
    public ViewLinkImpl getRacaReqsJobCodeNotifLk1(){
        return (ViewLinkImpl)findViewLink("RacaReqsJobCodeNotifLk1");
    }

    /**Container's getter for RacaJobCodeNotifJCNLinesLk1
     */
    public ViewLinkImpl getRacaJobCodeNotifJCNLinesLk1(){
        return (ViewLinkImpl)findViewLink("RacaJobCodeNotifJCNLinesLk1");
    }

    /**Container's getter for RacaJCNotifStatusesView
     */
    public RacaJCNotifStatusesViewImpl getRacaJCNotifStatusesView(){
        return (RacaJCNotifStatusesViewImpl)findViewObject("RacaJCNotifStatusesView");
    }

    /**Container's getter for RacaJobCodeNotifJCNStLk1
     */
    public ViewLinkImpl getRacaJobCodeNotifJCNStLk1(){
        return (ViewLinkImpl)findViewLink("RacaJobCodeNotifJCNStLk1");
    }

    /**Container's getter for LovJobCodeSource
     */
    public LovJobCodeSourceImpl getLovJobCodeSource(){
        return (LovJobCodeSourceImpl)findViewObject("LovJobCodeSource");
    }

    /**Container's getter for LovJobCodeFundType
     */
    public LovJobCodeFundTypeImpl getLovJobCodeFundType(){
        return (LovJobCodeFundTypeImpl)findViewObject("LovJobCodeFundType");
    }

    /**Container's getter for RacaBillsView
     */
    public RacaBillsViewImpl getRacaBillsView(){
        return (RacaBillsViewImpl)findViewObject("RacaBillsView");
    }

    /**Container's getter for RacaBillLinesView
     */
    public RacaBillLinesViewImpl getRacaBillLinesView(){
        return (RacaBillLinesViewImpl)findViewObject("RacaBillLinesView");
    }

    /**Container's getter for RacaBillTextLinesView
     */
    public RacaBillTextLinesViewImpl getRacaBillTextLinesView(){
        return (RacaBillTextLinesViewImpl)findViewObject("RacaBillTextLinesView");
    }

    /**Container's getter for RacaBillsRacaAgmtLk1
     */
    public ViewLinkImpl getRacaBillsRacaAgmtLk1(){
        return (ViewLinkImpl)findViewLink("RacaBillsRacaAgmtLk1");
    }

    /**Container's getter for RacaBillsRacaBillLinesLk1
     */
    public ViewLinkImpl getRacaBillsRacaBillLinesLk1(){
        return (ViewLinkImpl)findViewLink("RacaBillsRacaBillLinesLk1");
    }

    /**Container's getter for RacaBillsRacaBillTextLinesLk1
     */
    public ViewLinkImpl getRacaBillsRacaBillTextLinesLk1(){
        return (ViewLinkImpl)findViewLink("RacaBillsRacaBillTextLinesLk1");
    }

    /**Container's getter for RacaCloseoutReasonsView
     */
    public RacaCloseoutReasonsViewImpl getRacaCloseoutReasonsView(){
        return (RacaCloseoutReasonsViewImpl)findViewObject("RacaCloseoutReasonsView");
    }

    /**Container's getter for RacaClosReson2RacaAgmtFkLk1
     */
    public ViewLinkImpl getRacaClosReson2RacaAgmtFkLk1(){
        return (ViewLinkImpl)findViewLink("RacaClosReson2RacaAgmtFkLk1");
    }

    /**Container's getter for lovCloseoutReason
     */
    public lovCloseoutReasonImpl getlovCloseoutReason(){
        return (lovCloseoutReasonImpl)findViewObject("lovCloseoutReason");
    }


    /**
     * Container's getter for LovOrg1.
     * @return LovOrg1
     */
    public LovOrgImpl getLovOrg1(){
        return (LovOrgImpl)findViewObject("LovOrg1");
    }

    /**
     * Container's getter for LovOrg.
     * @return LovOrg
     */
    public LovOrgImpl getLovOrg(){
        return (LovOrgImpl)findViewObject("LovOrg");
    }

    /**
     * Container's getter for lovCloseoutReason1.
     * @return lovCloseoutReason1
     */
    public lovCloseoutReasonImpl getlovCloseoutReason1(){
        return (lovCloseoutReasonImpl)findViewObject("lovCloseoutReason1");
    }

    /**
     * Container's getter for FaadsFfataMlogSpreadView1.
     * @return FaadsFfataMlogSpreadView1
     */
    public FaadsFfataMlogSpreadViewImpl getFaadsFfataMlogSpreadView() {
        return (FaadsFfataMlogSpreadViewImpl) findViewObject("FaadsFfataMlogSpreadView");
    }

    /**
     * Container's getter for FfataMessageLogView1.
     * @return FfataMessageLogView1
     */
    public FfataMessageLogViewImpl getFfataMessageLogView() {
        return (FfataMessageLogViewImpl) findViewObject("FfataMessageLogView");
    }

    /**
     * Container's getter for LovFFISBudget1.
     * @return LovFFISBudget1
     */
    public ViewObjectImpl getLovFFISBudget1(){
        return (ViewObjectImpl)findViewObject("LovFFISBudget1");
    }


    /**
     * Container's getter for ZipcodesGeoView1.
     * @return ZipcodesGeoView1
     */
    public ZipcodesGeoViewImpl getZipcodesGeoView() {
        return (ZipcodesGeoViewImpl) findViewObject("ZipcodesGeoView");
    }


    /**
     * Container's getter for GACodesList2.
     * @return GACodesList2
     */
    public GACodesListImpl getGACodesList() {
        return (GACodesListImpl) findViewObject("GACodesList");
    }

    /**
     * Container's getter for CodesView2.
     * @return CodesView2
     */
    public CodesViewImpl getCodesView() {
        return (CodesViewImpl) findViewObject("CodesView");
    }

    /**
     * Container's getter for GaCodesFilterLk.
     * @return GaCodesFilterLk
     */
    public ViewLinkImpl getGaCodesFilterLk() {
        return (ViewLinkImpl) findViewLink("GaCodesFilterLk");
    }

    /**
     * Container's getter for CodeMappingsView1.
     * @return CodeMappingsView1
     */
    public CodeMappingsViewImpl getCodeMappingsView() {
        return (CodeMappingsViewImpl) findViewObject("CodeMappingsView");
    }

    /**
     * Container's getter for LovContacts1.
     * @return LovContacts1
     */
    public LovContactsImpl getLovContacts() {
        return (LovContactsImpl) findViewObject("LovContacts");
    }

    /**
     * Container's getter for LovOrgs1.
     * @return LovOrgs1
     */
    public LovOrgsImpl getLovOrgs() {
        return (LovOrgsImpl) findViewObject("LovOrgs");
    }

    /**
     * Container's getter for ContactGrantView1.
     * @return ContactGrantView1
     */
    public ContactGrantViewImpl getContactGrantView() {
        return (ContactGrantViewImpl) findViewObject("ContactGrantView");
    }

    /**
     * Container's getter for FilteredGrantView1.
     * @return FilteredGrantView1
     */
    public FilteredGrantViewImpl getFilteredGrantView() {
        return (FilteredGrantViewImpl) findViewObject("FilteredGrantView");
    }
    
    public boolean isNullOrEmpty(String s)
    {
      return (s == null) || (s.equals(""));
    }
    




    public void processContactReplace(String fromContCn, String toContCn, String orgCn, ArrayList grantsArray)
    {
      try
      {
        Iterator iter = grantsArray.iterator();
        while (iter.hasNext()) {
          String grantCn = (String)iter.next();
          if (grantCn != null) {
            ContactsCleanupViewRowImpl rowNewContactCleanup = (ContactsCleanupViewRowImpl)getContactsCleanupView().createRow();
            rowNewContactCleanup.setNewCn(toContCn);
            rowNewContactCleanup.setOldCn(fromContCn);
            rowNewContactCleanup.setOrgCn(orgCn);
            rowNewContactCleanup.setGrantCn(grantCn);
            rowNewContactCleanup.setGaInd("Y");
            rowNewContactCleanup.setReassignInd("Y");
            rowNewContactCleanup.setStatus("PENDING");
            getContactsCleanupView().insertRow(rowNewContactCleanup);
          }
        }
        getTransaction().commit();
      }
      catch (Exception e) {
          log.debug("ProcessContactReplace",e);   
        //e.printStackTrace();
      }
    }
    




    public void searchContacts(String id, String lastName, String firstName)
    {
      log.debug("id : " + id + ",lastName: " + lastName);
      String whereClause = "rownum<501 ";
      if (!isNullOrEmpty(id))
        whereClause = whereClause + " AND UPPER(ID) LIKE UPPER('%" + id.trim() + "%')";
      if (!isNullOrEmpty(lastName))
        whereClause = whereClause + " AND UPPER(LAST_OR_ORG_NAME) LIKE UPPER('%" + lastName.trim() + "%')";
      if (!isNullOrEmpty(firstName)) {
        whereClause = whereClause + " AND UPPER(FIRST_NAME) LIKE UPPER('%" + firstName.trim() + "%')";
      }
      if (whereClause.length() == 11) {
        whereClause = "CN = '0'";
      }
      getLovContacts().setWhereClause(whereClause);
      
      getLovContacts().executeQuery();
    }
    public void filterOrgs(String contCn)
    {
      if (!isNullOrEmpty(contCn)) {
        getLovOrgs().setNamedWhereClauseParam("contCn", contCn);
        getLovOrgs().executeQuery();
      }
    }
    



    public ArrayList filterAllListedGrants()
    {
      ArrayList grantsArray = new ArrayList();
      String listOfCns = "";
      String cn = "";
      
      Row currentRow = getContactGrantView().getCurrentRow();
      cn = (String)currentRow.getAttribute("Cn");
      log.debug("currentRow-cn: " + cn);
      listOfCns = listOfCns + "'" + cn + "'";
      grantsArray.add(cn);
      
      RowSetIterator iter = getContactGrantView().getRowSetIterator();
      log.debug("getContactGrantView().getRowCount(): " + getContactGrantView().getRowCount());
      iter.reset();
      while (iter.hasNext()) {
        ViewRowImpl row = (ViewRowImpl)iter.next();
        if (row != null) {
          cn = (String)row.getAttribute("Cn");
          
          if (listOfCns.length() > 1) {
            listOfCns = listOfCns + ", ";
          }
          listOfCns = listOfCns + "'" + cn + "'";
          grantsArray.add(cn);
        }
      }
      
      filterGrants(listOfCns);
      
      return grantsArray;
    }
    


    public void filterGrants(String sListOfCns)
    {
      if (!isNullOrEmpty(sListOfCns)) {
        getFilteredGrantView().setWhereClause("CN in (" + sListOfCns + ")");
        getFilteredGrantView().executeQuery();
      }
    }
    
    public void searchGrants(String contCn, String orgCn)
    {
      log.debug("contCn : " + contCn + ",orgCn: " + orgCn);
      if (!isNullOrEmpty(contCn)) {
        getContactGrantView().setNamedWhereClauseParam("contactCn", contCn);
      }
      if (!isNullOrEmpty(orgCn)) {
        getContactGrantView().setNamedWhereClauseParam("managingContCn", orgCn);
      }
      
      getContactGrantView().executeQuery();
    }


    /**
     * Container's getter for ContactsCleanupView1.
     * @return ContactsCleanupView1
     */
    public ContactsCleanupViewImpl getContactsCleanupView() {
        return (ContactsCleanupViewImpl) findViewObject("ContactsCleanupView");
    }

    /**
     * Container's getter for LovContSubType1.
     * @return LovContSubType1
     */
    public LovContSubTypeImpl getLovContSubType1(){
        return (LovContSubTypeImpl)findViewObject("LovContSubType1");
    }

    /**
     * Container's getter for SetNameCodeMappingLOV1.
     * @return SetNameCodeMappingLOV1
     */
    public SetNameCodeMappingLOVImpl getSetNameCodeMappingLOV() {
        return (SetNameCodeMappingLOVImpl) findViewObject("SetNameCodeMappingLOV");
    }
    public String setProcessSent() {

            try
            {          
              String stmt = "Begin ?:= fsdba.ii_ffata_to_ga.process_sent; End;";

              String rtn = callFunction(stmt);

              //callStoredProcedure(storeProc);
              // force refresh
              getDBTransaction().commit();
              return rtn;
            }
            catch (Exception e)
            {
              System.err.println("Exception on ii_ffata_to_ga.process_sent: " + e.getMessage());
              //e.printStackTrace();
            }
          
          return null;
        }
        
        public String callFunction(String stmt) {
          CallableStatement cs = null ; 
          try 
          {
            cs = getDBTransaction().createCallableStatement(stmt,0) ; 
            cs.registerOutParameter(1,Types.VARCHAR);
            cs.executeUpdate();
            return cs.getString(1) ;
          } 
          catch (SQLException e)
          {
            throw new JboException(e) ; 
          }

        }
        
        public String setProcessRejects() {

            try
            {          
              String stmt = "Begin ?:= fsdba.ii_ffata_to_ga.process_rejects; End;";

              String rtn = callFunction(stmt);

              //callStoredProcedure(storeProc);
              // force refresh
              getDBTransaction().commit();
              return rtn;
            }
            catch (Exception e)
            {
              System.err.println("Exception on ii_ffata_to_ga.process_rejects: " + e.getMessage());
              //e.printStackTrace();
            }
          
          return null;
        }

    /**
     * Container's getter for DomainNameView1.
     * @return DomainNameView1
     */
    public DomainNameViewImpl getDomainNameView1(){
        return (DomainNameViewImpl)findViewObject("DomainNameView1");
    }
}
