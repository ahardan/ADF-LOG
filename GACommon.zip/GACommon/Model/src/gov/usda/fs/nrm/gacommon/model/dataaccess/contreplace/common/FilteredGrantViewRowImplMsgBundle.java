package gov.usda.fs.iweb.contactreplace.model.dataaccess.common;

import oracle.jbo.common.JboResourceBundle;



public class FilteredGrantViewRowImplMsgBundle
  extends JboResourceBundle
{
  static final Object[][] sMessageStrings = { { "ProjCfdaNo_LABEL", "CFDA No" }, { "Expdate_FMT_FORMAT", "MM/dd/yyyy" }, { "ProjTitle_LABEL", "Project Title" }, { "AppReceivedDate_LABEL", "Received Date" }, { "FedIdRegion_LABEL", "Region" }, { "Expdate_FMT_FORMATTER", "oracle.jbo.format.DefaultDateFormatter" }, { "FedIdSubunit_LABEL", "Subunit" }, { "StatusDate_LABEL", "Status Date" }, { "Expdate_LABEL", "Exp Date" }, { "AppReceivedDate_FMT_FORMATTER", "oracle.jbo.format.DefaultDateFormatter" }, { "ApplicantName_LABEL", "Applicant Name" }, { "ApplicationId_LABEL", "Application ID" }, { "FedIdUnit_LABEL", "Unit" }, { "StatusDate_FMT_FORMAT", "MM/dd/yyyy" }, { "StatusDate_FMT_FORMATTER", "oracle.jbo.format.DefaultDateFormatter" }, { "AppReceivedDate_FMT_FORMAT", "MM/dd/yyyy" }, { "ManagingOrg_LABEL", "Org" }, { "Id_LABEL", "ID" } };
  


























  public Object[][] getContents()
  {
    return super.getMergedArray(sMessageStrings, super.getContents());
  }
}


