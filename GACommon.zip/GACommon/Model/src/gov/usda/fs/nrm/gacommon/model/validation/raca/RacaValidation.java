package gov.usda.fs.nrm.gacommon.model.validation.raca;

import gov.usda.fs.nrm.gacommon.model.entity.raca.AiRacaAgmtAppVImpl;
import gov.usda.fs.nrm.gacommon.model.entity.raca.RacaReqsImpl;

import gov.usda.fs.nrm.gacommon.model.exception.raca.RacaErrorMessages;

import gov.usda.fs.nrm.gacommon.model.service.GACommonServiceImpl;

import oracle.jbo.JboException;

import org.apache.log4j.*;

public class RacaValidation {

    private static Logger log = LogManager.getLogger(RacaValidation.class);
    
    public RacaValidation() {
    }

    /**
     * validatePRCContact
     * Called From: RacaServiceImpl.setRacaRequestStatus
     * @param racaService
     */
    public static void validatePRCContact(GACommonServiceImpl racaService){
        // BASE DEV000566 : 4.1 - G&A: Require validation of PRC at submittal of collection request       
        if (!racaService.isContactLinked("PRC")){         
                String[] params = {"Project Contact (PRC) is required before submitting a request."};
                throw new JboException(RacaErrorMessages.class,RacaErrorMessages.GENERAL_ERROR_MESSAGE,
                                       params);            
        }
    }

    /**
     * validateAssessOverheadCheckBoxes
     * Called From: AiRacaAgmtAppVImpl.validateInfraBusinesRules
     * @param racaAgmt
     */
    public static void validateAssessOverheadCheckBoxes(AiRacaAgmtAppVImpl racaAgmt){
        // validate that at least one FSH 1909.13 checkbox is checked        
        int counter = 0;
        if ("No".equalsIgnoreCase(racaAgmt.getAssessOverhead())){
            if ("Y".equalsIgnoreCase(racaAgmt.getFsh1909131a()))     counter = counter +1;
            if ("Y".equalsIgnoreCase(racaAgmt.getFsh1909131b()))     counter = counter +1;  
            //if ("Y".equalsIgnoreCase(racaAgmt.getFsh1909133()))      counter = counter +1;            

            if (counter == 0){               
                String[] params = {"Identify which criteria of FSH 1909.13, Ch 40, Sec 40.61 is applicable"};
                throw new JboException(RacaErrorMessages.class,RacaErrorMessages.GENERAL_ERROR_MESSAGE,
                                       params);            
            }
        }
    }

    /**
     * validateAssessOverheadDocumented
     * @param racaAgmt
     */
    public static void validateAssessOverheadDocumented(AiRacaAgmtAppVImpl racaAgmt){ 
        // validate that AssessOverheadDocumented is true      
        if ("No".equalsIgnoreCase(racaAgmt.getAssessOverheadDocumented())){
                String[] params = {"Decision whether or not to assessed overhead is not documented"};
                throw new JboException(RacaErrorMessages.class,RacaErrorMessages.GENERAL_ERROR_MESSAGE,
                                       params);            
        }
    }

    /**
     * validateTransmittalPurpose
     * @param req
     */
    public static void validateTransmittalPurpose(RacaReqsImpl req){
        // validate that validateTransmittalPurpose     
         if ("CLOSEOUT REQUEST".equalsIgnoreCase(req.getTransmittalPurpose()) 
            && (!"Y".equalsIgnoreCase(req.getFs6500243Attached())) ){
             String[] params = {"When CLOSEOUT REQUEST Transmittal Purpose is selected, the FS 6500-243 Check Box must be checked."};
             throw new JboException(RacaErrorMessages.class,RacaErrorMessages.GENERAL_ERROR_MESSAGE,
                                    params);            
         }
    }
}
