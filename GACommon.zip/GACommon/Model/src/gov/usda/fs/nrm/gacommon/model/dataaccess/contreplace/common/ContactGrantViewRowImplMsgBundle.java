package gov.usda.fs.iweb.contactreplace.model.dataaccess.common;

import oracle.jbo.common.JboResourceBundle;



public class ContactGrantViewRowImplMsgBundle
  extends JboResourceBundle
{
  static final Object[][] sMessageStrings = { { "contactCn_LABEL", "Contact CN" }, { "ProjCfdaNo_LABEL", "CFDA No" }, { "Expdate_FMT_FORMAT", "MM/dd/yyyy" }, { "ProjTitle_LABEL", "Project Title" }, { "FedIdRegion_LABEL", "Region" }, { "AppReceivedDate_LABEL", "Received Date" }, { "Expdate_FMT_FORMATTER", "oracle.jbo.format.DefaultDateFormatter" }, { "FedIdSubunit_LABEL", "Subunit" }, { "StatusDate_LABEL", "Status Date" }, { "Expdate_LABEL", "Exp Date" }, { "AppReceivedDate_FMT_FORMATTER", "oracle.jbo.format.DefaultDateFormatter" }, { "managingContCn_LABEL", "Managing Cont CN" }, { "ApplicantName_LABEL", "Applicant Name" }, { "ApplicationId_LABEL", "Application ID" }, { "FedIdUnit_LABEL", "Unit" }, { "StatusDate_FMT_FORMAT", "MM/dd/yyyy" }, { "StatusDate_FMT_FORMATTER", "oracle.jbo.format.DefaultDateFormatter" }, { "ManagingOrg_LABEL", "Org" }, { "AppReceivedDate_FMT_FORMAT", "MM/dd/yyyy" }, { "Id_LABEL", "ID" } };
  




























  public Object[][] getContents()
  {
    return super.getMergedArray(sMessageStrings, super.getContents());
  }
}


