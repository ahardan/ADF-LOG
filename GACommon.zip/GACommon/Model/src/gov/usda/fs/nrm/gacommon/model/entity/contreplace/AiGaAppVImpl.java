package gov.usda.fs.nrm.gacommon.model.entity.contreplace;


import gov.usda.fs.nrm.framework.model.entity.IWebEntity;

import oracle.jbo.Key;
import oracle.jbo.domain.Date;
import oracle.jbo.domain.Number;
import oracle.jbo.server.AttributeDefImpl;
import oracle.jbo.server.EntityDefImpl;
import oracle.jbo.server.EntityImpl;


public class AiGaAppVImpl
  extends IWebEntity {
    /**
     * AttributesEnum: generated enum for identifying attributes and accessors. DO NOT MODIFY.
     */
    protected enum AttributesEnum {
        Cn,
        Id,
        Name,
        ObjTech,
        ObjName,
        ObjClass,
        Description,
        ManagingContCn,
        GaCn,
        FedIdFy,
        FedIdType,
        FedIdAgency,
        FedIdRegion,
        FedIdUnit,
        FedIdSubunit,
        FedIdSeq,
        ProjTitle,
        ProjStatus,
        ApplicationId,
        ApplicationType,
        AppSubmissionType,
        AppSubmitDate,
        AppReceivedDate,
        HhsPaymentInd,
        ProposedStartDate,
        ProposedEndDate,
        ProjDesc,
        ProjReceivedDt,
        ProjExecutionDt,
        ProjStartDt,
        ProjObligationDt,
        ProjExpirationDt,
        ProjRwu,
        ProjCloseDt,
        ProjCancellationDt,
        DateMailed,
        DateSigned,
        ExtramuralInd,
        ProjCfdaNo,
        ProjScienceCd,
        ResearchType,
        FaadsPerfPlace,
        JournalInd,
        ModNumber,
        OrigFedId,
        FaadsDepartmentNo,
        FaadsAgencyCd,
        FaadsAgreementType,
        FaadsStateAppId,
        FaadsMinorityCd,
        ProjAssistType,
        Comments,
        MasterFedId,
        AopInd,
        GeoType,
        ManagingStateCounty,
        AreasEffected,
        Ffin,
        StateEoCode,
        StateEoDate,
        FedEstFund,
        ApplicantEstFund,
        StateEstFund,
        LocalEstFund,
        PiEstFund,
        OthEstFund,
        Status,
        StatusDate,
        RerouteFrom,
        RerouteDate,
        ProjectCongressionalDistrict,
        FfisDocId,
        LockedInd,
        ApplicantName,
        StateIdentifier,
        InternationalActInd,
        ProjType,
        AdvanceAllowedInd,
        SecurityId,
        Line1,
        Line2,
        Line3,
        CityName,
        County,
        StateCode,
        CountryName,
        PostalCode,
        Zip4,
        ElectronicAddress,
        Restrictions,
        AuthorityApproval,
        Authority,
        Format,
        OtherApproval;
        private static AttributesEnum[] vals = null;
        private static final int firstIndex = 0;

        protected int index() {
            return AttributesEnum.firstIndex() + ordinal();
        }

        protected static final int firstIndex() {
            return firstIndex;
        }

        protected static int count() {
            return AttributesEnum.firstIndex() + AttributesEnum.staticValues().length;
        }

        protected static final AttributesEnum[] staticValues() {
            if (vals == null) {
                vals = AttributesEnum.values();
            }
            return vals;
        }
    }
    public static final int CN = AttributesEnum.Cn.index();
    public static final int ID = AttributesEnum.Id.index();
    public static final int NAME = AttributesEnum.Name.index();
    public static final int OBJTECH = AttributesEnum.ObjTech.index();
    public static final int OBJNAME = AttributesEnum.ObjName.index();
    public static final int OBJCLASS = AttributesEnum.ObjClass.index();
    public static final int DESCRIPTION = AttributesEnum.Description.index();
    public static final int MANAGINGCONTCN = AttributesEnum.ManagingContCn.index();
    public static final int GACN = AttributesEnum.GaCn.index();
    public static final int FEDIDFY = AttributesEnum.FedIdFy.index();
    public static final int FEDIDTYPE = AttributesEnum.FedIdType.index();
    public static final int FEDIDAGENCY = AttributesEnum.FedIdAgency.index();
    public static final int FEDIDREGION = AttributesEnum.FedIdRegion.index();
    public static final int FEDIDUNIT = AttributesEnum.FedIdUnit.index();
    public static final int FEDIDSUBUNIT = AttributesEnum.FedIdSubunit.index();
    public static final int FEDIDSEQ = AttributesEnum.FedIdSeq.index();
    public static final int PROJTITLE = AttributesEnum.ProjTitle.index();
    public static final int PROJSTATUS = AttributesEnum.ProjStatus.index();
    public static final int APPLICATIONID = AttributesEnum.ApplicationId.index();
    public static final int APPLICATIONTYPE = AttributesEnum.ApplicationType.index();
    public static final int APPSUBMISSIONTYPE = AttributesEnum.AppSubmissionType.index();
    public static final int APPSUBMITDATE = AttributesEnum.AppSubmitDate.index();
    public static final int APPRECEIVEDDATE = AttributesEnum.AppReceivedDate.index();
    public static final int HHSPAYMENTIND = AttributesEnum.HhsPaymentInd.index();
    public static final int PROPOSEDSTARTDATE = AttributesEnum.ProposedStartDate.index();
    public static final int PROPOSEDENDDATE = AttributesEnum.ProposedEndDate.index();
    public static final int PROJDESC = AttributesEnum.ProjDesc.index();
    public static final int PROJRECEIVEDDT = AttributesEnum.ProjReceivedDt.index();
    public static final int PROJEXECUTIONDT = AttributesEnum.ProjExecutionDt.index();
    public static final int PROJSTARTDT = AttributesEnum.ProjStartDt.index();
    public static final int PROJOBLIGATIONDT = AttributesEnum.ProjObligationDt.index();
    public static final int PROJEXPIRATIONDT = AttributesEnum.ProjExpirationDt.index();
    public static final int PROJRWU = AttributesEnum.ProjRwu.index();
    public static final int PROJCLOSEDT = AttributesEnum.ProjCloseDt.index();
    public static final int PROJCANCELLATIONDT = AttributesEnum.ProjCancellationDt.index();
    public static final int DATEMAILED = AttributesEnum.DateMailed.index();
    public static final int DATESIGNED = AttributesEnum.DateSigned.index();
    public static final int EXTRAMURALIND = AttributesEnum.ExtramuralInd.index();
    public static final int PROJCFDANO = AttributesEnum.ProjCfdaNo.index();
    public static final int PROJSCIENCECD = AttributesEnum.ProjScienceCd.index();
    public static final int RESEARCHTYPE = AttributesEnum.ResearchType.index();
    public static final int FAADSPERFPLACE = AttributesEnum.FaadsPerfPlace.index();
    public static final int JOURNALIND = AttributesEnum.JournalInd.index();
    public static final int MODNUMBER = AttributesEnum.ModNumber.index();
    public static final int ORIGFEDID = AttributesEnum.OrigFedId.index();
    public static final int FAADSDEPARTMENTNO = AttributesEnum.FaadsDepartmentNo.index();
    public static final int FAADSAGENCYCD = AttributesEnum.FaadsAgencyCd.index();
    public static final int FAADSAGREEMENTTYPE = AttributesEnum.FaadsAgreementType.index();
    public static final int FAADSSTATEAPPID = AttributesEnum.FaadsStateAppId.index();
    public static final int FAADSMINORITYCD = AttributesEnum.FaadsMinorityCd.index();
    public static final int PROJASSISTTYPE = AttributesEnum.ProjAssistType.index();
    public static final int COMMENTS = AttributesEnum.Comments.index();
    public static final int MASTERFEDID = AttributesEnum.MasterFedId.index();
    public static final int AOPIND = AttributesEnum.AopInd.index();
    public static final int GEOTYPE = AttributesEnum.GeoType.index();
    public static final int MANAGINGSTATECOUNTY = AttributesEnum.ManagingStateCounty.index();
    public static final int AREASEFFECTED = AttributesEnum.AreasEffected.index();
    public static final int FFIN = AttributesEnum.Ffin.index();
    public static final int STATEEOCODE = AttributesEnum.StateEoCode.index();
    public static final int STATEEODATE = AttributesEnum.StateEoDate.index();
    public static final int FEDESTFUND = AttributesEnum.FedEstFund.index();
    public static final int APPLICANTESTFUND = AttributesEnum.ApplicantEstFund.index();
    public static final int STATEESTFUND = AttributesEnum.StateEstFund.index();
    public static final int LOCALESTFUND = AttributesEnum.LocalEstFund.index();
    public static final int PIESTFUND = AttributesEnum.PiEstFund.index();
    public static final int OTHESTFUND = AttributesEnum.OthEstFund.index();
    public static final int STATUS = AttributesEnum.Status.index();
    public static final int STATUSDATE = AttributesEnum.StatusDate.index();
    public static final int REROUTEFROM = AttributesEnum.RerouteFrom.index();
    public static final int REROUTEDATE = AttributesEnum.RerouteDate.index();
    public static final int PROJECTCONGRESSIONALDISTRICT = AttributesEnum.ProjectCongressionalDistrict.index();
    public static final int FFISDOCID = AttributesEnum.FfisDocId.index();
    public static final int LOCKEDIND = AttributesEnum.LockedInd.index();
    public static final int APPLICANTNAME = AttributesEnum.ApplicantName.index();
    public static final int STATEIDENTIFIER = AttributesEnum.StateIdentifier.index();
    public static final int INTERNATIONALACTIND = AttributesEnum.InternationalActInd.index();
    public static final int PROJTYPE = AttributesEnum.ProjType.index();
    public static final int ADVANCEALLOWEDIND = AttributesEnum.AdvanceAllowedInd.index();
    public static final int SECURITYID = AttributesEnum.SecurityId.index();
    public static final int LINE1 = AttributesEnum.Line1.index();
    public static final int LINE2 = AttributesEnum.Line2.index();
    public static final int LINE3 = AttributesEnum.Line3.index();
    public static final int CITYNAME = AttributesEnum.CityName.index();
    public static final int COUNTY = AttributesEnum.County.index();
    public static final int STATECODE = AttributesEnum.StateCode.index();
    public static final int COUNTRYNAME = AttributesEnum.CountryName.index();
    public static final int POSTALCODE = AttributesEnum.PostalCode.index();
    public static final int ZIP4 = AttributesEnum.Zip4.index();
    public static final int ELECTRONICADDRESS = AttributesEnum.ElectronicAddress.index();
    public static final int RESTRICTIONS = AttributesEnum.Restrictions.index();
    public static final int AUTHORITYAPPROVAL = AttributesEnum.AuthorityApproval.index();
    public static final int AUTHORITY = AttributesEnum.Authority.index();
    public static final int FORMAT = AttributesEnum.Format.index();
    public static final int OTHERAPPROVAL = AttributesEnum.OtherApproval.index();

    /**
     * This is the default constructor (do not remove).
     */
    public AiGaAppVImpl() {
    }

    /**
     * @return the definition object for this instance class.
     */
    public static synchronized EntityDefImpl getDefinitionObject() {
        return EntityDefImpl.findDefObject("gov.usda.fs.iweb.contactreplace.model.entity.AiGaAppV");
    }


    public String getCn()
  {
    return (String)getAttributeInternal(0);
  }
  
  public void setCn(String value)
  {
    setAttributeInternal(0, value);
  }
  


  public String getId()
  {
    return (String)getAttributeInternal(1);
  }
  
  public void setId(String value)
  {
    setAttributeInternal(1, value);
  }
  


  public String getName()
  {
    return (String)getAttributeInternal(2);
  }
  
  public void setName(String value)
  {
    setAttributeInternal(2, value);
  }
  


  public String getObjTech()
  {
    return (String)getAttributeInternal(3);
  }
  
  public void setObjTech(String value)
  {
    setAttributeInternal(3, value);
  }
  


  public String getObjName()
  {
    return (String)getAttributeInternal(4);
  }
  
  public void setObjName(String value)
  {
    setAttributeInternal(4, value);
  }
  


  public String getObjClass()
  {
    return (String)getAttributeInternal(5);
  }
  
  public void setObjClass(String value)
  {
    setAttributeInternal(5, value);
  }
  


  public String getDescription()
  {
    return (String)getAttributeInternal(6);
  }
  
  public void setDescription(String value)
  {
    setAttributeInternal(6, value);
  }
  


  public String getManagingContCn()
  {
    return (String)getAttributeInternal(7);
  }
  
  public void setManagingContCn(String value)
  {
    setAttributeInternal(7, value);
  }
  


  public String getGaCn()
  {
    return (String)getAttributeInternal(8);
  }
  
  public void setGaCn(String value)
  {
    setAttributeInternal(8, value);
  }
  


  public String getFedIdFy()
  {
    return (String)getAttributeInternal(9);
  }
  
  public void setFedIdFy(String value)
  {
    setAttributeInternal(9, value);
  }
  


  public String getFedIdType()
  {
    return (String)getAttributeInternal(10);
  }
  
  public void setFedIdType(String value)
  {
    setAttributeInternal(10, value);
  }
  


  public String getFedIdAgency()
  {
    return (String)getAttributeInternal(11);
  }
  
  public void setFedIdAgency(String value)
  {
    setAttributeInternal(11, value);
  }
  


  public String getFedIdRegion()
  {
    return (String)getAttributeInternal(12);
  }
  
  public void setFedIdRegion(String value)
  {
    setAttributeInternal(12, value);
  }
  


  public String getFedIdUnit()
  {
    return (String)getAttributeInternal(13);
  }
  
  public void setFedIdUnit(String value)
  {
    setAttributeInternal(13, value);
  }
  


  public String getFedIdSubunit()
  {
    return (String)getAttributeInternal(14);
  }
  
  public void setFedIdSubunit(String value)
  {
    setAttributeInternal(14, value);
  }
  


  public Number getFedIdSeq()
  {
    return (Number)getAttributeInternal(15);
  }
  
  public void setFedIdSeq(Number value)
  {
    setAttributeInternal(15, value);
  }
  


  public String getProjTitle()
  {
    return (String)getAttributeInternal(16);
  }
  
  public void setProjTitle(String value)
  {
    setAttributeInternal(16, value);
  }
  


  public String getProjStatus()
  {
    return (String)getAttributeInternal(17);
  }
  
  public void setProjStatus(String value)
  {
    setAttributeInternal(17, value);
  }
  


  public String getApplicationId()
  {
    return (String)getAttributeInternal(18);
  }
  
  public void setApplicationId(String value)
  {
    setAttributeInternal(18, value);
  }
  


  public String getApplicationType()
  {
    return (String)getAttributeInternal(19);
  }
  
  public void setApplicationType(String value)
  {
    setAttributeInternal(19, value);
  }
  


  public String getAppSubmissionType()
  {
    return (String)getAttributeInternal(20);
  }
  
  public void setAppSubmissionType(String value)
  {
    setAttributeInternal(20, value);
  }
  


  public Date getAppSubmitDate()
  {
    return (Date)getAttributeInternal(21);
  }
  
  public void setAppSubmitDate(Date value)
  {
    setAttributeInternal(21, value);
  }
  


  public Date getAppReceivedDate()
  {
    return (Date)getAttributeInternal(22);
  }
  
  public void setAppReceivedDate(Date value)
  {
    setAttributeInternal(22, value);
  }
  


  public String getHhsPaymentInd()
  {
    return (String)getAttributeInternal(23);
  }
  
  public void setHhsPaymentInd(String value)
  {
    setAttributeInternal(23, value);
  }
  


  public Date getProposedStartDate()
  {
    return (Date)getAttributeInternal(24);
  }
  
  public void setProposedStartDate(Date value)
  {
    setAttributeInternal(24, value);
  }
  


  public Date getProposedEndDate()
  {
    return (Date)getAttributeInternal(25);
  }
  
  public void setProposedEndDate(Date value)
  {
    setAttributeInternal(25, value);
  }
  


  public String getProjDesc()
  {
    return (String)getAttributeInternal(26);
  }
  
  public void setProjDesc(String value)
  {
    setAttributeInternal(26, value);
  }
  


  public Date getProjReceivedDt()
  {
    return (Date)getAttributeInternal(27);
  }
  
  public void setProjReceivedDt(Date value)
  {
    setAttributeInternal(27, value);
  }
  


  public Date getProjExecutionDt()
  {
    return (Date)getAttributeInternal(28);
  }
  
  public void setProjExecutionDt(Date value)
  {
    setAttributeInternal(28, value);
  }
  


  public Date getProjStartDt()
  {
    return (Date)getAttributeInternal(29);
  }
  
  public void setProjStartDt(Date value)
  {
    setAttributeInternal(29, value);
  }
  


  public Date getProjObligationDt()
  {
    return (Date)getAttributeInternal(30);
  }
  
  public void setProjObligationDt(Date value)
  {
    setAttributeInternal(30, value);
  }
  


  public Date getProjExpirationDt()
  {
    return (Date)getAttributeInternal(31);
  }
  
  public void setProjExpirationDt(Date value)
  {
    setAttributeInternal(31, value);
  }
  


  public String getProjRwu()
  {
    return (String)getAttributeInternal(32);
  }
  
  public void setProjRwu(String value)
  {
    setAttributeInternal(32, value);
  }
  


  public Date getProjCloseDt()
  {
    return (Date)getAttributeInternal(33);
  }
  
  public void setProjCloseDt(Date value)
  {
    setAttributeInternal(33, value);
  }
  


  public Date getProjCancellationDt()
  {
    return (Date)getAttributeInternal(34);
  }
  
  public void setProjCancellationDt(Date value)
  {
    setAttributeInternal(34, value);
  }
  


  public Date getDateMailed()
  {
    return (Date)getAttributeInternal(35);
  }
  
  public void setDateMailed(Date value)
  {
    setAttributeInternal(35, value);
  }
  


  public Date getDateSigned()
  {
    return (Date)getAttributeInternal(36);
  }
  
  public void setDateSigned(Date value)
  {
    setAttributeInternal(36, value);
  }
  


  public String getExtramuralInd()
  {
    return (String)getAttributeInternal(37);
  }
  
  public void setExtramuralInd(String value)
  {
    setAttributeInternal(37, value);
  }
  


  public String getProjCfdaNo()
  {
    return (String)getAttributeInternal(38);
  }
  
  public void setProjCfdaNo(String value)
  {
    setAttributeInternal(38, value);
  }
  


  public String getProjScienceCd()
  {
    return (String)getAttributeInternal(39);
  }
  
  public void setProjScienceCd(String value)
  {
    setAttributeInternal(39, value);
  }
  


  public String getResearchType()
  {
    return (String)getAttributeInternal(40);
  }
  
  public void setResearchType(String value)
  {
    setAttributeInternal(40, value);
  }
  


  public String getFaadsPerfPlace()
  {
    return (String)getAttributeInternal(41);
  }
  
  public void setFaadsPerfPlace(String value)
  {
    setAttributeInternal(41, value);
  }
  


  public String getJournalInd()
  {
    return (String)getAttributeInternal(42);
  }
  
  public void setJournalInd(String value)
  {
    setAttributeInternal(42, value);
  }
  


  public Number getModNumber()
  {
    return (Number)getAttributeInternal(43);
  }
  
  public void setModNumber(Number value)
  {
    setAttributeInternal(43, value);
  }
  


  public String getOrigFedId()
  {
    return (String)getAttributeInternal(44);
  }
  
  public void setOrigFedId(String value)
  {
    setAttributeInternal(44, value);
  }
  


  public String getFaadsDepartmentNo()
  {
    return (String)getAttributeInternal(45);
  }
  
  public void setFaadsDepartmentNo(String value)
  {
    setAttributeInternal(45, value);
  }
  


  public String getFaadsAgencyCd()
  {
    return (String)getAttributeInternal(46);
  }
  
  public void setFaadsAgencyCd(String value)
  {
    setAttributeInternal(46, value);
  }
  


  public String getFaadsAgreementType()
  {
    return (String)getAttributeInternal(47);
  }
  
  public void setFaadsAgreementType(String value)
  {
    setAttributeInternal(47, value);
  }
  


  public String getFaadsStateAppId()
  {
    return (String)getAttributeInternal(48);
  }
  
  public void setFaadsStateAppId(String value)
  {
    setAttributeInternal(48, value);
  }
  


  public String getFaadsMinorityCd()
  {
    return (String)getAttributeInternal(49);
  }
  
  public void setFaadsMinorityCd(String value)
  {
    setAttributeInternal(49, value);
  }
  


  public String getProjAssistType()
  {
    return (String)getAttributeInternal(50);
  }
  
  public void setProjAssistType(String value)
  {
    setAttributeInternal(50, value);
  }
  


  public String getComments()
  {
    return (String)getAttributeInternal(51);
  }
  
  public void setComments(String value)
  {
    setAttributeInternal(51, value);
  }
  


  public String getMasterFedId()
  {
    return (String)getAttributeInternal(52);
  }
  
  public void setMasterFedId(String value)
  {
    setAttributeInternal(52, value);
  }
  


  public String getAopInd()
  {
    return (String)getAttributeInternal(53);
  }
  
  public void setAopInd(String value)
  {
    setAttributeInternal(53, value);
  }
  


  public String getGeoType()
  {
    return (String)getAttributeInternal(54);
  }
  
  public void setGeoType(String value)
  {
    setAttributeInternal(54, value);
  }
  


  public String getManagingStateCounty()
  {
    return (String)getAttributeInternal(55);
  }
  
  public void setManagingStateCounty(String value)
  {
    setAttributeInternal(55, value);
  }
  


  public String getAreasEffected()
  {
    return (String)getAttributeInternal(56);
  }
  
  public void setAreasEffected(String value)
  {
    setAttributeInternal(56, value);
  }
  


  public String getFfin()
  {
    return (String)getAttributeInternal(57);
  }
  
  public void setFfin(String value)
  {
    setAttributeInternal(57, value);
  }
  


  public String getStateEoCode()
  {
    return (String)getAttributeInternal(58);
  }
  
  public void setStateEoCode(String value)
  {
    setAttributeInternal(58, value);
  }
  


  public Date getStateEoDate()
  {
    return (Date)getAttributeInternal(59);
  }
  
  public void setStateEoDate(Date value)
  {
    setAttributeInternal(59, value);
  }
  


  public Number getFedEstFund()
  {
    return (Number)getAttributeInternal(60);
  }
  
  public void setFedEstFund(Number value)
  {
    setAttributeInternal(60, value);
  }
  


  public Number getApplicantEstFund()
  {
    return (Number)getAttributeInternal(61);
  }
  
  public void setApplicantEstFund(Number value)
  {
    setAttributeInternal(61, value);
  }
  


  public Number getStateEstFund()
  {
    return (Number)getAttributeInternal(62);
  }
  
  public void setStateEstFund(Number value)
  {
    setAttributeInternal(62, value);
  }
  


  public Number getLocalEstFund()
  {
    return (Number)getAttributeInternal(63);
  }
  
  public void setLocalEstFund(Number value)
  {
    setAttributeInternal(63, value);
  }
  


  public Number getPiEstFund()
  {
    return (Number)getAttributeInternal(64);
  }
  
  public void setPiEstFund(Number value)
  {
    setAttributeInternal(64, value);
  }
  


  public Number getOthEstFund()
  {
    return (Number)getAttributeInternal(65);
  }
  
  public void setOthEstFund(Number value)
  {
    setAttributeInternal(65, value);
  }
  


  public String getStatus()
  {
    return (String)getAttributeInternal(66);
  }
  
  public void setStatus(String value)
  {
    setAttributeInternal(66, value);
  }
  


  public Date getStatusDate()
  {
    return (Date)getAttributeInternal(67);
  }
  
  public void setStatusDate(Date value)
  {
    setAttributeInternal(67, value);
  }
  


  public String getRerouteFrom()
  {
    return (String)getAttributeInternal(68);
  }
  
  public void setRerouteFrom(String value)
  {
    setAttributeInternal(68, value);
  }
  


  public Date getRerouteDate()
  {
    return (Date)getAttributeInternal(69);
  }
  
  public void setRerouteDate(Date value)
  {
    setAttributeInternal(69, value);
  }
  


  public String getProjectCongressionalDistrict()
  {
    return (String)getAttributeInternal(70);
  }
  
  public void setProjectCongressionalDistrict(String value)
  {
    setAttributeInternal(70, value);
  }
  


  public String getFfisDocId()
  {
    return (String)getAttributeInternal(71);
  }
  
  public void setFfisDocId(String value)
  {
    setAttributeInternal(71, value);
  }
  


  public String getLockedInd()
  {
    return (String)getAttributeInternal(72);
  }
  
  public void setLockedInd(String value)
  {
    setAttributeInternal(72, value);
  }
  


  public String getApplicantName()
  {
    return (String)getAttributeInternal(73);
  }
  
  public void setApplicantName(String value)
  {
    setAttributeInternal(73, value);
  }
  


  public String getStateIdentifier()
  {
    return (String)getAttributeInternal(74);
  }
  
  public void setStateIdentifier(String value)
  {
    setAttributeInternal(74, value);
  }
  


  public String getInternationalActInd()
  {
    return (String)getAttributeInternal(75);
  }
  
  public void setInternationalActInd(String value)
  {
    setAttributeInternal(75, value);
  }
  


  public String getProjType()
  {
    return (String)getAttributeInternal(76);
  }
  
  public void setProjType(String value)
  {
    setAttributeInternal(76, value);
  }
  


  public String getAdvanceAllowedInd()
  {
    return (String)getAttributeInternal(77);
  }
  
  public void setAdvanceAllowedInd(String value)
  {
    setAttributeInternal(77, value);
  }
  



  public String getSecurityId()
  {
    return (String)getAttributeInternal(78);
  }
  
  public void setSecurityId(String value)
  {
    setAttributeInternal(78, value);
  }
  


  public String getLine1()
  {
    return (String)getAttributeInternal(79);
  }
  
  public void setLine1(String value)
  {
    setAttributeInternal(79, value);
  }
  


  public String getLine2()
  {
    return (String)getAttributeInternal(80);
  }
  
  public void setLine2(String value)
  {
    setAttributeInternal(80, value);
  }
  


  public String getLine3()
  {
    return (String)getAttributeInternal(81);
  }
  
  public void setLine3(String value)
  {
    setAttributeInternal(81, value);
  }
  


  public String getCityName()
  {
    return (String)getAttributeInternal(82);
  }
  
  public void setCityName(String value)
  {
    setAttributeInternal(82, value);
  }
  


  public String getCounty()
  {
    return (String)getAttributeInternal(83);
  }
  
  public void setCounty(String value)
  {
    setAttributeInternal(83, value);
  }
  


  public String getStateCode()
  {
    return (String)getAttributeInternal(84);
  }
  
  public void setStateCode(String value)
  {
    setAttributeInternal(84, value);
  }
  


  public String getCountryName()
  {
    return (String)getAttributeInternal(85);
  }
  
  public void setCountryName(String value)
  {
    setAttributeInternal(85, value);
  }
  


  public String getPostalCode()
  {
    return (String)getAttributeInternal(86);
  }
  
  public void setPostalCode(String value)
  {
    setAttributeInternal(86, value);
  }
  


  public String getZip4()
  {
    return (String)getAttributeInternal(87);
  }
  
  public void setZip4(String value)
  {
    setAttributeInternal(87, value);
  }
  


  public String getElectronicAddress()
  {
    return (String)getAttributeInternal(88);
  }
  
  public void setElectronicAddress(String value)
  {
    setAttributeInternal(88, value);
  }
  


  public String getRestrictions()
  {
    return (String)getAttributeInternal(89);
  }
  
  public void setRestrictions(String value)
  {
    setAttributeInternal(89, value);
  }
  


  public String getAuthorityApproval()
  {
    return (String)getAttributeInternal(90);
  }
  
  public void setAuthorityApproval(String value)
  {
    setAttributeInternal(90, value);
  }
  


  public String getAuthority()
  {
    return (String)getAttributeInternal(91);
  }
  
  public void setAuthority(String value)
  {
    setAttributeInternal(91, value);
  }
  


  public String getFormat()
  {
    return (String)getAttributeInternal(92);
  }
  
  public void setFormat(String value)
  {
    setAttributeInternal(92, value);
  }
  


  public String getOtherApproval()
  {
    return (String)getAttributeInternal(93);
  }
  
  public void setOtherApproval(String value)
  {
    setAttributeInternal(93, value);
  }

    /**
     * @param cn key constituent

     * @return a Key object based on given key constituents.
     */
    public static Key createPrimaryKey(String cn) {
        return new Key(new Object[] { cn });
    }


}

