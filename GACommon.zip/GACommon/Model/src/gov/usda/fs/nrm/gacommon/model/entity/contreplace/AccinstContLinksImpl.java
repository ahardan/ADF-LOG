package gov.usda.fs.nrm.gacommon.model.entity.contreplace;


import gov.usda.fs.nrm.framework.model.entity.IWebEntity;

import oracle.jbo.Key;
import oracle.jbo.domain.Date;
import oracle.jbo.server.AttributeDefImpl;
import oracle.jbo.server.EntityDefImpl;
import oracle.jbo.server.EntityImpl;


public class AccinstContLinksImpl
  extends IWebEntity {
    /**
     * AttributesEnum: generated enum for identifying attributes and accessors. DO NOT MODIFY.
     */
    protected enum AttributesEnum {
        AccinstCn,
        ContCn,
        LinkTypeName,
        StartDate,
        EndDate,
        Remarks,
        LeadingInd,
        Department,
        Division,
        FfisVendorId,
        FaadsAddrCn,
        InstitutionCode,
        FedDebtDelnqntInd,
        PayeeInd,
        ApplicantInd,
        LinkSubType,
        Cn,
        FfisCanNumberStatus,
        PayerInd,
        Contacts;
        private static AttributesEnum[] vals = null;
        private static final int firstIndex = 0;

        protected int index() {
            return AttributesEnum.firstIndex() + ordinal();
        }

        protected static final int firstIndex() {
            return firstIndex;
        }

        protected static int count() {
            return AttributesEnum.firstIndex() + AttributesEnum.staticValues().length;
        }

        protected static final AttributesEnum[] staticValues() {
            if (vals == null) {
                vals = AttributesEnum.values();
            }
            return vals;
        }
    }
    public static final int ACCINSTCN = AttributesEnum.AccinstCn.index();
    public static final int CONTCN = AttributesEnum.ContCn.index();
    public static final int LINKTYPENAME = AttributesEnum.LinkTypeName.index();
    public static final int STARTDATE = AttributesEnum.StartDate.index();
    public static final int ENDDATE = AttributesEnum.EndDate.index();
    public static final int REMARKS = AttributesEnum.Remarks.index();
    public static final int LEADINGIND = AttributesEnum.LeadingInd.index();
    public static final int DEPARTMENT = AttributesEnum.Department.index();
    public static final int DIVISION = AttributesEnum.Division.index();
    public static final int FFISVENDORID = AttributesEnum.FfisVendorId.index();
    public static final int FAADSADDRCN = AttributesEnum.FaadsAddrCn.index();
    public static final int INSTITUTIONCODE = AttributesEnum.InstitutionCode.index();
    public static final int FEDDEBTDELNQNTIND = AttributesEnum.FedDebtDelnqntInd.index();
    public static final int PAYEEIND = AttributesEnum.PayeeInd.index();
    public static final int APPLICANTIND = AttributesEnum.ApplicantInd.index();
    public static final int LINKSUBTYPE = AttributesEnum.LinkSubType.index();
    public static final int CN = AttributesEnum.Cn.index();
    public static final int FFISCANNUMBERSTATUS = AttributesEnum.FfisCanNumberStatus.index();
    public static final int PAYERIND = AttributesEnum.PayerInd.index();
    public static final int CONTACTS = AttributesEnum.Contacts.index();

    /**
     * This is the default constructor (do not remove).
     */
    public AccinstContLinksImpl() {
    }

    /**
     * @return the definition object for this instance class.
     */
    public static synchronized EntityDefImpl getDefinitionObject() {
        return EntityDefImpl.findDefObject("gov.usda.fs.iweb.contactreplace.model.entity.AccinstContLinks");
    }


    public String getAccinstCn()
  {
    return (String)getAttributeInternal(0);
  }
  
  public void setAccinstCn(String value)
  {
    setAttributeInternal(0, value);
  }
  


  public String getContCn()
  {
    return (String)getAttributeInternal(1);
  }
  
  public void setContCn(String value)
  {
    setAttributeInternal(1, value);
  }
  


  public String getLinkTypeName()
  {
    return (String)getAttributeInternal(2);
  }
  
  public void setLinkTypeName(String value)
  {
    setAttributeInternal(2, value);
  }
  


  public Date getStartDate()
  {
    return (Date)getAttributeInternal(3);
  }
  
  public void setStartDate(Date value)
  {
    setAttributeInternal(3, value);
  }
  


  public Date getEndDate()
  {
    return (Date)getAttributeInternal(4);
  }
  
  public void setEndDate(Date value)
  {
    setAttributeInternal(4, value);
  }
  


  public String getRemarks()
  {
    return (String)getAttributeInternal(5);
  }
  
  public void setRemarks(String value)
  {
    setAttributeInternal(5, value);
  }
  


  public String getLeadingInd()
  {
    return (String)getAttributeInternal(6);
  }
  
  public void setLeadingInd(String value)
  {
    setAttributeInternal(6, value);
  }
  


  public String getDepartment()
  {
    return (String)getAttributeInternal(7);
  }
  
  public void setDepartment(String value)
  {
    setAttributeInternal(7, value);
  }
  


  public String getDivision()
  {
    return (String)getAttributeInternal(8);
  }
  
  public void setDivision(String value)
  {
    setAttributeInternal(8, value);
  }
  


  public String getFfisVendorId()
  {
    return (String)getAttributeInternal(9);
  }
  
  public void setFfisVendorId(String value)
  {
    setAttributeInternal(9, value);
  }
  


  public String getFaadsAddrCn()
  {
    return (String)getAttributeInternal(10);
  }
  
  public void setFaadsAddrCn(String value)
  {
    setAttributeInternal(10, value);
  }
  


  public String getInstitutionCode()
  {
    return (String)getAttributeInternal(11);
  }
  
  public void setInstitutionCode(String value)
  {
    setAttributeInternal(11, value);
  }
  


  public String getFedDebtDelnqntInd()
  {
    return (String)getAttributeInternal(12);
  }
  
  public void setFedDebtDelnqntInd(String value)
  {
    setAttributeInternal(12, value);
  }
  


  public String getPayeeInd()
  {
    return (String)getAttributeInternal(13);
  }
  
  public void setPayeeInd(String value)
  {
    setAttributeInternal(13, value);
  }
  


  public String getApplicantInd()
  {
    return (String)getAttributeInternal(14);
  }
  
  public void setApplicantInd(String value)
  {
    setAttributeInternal(14, value);
  }
  


  public String getLinkSubType()
  {
    return (String)getAttributeInternal(15);
  }
  
  public void setLinkSubType(String value)
  {
    setAttributeInternal(15, value);
  }
  


  public String getCn()
  {
    return (String)getAttributeInternal(16);
  }
  
  public void setCn(String value)
  {
    setAttributeInternal(16, value);
  }
  


  public String getFfisCanNumberStatus()
  {
    return (String)getAttributeInternal(17);
  }
  
  public void setFfisCanNumberStatus(String value)
  {
    setAttributeInternal(17, value);
  }
  


  public String getPayerInd()
  {
    return (String)getAttributeInternal(18);
  }
  
  public void setPayerInd(String value)
  {
    setAttributeInternal(18, value);
  }


    public ContactsImpl getContacts()
  {
    return (ContactsImpl)getAttributeInternal(19);
  }
  
  public void setContacts(ContactsImpl value)
  {
    setAttributeInternal(19, value);
  }

    /**
     * @param cn key constituent

     * @return a Key object based on given key constituents.
     */
    public static Key createPrimaryKey(String cn) {
        return new Key(new Object[] { cn });
    }


}

