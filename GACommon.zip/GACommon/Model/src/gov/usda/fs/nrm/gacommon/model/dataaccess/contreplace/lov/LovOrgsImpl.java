package gov.usda.fs.nrm.gacommon.model.dataaccess.contreplace.lov;

import gov.usda.fs.nrm.framework.model.dataaccess.IWebViewObject;


public class LovOrgsImpl
  extends IWebViewObject
{
  public String getcontCn()
  {
    return (String)getNamedWhereClauseParam("contCn");
  }
  
  public void setcontCn(String value)
  {
    setNamedWhereClauseParam("contCn", value);
  }
}

