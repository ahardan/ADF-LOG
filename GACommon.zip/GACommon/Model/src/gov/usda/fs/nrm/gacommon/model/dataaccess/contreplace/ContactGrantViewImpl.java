package gov.usda.fs.nrm.gacommon.model.dataaccess.contreplace;


import gov.usda.fs.nrm.framework.model.dataaccess.IWebViewObject;

import oracle.jbo.server.ViewObjectImpl;


public class ContactGrantViewImpl
  extends IWebViewObject {
    /**
     * This is the default constructor (do not remove).
     */
    public ContactGrantViewImpl() {
    }

    public String getcontactCn()
  {
    return (String)getNamedWhereClauseParam("contactCn");
  }
  
  public void setcontactCn(String value)
  {
    setNamedWhereClauseParam("contactCn", value);
  }
  


  public String getmanagingContCn()
  {
    return (String)getNamedWhereClauseParam("managingContCn");
  }
  
  public void setmanagingContCn(String value)
  {
    setNamedWhereClauseParam("managingContCn", value);
  }


}

