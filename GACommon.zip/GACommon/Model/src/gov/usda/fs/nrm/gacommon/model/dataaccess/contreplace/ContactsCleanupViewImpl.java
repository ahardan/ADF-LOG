package gov.usda.fs.nrm.gacommon.model.dataaccess.contreplace;

import gov.usda.fs.nrm.framework.model.dataaccess.IWebViewObject;

public class ContactsCleanupViewImpl
  extends IWebViewObject
{}

