package gov.usda.fs.iweb.contactreplace.model.dataaccess.lov.common;

import oracle.jbo.common.JboResourceBundle;



public class LovContactsRowImplMsgBundle
  extends JboResourceBundle {

    static final Object[][] sMessageStrings = 
    {
{ "StateCode_LABEL", "State" },
{ "Cn_LABEL", "CN" },
{ "AddressType_LABEL", "Address Type" },
{ "ElectronicAddress_LABEL", "Email" },
{ "LastOrOrgName_LABEL", "Last/Org Name" },
{ "Duns_LABEL", "DUNS" },
{ "ContactType_LABEL", "Type" },
{ "FirstName_LABEL", "First Name" },
{ "CityName_LABEL", "City" },
{ "Line1_LABEL", "Line 1" }};

    /**This is the default constructor (do not remove)
     */
    public LovContactsRowImplMsgBundle() {
    }


    public Object[][] getContents()
  {
    return super.getMergedArray(sMessageStrings, super.getContents());
  }
}

