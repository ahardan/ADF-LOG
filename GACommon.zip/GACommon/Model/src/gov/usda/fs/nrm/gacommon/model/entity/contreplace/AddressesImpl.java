package gov.usda.fs.nrm.gacommon.model.entity.contreplace;

import gov.usda.fs.nrm.framework.model.entity.IWebEntity;

import oracle.jbo.Key;
import oracle.jbo.server.AttributeDefImpl;
import oracle.jbo.server.EntityDefImpl;
import oracle.jbo.server.EntityImpl;


public class AddressesImpl
  extends IWebEntity {
    /**
     * AttributesEnum: generated enum for identifying attributes and accessors. DO NOT MODIFY.
     */
    protected enum AttributesEnum {
        ContCn,
        AddressType,
        Line1,
        Line2,
        Line3,
        CityName,
        StateCode,
        PostalCode,
        ElectronicAddress,
        Restrictions,
        CountryName,
        CongressionalDistrict,
        County,
        ProgramArea,
        SecurityId,
        Zip4,
        Contacts;
        private static AttributesEnum[] vals = null;
        private static final int firstIndex = 0;

        protected int index() {
            return AttributesEnum.firstIndex() + ordinal();
        }

        protected static final int firstIndex() {
            return firstIndex;
        }

        protected static int count() {
            return AttributesEnum.firstIndex() + AttributesEnum.staticValues().length;
        }

        protected static final AttributesEnum[] staticValues() {
            if (vals == null) {
                vals = AttributesEnum.values();
            }
            return vals;
        }
    }
    public static final int CONTCN = AttributesEnum.ContCn.index();
    public static final int ADDRESSTYPE = AttributesEnum.AddressType.index();
    public static final int LINE1 = AttributesEnum.Line1.index();
    public static final int LINE2 = AttributesEnum.Line2.index();
    public static final int LINE3 = AttributesEnum.Line3.index();
    public static final int CITYNAME = AttributesEnum.CityName.index();
    public static final int STATECODE = AttributesEnum.StateCode.index();
    public static final int POSTALCODE = AttributesEnum.PostalCode.index();
    public static final int ELECTRONICADDRESS = AttributesEnum.ElectronicAddress.index();
    public static final int RESTRICTIONS = AttributesEnum.Restrictions.index();
    public static final int COUNTRYNAME = AttributesEnum.CountryName.index();
    public static final int CONGRESSIONALDISTRICT = AttributesEnum.CongressionalDistrict.index();
    public static final int COUNTY = AttributesEnum.County.index();
    public static final int PROGRAMAREA = AttributesEnum.ProgramArea.index();
    public static final int SECURITYID = AttributesEnum.SecurityId.index();
    public static final int ZIP4 = AttributesEnum.Zip4.index();
    public static final int CONTACTS = AttributesEnum.Contacts.index();

    /**
     * This is the default constructor (do not remove).
     */
    public AddressesImpl() {
    }

    /**
     * @return the definition object for this instance class.
     */
    public static synchronized EntityDefImpl getDefinitionObject() {
        return EntityDefImpl.findDefObject("gov.usda.fs.iweb.contactreplace.model.entity.Addresses");
    }


    public String getContCn()
  {
    return (String)getAttributeInternal(0);
  }
  
  public void setContCn(String value)
  {
    setAttributeInternal(0, value);
  }
  


  public String getAddressType()
  {
    return (String)getAttributeInternal(1);
  }
  
  public void setAddressType(String value)
  {
    setAttributeInternal(1, value);
  }
  


  public String getLine1()
  {
    return (String)getAttributeInternal(2);
  }
  
  public void setLine1(String value)
  {
    setAttributeInternal(2, value);
  }
  


  public String getLine2()
  {
    return (String)getAttributeInternal(3);
  }
  
  public void setLine2(String value)
  {
    setAttributeInternal(3, value);
  }
  


  public String getLine3()
  {
    return (String)getAttributeInternal(4);
  }
  
  public void setLine3(String value)
  {
    setAttributeInternal(4, value);
  }
  


  public String getCityName()
  {
    return (String)getAttributeInternal(5);
  }
  
  public void setCityName(String value)
  {
    setAttributeInternal(5, value);
  }
  


  public String getStateCode()
  {
    return (String)getAttributeInternal(6);
  }
  
  public void setStateCode(String value)
  {
    setAttributeInternal(6, value);
  }
  


  public String getPostalCode()
  {
    return (String)getAttributeInternal(7);
  }
  
  public void setPostalCode(String value)
  {
    setAttributeInternal(7, value);
  }
  


  public String getElectronicAddress()
  {
    return (String)getAttributeInternal(8);
  }
  
  public void setElectronicAddress(String value)
  {
    setAttributeInternal(8, value);
  }
  


  public String getRestrictions()
  {
    return (String)getAttributeInternal(9);
  }
  
  public void setRestrictions(String value)
  {
    setAttributeInternal(9, value);
  }
  


  public String getCountryName()
  {
    return (String)getAttributeInternal(10);
  }
  
  public void setCountryName(String value)
  {
    setAttributeInternal(10, value);
  }
  


  public String getCongressionalDistrict()
  {
    return (String)getAttributeInternal(11);
  }
  
  public void setCongressionalDistrict(String value)
  {
    setAttributeInternal(11, value);
  }
  


  public String getCounty()
  {
    return (String)getAttributeInternal(12);
  }
  
  public void setCounty(String value)
  {
    setAttributeInternal(12, value);
  }
  


  public String getProgramArea()
  {
    return (String)getAttributeInternal(13);
  }
  
  public void setProgramArea(String value)
  {
    setAttributeInternal(13, value);
  }
  


  public String getSecurityId()
  {
    return (String)getAttributeInternal(14);
  }
  
  public void setSecurityId(String value)
  {
    setAttributeInternal(14, value);
  }
  


  public String getZip4()
  {
    return (String)getAttributeInternal(15);
  }
  
  public void setZip4(String value)
  {
    setAttributeInternal(15, value);
  }


    public ContactsImpl getContacts()
  {
    return (ContactsImpl)getAttributeInternal(16);
  }
  
  public void setContacts(ContactsImpl value)
  {
    setAttributeInternal(16, value);
  }

    /**
     * @param contCn key constituent
     * @param addressType key constituent
     * @param programArea key constituent
     * @param securityId key constituent

     * @return a Key object based on given key constituents.
     */
    public static Key createPrimaryKey(String contCn, String addressType, String programArea, String securityId) {
        return new Key(new Object[] { contCn, addressType, programArea, securityId });
    }


}

