package gov.usda.fs.nrm.gacommon.model.dataaccess.contreplace.lov;


import gov.usda.fs.nrm.framework.model.dataaccess.IWebViewObject;

import oracle.jbo.server.ViewObjectImpl;

public class LovContactsImpl
  extends IWebViewObject {
    /**This is the default constructor (do not remove)
     */
    public LovContactsImpl() {
    }
}
