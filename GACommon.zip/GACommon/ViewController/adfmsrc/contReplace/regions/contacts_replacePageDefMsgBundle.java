package contReplace.regions;

import oracle.jbo.common.JboResourceBundle;





public class contacts_replacePageDefMsgBundle
  extends JboResourceBundle
{
  static final Object[][] sMessageStrings = { { "managingContCn1_null", "ALL" } };
  








  public Object[][] getContents()
  {
    return super.getMergedArray(sMessageStrings, super.getContents());
  }
}


