//**********************************************************************
// Format Agreement Number
function formatAgreementNo(sSource)
{
  var val=sSource.value;
  var sLength=val.length;
  var firstBlock;
  var secondBlock;  
  var thirdBlock;
  var fourthBlock;
  var formattedString;  
  var dash = '-'; 
  var percent = '%'; 
  var dashIndex = val.indexOf(dash)
  var percentIndex = val.indexOf(percent)
  
  //alert("dashIndex:" + dashIndex);  
  //alert("sLength:" + sLength);  
  if ( (dashIndex == -1) && (percentIndex == -1) && (sLength >= 15) )
  {
      firstBlock = val.substring(0,2);
      secondBlock = val.substring(2,4);
      thirdBlock = val.substring(4,12);
      fourthBlock = val.substring(12,sLength);  
      formattedString = firstBlock + "-" + secondBlock + "-" + thirdBlock + "-" + fourthBlock;

      sSource.value = formattedString;
  }
  sSource.value = sSource.value.toUpperCase(); 
}

//*******************************************************************
// Confirm Dialog Box before delete action
function confirmWindow(sAction, sSource)
{
  //alert("Start confirm");
  var delMsg = "Are you sure you want to delete?"; 
  var msg = "";
  
  if (sAction == 'DELETE')
  {
      msg = delMsg;
  }
  
  var ret = confirm(msg);
  //alert("ret= " + ret);
  if (ret)
  {
      //alert("submit");
      //document.form0.submit();
      submitForm('form0',0,{'event':'action','source':sSource});
  }
  return ret;
}

//*******************************************************************
// Handle Dialog Email CheckBox
function handleDialogEmailCheckBox(field)
{
  var emailR1 = "statusDialog:emailRecipient1";
  var emailCheckBox = "statusDialog:checkField";

  if ( (document.getElementById(emailCheckBox) != null) && (document.getElementById(emailR1) != null) )
  {
    if (document.getElementById(emailCheckBox).checked){
          document.getElementById(emailR1).disabled = false;
          //document.getElementById(emailR1).readOnly = false;
          document.getElementById(emailR1).focus();
          document.getElementById(emailR1).style.color = 'black';
    }else
       {
        document.getElementById(emailR1).disabled = true;
        document.getElementById(emailR1).value='';
        }
  }
}  
//*******************************************************************
// Validate Action Diaglog Form and Submit
function validateActionDialogForm()
{
  //alert("validateActionDialogForm: ");
  var statusDialog = "statusDialog";
  var emailR1 = "statusDialog:emailRecipient1";
  var emailCheckBox = "statusDialog:checkField";

  if (catchDoubleSubmission()){ }
  return true;
}  
                
// *****************************************************************************
// Semaphore to catch double submissions
vSubmitted = 'false';
function catchDoubleSubmission()
{
  if (vSubmitted=='true')
  {
    //return confirm('It appears that you have already submitted this form.  Click OK to continue submitting this form.');
    alert('It appears that you have already submitted this form.');
    return false;
  }
  else
  {
    vSubmitted='true';
    return true;
  }
}

// Set the value of the element to upper case
function setUpperCase(pElement)
{
  pElement.value = pElement.value.toUpperCase();
}

// *****************************************************************************
// Set focus for page
function setInitialFocus(pElementId)
{
  try {
    document.getElementById(pElementId).focus();
  } catch (e)
  {
    // do nothing, field may not be visible
  }
}

// *****************************************************************************
// This will set the forward formValue which will be handled by the InfraForwardAction
// sForward = *StrutsLink (* prefix)
// sForward = absoluteURL (otherwise)
function setInfraForward(pForward)
{
  //alert(pForward);
//  document.getElementById('infraForward').value = pForward;
  setFormVariable('infraForward',pForward);
}

// *****************************************************************************
function setFormVariable(variable, value)
{
//  alert(variable + ' '+ value);
  document.getElementById(variable).value = value;
}

// *****************************************************************************
function showDialog(pDialogType)
{
  dialogUrl = "actionDialog.do?dialogType=" + pDialogType;
  dialogOption = "dialogheight:400px;dialogwidth:300px;";
  dialogOption = "height=400,width=300,toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,copyhistory=no,resizable=no";
  window.showModalDialog(dialogUrl,'null',dialogOption);

}


// *****************************************************************************
function windowOpenerWHeader(pFileName, pWidth, pHeight)
{  
  window.document.body.style.backgroundColor = "#eeeeee";
  window.document.body.style.backgroundColor = "#ffffff";
  var newwindow = window.open(pFileName, 'mywindow','width= ' + pWidth + ', height= ' + pHeight + ',toolbar=yes,location=yes,directories=yes,status=yes,menubar=yes,scrollbars=yes,copyhistory=yes,resizable=yes');

  if (window.focus) {newwindow.focus()}
}

// *****************************************************************************
// APIs from G&A
function windowOpener(pFileName, pWidth, pHeight)
{ 
  //alert("Opening ...");  
  window.document.body.style.backgroundColor = "#eeeeee";
  //var ret = window.showModalDialog(pFileName, "mywindow", "dialogWidth: " + pWidth + "px; dialogHeight: " + pHeight + "px; edge: Raised; center: Yes; help: Yes; resizable: No; status: No;");
  window.document.body.style.backgroundColor = "#ffffff";
  var newwindow = window.open(pFileName, 'mywindow','width= ' + pWidth + ', height= ' + pHeight + ',toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,copyhistory=no,resizable=yes');

  if (window.focus) {newwindow.focus()}

  //alert("ret: " + ret);

//  var arrayRet = ret.split(",");
//  //alert("length: " + arrayRet.length);
//  var ret1;
//  var ret2;
//  if (arrayRet.length > "1")
//  {
//    ret1 = arrayRet["0"];
//    ret2 = arrayRet["1"];
//    //alert("ret2: " + ret2);
//  }
  
  //window.document.href = 
}

// *****************************************************************************
function windowCloser(pAction)
{ 
  //alert("Closing ...");
  window.returnValue = pAction;   
  window.close();
}

// *****************************************************************************
// Set JavaScript for onLoad of next page
// this will cause the dialog to open when the page is re-loaded
function openDialogAfterReload(pJS)
{ 
  setFormVariable('onLoadJS',"windowOpener('actionDialog.do?dialogType="+pJS+"',600,350);");
}

function openDialogAfterReload(pJS, height, width)
{
   if (height == null) height = 600;
    if (width == null) width = 350;
  setFormVariable('onLoadJS',"windowOpener('actionDialog.do?dialogType="+pJS+"',"+height+","+width+");");
}

// ************** LOV FUNCTIONS BEGIN *****************
// ************** LOV FUNCTIONS BEGIN *****************
// ************** LOV FUNCTIONS BEGIN *****************

var sSearchText = "";     // LOV pre-filter value
// LOV Hook -- LOV Window Initialized
function InitCallBack(params)
{
  // if DA changed searchText -- we will use searchText from DA, otherwise %
  if (sSearchText != "" && params["searchText"] == sSearchText)
      sSearchText = params["searchText"];
  else
    sSearchText = "%";
    
  //alert('Init:' + sSearchText);
  params["searchText"] = sSearchText;
  sSearchText = "";
  return true;
}
// LOV Hook -- LOV Window pre-load
function ValidateCallBack(params)
{
  // sValidateText = pre-filter value
  sSearchText = params["searchText"];
  //alert('Validate:' + sSearchText);
  return true;
}
// LOV Hook -- LOV Value Selected
function SelectCallBack(Win, field, event)
{
  //document.form0.lovPhoneType.value
  //params["searchText"] = sSearchText;
  //alert('Select');
  // selectedValue is set by the lov Window
  //field.value = Win.document.selectedValue;
  return true;
}
// LOV Hook -- On Blur
function BlurCallBack()
{
  // reset values for next LOV
  sSearchText = "";
  //alert('Blur');
  return true;
}
// ************** LOV FUNCTIONS END *****************
// ************** LOV FUNCTIONS END *****************
// ************** LOV FUNCTIONS END *****************
// *****************************************************************************
function validateMultipleEmails(str)
{
  var vSplit = ",";
  
  if (str.indexOf(vSplit) == -1)
  {
      return echeck(str);
  }
  else
  {
      var emailArray = str.split(vSplit);
      var partNum = 0;

      while (partNum < emailArray.length)
      {
        //alert(emailArray[partNum]);
        if (echeck(emailArray[partNum]) == false){
            return false;
            //break;
        }
        partNum += 1;
      }           
      return true;
  }
}
// *****************************************************************************
function emailCheck(field){
  echeck(field.value);
}
// *****************************************************************************
function echeck(str) {
		str = Trim(str);
    var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
    var eMsg = "Invalid Email ID, please click Cancel and Resubmit"
		if (str.indexOf(at)==-1){
		   alert(eMsg)
		   return false
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert(eMsg)
		   return false
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert(eMsg)
		    return false
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		    alert(eMsg)
		    return false
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert(eMsg)
		    return false
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID")
		    return false
		 }
		
		 if (str.indexOf(" ")!=-1){
		    alert(eMsg)
		    return false
		 }

 		 return true					
	}
// ***************************************************************************** 
function clearForm(form)
{
    for ( i = 0; i < form.elements.length; i++)
   {
      if (form.elements[i].type == "text")
      form.elements[i].value = "";
   }
}
// *****************************************************************************
// Start of Trim
function Trim(TRIM_VALUE)
{
  if(TRIM_VALUE.length < 1){
    return"";
  }
  
  TRIM_VALUE = RTrim(TRIM_VALUE);
  TRIM_VALUE = LTrim(TRIM_VALUE);
  
  if(TRIM_VALUE==""){
    return "";
  }
  else{
    return TRIM_VALUE;
  }
} //End Function

function RTrim(VALUE)
{
  var w_space = String.fromCharCode(32);
  var v_length = VALUE.length;
  var strTemp = "";
  
  if(v_length < 0){
  return"";
  }
  
  var iTemp = v_length -1;

  while(iTemp > -1)
  {
    if(VALUE.charAt(iTemp) == w_space){
    }
    else{
      strTemp = VALUE.substring(0,iTemp +1);
      break;
    }
    iTemp = iTemp-1;
  } //End While
  return strTemp;
} //End Function

function LTrim(VALUE)
{
  var w_space = String.fromCharCode(32);
  if(v_length < 1){
    return"";
  }
  var v_length = VALUE.length;
  var strTemp = "";

  var iTemp = 0;

  while(iTemp < v_length)
  {
    if(VALUE.charAt(iTemp) == w_space){
    }
    else{
      strTemp = VALUE.substring(iTemp,v_length);
      break;
    }
    iTemp = iTemp + 1;
  } //End While
  return strTemp;
} //End Function
// End of Trim
// *****************************************************************************
var editWin = null;
function editComment(id, header, cols, rows, width, height, notEditable) 
{ 
   if (editWin != null)
   {
      editWin.close();
   }
   obj = document.getElementById(id);
   if (obj == null)
   {
      return;
   }
  
   readOnly = " ";
   disabled = " ";

   if (notEditable == "true")
   {
      readOnly = " READONLY ";
      disabled = " DISABLED ";
   }
   
   html = "<html><head><meta http-equiv='Content-Type' content='text/html; charset=windows-1252'><title></title>" + 
          "</head><body><form name='form0' action='submit'>" + 
          "<h4><font color='31639C'>" + header + "</font></h4>" + 
          "<textarea name='comments' cols='" + cols + "' rows='" + rows + "'" + readOnly + ">" + obj.value + "</textarea><br/>" + 
          "<input type='hidden' name='id' value='" + id + "'/>" +
          "<input type='button' value='  OK  '" + disabled +  
          "onClick='self.opener.document.getElementById(document.form0.id.value).value = document.form0.comments.value; window.close(); return false;'/>" +
          "<input type='button' value='Cancel' onClick='window.close(); return false;'/>" + 
          "</form></body></html>";
   status = "toolbar=0,location=0,directories=0,status=0,menubar=0,scrollbars=0,resizable=1,width=" + width + ",height=" + height + ",top=20,left=20";
   editWin=window.open(null, "editWin", status);
   editWin.opener = self;
   editWin.document.open();
   editWin.document.write(html);
   editWin.document.close();
   editWin.focus(); 
} 
