var prefix;
var suffix;
var lovBASE = '/framework/';
//var lovBASE = 'http://iwebdev.fs.usda.gov:7780/framework/';
//var lovUSER = document.getElementById('lovUSER').value;
var juser='FSDBA';
var ppg = '8';
var mmpg = '100';
llovn='LOV_TEST';
tval='';
bbb=('1','2','3');
ccb=('1','2','3');
cbar=('1','2','3');
cpar='';
//Function to register lov
function JSFregisterLOV(t,elementId,lovn,cop,minc,luser,pg,mpg,cb,bb,wid,par) {
if (isLovMatch('lovField','lovField'))
{
 new CAPXOUS.AutoComplete(getMatchingElement(t.id).name, function() { 
 for (var i = 0; i<bbb.length; i++) {
 lovCallback(bbb[i],'');
		}
//alert(lovBASE + "lov/autocomplete_dynamic.jsp?username=" + juser + "&lov="+llovn+"&copy=copyId&pageSize="+ ppg + "&maxPages="+ mmpg +"&filter=" + this.text.value +cpar );
 return lovBASE + "lov/autocomplete_dynamic.jsp?username=" + juser + "&lov="+llovn+"&copy=copyId&pageSize="+ ppg + "&maxPages="+ mmpg +"&filter=" + this.text.value +cpar}, {width : wid , minChars : minc}); 

}
}
// handle Blur of LOV Fields
function blurLOV(el,eid,bl)
{
  var elementId = el.id;
  if (isLovMatch(suffix,eid))
  {
    //alert(prefix.replace(suffix,ccb[0]));
    var copyEl = getMatchingElement(prefix.replace(suffix,ccb[0]));
    if (el.value == '')
    {
       copyEl.value = '';
			 for (var i=0;i<bl.length; i++) {
				lovCallback(bl[i],''); }
       return true;
    }
    else if (el.value != copyEl.value)
      return mismatch(el);
  }
}

// Process callback in LOV Framework
// Function can be overridden here if necessary
function lovCallback(targetId, callbackValue)
{ 
  _lovCallback(prefix.replace(suffix,ccb[cbar.indexOf(targetId)]),callbackValue)
}

// Funtion to refgister lov if regitering using onfovus event.
function JSFreregisterLOV(t,elementId,lovn,cop,minc,luser,pg,mpg,cb,bb,wid,par)
{
  _lovOnFocus(t); // added by BWILCOX -- need to register focus or doubleClick event is ignored
  prefix= t.id;
  suffix=elementId;
  juser=luser;
  ppg=pg;
  mmpg=mpg;
  llovn=lovn;
  tval=t.value;
  bbb=bb;
  ccb=cb;
  cbar=bb;
	cpar=par;	
if (t.title != '_')
  {
    t.title = '_';
    JSFregisterLOV(t,elementId,lovn,cop,minc,luser,pg,mpg,cb,bb,wid,par);
  }
}
function include(file) {
  if (document.createElement && document.getElementsByTagName) {
    var head = document.getElementsByTagName('head')[0];
    var script = document.createElement('script');
    script.setAttribute('type', 'text/javascript');
    script.setAttribute('src', file);
    head.appendChild(script);
  } else {
    alert('Your browser does\'t handle the DOM standard well.');
  }
}
//include("http://iwebdev.fs.usda.gov:7780/framework/js/prototype.js"); 
//include("http://iwebdev.fs.usda.gov:7780/framework/js/capxous.js"); 
//include("http://iwebdev.fs.usda.gov:7780/framework/js/lovHelper.js"); 
//include("http://iwebdev.fs.usda.gov:7780/framework/js/datepicker.js");

