    function handleInboxTableDoubleClick(evt){   
        var table = evt.getSource();   
        var btnName = evt.getSource().getProperty('btnName'); 
        
        var popup = AdfPage.PAGE.findComponentByAbsoluteId('pt1:longRunningPopup');
        if (popup != null) {
            AdfPage.PAGE.addBusyStateListener(popup, busyStateListener);
            evt.preventUserInput();
        }        
        
    AdfCustomEvent.queue(table, "TableDoubleClickEvent", 
    {
        buttonName : btnName
    }, true);
    evt.cancel();
    }
    
    function handleInboxTableDoubleClickWO(evt){   
        var table = evt.getSource();   
        var btnName = evt.getSource().getProperty('btnName'); 
        
//        var popup = AdfPage.PAGE.findComponentByAbsoluteId('pt1:longRunningPopup');
//        if (popup != null) {
//            AdfPage.PAGE.addBusyStateListener(popup, busyStateListener);
//            evt.preventUserInput();
//        }        
        
        AdfCustomEvent.queue(table, "TableDoubleClickEvent", 
        {
            buttonName : btnName
        }, true);
        evt.cancel();
    }    
    
    function longRunningTask(evt) {
        var popup = AdfPage.PAGE.findComponentByAbsoluteId('pt1:longRunningPopup');
        if (popup != null) {
            AdfPage.PAGE.addBusyStateListener(popup, busyStateListener);
            evt.preventUserInput();
        }
    }    
    
    function handleInboxTableDoubleClickProp(evt){   
        if (dashBoard == 'Dashboard') {
            return;
        }
        var table = evt.getSource();   
        var btnName = evt.getSource().getProperty('btnName'); 
        
        var popup = AdfPage.PAGE.findComponentByAbsoluteId('pt1:longRunningPopup');
        if (popup != null) {
            AdfPage.PAGE.addBusyStateListener(popup, busyStateListener);
            evt.preventUserInput();
        }        
        
        AdfCustomEvent.queue(table, "TableDoubleClickEvent", 
        {
            buttonName : btnName
        }, true);
        evt.cancel();
    }   
    
    function busyStateListener(evt) {
        var popup = AdfPage.PAGE.findComponentByAbsoluteId('pt1:longRunningPopup');
        if (popup != null) {
            if (evt.isBusy()) {
                popup.show();
            }
            else if (popup.isPopupVisible()) {
                popup.hide();
                AdfPage.PAGE.removeBusyStateListener(popup, busyStateListener);
            }
        }
    }    
    
    function confirmMessageDialog(msg) {
        return confirm(msg);
    }
    
    function confirmMessageDelete(event) {
        if (!confirmMessageDialog('Are you sure you want to delete?')) {
            event.cancel();
        }
    }
    
    function confirmMessageRefresh(event) {
        if (!confirmMessageDialog('Are you sure you want to refresh the current page ?')) {
            event.cancel();
        }
    }
    
 function setUpperCase(event) {
        var eventSource = event.getSource();
        eventSource.setValue(eventSource.getValue().toUpperCase());
 }    

function toDate(event) {
    var eventSource = event.getSource();
    var inputData = eventSource.getValue();
    var result;
    // eventSource.setValue(eventSource.getValue().toUpperCase());
    var currentYear = new Date().getFullYear();
    var temp = inputData;
    
    if (inputData != null) {
        if (isNaN(inputData)) {
            alert("Please enter the valid Year");
            eventSource.setValue("");
            return;
        }
        if ((inputData.length == 2) && (!isNaN(inputData))) {
            result = 19 + inputData;
            if (result < (currentYear - 50)) {
                result = 20 + inputData;
            }    
            eventSource.setValue(result)            
        }   
        if (inputData > (currentYear + 50)) {
            eventSource.setValue("");
            alert("Please enter the valid Year");
        } else {
            
        }
    }
}
function setUpperCase(event) {
        var eventSource = event.getSource();
    
        eventSource.setValue(eventSource.getValue().toUpperCase());
    }    
    
    function returnClick(evt){
        var currentUrl = window.location.href;
        
        window.history.back();
        
        window.onload=setTimeout(function(){
        if(currentUrl === window.location.href) {  // if location was not changed in 1000 ms, then there is no history back
            var msg=confirm("Are you sure you want to exit G&A? You will lose any unsaved data." );
            if (msg) {
                window.close(); // close the window
            }         
        }}, 1000);
    
}


//open LOV of af:inputListOfValues with a double click
function handleLovOnDblclick(evt){
  var lovComp = evt.getSource();
  if (lovComp instanceof AdfRichInputListOfValues &&
      lovComp.getReadOnly()==false){
        AdfLaunchPopupEvent.queue(lovComp,true);
  }
}

function isExistElement(id) {
    var result = false;
    var HiddenMenuInfo = document.getElementById(id);
    var HiddenMenuInfoData;
    if (HiddenMenuInfo != null && HiddenMenuInfo != undefined) {
        HiddenMenuInfoData = HiddenMenuInfo.value;
        result = true;
    } else {
        
    }
    
    return result;
}

function closepage(event){
    window.close();
}

function openAttach(evt) {
    var attachWin = null;
    source = evt.getSource();
    url = source.getProperty("url");
    if (url != null && url != "") {
        attachWin = window.open(url);
    }
}

function handleKeyClick (event) {
     var btnComponent = event.getSource();   
     var locName = event.getSource().getProperty('locName'); 
     AdfCustomEvent.queue(btnComponent,"ToolbarReturnServerServerEvent", 
                        {
                   //       fvalue:component.getSubmittedValue()
                         },true);
     window.location = locName;
     event.cancel();
} 

function openUrl(url) {
    window.open(url);
}


function DateValid(event)  {
    
    var EnteredDate= event.getSource().getValue();
   
    var id=  event.getSource().getId();
    var today = new Date();
    if(EnteredDate.getFullYear() > today.getFullYear())
      { 
       alert(id+ " cannot be greater than todays Date ");
       event.cancel();
      }
      else if(EnteredDate.getMonth() > today.getMonth()){
           alert(id+ " cannot be greater than todays Date ");
                event.cancel();
      }
      else if(EnteredDate.getDate() > today.getDate()){
           alert(id+ " cannot be greater than todays Date ");
           event.cancel();
      }
    
 }
    
