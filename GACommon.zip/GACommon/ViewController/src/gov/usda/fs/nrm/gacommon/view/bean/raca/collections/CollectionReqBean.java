package gov.usda.fs.nrm.gacommon.view.bean.raca.collections;

import gov.usda.fs.nrm.framework.utils.NRMUtils;
import gov.usda.fs.nrm.gacommon.view.bean.raca.RacaBean;
import gov.usda.fs.nrm.gacommon.view.utils.ADFUtils;
import gov.usda.fs.nrm.framework.view.utils.IWebViewUtils;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.application.ViewHandler;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;

import javax.servlet.http.HttpServletRequest;

import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.view.rich.component.rich.data.RichTable;
import oracle.adf.view.rich.component.rich.input.RichInputDate;
import oracle.adf.view.rich.component.rich.input.RichInputListOfValues;
import oracle.adf.view.rich.component.rich.input.RichInputText;
import oracle.adf.view.rich.component.rich.input.RichSelectBooleanCheckbox;
import oracle.adf.view.rich.component.rich.input.RichSelectOneChoice;
import oracle.adf.view.rich.component.rich.input.RichSelectOneRadio;
import oracle.adf.view.rich.component.rich.layout.RichPanelGroupLayout;

import oracle.binding.OperationBinding;

import oracle.jbo.Row;
import oracle.jbo.ViewObject;
import oracle.jbo.uicli.binding.JUCtrlValueBindingRef;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.myfaces.trinidad.context.RequestContext;
import org.apache.myfaces.trinidad.event.ReturnEvent;
import org.apache.myfaces.trinidad.event.SelectionEvent;
import org.apache.myfaces.trinidad.model.RowKeySet;
//import org.apache.myfaces.trinidad.model.CurrencySet;

public class CollectionReqBean extends RacaBean {

    private static Logger log = LogManager.getLogger(CollectionReqBean.class);
    public String statusCmdId;
    public String dialogHeader;
    public String dialogFooter;
    private RichInputDate verifiedDate;
    private RichInputDate receivedDate;
    private RichTable collectionsTable;
    private RichInputText status;      // Request Status  
    private RichInputText statusA;     // Agreement Status
    private RichPanelGroupLayout agreementPanelGroup;
    private RichInputText securityId;
    private RichInputText projectTitle;
    private RichInputDate expirationDate;
    private RichSelectOneRadio assessOverhead;
    private RichSelectBooleanCheckbox fsh1909131a;
    private RichSelectBooleanCheckbox fsh1909131b;
    private RichSelectBooleanCheckbox fsh1909133;
    private RichSelectOneChoice collectionType;
    private RichSelectOneChoice statusSelectionA;    //6/11/15
    private RichInputText cooperatorAgmtNo;
    private RichInputText ffisAgmtNo;
    private RichInputText cooperatorCashContribution;
    private RichInputText jobCodesA;
    private RichInputText branchHandlingAgmt;
    private RichInputDate effectiveDate;
    private RichInputDate closedDateByFin;
    private RichInputText fund;
    private RichInputText program;
    private RichInputText rptg;
    private RichInputText commentsA;
    private RichSelectOneRadio assessOverheadDocumented;
    private RichPanelGroupLayout collectionReqPanelGroup;
    private RichInputText budgetOrg;
    private RichSelectOneChoice transmittalPurpose;
    private RichSelectBooleanCheckbox fs6500243;
    private RichInputText managingContCn;
    private RichInputListOfValues     programInputListBinding;
    private String reportURI;
    public CollectionReqBean() {
    }

    /**
     * statusDialogAction
     * @return
     */
    public String statusDialogAction() {
        String retValue;
        retValue = "dialog:statusChange";
  
        if (log.isDebugEnabled()) {          
            log.debug("statusDialogAction: " + retValue);
            log.debug("getStatusCmdId: " + getStatusCmdId());
        }

        //Object oldKey = getCollectionsTable().getRowKey();
        //log.debug("oldKey: " + oldKey.toString());
        
        if (!IWebViewUtils.commitNoMessage())
            retValue = null;
                    
        return null;   
    }

    /**
     * statusReqActiveDialogAction
     * @return
     */
    public String statusReqActiveDialogAction() {
        String retValue;
        retValue = "dialog:statusChange";
    
        if (log.isDebugEnabled()) {          
            log.debug("statusReqActiveDialogAction: " + retValue);
            log.debug("getStatusCmdId: " + getStatusCmdId());
        }  
        
        if (!IWebViewUtils.commitNoMessage())
            retValue = null;

        //check that Collection Type is not blank        
        if (getGACommonService().isCollectionTypeEmpty()){
            String message = "Collection Type cannot be blank when request status is set to ACTIVE.";
            IWebViewUtils.addMessage(FacesMessage.SEVERITY_ERROR, message, (String) null);
            retValue = null;                        
        }
                    
        return null;   
    }

    /**
     * statusReqSubmittedDialogAction
     * @return
     */
    public String statusReqSubmittedDialogAction() {
        String retValue;
        retValue = "dialog:statusChange";
    
        if (log.isDebugEnabled()) {          
            log.debug("statusReqSubmittedDialogAction: " + retValue);
            log.debug("getStatusCmdId: " + getStatusCmdId());
        }  
        
        if (!IWebViewUtils.commitNoMessage())
            retValue = null;

        //check Decision radio button        
        if (!getGACommonService().isAssessOverheadDocumented()){
            String message = "Decision whether or not to assessed overhead is not documented.";
            IWebViewUtils.addMessage(FacesMessage.SEVERITY_ERROR, message, (String) null);
            retValue = null;                        
        }
        // BASE DEV000566 : 4.1 - G&A: Require validation of PRC at submittal of collection request 
        if (!getGACommonService().isContactLinked("PRC")){
            String message = "Project Contact (PRC) is required before submitting a request.";
            IWebViewUtils.addMessage(FacesMessage.SEVERITY_ERROR, message, (String) null);
            retValue = null;   
        }
        
        return null;   
    }
    
    /**
     * statusAgmtDialogReturn 
     * Handles Agreement Status Dialog Return
     * @param returnEvent
     */
    public void statusAgmtDialogReturn(ReturnEvent returnEvent) {
        if (returnEvent.getReturnValue() != null) {            
            IWebViewUtils.commitNoMessage();
            getGACommonService().executeViewQuery("RacaAgmtView");
        
            getStatusA().resetValue();

            RequestContext adfContext = RequestContext.getCurrentInstance();
            if(adfContext != null){
                log.debug("getStatusA: " + getStatusA().getValue());
                adfContext.addPartialTarget(getStatusA());
               // adfContext.addPartialTarget(getAgreementPanelButtonBar());              
            }

        }
    }
    
    /**
     * statusReqDialogReturn
     * Handles Request Status Dialog Return
     * @param returnEvent
     */
    public void statusReqDialogReturn(ReturnEvent returnEvent) {
        log.debug("start statusReqDialogReturn: ");
        RequestContext afContext = RequestContext.getCurrentInstance(); 
        if (returnEvent.getReturnValue() != null) {                        
            IWebViewUtils.commitNoMessage();            
            getGACommonService().executeViewQuery("RacaReqsView");
 
            // Set Raca Req Current Row Key stored in the process scope
            Object rowKey = afContext.getProcessScope().get("rowKey");    
            log.debug("rowKey: " + rowKey); 
            if (rowKey != null){
                    setRacaReqRowKey(rowKey);
            }
    
            getStatus().resetValue();
            getVerifiedDate().resetValue();
            getReceivedDate().resetValue();
            getCooperatorCashContribution().resetValue();
    
    //        FacesContext context = FacesContext.getCurrentInstance();
    //        Application app = context.getApplication();
    //        ValueBinding bind = app.createValueBinding("#{bindings.VerifiedDate.inputValue}");
    //        String verifiedDt = (String)bind.getValue(context);
    //        log.debug("verifiedDt : " + verifiedDt);
    //        bind.setValue(context, new java.util.Date());
    
    //        JSFUtils.setExpressionValue("#{bindings.VerifiedDate.inputValue}", new java.util.Date());
    //        getGACommonService().sync();
            
    //        DCBindingContainer bindingContainer = getBindingContainer();
    //        bindingContainer.refresh();
    //        
    //        //getGACommonService().findViewObject("RacaReqsView");
    //        ViewObject view = getGACommonService().findViewObject("RacaReqsView");
    //        view.executeQuery();        
    //
    //        RacaReqsViewImpl view = (RacaReqsViewImpl)getApplicationModule().findViewObject("RacaReqsView");
    //        view.clearCache();
    //        view.executeQuery();
    
    //        refreshView();
            
            RequestContext adfContext = RequestContext.getCurrentInstance();
            if(adfContext != null){
                log.debug("getVerifiedDate: " + getVerifiedDate().getValue());
                adfContext.addPartialTarget(getStatus());
                adfContext.addPartialTarget(getVerifiedDate());
                adfContext.addPartialTarget(getCollectionsTable());
                
                // refresh agreement fields 
                adfContext.addPartialTarget(getStatusA());
                log.debug("getReceivedDate: " + getReceivedDate().getValue());
                adfContext.addPartialTarget(getReceivedDate());
              //  adfContext.addPartialTarget(getAgreementPanelButtonBar()); 
                adfContext.addPartialTarget(getCooperatorCashContribution());
            }
        }
        refreshCurrentPage();
    }

    protected void refreshCurrentPage() { 
            FacesContext context = FacesContext.getCurrentInstance(); 
            if(context != null){
                String currentView = context.getViewRoot().getViewId();  
                ViewHandler vh = context.getApplication().getViewHandler(); 
                UIViewRoot x = vh.createView(context, currentView); 
                context.setViewRoot(x);     
            }
        }
    public void setStatusCmdId(String statusCmdId) {
        this.statusCmdId = statusCmdId;
    }

    public String getStatusCmdId() {
        return statusCmdId;
    }

    public void setDialogHeader(String dialogTitle) {
        this.dialogHeader = dialogTitle;
    }

    public String getDialogHeader() {
        return dialogHeader;
    }

    public void setDialogFooter(String dialogFooter) {
        this.dialogFooter = dialogFooter;
    }

    public String getDialogFooter() {
        return dialogFooter;
    }

    public void setVerifiedDate(RichInputDate verifiedDate) {
        this.verifiedDate = verifiedDate;
    }

    public RichInputDate getVerifiedDate() {
        return verifiedDate;
    }

    public void setReceivedDate(RichInputDate receivedDate) {
        this.receivedDate = receivedDate;
    }

    public RichInputDate getReceivedDate() {
        return receivedDate;
    }

    public void setCollectionsTable(RichTable collectionsTable) {
        this.collectionsTable = collectionsTable;
    }

    public RichTable getCollectionsTable() {
        return collectionsTable;
    }

    public void setStatus(RichInputText status) {
        this.status = status;
    }

    public RichInputText getStatus() {
        return status;
    }
    /*  6/11/15 Duk modified
    public void setStatusA(RichInputText statusA) {
        this.statusA = statusA;
    }

    public RichInputText getStatusA() {
        return statusA;
    }
    */
    public void setStatusA(RichSelectOneChoice statusSelectionA) {
        this.statusSelectionA = statusSelectionA;
    }

    public RichSelectOneChoice getStatusA() {
        return statusSelectionA;
    }    

    /**
     * sudsAgmtIdRetListener
     * @param returnEvent
     */
    public void sudsAgmtIdRetListener(ReturnEvent returnEvent) {
        log.debug("sudsAgmtIdRetListener");
        if (returnEvent.getReturnValue() != null) {
            String lovSudsCn = (String)returnEvent.getReturnParameters().get("sudsCn");
            log.debug("lovSudsCn : " + lovSudsCn);
            getGACommonService().setRacaAgmtCurrentRowByCn(lovSudsCn);
            //getGACommonService().executeViewQuery("RacaAgmtView");
            getGACommonService().sync();
            
//            DCIteratorBinding iterator = ADFUtils.findIterator("RacaAgmtViewIterator");
//            iterator.refresh(1);
//            ViewObject vo = iterator.getViewObject();
//            vo.executeQuery();
//            Row row = vo.getCurrentRow();
//            log.debug("ProjectTitle : " + row.getAttribute("ProjectTitle"));                      
//            BindingContext bindingCtx = ADFUtils.getDCBindingContainer().getBindingContext();     
//            refreshBindingContainer(bindingCtx.findBindingContainer("global_content_agreementContextPageDef"));
                     
            // bug: force update hidden field managingContCn
            String lovManagingContCn = (String)returnEvent.getReturnParameters().get("managingContCn");
            log.debug("lovManagingContCn : " + lovManagingContCn);
            getManagingContCn().setSubmittedValue(lovManagingContCn);

            // reset controls
            getProjectTitle().resetValue();
            log.debug("getProjectTitle().getValue() : " + getProjectTitle().getValue());
            getCollectionType().resetValue();
            getCooperatorAgmtNo().resetValue();
            getFfisAgmtNo().resetValue();
            getCooperatorCashContribution().resetValue();
            getJobCodesA().resetValue();
            getBranchHandlingAgmt().resetValue();
            getStatusA().resetValue();
            getExpirationDate().resetValue();
            getEffectiveDate().resetValue();
            getReceivedDate().resetValue();
            getClosedDateByFin().resetValue();
            getFund().resetValue();
            getProgram().resetValue();
            getRptg().resetValue();
            getCommentsA().resetValue();
            getAssessOverheadDocumented().setSubmittedValue("0");
            getAssessOverhead().setSubmittedValue("0");
            getFsh1909131a().resetValue();
            getFsh1909131b().resetValue();
            getFsh1909133().resetValue();
            
            //refresh table
            //getCollectionsTable().processUpdates(FacesContext.getCurrentInstance());
                       
            // refresh screen
            RequestContext adfContext = RequestContext.getCurrentInstance();
            if (adfContext != null) {
                adfContext.addPartialTarget(getAgreementPanelGroup());
                adfContext.addPartialTarget(getCollectionsTable());
                adfContext.addPartialTarget(getCollectionReqPanelGroup());
            }
        }
    }

    /**
     * selectSudsAgmtIdActListener
     * @param actionEvent
     */
    public void selectSudsAgmtIdActListener(ActionEvent actionEvent) {
        RequestContext afContext = RequestContext.getCurrentInstance();
        ViewObject view = getGACommonService().findViewObject("LovSUDSAgmts");    
        Row row = view.getCurrentRow();
        
        Map values = new HashMap();
        String sudsId = (String)row.getAttribute("Id");
        String sudsCn = (String)row.getAttribute("Cn");
        String securityId = (String)row.getAttribute("SecurityId");
        String managingContCn = (String)row.getAttribute("ManagingContCn");
        values.put("sudsCn", sudsCn);
        values.put("securityId", securityId);
        values.put("managingContCn", managingContCn);
        
        log.debug("selectSudsAgmtIdActListener:sudsCn: " + sudsCn);
        
        afContext.returnFromDialog(sudsCn, values);
        afContext.getProcessScope().clear();
        
        // reset LOV options
        view.executeQuery();
        view.first();
    }
    
    /**
    * cancelActListener
    * @param actionEvent
    */
    public void cancelActListener(ActionEvent actionEvent) {
        RequestContext.getCurrentInstance().returnFromDialog(null, null);
    }

    /**
     * setRacaReqRowKey
     * @param rowKey
     */
    public void setRacaReqRowKey(Object rowKey) {
        RichTable table = getCollectionsTable();        
        JUCtrlValueBindingRef binding = null;
        table.setRowKey(rowKey);
        Object row = table.getRowData();                   
        binding = (JUCtrlValueBindingRef)row;
        if (binding != null) {
            binding.makeCurrentRow();
//            Row actualRow = binding.getRow();
//            Object racaReqNo = actualRow.getAttribute("RacaReqNo");
//            log.debug("racaReqNo: " + racaReqNo); 
        }
    }

    /**
     * onRacaReqSelection
     * @param selectionEvent
     */
    public void onRacaReqSelection(SelectionEvent selectionEvent){
        //log.debug("onRacaReqSelection:start ");
        RequestContext afContext=RequestContext.getCurrentInstance();
        //CurrencySet state = selectionEvent.getSelectedKeys();
        RowKeySet state=getCollectionsTable().getSelectedRowKeys();
        if(state!=null){
            Iterator selection=state.iterator();
            RichTable table=getCollectionsTable();
            JUCtrlValueBindingRef binding  =null;
            while(selection!=null&&selection.hasNext()){
                if(table!=null){
                    Object rowKey=selection.next();
                    afContext.getProcessScope().put("rowKey",rowKey);
                    //log.debug("rowKey: " + rowKey.toString());
                    table.setRowKey(rowKey);
                    Object row=table.getRowData();
                    binding=(JUCtrlValueBindingRef)row;
                    if(binding!=null){
                        binding.makeCurrentRow();
                        //                        Row actualRow = binding.getRow();
                        //                        Object racaReqNo = actualRow.getAttribute("RacaReqNo");
                        //                        log.debug("racaReqNo: " + racaReqNo);
                    }
                }
            }
        }
    }
    
//    /**
//     * onRacaReqRangeChange
//     * @param rangeChangeEvent
//     */
//    public void onRacaReqRangeChange(RangeChangeEvent rangeChangeEvent) {
//        log.debug("onRacaReqRangeChange:start "); 
//        DCBindingContainer dc = IWebViewUtils.getBindingContainer();
//        JUCtrlValueBindingRef ctrlValuDef = (JUCtrlValueBindingRef)getCollectionsTable().getRowData(rangeChangeEvent.getNewStart());
//        if (dc != null && ctrlValuDef != null) {
//            Row firstRow = ctrlValuDef.getRow();
//            log.debug("firstRow " + firstRow.getKey().toString()); 
//            DCIteratorBinding dciter = (DCIteratorBinding)dc.get("RacaReqsViewIterator");
//            if (dciter != null && firstRow != null) {
//                dciter.setCurrentRowWithKey(firstRow.getKey().toStringFormat(true));
//                AdfFacesContext.getCurrentInstance().addPartialTarget(getCollectionsTable());
//            }
//        }
//    }

    public void setAgreementPanelGroup(RichPanelGroupLayout agreementPanelGroup) {
        this.agreementPanelGroup = agreementPanelGroup;
    }

    public RichPanelGroupLayout getAgreementPanelGroup() {
        return agreementPanelGroup;
    }

    public void setSecurityId(RichInputText securityId) {
        this.securityId = securityId;
    }

    public RichInputText getSecurityId() {
        return securityId;
    }

    public void setManagingContCn(RichInputText managingContCn) {
        this.managingContCn = managingContCn;
    }

    public RichInputText getManagingContCn() {
        return managingContCn;
    }

    public void setProjectTitle(RichInputText projectTitle) {
        this.projectTitle = projectTitle;
    }

    public RichInputText getProjectTitle() {
        return projectTitle;
    }

    public void setExpirationDate(RichInputDate expirationDate) {
        this.expirationDate = expirationDate;
    }

    public RichInputDate getExpirationDate() {
        return expirationDate;
    }

    public void setAssessOverhead(RichSelectOneRadio assessOverhead) {
        this.assessOverhead = assessOverhead;
    }

    public RichSelectOneRadio getAssessOverhead() {
        return assessOverhead;
    }

    public void setFsh1909131a(RichSelectBooleanCheckbox fsh1909131a) {
        this.fsh1909131a = fsh1909131a;
    }

    public RichSelectBooleanCheckbox getFsh1909131a() {
        return fsh1909131a;
    }

    public void setFsh1909131b(RichSelectBooleanCheckbox fsh1909131b) {
        this.fsh1909131b = fsh1909131b;
    }

    public RichSelectBooleanCheckbox getFsh1909131b() {
        return fsh1909131b;
    }

    public void setFsh1909133(RichSelectBooleanCheckbox fsh1909133) {
        this.fsh1909133 = fsh1909133;
    }

    public RichSelectBooleanCheckbox getFsh1909133() {
        return fsh1909133;
    }

    public void setCollectionType(RichSelectOneChoice collectionType) {
        this.collectionType = collectionType;
    }

    public RichSelectOneChoice getCollectionType() {
        return collectionType;
    }

    public void setCooperatorAgmtNo(RichInputText cooperatorAgmtNo) {
        this.cooperatorAgmtNo = cooperatorAgmtNo;
    }

    public RichInputText getCooperatorAgmtNo() {
        return cooperatorAgmtNo;
    }

    public void setFfisAgmtNo(RichInputText ffisAgmtNo) {
        this.ffisAgmtNo = ffisAgmtNo;
    }

    public RichInputText getFfisAgmtNo() {
        return ffisAgmtNo;
    }

    public void setCooperatorCashContribution(RichInputText cooperatorCashContribution) {
        this.cooperatorCashContribution = cooperatorCashContribution;
    }

    public RichInputText getCooperatorCashContribution() {
        return cooperatorCashContribution;
    }

    public void setJobCodesA(RichInputText jobCodesA) {
        this.jobCodesA = jobCodesA;
    }

    public RichInputText getJobCodesA() {
        return jobCodesA;
    }

    public void setBranchHandlingAgmt(RichInputText branchHandlingAgmt) {
        this.branchHandlingAgmt = branchHandlingAgmt;
    }

    public RichInputText getBranchHandlingAgmt() {
        return branchHandlingAgmt;
    }

    public void setEffectiveDate(RichInputDate effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public RichInputDate getEffectiveDate() {
        return effectiveDate;
    }

    public void setClosedDateByFin(RichInputDate closedDateByFin) {
        this.closedDateByFin = closedDateByFin;
    }

    public RichInputDate getClosedDateByFin() {
        return closedDateByFin;
    }

    public void setFund(RichInputText fund) {
        this.fund = fund;
    }

    public RichInputText getFund() {
        return fund;
    }

    public void setProgram(RichInputText program) {
        this.program = program;
    }

    public RichInputText getProgram() {
        return program;
    }

    public void setRptg(RichInputText rptg) {
        this.rptg = rptg;
    }

    public RichInputText getRptg() {
        return rptg;
    }

    public void setCommentsA(RichInputText commentsA) {
        this.commentsA = commentsA;
    }

    public RichInputText getCommentsA() {
        return commentsA;
    }

    public void setAssessOverheadDocumented(RichSelectOneRadio assessOverheadDocumented) {
        this.assessOverheadDocumented = assessOverheadDocumented;
    }

    public RichSelectOneRadio getAssessOverheadDocumented() {
        return assessOverheadDocumented;
    }

    public void setCollectionReqPanelGroup(RichPanelGroupLayout collectionReqPanelGroup) {
        this.collectionReqPanelGroup = collectionReqPanelGroup;
    }

    public RichPanelGroupLayout getCollectionReqPanelGroup() {
        return collectionReqPanelGroup;
    }

    

    /**
     * selectBudgetOrgActListener
     * @param actionEvent
     */
    public void selectBudgetOrgActListener(ActionEvent actionEvent) {
        RequestContext afContext = RequestContext.getCurrentInstance();
        ViewObject view = getGACommonService().findViewObject("LovBudgetOrg");    
        Row row = view.getCurrentRow();
        
        Map values = new HashMap();
        String budgetOrgCode = (String)row.getAttribute("BudgetOrgCode");
        values.put("budgetOrgCode", budgetOrgCode);
        
        log.debug("selectBudgetOrgActListener:budgetOrgCode: " + budgetOrgCode);
        
        afContext.returnFromDialog(budgetOrgCode, values);
        afContext.getProcessScope().clear();
        
        // reset LOV options
        view.executeQuery();
        view.first();
    }

    /**
     * budgetOrgRetListener from Dialog Lov
     * @param returnEvent
     */
    public void budgetOrgRetListener(ReturnEvent returnEvent) {
        log.debug("budgetOrgRetListener");
        if (returnEvent.getReturnValue() != null) {
            String budgetOrgCode = (String)returnEvent.getReturnParameters().get("budgetOrgCode");
            log.debug("budgetOrgCode : " + budgetOrgCode);
            getBudgetOrg().setSubmittedValue(budgetOrgCode);
        }
    }

    /**
     * transmittalPurposeValueChListener
     * @param valueChangeEvent
     */
    public void transmittalPurposeValueChListener(ValueChangeEvent valueChangeEvent) {
        String transmittalValue = (String) valueChangeEvent.getNewValue();
        //log.debug("transmittalValue Event: " + transmittalValue);
        if ("4".equalsIgnoreCase(transmittalValue)){
            getFs6500243().setRendered(true);
        }
        else
            getFs6500243().setRendered(false);
    }
    
    public void setBudgetOrg(RichInputText budgetOrg) {
        this.budgetOrg = budgetOrg;
    }

    public RichInputText getBudgetOrg() {
        return budgetOrg;
    }

    public void setTransmittalPurpose(RichSelectOneChoice transmittalPurpose) {
        this.transmittalPurpose = transmittalPurpose;
    }

    public RichSelectOneChoice getTransmittalPurpose() {
        return transmittalPurpose;
    }

    public void setFs6500243(RichSelectBooleanCheckbox fs6500243) {
        this.fs6500243 = fs6500243;
    }

    public RichSelectBooleanCheckbox getFs6500243() {
        return fs6500243;
    }
    
    public String getContactBASE() {
        String url = "";
         OperationBinding op =   ADFUtils.findOperation("getDomainName");
         if (null != op){
          url= (String)op.execute();
         }
     
        if (! url.endsWith("/")) {
            url = url + "/";
        }
        
        return url;
    } 
    
    
    public String getReportBASE() {
        String url = "";
         OperationBinding op =   ADFUtils.findOperation("getReportServerName");
         if (null != op){
          url= (String)op.execute();
         }
     System.out.println("url report"+url);
    
        
        return url;
    }  
    
    
    
    
    
    private String getURLSession() {
        FacesContext ctx = FacesContext.getCurrentInstance();
        HttpServletRequest servletRequest = (HttpServletRequest) ctx.getExternalContext().getRequest();
        String sessionParam = servletRequest.getParameter("_adf.ctrl-state");
        log.debug("sessionParam: " + sessionParam);
        
        return sessionParam;
    }
    

    // 3/30/15 Duk added
    public String getReturnString() {
        StringBuffer returnScript = new StringBuffer();
        String base = getContactBASE();
        String sessionParam = getURLSession();
        System.out.println("getIWebRequestParameters Vlaue -->"+IWebViewUtils.getIWebRequestParameters());
      //  String fp1 = IWebViewUtils.getIWebRequestParameters().getFp1();
      //String fp1 = getCnRacaAgmtView();
      //  String fp7 = IWebViewUtils.getIWebRequestParameters().getFp7();
      //  String getRefreshParentUrl = IWebViewUtils.getIWebRequestParameters().getFp8();
        
         String getRefreshParentUrl = "/grants/faces/inboxCollections";
        String fp1 = NRMUtils.getParameter("fp1");
        String fp2 = NRMUtils.getParameter("fp2");
        String fp3 = NRMUtils.getParameter("fp3");
        String fp4 = NRMUtils.getParameter("fp4");
        String fp7 =  NRMUtils.getParameter("fp7");
        String fp9=  NRMUtils.getParameter("fp9");
        String fp8 =  NRMUtils.getParameter("fp8");
        String fp5 = null;       
        /* 4/4/15 Duk modified
        if (fp7 == null || fp7.length() == 0) {
            //returnScript = "windowOpenerWHeader('/ga/details.do?fp1=#{bindings.CnA.inputValue}','800','600');";
            returnScript.append("windowOpenerWHeader('/ga/details.do?fp1=");
            returnScript.append(fp1);
            returnScript.append("','800','600');");
        } else {
            //returnScript.append("window.opener.location.href='").append("http://127.0.0.1:7101" + getRefreshParentUrl).append("?fp4=RELOAD_COLLECTIONS");
            returnScript.append("window.opener.location.href='").append(getRefreshParentUrl).append("?fp4=RELOAD_COLLECTIONS");
            returnScript.append("&" + fp7 + "';");
            returnScript.append("setTimeout('window.close()',1);");
            //returnScript.append("setTimeout('window.close()',1);");
        }
        */
        // if (fp7 == null || fp7.length() == 0) {
           if(getRefreshParentUrl!=null &&  getRefreshParentUrl.indexOf("inboxCollections")>0) {// this is fp8 value and it needs to checked to know whether the request is coming 
                                                                    //from inbox or agreement collections tab
             //returnScript = "windowOpenerWHeader('/ga/details.do?fp1=#{bindings.CnA.inputValue}','800','600');";
            
             returnScript.append("/grants/faces/details?fp1=");
             returnScript.append(fp1);
             returnScript.append("&fp2=LOAD_FROM_RACA");
            
        
             //returnScript.append("setTimeout('window.close()',1);");   // 4/8/15 Duk deleted          
         } else {
              returnScript.append(getRefreshParentUrl).append("?fp4=RELOAD_COLLECTIONS");
             // returnScript.append("window.opener.location.href='").append(getRefreshParentUrl).append("?fp4=RELOAD_COLLECTIONS");
              returnScript.append("&" + fp7 + "';");
          
            
            //returnScript.append("setTimeout('window.close()',1);");
//              ReturnBean returnBean = (ReturnBean)JSFUtils.getManagedBeanValue("returnBean");
//              returnBean.setDisabled(Boolean.valueOf(true));
    }
           System.out.println("Go Aggremt -->>"+base+returnScript.toString()+sessionParam);
           return base+returnScript.toString()+sessionParam;
    }
    private String getCnRacaAgmtView() {
       
        DCIteratorBinding roleIter=ADFUtils.findIterator("RacaAgmtViewIterator");
       
       // ViewObject view = getGACommonService().findViewObject("RacaAgmtView");    
        Row row =  roleIter.getCurrentRow();
        if(row!=null)
        return (String)row.getAttribute("Cn");
        else
        return "";
    }
    
    /*
     public boolean isFp7Available() {
         String fp7 = IWebViewUtils.getIWebRequestParameters().getFp7();

         return (fp7 == null || fp7.length() == 0) ? false: true;
     }
     *
    public String getRefreshParentUrl() {
        Object url = IWebViewUtils.getIWebRequestParameters().getFp8();
        return (url == null ? null : url.toString());

    }

    public String getFp7() {
        Object url = IWebViewUtils.getIWebRequestParameters().getFp7();
        return (url == null ? null : url.toString());
    }
    */
    public void setProgramInputListBinding(RichInputListOfValues programInputListBinding){
        this.programInputListBinding=programInputListBinding;
    }

    public RichInputListOfValues getProgramInputListBinding(){
        return programInputListBinding;
    }
    
    public String getReportURL() {
        String base = getContactBASE();
        String reportURl= getReportBASE();
        System.out.println("reportURl"+getReportBASE());
        String attr1= "reports/rwservlet?report=ga_racap&amp;destype=cache&amp;desformat=PDF&amp;server=";
        String attr2=reportURl;
        String attr3="&amp;paramform=NO&amp;ssoconn=forms9i_sso&amp;p_grant_cn=";
        //anas
        String attr4=(String)ADFUtils.getBoundAttributeValue("Cn");
                             
        String sessionParam = getURLSession();
        System.out.println("session contact  URL"+ base+attr1 +attr2 + attr3+attr4+ sessionParam);

       
        return base+attr1 +attr2 + attr3+attr4+ sessionParam;
    }
    



    public String getJobReportURL() {
//"/reports/rwservlet?report=ga_rjcnl&amp;destype=cache&amp;desformat=PDF&amp;server=#{sessionScope.reportServerName}&amp;paramform=NO&amp;ssoconn=forms9i_sso&amp;p_jobcode_cn=#{bindings.RacaJobCodeNotifViewCn.inputValue}"

        String base = getContactBASE();
        String reportURl= getReportBASE();
        System.out.println("reportURl"+getReportBASE());
        String attr1= "reports/rwservlet?report=ga_racap&amp;destype=cache&amp;desformat=PDF&amp;server=";
        String attr2=reportURl;
        String attr3="&amp;paramform=NO&amp;ssoconn=forms9i_sso&amp;p_jobcode_cn=";
        //anas
        String attr4=(String)ADFUtils.getBoundAttributeValue("RacaJobCodeNotifViewCn");
                             
        String sessionParam = getURLSession();
        System.out.println("session contact  URL"+ base+attr1 +attr2 + attr3+attr4+ sessionParam);

       
        return base+attr1 +attr2 + attr3+attr4+ sessionParam;
    }
    
}
