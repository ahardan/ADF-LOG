package gov.usda.fs.nrm.gacommon.view.bean.raca;


import gov.usda.fs.nrm.framework.view.utils.IWebViewUtils;

import javax.faces.event.ActionEvent;

import oracle.adf.view.rich.component.rich.data.RichTable;
import oracle.adf.view.rich.component.rich.input.RichInputText;
import oracle.adf.view.rich.component.rich.layout.RichPanelGroupLayout;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.myfaces.trinidad.component.core.layout.CorePanelButtonBar;
import org.apache.myfaces.trinidad.context.RequestContext;
import org.apache.myfaces.trinidad.event.ReturnEvent;

public class JobCodeNotifBean extends RacaBean {

    private static Logger log = LogManager.getLogger(JobCodeNotifBean.class);
    public String jclTotalAmount;
    public String jclTotalBurden;
    public String jclTotalNetAvail;
    private RichInputText jobCodeStatus;
    private CorePanelButtonBar jcPanelButtonBar;
    private RichTable jobCodeLinesTable;
    private RichPanelGroupLayout jobCodePanelGroup;

    public JobCodeNotifBean() {
    }
    
    /**
     * onJCLCalculateActListener
     * It calculates Job Code Lines Totals
     * @param actionEvent
     */
    public void onJCLCalculateActListener(ActionEvent actionEvent) {
         //log.debug("onJCLCalculateActListener: " );   
         IWebViewUtils.commitNoMessage();
         setJclTotalAmount(getGACommonService().calcTotal("RacaJobCodeNotifLinesView", "AgmtAmount"));
         setJclTotalBurden(getGACommonService().calcTotal("RacaJobCodeNotifLinesView", "BurdenAmount"));
         setJclTotalNetAvail(getGACommonService().calcTotal("RacaJobCodeNotifLinesView", "NetSpending"));         
         //AdfFacesContext.getCurrentInstance().addPartialTarget(jobCodePanelGroup);
    }
          
    /**
     * statusJobCodeSendDialogAction
     * @return
     */
    public String statusJobCodeSendDialogAction() {
        String retValue;
        retValue = "dialog:statusChange";
        
        System.out.println("Inside Job Code Notify Sent ");
        if (log.isDebugEnabled()) {          
            log.debug("statusJobCodeSendDialogAction: " + retValue);
            //log.debug("getStatusCmdId: " + getStatusCmdId());
        }  
        
        if (!IWebViewUtils.commitNoMessage())
            retValue = null;
                    
        return retValue;   
    }

    /**
     * statusJobCodeDialogReturn
     * @param returnEvent
     */
    public void statusJobCodeDialogReturn(ReturnEvent returnEvent) {
        log.debug("start statusJobCodeDialogReturn: ");
        RequestContext afContext = RequestContext.getCurrentInstance(); 
        if (returnEvent.getReturnValue() != null) {                        
            IWebViewUtils.commitNoMessage();            
            getGACommonService().executeViewQuery("RacaJobCodeNotifView");
            getJobCodeStatus().resetValue();

            RequestContext adfContext = RequestContext.getCurrentInstance();
            if(adfContext != null){
                log.debug("getJobCodeStatus: " + getJobCodeStatus().getValue());
                adfContext.addPartialTarget(getJobCodeStatus());
                adfContext.addPartialTarget(getJcPanelButtonBar());              
            }
        }
    }
    
    public void setJclTotalAmount(String jclTotalAmount) {
        this.jclTotalAmount = jclTotalAmount;
    }

    public String getJclTotalAmount() {
        return jclTotalAmount;
    }

    public void setJclTotalBurden(String jclTotalBurden) {
        this.jclTotalBurden = jclTotalBurden;
    }

    public String getJclTotalBurden() {
        return jclTotalBurden;
    }

    public void setJclTotalNetAvail(String jclTotalNetAvail) {
        this.jclTotalNetAvail = jclTotalNetAvail;
    }

    public String getJclTotalNetAvail() {
        return jclTotalNetAvail;
    }

    public void setJobCodeStatus(RichInputText jobCodeStatus) {
        this.jobCodeStatus = jobCodeStatus;
    }

    public RichInputText getJobCodeStatus() {
        return jobCodeStatus;
    }

    public void setJcPanelButtonBar(CorePanelButtonBar jcPanelButtonBar) {
        this.jcPanelButtonBar = jcPanelButtonBar;
    }

    public CorePanelButtonBar getJcPanelButtonBar() {
        return jcPanelButtonBar;
    }

    public void setJobCodeLinesTable(RichTable jobCodeLinesTable) {
        this.jobCodeLinesTable = jobCodeLinesTable;
    }

    public RichTable getJobCodeLinesTable() {
        return jobCodeLinesTable;
    }

    public void setJobCodePanelGroup(RichPanelGroupLayout jobCodePanelGroup) {
        this.jobCodePanelGroup = jobCodePanelGroup;
    }

    public RichPanelGroupLayout getJobCodePanelGroup() {
        return jobCodePanelGroup;
    }
    

}
