package gov.usda.fs.nrm.gacommon.view.bean.raca;


import gov.usda.fs.nrm.framework.utils.JSFUtils;
import gov.usda.fs.nrm.framework.view.utils.IWebViewUtils;
import gov.usda.fs.nrm.gacommon.model.service.common.GACommonService;
import gov.usda.fs.nrm.gacommon.view.utils.ADFUtils;

import java.io.Serializable;

import javax.faces.context.FacesContext;

import javax.servlet.http.HttpServletRequest;

import oracle.adf.view.rich.component.rich.layout.RichPanelGroupLayout;
import oracle.adf.view.rich.context.AdfFacesContext;

import oracle.binding.OperationBinding;

import oracle.jbo.Row;
import oracle.jbo.ViewObject;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.myfaces.trinidad.event.SelectionEvent;

public class RacaContactsBean implements Serializable{
    @SuppressWarnings("compatibility:760251684810191706")
    private static final long    serialVersionUID=1L;
    private static Logger        log             =LogManager.getLogger(RacaContactsBean.class);
    private RichPanelGroupLayout grouplayout;

    public RacaContactsBean(){
    }

    // 3/10/15 Duk added
    private String getURLSession(){
        FacesContext       ctx           =FacesContext.getCurrentInstance();
        HttpServletRequest servletRequest=(HttpServletRequest)ctx.getExternalContext().getRequest();
        String             sessionParam  =servletRequest.getParameter("_adf.ctrl-state");
        log.debug("sessionParam: "+sessionParam);

        return sessionParam;
    }

    public String getContactURL(){
        //contactsapp/faces/searchContact.jspx?initSession=Y&amp;fpAction=link&amp;fp1=#{bindings.CnA}&amp;fp2=ACCOMPLISHMENT_INSTRUMENT&amp;fp3=GA-CONTACT&amp;fp6=GA&amp;fp7=XXXX&amp;fp8=/raca/faces/contacts/layouts/contactsLayout.jspx','800','600');"/>

        String base =getContactBASE();
        String attr1=
            "contactsapp/faces/search.jsf?initSession=Y&fp8=/gacommon/faces/raca&fpAction=link&fp7=XXXX&fp6=GA&fp5=Y&fp3=GA-CONTACT&fp2=ACCOMPLISHMENT_INSTRUMENT&fp1=";
        //anas
        String attr2=(String)ADFUtils.getBoundAttributeValue("CnA");

        String sessionParam=getURLSession();
        System.out.println("session contact  URL"+base+attr1+attr2+"&fp9=_adf.ctrl-state%3d"+sessionParam);

        //return base + attr1 + attr2;
        return base+attr1+attr2+"&fp9=_adf.ctrl-state%3d"+sessionParam;
    }


    public String getContactBASE(){
        String           url="";
        OperationBinding op =ADFUtils.findOperation("getDomainName");
        if(null!=op){
            url=(String)op.execute();
        }

        if(!url.endsWith("/")){
            url=url+"/";
        }

        return url;
    }


    private GACommonService getApplicationModule(){
        return (GACommonService)IWebViewUtils.getApplicationModule();
    }

    private ViewObject getViewObject(GACommonService appModule,String viewName){
        return appModule.findViewObject(viewName);
    }


    public String getContactURLEdit(){
        // uix   https://nrmdev.fs.usda.gov/contactsapp/faces/searchContact.jspx?restart=9&fpAction=edit&fp8=/ga/cooperators.do&fp7=XXXX&fp6=GA&CN=147901010602&fp3=GA-COOPERATOR&fp2=ACCOMPLISHMENT_INSTRUMENT&fp1=4274449010848&fp5=Y

        String base=getContactBASE();
        //contactsapp/faces/searchContact.jspx?initSession=Y&amp;fpAction=edit&amp;fp1=#{bindings.CnA}&amp;fp2=ACCOMPLISHMENT_INSTRUMENT&amp;fp3=GA-CONTACT&amp;CN=#{bindings.ContCn}&amp;fp5=Y&amp;fp6=GA&amp;fp7=XXXX&amp;fp8=/raca/faces/contacts/layouts/contactsLayout.jspx'

        String attr1=
            "contactsapp/faces/editPerson.jsf?initSession=Y&fp8=/gacommon/faces/raca&fpAction=edit&fp7=XXXX&fp6=GA&fp3=GA-CONTACT&fp2=ACCOMPLISHMENT_INSTRUMENT&fp5=Y&fp1=";
        GACommonService appModule              =getApplicationModule();
        ViewObject      voContactsLinksView    =getViewObject(appModule,"ContactsLinksView");
        Row             currentRowAddressesView=voContactsLinksView.getCurrentRow();
        String          accinst_CN             ="";
        String          cont_CN                ="";
        String          sessionParam           =getURLSession();

        if(currentRowAddressesView!=null){
            accinst_CN=(String)currentRowAddressesView.getAttribute("AccinstCn");
            cont_CN=(String)currentRowAddressesView.getAttribute("ContCn");
        }
        System.out.println("session contact  URL"+base+attr1+accinst_CN+"&CN="+cont_CN+"&fp9=_adf.ctrl-state%3d"+
                           sessionParam);
        //return base + attr1 + accinst_CN + "&CN=" + cont_CN;
        return base+attr1+accinst_CN+"&CN="+cont_CN+"&fp9=_adf.ctrl-state%3d"+sessionParam;
    }

    public void selectionlistener(SelectionEvent selectionEvent){

        JSFUtils.resolveMethodExpression("#{bindings.ContactsLinksView.collectionModel.makeCurrent}",null,
                                         new Class[]{ SelectionEvent.class },new Object[]{ selectionEvent });
        getContactURLEdit();
        AdfFacesContext.getCurrentInstance().addPartialTarget(getgrouplayout());

    }

    public void setgrouplayout(RichPanelGroupLayout grouplayout){
        this.grouplayout=grouplayout;
    }

    public RichPanelGroupLayout getgrouplayout(){
        return grouplayout;
    }


}
