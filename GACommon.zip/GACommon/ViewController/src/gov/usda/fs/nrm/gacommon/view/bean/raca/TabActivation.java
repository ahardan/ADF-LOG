package gov.usda.fs.nrm.gacommon.view.bean.raca;

import java.io.Serializable;

public class TabActivation implements Serializable{
    @SuppressWarnings("compatibility:-1589616948161648761")
    private static final long serialVersionUID=1L;
    private String tabClicked ;
    public TabActivation(){
        super();
    }

    public void setTabClicked(String tabClicked){
        this.tabClicked=tabClicked;
    }

    public String getTabClicked(){
        return tabClicked;
    }
}
