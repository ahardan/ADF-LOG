package gov.usda.fs.nrm.gacommon.view.bean;

import java.io.IOException;
import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;

import oracle.adf.controller.ControllerContext;
import oracle.adf.share.ADFContext;


/**
 *
 * @author Naveen Jonnalagadda
 *
 *
 */

public class SkinManagerBean implements Serializable {


    @SuppressWarnings("compatibility:-2536732871901561510")
    private static final long serialVersionUID = 1L;
    
    
    public SkinManagerBean() {
        ADFContext adfctx = ADFContext.getCurrent();
        Map sessionScope = adfctx.getSessionScope();
        Object skinFamily = sessionScope.get("skinFamily");
        if(skinFamily == null){
            sessionScope.put("skinFamily", "gacommon-fusion");
        }
    }

    public List getSkinChoices() {
        
        // limit the choices for the users
        List choices = new ArrayList();
        choices.add(new SelectItem("gacommon-fusion", "gacommon-fusion"));
        choices.add(new SelectItem("fusionFx", "fusionFx"));
        choices.add(new SelectItem("fusion", "fusion"));
        choices.add(new SelectItem("blafplus", "blafplus"));
        choices.add(new SelectItem("blafplus-rich", "blafplus-rich"));
        choices.add(new SelectItem("blafplus-medium", "blafplus-medium"));
        choices.add(new SelectItem("fusionFx-simple", "fusionFx-simple"));
        choices.add(new SelectItem("fusion-simple", "fusion-simple"));
        choices.add(new SelectItem("fusion-base", "fusion-base"));
        //choices.add(new SelectItem("twitter", "twitter"));
                
        return choices;                
        
    }

    public void onNewSkinSelection(ValueChangeEvent valueChangeEvent) {
        ADFContext adfctx = ADFContext.getCurrent();
        Map sessionScope = adfctx.getSessionScope();
        sessionScope.put("skinFamily", (String) valueChangeEvent.getNewValue());
        redirectToSelf();
    }

    private void redirectToSelf() {
        FacesContext fctx = FacesContext.getCurrentInstance();
        ExternalContext ectx = fctx.getExternalContext();
        String viewId = fctx.getViewRoot().getViewId();
        ControllerContext controllerCtx = null;
        controllerCtx = ControllerContext.getInstance();
        String activityURL = controllerCtx.getGlobalViewActivityURL(viewId);
        try {
            ectx.redirect(activityURL);
            fctx.responseComplete();
        } catch (IOException e) {
            //Can't redirect
            e.printStackTrace();
            fctx.renderResponse();
        }
    }
    
    
}
