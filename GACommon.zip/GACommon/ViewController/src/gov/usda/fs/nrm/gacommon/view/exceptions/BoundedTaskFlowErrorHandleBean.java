package gov.usda.fs.nrm.gacommon.view.exceptions;

import gov.usda.fs.nrm.framework.view.utils.IWebViewUtils;

import javax.faces.application.FacesMessage;

import oracle.adf.controller.ControllerContext;
import oracle.adf.controller.ViewPortContext;

public class BoundedTaskFlowErrorHandleBean {
    public BoundedTaskFlowErrorHandleBean() {
            super();
    }

    public void controllerExceptionHandler() {
   
         ControllerContext context = ControllerContext.getInstance();
         ViewPortContext currentRootViewPort = context.getCurrentRootViewPort();
         Exception exceptionData = currentRootViewPort.getExceptionData();
         
         if (currentRootViewPort.isExceptionPresent()) {
             exceptionData.printStackTrace();
             currentRootViewPort.clearException();

             String message = exceptionData.getMessage();


             //if (message.indexOf("JBO-27024") >= 0 )
             //{                 
             //  if ( message.indexOf("GaCommitments") >= 0 )                   
             //        message = "Failed to validate 1 or more Commitments. Review Transaction for Completeness";
             //}

             // since there is no direct way to remove error,
             // remove 'product code-error code: ' from the message
             // example message to strip out - oracle.jbo.JboException: JBO-100041:
             // oracle.jbo.JboException: JBO-100041: Can only change status back to a previously used status             
             while (message.indexOf("oracle.jbo.JboException:") >= 0 || message.indexOf("JBO-") >= 0){
                 if (message.indexOf("oracle.jbo.JboException:") >= 0)
                     message = message.substring(message.indexOf(":") + 2);
                 if (message.indexOf("JBO-") >= 0)
                     message = message.substring(message.indexOf(":") + 2);
             }    
             IWebViewUtils.addMessage(FacesMessage.SEVERITY_ERROR, message, (String) null);             
         }
    }
}
