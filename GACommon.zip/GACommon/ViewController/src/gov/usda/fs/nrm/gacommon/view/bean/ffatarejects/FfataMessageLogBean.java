package gov.usda.fs.nrm.gacommon.view.bean.ffatarejects;


import gov.usda.fs.nrm.framework.binding.IWebInitialBindingContainer;
import gov.usda.fs.nrm.framework.utils.ADFUtils;
import gov.usda.fs.nrm.framework.view.IWebBaseBackingBean;

import gov.usda.fs.nrm.framework.view.utils.IWebViewUtils;

import gov.usda.fs.nrm.gacommon.model.service.GACommonServiceImpl;

import javax.faces.application.FacesMessage;
import javax.faces.event.ActionEvent;

import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCIteratorBinding;

import oracle.jbo.ViewObject;


public class FfataMessageLogBean extends  IWebBaseBackingBean{

     public FfataMessageLogBean() {
     }


    public void ProcessMessageLog(ActionEvent actionEvent) {
        //Refresh the Table
        String rtn = "0";
        BindingContext bindingCtx = ADFUtils.getDCBindingContainer().getBindingContext();                
        GACommonServiceImpl am =  (GACommonServiceImpl)IWebViewUtils.getApplicationModule();  
        rtn = am.setProcessRejects();
        
        DCIteratorBinding iterator = ADFUtils.findIterator("FfataMessageLogViewIterator");
        ViewObject vo = iterator.getViewObject();
        
        //      System.out.println("CurrentCn =" + feaCnFp1);
        
        vo.executeQuery();
        refreshBindingContainer(bindingCtx.findBindingContainer("FfataMessageLogViewIterator"));
        IWebViewUtils.addMessage(FacesMessage.SEVERITY_INFO, "Process Rejects",rtn+" Records were saved and processed ");
        
     //     IWebViewUtils.addPartialTarget("MessageLogTblId", actionEvent.getSource());
      
    }
 
      public void ProcessSent(ActionEvent actionEvent) {
          //Refresh the Table
          String rtn = "0";
           BindingContext bindingCtx = ADFUtils.getDCBindingContainer().getBindingContext();                
          GACommonServiceImpl am =  (GACommonServiceImpl)IWebViewUtils.getApplicationModule();  
          rtn = am.setProcessSent();
          
          DCIteratorBinding iterator = ADFUtils.findIterator("FfataMessageLogViewIterator");
          ViewObject vo = iterator.getViewObject();
          
          //      System.out.println("CurrentCn =" + feaCnFp1);
          
          vo.executeQuery();
          refreshBindingContainer(bindingCtx.findBindingContainer("FfataMessageLogViewIterator"));
          IWebViewUtils.addMessage(FacesMessage.SEVERITY_INFO, "Process Sent",rtn+" Records were saved and processed");
          
       //     IWebViewUtils.addPartialTarget("MessageLogTblId", actionEvent.getSource());
        
      }

    
    protected void refreshBindingContainer(DCBindingContainer bc)
    {
       if (bc instanceof IWebInitialBindingContainer)      
       {
          ((IWebInitialBindingContainer)bc).resetIteratorRefreshOption();
       }
    }    
}
