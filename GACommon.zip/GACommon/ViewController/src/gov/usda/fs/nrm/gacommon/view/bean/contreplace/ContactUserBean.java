package gov.usda.fs.nrm.gacommon.view.bean.contreplace;
import gov.usda.fs.nrm.framework.view.IWebBaseBackingBean;

import org.apache.log4j.*;

public class ContactUserBean
  extends IWebBaseBackingBean
{
  private static Logger log = LogManager.getLogger(ContactGrantBean.class);
}

