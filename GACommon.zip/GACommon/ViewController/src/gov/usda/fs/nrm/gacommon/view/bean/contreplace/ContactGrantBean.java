package gov.usda.fs.nrm.gacommon.view.bean.contreplace;

import gov.usda.fs.nrm.framework.utils.ADFUtils;
import gov.usda.fs.nrm.framework.view.utils.IWebViewUtils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.faces.application.FacesMessage;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import oracle.adf.model.binding.DCIteratorBinding;


import oracle.adf.view.rich.component.rich.data.RichTable;

import oracle.adf.view.rich.component.rich.input.RichInputText;
import oracle.adf.view.rich.component.rich.input.RichSelectOneChoice;
import oracle.adf.view.rich.context.AdfFacesContext;


import oracle.adf.view.rich.event.DialogEvent;
import oracle.adf.view.rich.event.PopupFetchEvent;

import org.apache.myfaces.trinidad.event.LaunchEvent;


import oracle.jbo.Key;
import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;
import oracle.jbo.ViewObject;
import oracle.jbo.server.ViewRowImpl;
import oracle.jbo.uicli.binding.JUCtrlHierNodeBinding;

import org.apache.log4j.*;
import org.apache.myfaces.trinidad.event.ReturnEvent;


public class ContactGrantBean
  extends ContactBaseBean
{
  private static Logger log = LogManager.getLogger(ContactGrantBean.class);
  private RichInputText contSourceId;
  private RichInputText contTargetId;
  private RichInputText contSourceCn;
  
  private void $init$()
  {
    this.grantsArray = new ArrayList();
  }
  
  private String strContSourceCn;
  private String strContTargetCn;
  private RichTable grantTable;
  public ContactGrantBean()
  {
    $init$();
  }
  




  public void selManyGrantsActListener(ActionEvent actionEvent)
  {
    RichTable table = getGrantTable();
    DCIteratorBinding grantIter = ADFUtils.findIterator("ContactGrantViewIterator");
    RowSetIterator grantRSIter = grantIter.getRowSetIterator();
    


    getGrantsArray().clear();
    setListOfCns("");
    
    Iterator selection = table.getSelectedRowKeys().iterator();
    while (selection.hasNext()) {
      Object key = selection.next();
      //ViewRowImpl row = (ViewRowImpl)grantRSIter.getRow(key);
      table.setRowKey(key);
      JUCtrlHierNodeBinding node = (JUCtrlHierNodeBinding)table.getRowData();
      Row row =   node.getRow();
      if (row != null) {
        String cn = (String)row.getAttribute("Cn");
        log.debug("cn : " + cn);
        if (getListOfCns().length() > 1) {
          setListOfCns(getListOfCns() + ", ");
        }
        setListOfCns(getListOfCns() + "'" + cn + "'");
        getGrantsArray().add(cn);
      }
    }
    
    log.debug("getListOfCns() : " + getListOfCns());
    
    getRacaService().filterGrants(getListOfCns());
  }
  



  public void selAllGrantsActListener(ActionEvent actionEvent)
  {
    getGrantsArray().addAll((Collection)getRacaService().filterAllListedGrants());
  }
  



  public String selManyGrantsAction()
  {
    String retValue = null;
    if (getGrantsArray().size() > 0) {
      retValue = "filteredGrantsPage";
    }
    else {
      String message = "Please select one or more Grant records before you click on 'Continue'";
      IWebViewUtils.addMessage(FacesMessage.SEVERITY_ERROR, message, (String)null);
    }
    

    if (getStrContTargetCn() == null) {
      retValue = null;
      String message = "Please select a valid value for field 'To Contact ID'";
      IWebViewUtils.addMessage(FacesMessage.SEVERITY_ERROR, message, (String)null);
    }
    

    return retValue;
  }
  



  public void orgValueActListener(ValueChangeEvent vEvent)
  {
    int rowIdx = ((Integer)vEvent.getNewValue()).intValue();
    log.debug("rowIdx : " + rowIdx);
    
    rowIdx -= 1;
    if (rowIdx == -1) {
      setStrOrgCn("%");
      setStrOrg("ALL");
    }
    else {
      DCIteratorBinding orgIter = ADFUtils.findIterator("LovOrgsIterator");
      RowSetIterator iterRSIter = orgIter.getRowSetIterator();
      
      iterRSIter.setCurrentRowAtRangeIndex(rowIdx);
      
      Row row = iterRSIter.getCurrentRow();
      setStrOrgCn((String)row.getAttribute("ManagingContCn"));
      setStrOrg((String)row.getAttribute("Org"));
    }
  }
  
  private ArrayList grantsArray;
  private String listOfCns;
  private RichSelectOneChoice org;
  private String strOrgCn;
  private String strOrg;
  private String contactCmdId;
  public void searchGrantsActListener(ActionEvent actionEvent) {
    getRacaService().searchGrants(getStrContSourceCn(), getStrOrgCn());
  }
  




  public void clearSearchActListener(ActionEvent actionEvent)
  {
    clearSearchScreen();
  }
  


  public void clearSearchScreen()
  {
    getContSourceId().setValue("");
    getContSourceCn().setValue("");
    getContTargetId().setValue("");
    setStrContTargetCn(null);
    setStrContSourceCn(null);
    getOrg().resetValue();
    setStrOrg(null);
    setStrOrgCn(null);
    getRacaService().searchGrants("0", null);
  }
  



  public void contLaunchListener(LaunchEvent launchEvent)
  {
    FacesContext context = FacesContext.getCurrentInstance();
    setContactCmdId(launchEvent.getComponent().getClientId(context));
    log.debug("getContactCmdId() : " + getContactCmdId());
    
    if (getContactCmdId() != null) {
      launchEvent.getDialogParameters().put("contactCmdId", getContactCmdId());
    }
  }
  



  public void contIdRetListener(ReturnEvent returnEvent)
  {
    AdfFacesContext adfContext = AdfFacesContext.getCurrentInstance();
    
    if (returnEvent.getReturnValue() != null) {
      String lovContactId = (String)returnEvent.getReturnParameters().get("contactId");
      String lovContactCn = (String)returnEvent.getReturnParameters().get("contactCn");
      String lovContactCmdId = (String)returnEvent.getReturnParameters().get("contactCmdId");
      log.debug("lovContactId : " + lovContactId);
      log.debug("lovContactCn : " + lovContactCn);
      log.debug("lovContactCmdId : " + lovContactCmdId);
      
      if (adfContext != null) {
       // if ("contSourceCmdId".equalsIgnoreCase(lovContactCmdId)) {
         if   (lovContactCmdId.contains("contSourceCmdId")){
          getContSourceId().setSubmittedValue(lovContactId);
          getContSourceCn().setSubmittedValue(lovContactCn);
          setStrContSourceCn(lovContactCn);
          
          getRacaService().filterOrgs(lovContactCn);
          
          adfContext.addPartialTarget(getOrg());
          adfContext.addPartialTarget(getContSourceId());
          adfContext.addPartialTarget(getContSourceCn());
        }
       // else if ("contTargetCmdId".equalsIgnoreCase(lovContactCmdId)) {
        // else   if ("contTargetCmdId".equalsIgnoreCase(lovContactCmdId)) {
             else   if (lovContactCmdId.contains("contTargetCmdId")){
          getContTargetId().setSubmittedValue(lovContactId);
          setStrContTargetCn(lovContactCn);
          log.debug("getStrContTargetCn : " + getStrContTargetCn());
          adfContext.addPartialTarget(getContTargetId());
        }
      }
    }
  }
  



  public void selectContIdActListener(ActionEvent actionEvent)
  {
    AdfFacesContext afContext = AdfFacesContext.getCurrentInstance();
    ViewObject view = getRacaService().findViewObject("LovContacts");
    Row row = view.getCurrentRow();
    
    setContactCmdId(afContext.getPageFlowScope().get("contactCmdId").toString());
    log.debug("getContactCmdId() : " + getContactCmdId());
    
    Map values = new HashMap();
    String contactId = (String)row.getAttribute("Id");
    String contactCn = (String)row.getAttribute("Cn");
    values.put("contactId", contactId);
    values.put("contactCn", contactCn);
    values.put("contactCmdId", getContactCmdId());
    
    afContext.returnFromDialog(contactId, values);
    afContext.getPageFlowScope().clear();
    


    view.executeQuery();
    view.first();
  }
  



  public void cancelActListener(ActionEvent actionEvent)
  {
    //RequestContext.getCurrentInstance().returnFromDialog(null, null);
    AdfFacesContext.getCurrentInstance().returnFromDialog(null, null);
  }
  



  public String backFilteredGrantsAction()
  {
    String retValue = null;
    retValue = "contactGrantsPage";
    
    return retValue;
  }
  



  public String processContactReplace()
  {
    String retValue = null;
    retValue = "contactGrantsPage";
    log.debug(toString());
    getRacaService().processContactReplace(getStrContSourceCn(), getStrContTargetCn(), getStrOrgCn(), getGrantsArray());
    clearSearchScreen();
    
    return retValue;
  }
  


  public String toString()
  {
    StringBuffer sb = new StringBuffer();
    sb.append("\n ContactGrantBean:");
    sb.append("\n getContSourceId().getValue(): " + getContSourceId().getValue());
    sb.append("\n getStrContSourceCn(): " + getStrContSourceCn());
    sb.append("\n getContTargetId().getValue(): " + getContTargetId().getValue());
    sb.append("\n getStrContTargetCn(): " + getStrContTargetCn());
    sb.append("\n getStrOrg: " + getStrOrg());
    sb.append("\n getStrOrgCn(): " + getStrOrgCn());
    sb.append("\n getListOfCns(): " + getListOfCns());
    sb.append("\n getGrantsArray().toString(): " + getGrantsArray().toString());
    
    return sb.toString();
  }
  
  public void setContSourceId(RichInputText contSourceId) { this.contSourceId = contSourceId; }
  

  public RichInputText getContSourceId()
  {
    return this.contSourceId;
  }
  
  public void setContSourceCn(RichInputText contSourceCn) { this.contSourceCn = contSourceCn; }
  

  public RichInputText getContSourceCn()
  {
    return this.contSourceCn;
  }
  
  public void setGrantTable(RichTable grantTable) { this.grantTable = grantTable; }
  

  public RichTable getGrantTable()
  {
    return this.grantTable;
  }
  
  public void setGrantsArray(ArrayList grantsArray) { this.grantsArray = grantsArray; }
  

  public ArrayList getGrantsArray()
  {
    return this.grantsArray;
  }
  
  public void setContTargetId(RichInputText contTargetId) { this.contTargetId = contTargetId; }
  

  public RichInputText getContTargetId()
  {
    return this.contTargetId;
  }
  
  public void setContactCmdId(String contactCmdId) { this.contactCmdId = contactCmdId; }
  

  public String getContactCmdId()
  {
    return this.contactCmdId;
  }
  
  public void setStrContTargetCn(String strContTargetCn) { this.strContTargetCn = strContTargetCn; }
  

  public String getStrContTargetCn()
  {
    return this.strContTargetCn;
  }
  
  public void setListOfCns(String listOfCns) { this.listOfCns = listOfCns; }
  

  public String getListOfCns()
  {
    return this.listOfCns;
  }
  
  public void setStrContSourceCn(String strContSourceCn) { this.strContSourceCn = strContSourceCn; }
  

  public String getStrContSourceCn()
  {
    return this.strContSourceCn;
  }
  
  public void setOrg(RichSelectOneChoice org) { this.org = org; }
  

  public RichSelectOneChoice getOrg()
  {
    return this.org;
  }
  
  public void setStrOrgCn(String strOrgCn) { this.strOrgCn = strOrgCn; }
  

  public String getStrOrgCn()
  {
    return this.strOrgCn;
  }
  
  public void setStrOrg(String strOrg) { this.strOrg = strOrg; }
  

  public String getStrOrg()
  {
    return this.strOrg;
  }


    public void onOpeningContact(ActionEvent actionEvent) {
        // Add event code here...
        getRacaService().searchContacts("", "", "");
        
       
    }

    public void onContactOpening(PopupFetchEvent popupFetchEvent) {
        
        System.out.println(popupFetchEvent.getLaunchSourceClientId()); 
        // Add event code here...
        
        AdfFacesContext.getCurrentInstance().getPageFlowScope().put("contactCmdId", popupFetchEvent.getLaunchSourceClientId());
        getRacaService().searchContacts("", "", "");
     
    }

    public void onContactSelect(DialogEvent dialogEvent) {
        // Add event code here...
        AdfFacesContext adfContext = AdfFacesContext.getCurrentInstance();
        ViewObject view = getRacaService().findViewObject("LovContacts");
        Row row = view.getCurrentRow();
        
        setContactCmdId(adfContext.getPageFlowScope().get("contactCmdId").toString()); 
        log.debug("getContactCmdId() : " + getContactCmdId());
        
        Map values = new HashMap();
        String contactId = (String)row.getAttribute("Id");
        String contactCn = (String)row.getAttribute("Cn");
        values.put("contactId", contactId);
        values.put("contactCn", contactCn);
        values.put("contactCmdId", getContactCmdId());
        
//        afContext.returnFromDialog(contactId, values);
//        afContext.getPageFlowScope().clear();
        


        view.executeQuery();
        view.first();
        if (getContactCmdId().contains("contSourceCmdId")){
            getContSourceId().setSubmittedValue(contactId);
            getContSourceCn().setSubmittedValue(contactCn);
            setStrContSourceCn(contactCn);
            
            getRacaService().filterOrgs(contactCn);
            
            adfContext.addPartialTarget(getOrg());
            adfContext.addPartialTarget(getContSourceId());
            adfContext.addPartialTarget(getContSourceCn());
        }
        else{
            getContTargetId().setSubmittedValue(contactId);
            setStrContTargetCn(contactCn);
            log.debug("getStrContTargetCn : " + getStrContTargetCn());
            adfContext.addPartialTarget(getContTargetId());
            
        }
        
     

    }
}

