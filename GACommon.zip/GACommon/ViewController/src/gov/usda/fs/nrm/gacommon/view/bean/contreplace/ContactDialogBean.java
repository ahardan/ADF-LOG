package gov.usda.fs.nrm.gacommon.view.bean.contreplace;

import gov.usda.fs.nrm.gacommon.model.service.common.GACommonService;
import gov.usda.fs.nrm.gacommon.view.bean.contreplace.ContactBaseBean;

import javax.faces.event.ActionEvent;

import oracle.adf.view.rich.component.rich.input.RichInputText;

import oracle.adf.view.rich.context.AdfFacesContext;
import oracle.adf.view.rich.event.PopupFetchEvent;

import org.apache.myfaces.trinidad.component.core.input.CoreInputText;
import org.apache.log4j.*;


public class ContactDialogBean
  extends ContactBaseBean
{
  private static Logger log = LogManager.getLogger(ContactDialogBean.class);
  

  private RichInputText id;
  

  private RichInputText lastName;
  
  private RichInputText firstName;
  

  public void searchContactsActListener(ActionEvent actionEvent)
  {
    String strId = "";
    String strLastName = "";
    String strFirstName = "";
    if (getId().getValue() != null) strId = getId().getValue().toString();
    if (getLastName().getValue() != null) strLastName = getLastName().getValue().toString();
    if (getFirstName().getValue() != null) strFirstName = getFirstName().getValue().toString();
    getRacaService().searchContacts(strId, strLastName, strFirstName);
    getFirstName().resetValue();
  }
  
   
  
  public void setId(RichInputText id) {
    this.id = id;
  }
  
  public RichInputText getId()
  {
    return this.id;
  }
  
  public void setLastName(RichInputText lastName) { this.lastName = lastName; }
  

  public RichInputText getLastName()
  {
    return this.lastName;
  }
  
  public void setFirstName(RichInputText firstName) { this.firstName = firstName; }
  

  public RichInputText getFirstName()
  {
    return this.firstName;
  }
  
    public void onContactOpening(PopupFetchEvent popupFetchEvent) {
        
        System.out.println(popupFetchEvent.getLaunchSourceClientId()); 
        // Add event code here...
        
        AdfFacesContext.getCurrentInstance().getPageFlowScope().put("contactCmdId", popupFetchEvent.getLaunchSourceClientId());
        getRacaService().searchContacts("", "", "");
        if (getFirstName() != null)
        {
        getFirstName().resetValue();
        }
        if (getLastName() != null)
        {
        getLastName().resetValue();
        }
     
    }
}
