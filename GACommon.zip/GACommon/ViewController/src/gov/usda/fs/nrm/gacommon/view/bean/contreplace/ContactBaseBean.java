package gov.usda.fs.nrm.gacommon.view.bean.contreplace;



import gov.usda.fs.nrm.framework.binding.IWebInitialBindingContainer;
import gov.usda.fs.nrm.framework.view.IWebBaseBackingBean;

import gov.usda.fs.nrm.framework.view.utils.IWebViewUtils;

import gov.usda.fs.nrm.gacommon.model.service.common.GACommonService;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import javax.faces.application.Application;
import javax.faces.application.NavigationHandler;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import oracle.adf.model.binding.DCBindingContainer;
import org.apache.log4j.*;




public class ContactBaseBean
  extends IWebBaseBackingBean
{
  private static Logger log = LogManager.getLogger(ContactBaseBean.class);
  

  public static final String ERROR_PAGE_URL = "../../../faces/global/validationMessages.jspx";
  

  public int maxRowCount;
  

  public boolean rowCountExceeded;
  
  public Hashtable errorWindowProperties;
  

  public GACommonService getRacaService()
  {
    return (GACommonService)IWebViewUtils.getApplicationModule("GACommonService");
  }
  




  public String getBeanName(String cardName, String action)
  {
    String beanName = cardName;
    if ("I".equalsIgnoreCase(action)) {
      beanName = beanName + "InsertBean";
    } else if ("D".equalsIgnoreCase(action)) {
      beanName = beanName + "DeleteBean";
    } else if ("R".equalsIgnoreCase(action)) {
      beanName = beanName + "RecursiveBean";
    } else {
      beanName = beanName + "ModifyBean";
    }
    
    return beanName;
  }
  
  protected void performNavigation(String outcome) { FacesContext context = FacesContext.getCurrentInstance();
    NavigationHandler nh = context.getApplication().getNavigationHandler();
    nh.handleNavigation(context, "", outcome);
  }
  
  public void setErrorWindowProperties(Hashtable errorWindowProperties) {
    this.errorWindowProperties = errorWindowProperties;
  }
  
  public Hashtable getErrorWindowProperties() {
    this.errorWindowProperties = new Hashtable();
    this.errorWindowProperties.put("width", "width=400");
    this.errorWindowProperties.put("height", "height=200");
    this.errorWindowProperties.put("toolbar", "toolbar=0");
    
    this.errorWindowProperties.put("location", "location=0");
    this.errorWindowProperties.put("menubar", "menubar=0");
    this.errorWindowProperties.put("top", "top=200");
    
    return this.errorWindowProperties;
  }
  
  public HttpSession getSession() { FacesContext context = FacesContext.getCurrentInstance();
    
    return (HttpSession)context.getExternalContext().getSession(true);
  }
  
  public void setMaxRowCount(int maxRowCount) {
    this.maxRowCount = maxRowCount;
  }
  
  public int getMaxRowCount()
  {
    return this.maxRowCount;
  }
  
  public void setRowCountExceeded(boolean rowCountExceeded) { this.rowCountExceeded = rowCountExceeded; }
  



  public boolean isRowCountExceeded() { return this.rowCountExceeded; }
  
  public String getRequestValue(String value) {
    FacesContext context = FacesContext.getCurrentInstance();
    ExternalContext extContext = context.getExternalContext();
    
    return (String)extContext.getRequestParameterMap().get(value);
  }
  





  public boolean isNullOrEmpty(String s)
  {
    return (s == null) || (s.equals(""));
  }
  



  protected void refreshBindingContainer(DCBindingContainer bc)
  {
    if ((bc instanceof IWebInitialBindingContainer))
    {
      ((IWebInitialBindingContainer)bc).resetIteratorRefreshOption();
    }
  }
  





  public void requestParams()
  {
    Iterator iter = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterNames();
    while (iter.hasNext())
    {
      String paramName = (String)iter.next();
      log.debug("paramName : " + paramName);
    }
  }
}
