package gov.usda.fs.nrm.gacommon.view.bean.raca;

import gov.usda.fs.nrm.framework.binding.IWebInitialBindingContainer;
import gov.usda.fs.nrm.framework.view.IWebBaseBackingBean;
import gov.usda.fs.nrm.framework.view.utils.IWebViewUtils;
import gov.usda.fs.nrm.gacommon.model.service.common.GACommonService;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Hashtable;

import javax.faces.application.NavigationHandler;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import javax.servlet.http.HttpSession;

import oracle.adf.model.binding.DCBindingContainer;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class RacaBean extends IWebBaseBackingBean {
    private static Logger log = LogManager.getLogger(RacaBean.class);
    
    public static final String ERROR_PAGE_URL = "../../../faces/global/validationMessages.jspx";
    public int maxRowCount;
    public boolean rowCountExceeded;
    public Hashtable errorWindowProperties;
    
    @SuppressWarnings("compatibility:-4631078578365499401")
    private static final long serialVersionUID = 1L;

    private boolean II_REG_PROJ_ADM_MGR;


    private boolean rolesPopulated = false;
     
    private HashMap<String, String> rolesMap = null;
    // this needs to be set by the individual tab
    private boolean pageReadOnly;
    private boolean validNAMPRole; 
    private String midtierFullDomainName;    
    private String userName = "";
    private boolean submitted;
    private String domainName ="";


    // have the session variables been read already?
    private boolean sessionVariablesRead = false;
    private String nampCn = "";
    
    private boolean decommissionPage = false;
    //private boolean otherFundingSourcesRequired = false;
    public RacaBean() {
    }
    
    /**
     * getGACommonService
     * @return GACommonService
     */
    public GACommonService getGACommonService(){
        GACommonService am = (GACommonService) IWebViewUtils.getApplicationModule("GACommonService");
    
    return (GACommonService)IWebViewUtils.getApplicationModule("GACommonService");
    }
    
 

    /**
     * getBeanName
     * @param cardName
     * @param action
     * @return
     */
    public String getBeanName(String cardName, String action){
        String beanName = cardName;
        if("I".equalsIgnoreCase(action)){
            beanName = beanName + "InsertBean";                
        }else if("D".equalsIgnoreCase(action)){
            beanName = beanName + "DeleteBean";
        }else if("R".equalsIgnoreCase(action)){
            beanName = beanName + "RecursiveBean";
        }else{
            beanName = beanName + "ModifyBean";
        }
        return beanName;
    }
    
    protected void performNavigation(String outcome) {
        FacesContext context = FacesContext.getCurrentInstance();
        NavigationHandler nh = context.getApplication().getNavigationHandler();
        nh.handleNavigation(context, "", outcome);
    }

    public void setErrorWindowProperties(Hashtable errorWindowProperties) {
        this.errorWindowProperties = errorWindowProperties;
    }

    public Hashtable getErrorWindowProperties() {
        errorWindowProperties = new Hashtable();
        errorWindowProperties.put("width", "width=400");
        errorWindowProperties.put("height", "height=200");
        errorWindowProperties.put("toolbar", "toolbar=0");
        //errorWindowProperties.put("modal", "modal=1");
        errorWindowProperties.put("location",  "location=0");
        errorWindowProperties.put("menubar",   "menubar=0");
        errorWindowProperties.put("top",   "top=200");   
        return errorWindowProperties;
    }   
    
    public HttpSession getSession() {
        FacesContext context = FacesContext.getCurrentInstance();
        return (HttpSession)context.getExternalContext().getSession(true);
    }


    public void setMaxRowCount(int maxRowCount) {
        this.maxRowCount = maxRowCount;
    }

    public int getMaxRowCount() {
        return maxRowCount;
    }

    public void setRowCountExceeded(boolean rowCountExceeded) {
        this.rowCountExceeded = rowCountExceeded;
    }

    public boolean isRowCountExceeded() {
        return rowCountExceeded;
    }

    public String getRequestValue(String value) {
        FacesContext context = FacesContext.getCurrentInstance();
        ExternalContext extContext = context.getExternalContext();
        return (String)extContext.getRequestParameterMap().get(value);
    }

    /**
     * Returns true if the string is either null or empty.
     *
     * @param s The string to evaluate
     * @return  True if the string is either null or empty.
     */
    public boolean isNullOrEmpty(String s) {
      return (s == null) || s.equals("");
    }

    /**
     * refreshBindingContainer
     * @param bc
     */
    protected void refreshBindingContainer(DCBindingContainer bc)
    {
       if (bc instanceof IWebInitialBindingContainer)      
       {
          ((IWebInitialBindingContainer)bc).resetIteratorRefreshOption();
       }
    }
    
//    public void processRoles(){
//        //UserBean userRacaBean = (UserBean)getSession().getAttribute("userBean");
//        userRacaBean = (UserBean) findBean("userBean");
//        log.debug("Roles : " + userRacaBean.getRoles());  
//
//        // remove all roles in case they were set already
//        getSession().removeAttribute("II_GA_SPEC");
//        getSession().removeAttribute("II_RACA_ASC");
//        
//        ArrayList roles = new ArrayList();
//        roles = userRacaBean.getRoles();
//        Iterator iter = roles.iterator();
//        while(iter.hasNext()){
//          String sRole = (String)iter.next();
//          //log.debug("sRole : " + sRole);
//          JSFUtils.storeOnSession(sRole,sRole);
//        }
//    }
    
        public void createSessionVariables() {
            
        log.debug("In createSessionVariables");
        if ( !sessionVariablesRead ) {  
            
            if ( rolesMap == null )
                rolesMap = new HashMap<String, String>();
            
            this.validNAMPRole =  isRoleExists("II_ADM_MGR")  || isRoleExists("II_BLDG_MGR") || isRoleExists("II_BMC_MGR") ||
                    isRoleExists("II_DAM_MGR")      || isRoleExists("II_DRS_MGR") || isRoleExists("II_DWS_MGR") ||
                    isRoleExists("II_RTE_MGR")   || isRoleExists("II_TRBR_MGR") || isRoleExists("II_WK_ITM_MGR") ||
                    isRoleExists("II_WWS_MGR")   || isRoleExists("II_REG_PROJ_ADM_MGR") ;
            
            //boolean isReadOnly = isRoleExists("INFRA READ ONLY");
            
            this.pageReadOnly =  isRoleExists("INFRA READ ONLY") || !this.validNAMPRole;
            
            sessionVariablesRead = true;

        }
            
    }
    

    public void setRolesMap(HashMap<String, String> rolesMap) {
        this.rolesMap = new HashMap<String, String>(rolesMap);
    }


    public boolean isProjAdmMgr() {
        return rolesMap.get("II_REG_PROJ_ADM_MGR") != null ? true : false;
    }


    public boolean isValidNampRole() {     
        return validNAMPRole;
    }

    public boolean isPageReadOnly() {
        return pageReadOnly;
    }

    public void setPageReadOnly(boolean pageReadOnly) {
        this.pageReadOnly = pageReadOnly;
    }


    public void setRolesPopulated(boolean rolesPopulated) {
        this.rolesPopulated = rolesPopulated;
    }

    public boolean isRolesPopulated() {
        return rolesPopulated;
    }


    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserName() {
        return userName.toUpperCase();
    }

   
    public boolean isRoleExists(String role) {
        return rolesMap.get(role) != null ? true : false;
    }


    public void setMidtierFullDomainName(String midtierFullDomainName) {
        this.midtierFullDomainName = midtierFullDomainName;
    }

    public String getMidtierFullDomainName() {
        return midtierFullDomainName;
    }


    public void setNampCn(String nampCn) {
        this.nampCn = nampCn;
    }

    public String getNampCn() {
        return nampCn;
    }
    
    public java.util.Date getCurrentDate() {
        Calendar cal = Calendar.getInstance();
        cal.set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH),23,59,59);
            
        return cal.getTime();

    }


    public void setDecommissionPage(boolean decommissionPage) {
        this.decommissionPage = decommissionPage;
    }

    public boolean isDecommissionPage() {
        return decommissionPage;
    }

//    public void setOtherFundingSourcesRequired(boolean otherFundingSourcesRequired) {
//        this.otherFundingSourcesRequired = otherFundingSourcesRequired;
//    }
//
//    public boolean isOtherFundingSourcesRequired() {
//        return otherFundingSourcesRequired;
//    }

    public void setSubmitted(boolean submitted) {
        this.submitted = submitted;
    }

    public boolean isSubmitted() {
        return submitted;
    }

    public void setDomainName(String domainName){
        this.domainName=domainName;
    }

    public String getDomainName(){
        return domainName;
    }
    
}
