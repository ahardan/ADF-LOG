package gov.usda.fs.nrm.gacommon.view.bean.raca.collections;

import gov.usda.fs.nrm.gacommon.view.bean.raca.RacaBean;

import java.util.HashMap;
import java.util.Map;

import javax.faces.application.Application;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.view.rich.component.rich.layout.RichPanelGroupLayout;

import oracle.jbo.Row;
import oracle.jbo.ViewObject;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.myfaces.trinidad.component.core.input.CoreInputText;
import org.apache.myfaces.trinidad.context.RequestContext;
import org.apache.myfaces.trinidad.event.ReturnEvent;

public class CooperatorBean extends RacaBean{

    private static Logger log = LogManager.getLogger(CooperatorBean.class);
    private RichPanelGroupLayout panelGroupCooperators;
    private CoreInputText ffisVendorId;

    public CooperatorBean() {
    }

    public void setPanelGroupCooperators(RichPanelGroupLayout panelGroupCooperators) {
        this.panelGroupCooperators = panelGroupCooperators;
    }

    public RichPanelGroupLayout getPanelGroupCooperators() {
//        String local_refresh = getIWebRequestParameters().getFp4();
//        if (log.isDebugEnabled()) {          
//            log.debug("getPanelGroupCooperators:local_refresh: " + local_refresh);
//        }
//
//        if (local_refresh != null) {
//            getGACommonService().executeViewQuery("CooperatorsLinksView");
//            getGACommonService().sync();
//        }
        return panelGroupCooperators;
    }

    public void setFfisVendorId(CoreInputText ffisVendorId) {
        this.ffisVendorId = ffisVendorId;
    }

    public CoreInputText getFfisVendorId() {
        return ffisVendorId;
    }

    protected DCBindingContainer getBindings() {
        FacesContext context = FacesContext.getCurrentInstance();
        Application app = context.getApplication();
        DCBindingContainer binding = 
            (DCBindingContainer)app.getVariableResolver().resolveVariable(context, 
                                                                          "bindings");
        return binding;
    }

    /**
     * ffisVendorIdRetListener
     * @param returnEvent
     */
    public void ffisVendorIdRetListener(ReturnEvent returnEvent) {
        if (returnEvent.getReturnValue() != null) {

            String lovVendorId = (String)returnEvent.getReturnParameters().get("vendorId");
            log.debug("lovVendorId : " + lovVendorId);

//            ViewObject view = getGACommonService().findViewObject("CooperatorsLinksView");    
//            Row row = view.getCurrentRow();
//            row.setAttribute("FfisVendorId", lovVendorId);
//            view.setCurrentRow(row);
            

//            getFfisVendorId().resetValue();
//            getFfisVendorId().setValue(lovVendorId);
            getFfisVendorId().setSubmittedValue(lovVendorId);
            
//            FacesContext context = FacesContext.getCurrentInstance();
//            Application app = context.getApplication();
//            ValueBinding bind = app.createValueBinding("#{bindings.FfisVendorId.inputValue}");
//            String fVendorId = (String)bind.getValue(context);
//            log.debug("fVendorId : " + fVendorId);
//            bind.setValue(context, lovVendorId);

//            
//            //String cn = (String) JSFUtils.resolveExpression("#{bindings.Cn.inputValue}");
//            JSFUtils.setExpressionValue("#{bindings.FfisVendorId.inputValue}", lovVendorId);
//            //ADFUtils.setBoundAttributeValue("#{bindings.FfisVendorId.inputValue}", (String)returnEvent.getReturnParameters().get("vendorId"));
//            //refreshView();
//

            RequestContext adfContext = RequestContext.getCurrentInstance();
            if (adfContext != null) {
                adfContext.addPartialTarget(getFfisVendorId());
            }
        }
    }

    /**
     * selectVendorIdActListener
     * @param actionEvent
     */
    public void selectVendorIdActListener(ActionEvent actionEvent) {
        RequestContext afContext = RequestContext.getCurrentInstance();
        ViewObject view = getGACommonService().findViewObject("LovFFISVendors");    
        Row row = view.getCurrentRow();

        Map values = new HashMap();
        String vendorId = (String)row.getAttribute("VendorId");
        values.put("vendorId", vendorId);

        afContext.returnFromDialog(vendorId, values);
        afContext.getProcessScope().clear();

        // reset LOV options
        //view.setsecurityId("%");
        view.executeQuery();
        view.first();
    }

    /**
     * cancelActListener
     * @param actionEvent
     */
    public void cancelActListener(ActionEvent actionEvent) {
        RequestContext.getCurrentInstance().returnFromDialog(null, null);
    }
    
    
    

}
