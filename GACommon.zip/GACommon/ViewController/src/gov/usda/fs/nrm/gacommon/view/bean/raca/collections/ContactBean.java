package gov.usda.fs.nrm.gacommon.view.bean.raca.collections;

import gov.usda.fs.nrm.gacommon.view.bean.raca.RacaBean;

import oracle.adf.view.rich.component.rich.layout.RichPanelGroupLayout;

import oracle.binding.BindingContainer;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.myfaces.trinidad.component.core.input.CoreInputText;

//public class ContactBean extends RacaBean  implements PagePhaseListener{

public class ContactBean extends RacaBean{
    
    private static Logger log = LogManager.getLogger(ContactBean.class);
    private CoreInputText remarks;
    private BindingContainer bc = null;
    private RichPanelGroupLayout panelGroupContacts;

    public ContactBean() {
    }

    public void setRemarks(CoreInputText remarks) {
        this.remarks = remarks;
    }

    public CoreInputText getRemarks() {
        return remarks;
    }

//    public void afterPhase(PagePhaseEvent event) {
//        if (log.isDebugEnabled()) {          
//            log.debug("In afterPhase");
//        }
//        FacesPageLifecycleContext ctx = 
//            (FacesPageLifecycleContext)event.getLifecycleContext();
//        if (event.getPhaseId() == Lifecycle.PREPARE_RENDER_ID) {
//            bc = ctx.getBindingContainer();
//            // Add method call for after Phase
//            bc = null;
//        }
//    }
//
//    public void beforePhase(PagePhaseEvent event) {
//         if (log.isDebugEnabled()) {          
//             log.debug("In beforePhase");
//         }
//        getRequestVariables();
//        
//        FacesPageLifecycleContext ctx = 
//            (FacesPageLifecycleContext)event.getLifecycleContext();
//        if (event.getPhaseId() == Lifecycle.PREPARE_MODEL_ID) {
//            bc = ctx.getBindingContainer();
////            getRequestVariables();
////            if (getRefreshTarget() == null) {
////                getRequestVariables();
////            }
//            bc = null;
//        }
//    }
    
//    public void getRequestVariables() {
//        String local_refresh = getIWebRequestParameters().getFp4();
//        local_refresh = (String)getRequestValue("fp4");
//    }


    public void setPanelGroupContacts(RichPanelGroupLayout panelGroupContacts) {
        this.panelGroupContacts = panelGroupContacts;
    }

    /**
     * When page is called to get PanelGroup refresh the list of contacts
     * @return
     */
    public RichPanelGroupLayout getPanelGroupContacts() {
//
//        String local_refresh = getIWebRequestParameters().getFp4();
//        if (log.isDebugEnabled()) {          
//            log.debug("getPanelGroupContacts:local_refresh: " + local_refresh);
//        }
//
//        if (local_refresh != null) {
////            ContactsLinksViewImpl view = (ContactsLinksViewImpl)getApplicationModule().findViewObject("ContactsLinksView");
////            view.executeQuery();           
////            getGACommonService().findViewObject("ContactsLinksView").executeQuery();
//            getGACommonService().executeViewQuery("ContactsLinksView");
//            getGACommonService().sync();
//        }
//        
        return panelGroupContacts;
    }
}


