package com.darden.krowd.portal.messaging.rest.exceptions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.ws.rs.WebApplicationException;
import java.util.*;
import javax.ws.rs.*;
import javax.ws.rs.core.*;
import javax.ws.rs.core.Response.*;

public class BusinessFaultRequestException  extends WebApplicationException
{
    public static final int GENERIC_APP_ERROR_CODE = 5001;       
    private static final long serialVersionUID = -2191179733969059302L;
    private List<String> errors;
    public BusinessFaultRequestException(ErrorMessage error)
    {
        super(Response.status(Status.BAD_REQUEST).type(MediaType.APPLICATION_JSON)
                .entity(new GenericEntity<ErrorMessage>(error){}).build());
    }
    
    public BusinessFaultRequestException(Throwable ex){
        super(Response.status(Response.Status.BAD_REQUEST.getStatusCode())
                        .entity(ErrorMessage.getErrorMessageInstance(ex))
                        .type(MediaType.APPLICATION_JSON)
                        .build());                  
        StackTraceElement[] elements = ex.getStackTrace();
        this.errors = new ArrayList<String>();
        for(StackTraceElement element : elements){
            this.errors.add(element.getFileName()+":"+element.getClassName()+":"+element.getMethodName()+":"+element.getLineNumber());
        }        
    }
}
