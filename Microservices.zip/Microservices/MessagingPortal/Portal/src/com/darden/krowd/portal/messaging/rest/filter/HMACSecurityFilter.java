package com.darden.krowd.portal.messaging.rest.filter;

import com.darden.krowd.common.KrowdUtility;

import com.darden.krowd.portal.messaging.rest.service.MessageResource;

import java.io.IOException;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;


import java.util.Date;
import javax.crypto.Mac;

import javax.crypto.spec.SecretKeySpec;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;

import oracle.adf.share.logging.ADFLogger;

import org.apache.commons.codec.binary.Base64;

public class HMACSecurityFilter implements Filter{
    private static final ADFLogger logger = ADFLogger.createADFLogger(HMACSecurityFilter.class);
    private static final String ALGORITHM = "HmacSHA256";
    private static final long NO_OF_SEC_THRESHOLD = 60L;
    private Mac sha256_HMAC;
    public HMACSecurityFilter() {
        super();
    }
    
    private String getSharedSecret() {
        String hmacSecret = KrowdUtility.getInstance().getProperties().getProperty("SPLASH_HMAC_SHARED_SECRET");
        if(hmacSecret == null){
            return "abcdefghijklmnopqrstuvwxyz0123456789";
        } else {
            return hmacSecret;
        }
    }
    
    private Long getTimeStampThresholdInSec(){
        String threshold = KrowdUtility.getInstance().getProperties().getProperty("SPLASH_HMAC_TIMESTAMP_THRESHOLD");
        if(threshold == null){
            return NO_OF_SEC_THRESHOLD;
        } else {
            return Long.parseLong(threshold);
        }
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        try{
            sha256_HMAC = Mac.getInstance(ALGORITHM);
            SecretKeySpec secretKey = new SecretKeySpec(getSharedSecret().getBytes(), ALGORITHM);
            sha256_HMAC.init(secretKey);    
        }catch(NoSuchAlgorithmException e){
            e.printStackTrace();
        }catch(InvalidKeyException e){
            e.printStackTrace();
        }
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
                         FilterChain filterChain) throws IOException, ServletException {
        
        //Authorization: hmac AppID:Signature:Nonce:UnixTimestampInSeconds
        //check for Authorization header
        HttpServletRequest httpRequest = (HttpServletRequest)request;
        HttpServletResponse httpResponse = (HttpServletResponse)response;
        
        String authHeader = httpRequest.getHeader("Authorization") == null ? httpRequest.getHeader("authorization") : httpRequest.getHeader("Authorization");
        if(authHeader == null){
            _send401(httpResponse, "No Authorization Header.");
            httpResponse.setHeader("Content-Type", "application/json");
        } else {
            String[] authHeaderParts = authHeader.split(" ");
            if(authHeaderParts != null && authHeaderParts.length == 2 && authHeaderParts[0].equalsIgnoreCase("hmac")){
                String tokenValue = authHeaderParts[1];
                String[] tokens = tokenValue.split(":");
                if(tokens != null && tokens.length == 4){
                    String appId = tokens[0];
                    String signature = tokens[1];
                    String nOnce = tokens[2];
                    Long unixTSInSec = 0L;
                    boolean isTSInThreshold = false;
                    try{
                        unixTSInSec = new Long(tokens[3]);//catch
                        isTSInThreshold = this.isTimeStampWithinThreshold(unixTSInSec);
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                    
                    if(isTSInThreshold){
                        String httpMethod = httpRequest.getMethod();
                        String PATH_PREPEND = "/rest/api";//pass /MessagingAPI/api for local run. Should be "/rest/api" in deployment
                        String urlPath = PATH_PREPEND + httpRequest.getPathInfo();
                        String calcSignature = calcSignature(appId, httpMethod, urlPath, nOnce, unixTSInSec);
                        
                        if(calcSignature.equalsIgnoreCase(signature)){
                            filterChain.doFilter(request, response);                
                        } else {
                            _send401(httpResponse, "Invalid Token");
                        }
                    } else {
                        _send401(httpResponse, "Expired Timestamp");
                    }
                } else {
                    _send401(httpResponse, "Malformed Token");
                }
            } else {
                _send401(httpResponse, "Invalid Auth Scheme");
            }
        }
        
    }
    
    private String calcSignature(String appId, String httpMethod, 
                                String urlPath, String nonceGuid, 
                                long timestamp)  {
        String signature = null;
        String message = (appId + httpMethod + urlPath + nonceGuid + timestamp).toLowerCase();
        logger.info("----message="+message);
        byte[] finalEncodedHash = sha256_HMAC.doFinal(message.getBytes());
        signature = new String(Base64.encodeBase64(finalEncodedHash));
        return signature;
    }
    
    private boolean isTimeStampWithinThreshold(long tsInSec){
        long nowInSec = new Date().getTime()/1000L;
        long diffInSec = Math.abs(nowInSec - tsInSec);
        return diffInSec < getTimeStampThresholdInSec();
    }
    

    @Override
    public void destroy() {
        // TODO any cleanup code here
    }
    
    private void _send401(HttpServletResponse httpResponse, String message) throws IOException {
        httpResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        httpResponse.setHeader("Content-Type", "application/json");
        String responseMsg = "{\n" + 
        "	\"status\": 401,\n" + 
        "       \"code\": 401,\n" + 
        "       \"message\": \""+message+"\",\n" + 
        "       \"link\": \"https://krowd.darden.com\",\n" + 
        "       \"developerMessage\": \""+message+"\"\n" + 
        "    }";
        httpResponse.getWriter().print(responseMsg);
    }
    
}
