package com.darden.krowd.portal.messaging.rest.service;

import com.darden.krowd.RIDCCommon.util.UCMUtil;
import com.darden.krowd.common.KrowdUtility;
import com.darden.krowd.common.cache.KrowdUserCache;
import com.darden.krowd.common.cache.LDAPCacheUtil;
import com.darden.krowd.common.dto.KrowdUserDTO;
import com.darden.krowd.common.identity.LdapHelper;
import com.darden.krowd.common.notification.GenericEventObject;
import com.darden.krowd.common.notification.KrowdBusinessObjectEvent;
import com.darden.krowd.common.util.CacheUtil;
import com.darden.krowd.common.util.KrowdQueueSender;
import com.darden.krowd.enhancedmessages.model.applicationmodule.common.KrowdEnhancedMessagesAppModule;
import com.darden.krowd.messages.splash.model.applicationModule.SplashMessageAMImpl;
import com.darden.krowd.messages.splash.model.applicationModule.jdbc.SplashDAO;
import com.darden.krowd.messages.splash.model.converter.CampaignImpressionConverter;
import com.darden.krowd.messages.splash.model.converter.KrowdCampaignToSOAXMLConverter;
import com.darden.krowd.messages.splash.model.dto.CampaignDetailDTO;
import com.darden.krowd.messages.splash.model.dto.EmployeeValidationDTO;
import com.darden.krowd.messages.splash.model.dto.ImpressionValuesDTO;
import com.darden.krowd.messages.splash.model.dto.KeyValueDTO;
import com.darden.krowd.messages.splash.model.dto.SplashImpressionDTO;
import com.darden.krowd.messages.splash.model.dto.SplashLocationDTO;
import com.darden.krowd.portal.messaging.rest.exceptions.BadRequestException;
import com.darden.krowd.portal.messaging.rest.exceptions.BusinessFaultRequestException;
import com.darden.krowd.portal.messaging.rest.exceptions.ErrorMessage;
import com.darden.krowd.targetedmessaging.model.ad.MessagesADHelper;
import com.darden.krowd.targetedmessaging.model.applicationmodule.MessagesAMImpl;
import com.darden.krowd.targetedmessaging.model.jdbc.MessageDAO;
import com.darden.krowd.targetedmessaging.model.pojo.AliasDTO;
import com.darden.krowd.targetedmessaging.model.pojo.AttachmentDTO;
import com.darden.krowd.targetedmessaging.model.pojo.ComposeDTO;
import com.darden.krowd.targetedmessaging.model.pojo.ConceptDTO;
import com.darden.krowd.targetedmessaging.model.pojo.EmployeeProfileSearchResultsDTO;
import com.darden.krowd.targetedmessaging.model.pojo.EmployeeSearchDTO;
import com.darden.krowd.targetedmessaging.model.pojo.EmployeeSearchResultsDTO;
import com.darden.krowd.targetedmessaging.model.pojo.EmployeeTypeDTO;
import com.darden.krowd.targetedmessaging.model.pojo.GroupDTO;
import com.darden.krowd.targetedmessaging.model.pojo.GroupPermissionDTO;
import com.darden.krowd.targetedmessaging.model.pojo.InboxDTO;
import com.darden.krowd.targetedmessaging.model.pojo.JobFamilyDTO;
import com.darden.krowd.targetedmessaging.model.pojo.KeyValDTO;
import com.darden.krowd.targetedmessaging.model.pojo.LogicalLocationDTO;
import com.darden.krowd.targetedmessaging.model.pojo.MessageReadReportDTO;
import com.darden.krowd.targetedmessaging.model.pojo.PhysicalLocationDTO;
import com.darden.krowd.targetedmessaging.model.pojo.ReadReportDTO;
import com.darden.krowd.targetedmessaging.model.pojo.ReadingPaneDTO;
import com.darden.krowd.targetedmessaging.model.pojo.RecipientDTO;
import com.darden.krowd.targetedmessaging.model.pojo.RestaurantLocationDTO;
import com.darden.krowd.messages.splash.model.dto.SplashMessageDTO;
import com.darden.krowd.messages.splash.model.dto.SplashReportDTO;
import com.darden.krowd.messages.splash.model.dto.UserSplashMessageDTO;
import com.darden.krowd.messages.splash.model.dto.SplashPreviewDTO;
import com.darden.krowd.targetedmessaging.model.pojo.UserDTO;
import com.darden.krowd.targetedmessaging.model.pojo.UserInboxInfoDTO;
import com.darden.krowd.targetedmessaging.model.pojo.UserProfileDTO;

import com.sun.jersey.core.header.FormDataContentDisposition;
import com.sun.jersey.multipart.FormDataParam;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;

import java.text.ParseException;

import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import java.util.Set;

import java.util.concurrent.TimeUnit;

import javax.jcr.LoginException;
import javax.jcr.RepositoryException;

import javax.jms.JMSException;

import javax.naming.NamingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;

import oracle.adf.model.BindingContext;
import oracle.adf.model.DataControlFrame;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;
import oracle.jbo.client.Configuration;
import oracle.jbo.common.ampool.ApplicationPool;
import oracle.jbo.common.ampool.PoolMgr;
import oracle.jbo.common.ampool.SessionCookie;

import oracle.security.idm.User;

import oracle.stellent.ridc.IdcClientException;

import oracle.webcenter.content.integration.cache.Cache;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;

import org.apache.commons.lang3.StringUtils;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import org.xml.sax.SAXException;


@Path("/messages")
@Produces("application/json")
public class MessageResource  {
    private static final ADFLogger logger = ADFLogger.createADFLogger(MessageResource.class);    
    private static String PAGE_DEF = "com_darden_krowd_portal_RestPageDef";    
    private static String MSG_DATACONTROL = "MessagesAMDataControl";
    private static String DATACONTROL_DEP = "KrowdEnhancedMessagesAppModuleDataControl";
    private static String SPLASH_DATACONTROL = "SplashMessageAMDataControl";
    private static final String MESSAGING_ALLOWED_ATTACHMENT_EXTENSIONS = KrowdUtility.getInstance().getProperties().getProperty("MESSAGING_ALLOWED_ATTACHMENT_EXTENSIONS");
    private static final String SPLASH_ALLOWED_TRIGGERS = KrowdUtility.getInstance().getProperties().getProperty("SPLASH_ALLOWED_TRIGGERS");
    private static final String[] USER_SEARCH_BASES =
    new String[] { "OU=Field,DC=darden,DC=com",
    "OU=Field,OU=PortalDev,DC=darden,DC=com",
    "OU=Restaurants,DC=darden,DC=com",
    "OU=Restaurants,OU=PortalDev,DC=darden,DC=com",
    "OU=RSC,DC=darden,DC=com",
    "OU=RSC,OU=PortalDev,DC=darden,DC=com",
    "OU=Employees,DC=mydish,DC=darden,DC=com", 
    "OU=Employees,OU=PortalDev,DC=mydish,DC=darden,DC=com" };
    
    
    
    private static ArrayList<String> PERSON_REF_ATTRIBUTES = new ArrayList<String>() {{
        add("CreatedBy");
        add("RecipentId");
        add("LastUpdatedBy");
        add("Recipients");
    }};

    @Context
    protected HttpServletRequest httpRequest;
    
    @Context
    protected HttpServletResponse httpResponse;
    
    private Map<String, String> validFileExtensions;
    public MessageResource() {
        super();
        validFileExtensions = new HashMap<String, String>();
        if(MESSAGING_ALLOWED_ATTACHMENT_EXTENSIONS != null){
            String[] exts = MESSAGING_ALLOWED_ATTACHMENT_EXTENSIONS.split("#");   
            for(String ext : exts){
                validFileExtensions.put(ext, ext);
            }
            logger.info("Number of file extensions allowed "+ validFileExtensions.size());
        }
    }
    
    private MessagesAMImpl getMessagesAM(){
        BindingContext bindingContext = BindingContext.getCurrent();
        String userName = ADFContext.getCurrent().getSecurityContext().getUserName();
        if(userName.equalsIgnoreCase("anonymous")){
            ErrorMessage err = new ErrorMessage();
            err.setMessage("Unexpected error. User is anonymous.");
            throw new BusinessFaultRequestException(err);
        }
        MessagesAMImpl am =null;
        DCDataControl dc = null; 
        if(bindingContext !=null){
            String dcFrameName = bindingContext.getCurrentDataControlFrame();
            DataControlFrame dcframe = dcFrameName == null? null : bindingContext.findDataControlFrame(dcFrameName);
            
            dc = dcframe == null ? null : dcframe.findDataControl(MSG_DATACONTROL);        
            dc = dc == null ? bindingContext.findDataControl(MSG_DATACONTROL) : dc;
            DCBindingContainer amxs = bindingContext.findBindingContainer(PAGE_DEF);
            if(dc == null){
               DCBindingContainer amx = bindingContext.findBindingContainer(PAGE_DEF);
                dc = amx.findDataControl(MSG_DATACONTROL); 
                am = (MessagesAMImpl)dc.getDataProvider();
            }else{
                am = (MessagesAMImpl)dc.getDataProvider();
            }
        }
        return am;
    }     
    
    private SplashMessageAMImpl getSplashMessageAM(){
        BindingContext bindingContext = BindingContext.getCurrent();
        SplashMessageAMImpl am =null;
        DCDataControl dc = null; 
        if(bindingContext !=null){
            String dcFrameName = bindingContext.getCurrentDataControlFrame();
            DataControlFrame dcframe = dcFrameName == null? null : bindingContext.findDataControlFrame(dcFrameName);
            
            dc = dcframe == null ? null : dcframe.findDataControl(SPLASH_DATACONTROL);        
            dc = dc == null ? bindingContext.findDataControl(SPLASH_DATACONTROL) : dc;
            DCBindingContainer amxs = bindingContext.findBindingContainer(PAGE_DEF);
            if(dc == null){
               DCBindingContainer amx = bindingContext.findBindingContainer(PAGE_DEF);
                dc = amx.findDataControl(SPLASH_DATACONTROL); 
                am = (SplashMessageAMImpl)dc.getDataProvider();
            }else{
                am = (SplashMessageAMImpl)dc.getDataProvider();
            }
        }
        return am;
    }     
    
    private KrowdEnhancedMessagesAppModule getEnhancedMessagesAM(){
        BindingContext bindingContext = BindingContext.getCurrent();
        KrowdEnhancedMessagesAppModule am =null;
        DCDataControl dc = null; 
        if(bindingContext !=null){
            String dcFrameName = bindingContext.getCurrentDataControlFrame();
            DataControlFrame dcframe = dcFrameName == null? null : bindingContext.findDataControlFrame(dcFrameName);
            dc = dcframe == null ? null : dcframe.findDataControl(DATACONTROL_DEP);        
            dc = dc == null ? bindingContext.findDataControl(DATACONTROL_DEP) : dc;
            
            if(dc == null){
               DCBindingContainer amx = bindingContext.findBindingContainer(PAGE_DEF);
                dc = amx.findDataControl(DATACONTROL_DEP); 
                am = (KrowdEnhancedMessagesAppModule)dc.getDataProvider();
            }else{
                am = (KrowdEnhancedMessagesAppModule)dc.getDataProvider();
            }
        }
        return am;
    }     
    
    
    
    
    
    
    /***********************************************************************************************
    ******************************** Adding Message endpoints for Targeted Messaging *************
    *************************************************************************************************/
    
    /** This is a common method to fetch an application module from Pool.
     * It tries to an application module based on logged in user's session cookie.
     * If pool does not exists, which happens when the module accessed for the first time
     * CreateRootAppModule is used to create a pool.
     * */
    
    private SessionCookie _getUserSessionCookie(){
//        PoolMgr poolMgr = PoolMgr.getInstance();
        ApplicationPool pool = PoolMgr.getInstance().findPool("com.darden.krowd.targetedmessaging.model.applicationmodule.MessagesAMLocal", "com.darden.krowd.targetedmessaging.model.applicationmodule", "MessagesAMLocal", null);// TargettedMessagesUtil.getInstance().getMessagesPool();

        //SessionCookie cookie= pool.findOrCreateSessionCookie(ADFContext.getCurrent().getADFApplicationUID(),httpRequest.getSession().getId(), null);//commented
        //subh,CWE ID:384-Session Fixation 
        //httpRequest.getSession()- Returns the current session associated with this request, or if the request does not have a session, creates one.
        httpRequest.getSession().invalidate();//invalidating the pre-existing session
        String sessionID=httpRequest.getSession().getId();//creating a new session & getting its ID
        SessionCookie cookie= pool.findOrCreateSessionCookie(ADFContext.getCurrent().getADFApplicationUID(),sessionID, null);
        //
        return cookie;
    }
    private MessagesAMImpl _getMessagesAM(){

        MessagesAMImpl am = null;
        String amDef =
            "com.darden.krowd.targetedmessaging.model.applicationmodule.MessagesAM";
        String config = "MessagesAMLocal";

        am =
            (MessagesAMImpl)Configuration.createRootApplicationModule(amDef,
                                                                      config);
        return am;
    }
    
    private MessagesADHelper _getMessagesAD(){
           MessagesADHelper ad = new MessagesADHelper();
           return ad;
       }
    
    /******************************************Inbox Methods *********************************/
    
     @GET
     @Path("/resourceIndex")
     public Response getResourceIndex(){
         String ret = "";
         return Response.ok(ret).type(MediaType.APPLICATION_XML).header("X-Oracle-RF-Token", "FA--dummy--local---utoken---uuYR**").build();
     }
    
     @GET
    @Path("/testSplash")
    public Response testSplash(){
        String ret = "";
        String msg = getSplashMessageAM().getMessage();
        return Response.ok(msg).type(MediaType.TEXT_HTML).build();
    }
    
     @GET
     @Path("/unreadCount")
    public Response getUnreadCount(){
        int ret = 0;
        Response response = null;
        String isMessageCountCacheDisabled = KrowdUtility.getInstance().getProperties().getProperty("MESSAGING_UNREAD_COUNT_CACHE_DISABLED");
        if(isMessageCountCacheDisabled == null || isMessageCountCacheDisabled.equalsIgnoreCase("FALSE")) {
            Cache cache = CacheUtil.getInstance().getCache(CacheUtil.CacheType.MESSAGE_COUNT_CACHE);
            String userName = ADFContext.getCurrent().getSecurityContext().getUserName();
            Object cacheEntry = cache.get(userName);
            if(cacheEntry == null){
                ret = getUnreadCountIntern();
                cache.put(userName, ret);
                response = Response.ok(ret).header("Cache-COH-Entry", "false").type(MediaType.APPLICATION_JSON).build();
            } else {
                ret = (Integer)cacheEntry; 
                response = Response.ok(ret).header("Cache-COH-Entry", "true").type(MediaType.APPLICATION_JSON).build();
            }    
        } else {
            ret = getUnreadCountIntern();
            response = Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
        }
        
        return response;
    }
     
     private int getUnreadCountIntern(){
         int ret = 0;
         String isMessagingUnreadCountThroughAM = KrowdUtility.getInstance().getProperties().getProperty("MESSAGING_UNREAD_COUNT_THROUGH_AM");
         if(isMessagingUnreadCountThroughAM != null && isMessagingUnreadCountThroughAM.equalsIgnoreCase("TRUE")){
             MessagesAMImpl am = (MessagesAMImpl) getMessagesAM();
             ret = am.getUnreadCount();  
         } else {
             String userId = ADFContext.getCurrent().getSecurityContext().getUserName();
             ret = new MessageDAO().getUnreadCount(userId);   
         }    
         return ret;
     }
    
    @GET
    @Path("/inbox")
    public Response getInbox(@DefaultValue("0") @QueryParam("itemsPerPage") int _itemsPerPage,
                             @DefaultValue("-1") @QueryParam("inboxId") int _inboxId,
                             @DefaultValue("DOWN") @QueryParam("fetchDir") String _fetchDir,
                             @QueryParam("sortBy") String _sortBy,
                             @QueryParam("searchString") String _searchString){
      //  
        MessagesAMImpl am = (MessagesAMImpl) getMessagesAM();//getMessagesAM();
       
      UserInboxInfoDTO  ret = am.getInbox(_itemsPerPage, _inboxId, _fetchDir, _sortBy, _searchString);
//       if(! sc.isApplicationModuleReleased())
//        sc.releaseApplicationModule(sc.SHARED_MANAGED_RELEASE_MODE);
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("/read/{messageId}")
    public Response readMessage(@PathParam("messageId") Long _messageId){
        
        MessagesAMImpl am = (MessagesAMImpl) getMessagesAM();
        String channel = getChannel();
        Long ret = am.updateReadStatus(_messageId, channel);
  
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    @DELETE
    @Path("/inbox/{inboxId}")
    public Response deleteMessage(@PathParam("inboxId") Long _inboxId){
        
        MessagesAMImpl am = (MessagesAMImpl) getMessagesAM();
        String channel = getChannel();
        Long ret = am.deleteMessage(_inboxId, channel);
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }

    /*****************************Draft Methods ***************************************/
    @GET
    @Path("/drafts")
    public Response getDrafts(@DefaultValue("0") @QueryParam("itemsPerPage") int _itemsPerPage,
                             @DefaultValue("10") @QueryParam("pageNumber") int _pageNumber,
                             @QueryParam("sortBy") String _sortBy){
        
        MessagesAMImpl am = (MessagesAMImpl) getMessagesAM();  
        InboxDTO[] ret = am.getDrafts(_itemsPerPage, _pageNumber, _sortBy);
             
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("/draft/{messageId}")
    public Response getDraft(@PathParam("messageId") Long _messageId){
        
        MessagesAMImpl am = (MessagesAMImpl) getMessagesAM(); 
        ComposeDTO ret = am.getDraft(_messageId);
              
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    @DELETE
    @Path("/draft/{messageId}")
    public Response deleteDraft(@PathParam("messageId") Long _messageId){
        
        MessagesAMImpl am = (MessagesAMImpl) getMessagesAM(); 
        Long ret = am.deleteDraft(_messageId);
              
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    


    /******************************Reading Pane Methods *******************************/
    @GET
    @Path("/readingPane/{parentMessageId}")
    public Response getMessagesForReadingPane(@DefaultValue("0") @QueryParam("itemsPerPage") int _itemsPerPage,
                             @DefaultValue("10") @QueryParam("messageId") int _messageId,
                             @QueryParam("sortBy") String _sortBy, @DefaultValue("DOWN") @QueryParam("fetchDir") String _fetchDir,
                                              @PathParam("parentMessageId") Long _parentMessageId){
        
        MessagesAMImpl am = (MessagesAMImpl) getMessagesAM(); 
        ReadingPaneDTO ret = am.getReadingPane(_parentMessageId, _itemsPerPage, _messageId, _fetchDir,_sortBy);
              
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("/message/{messageId}/recipients")
    public Response getUserList(@DefaultValue("0") @QueryParam("itemsPerPage") int _itemsPerPage,
                             @DefaultValue("10") @QueryParam("pageNumber") int _pageNumber, @QueryParam("sortBy") String _sortBy,@PathParam("messageId") Long _messageId){
        
        MessagesAMImpl am = (MessagesAMImpl) getMessagesAM(); 
        RecipientDTO[] ret = am.getInboxRecipients(_messageId, _itemsPerPage, _pageNumber, _sortBy);
              
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    /*****************************Attachment Methods *************************************/
    @GET
    @Path("/attachments")
    public Response getAllAttachments(@DefaultValue("0") @QueryParam("itemsPerPage") int _itemsPerPage,
                             @DefaultValue("10") @QueryParam("pageNumber") int _pageNumber){
        
        MessagesAMImpl am = (MessagesAMImpl) getMessagesAM(); 
        AttachmentDTO[] ret = am.getUnusedAttachments();
              
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("/attachment/{attachmentId}")
    @Produces(MediaType.APPLICATION_OCTET_STREAM)
    public Response getAttachment(@PathParam("attachmentId") Long _attachmentId,
                                  @QueryParam("isRendition") @DefaultValue("false") boolean isRendition){
        Response response = null;
        MessagesAMImpl am = (MessagesAMImpl) getMessagesAM(); 
        try{
            AttachmentDTO ret = am.getAttachment(_attachmentId, isRendition);     
            if(isRendition){
                response = Response.ok(ret.getAttachmentData(), "image/png")
                            .build();
            } else {
                response = Response.ok(ret.getAttachmentData(), MediaType.APPLICATION_OCTET_STREAM)
                            .header("Content-Disposition", "attachment; filename=\"" + ret.getAttachmentName() + "\"" ) //optional
                            .build();
            }
            
        }catch(Exception e){
            e.printStackTrace();
            logger.severe(" get attachment error "+ e.getMessage());
            response = Response.status(403).type("text/plain")
                        .entity(e.getMessage()).build();
        }
        
              
        return response;
    }    

    
    @POST
    @Path("/attachment")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    public Response uploadAttachment(@FormDataParam("file") InputStream uploadedInputStream,
                @FormDataParam("file") FormDataContentDisposition fileDetail){
        Response response = null;
        AttachmentDTO dto = this._uploadAttachment(uploadedInputStream, fileDetail);
        ObjectMapper mapper = new ObjectMapper();
        String ret = "";
        if(dto != null){
            try {
                ret = mapper.writeValueAsString(dto);
            } catch (Exception e) {
                e.printStackTrace();
            }     
            response = Response.ok(ret).type(MediaType.TEXT_HTML).build();
        } else {
            response = Response.serverError().type(MediaType.TEXT_HTML).build();
        }
        return response;
        
    }

    @POST
    @Path("/attachmentAck")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    public Response uploadAttachmentAck(@FormDataParam("file") InputStream uploadedInputStream,
                @FormDataParam("file") FormDataContentDisposition fileDetail,
                                        @FormDataParam("messageClientGuid") String messageClientGuid,
                                        @FormDataParam("attachmentClientGuid") String attachmentClientGuid){
        Response response = null;
        AttachmentDTO dto = this._uploadAttachment(uploadedInputStream, fileDetail);
        dto.setMessageClientGuid(messageClientGuid);
        dto.setAttachmentClientGuid(attachmentClientGuid);
        ObjectMapper mapper = new ObjectMapper();
        String ret = "";
        if(dto != null){
            try {
                ret = mapper.writeValueAsString(dto);
            } catch (Exception e) {
                e.printStackTrace();
            }     
            response = Response.ok(ret).type(MediaType.TEXT_HTML).build();
        } else {
            response = Response.serverError().type(MediaType.TEXT_HTML).build();
        }
        return response;
        
    }
    
    private AttachmentDTO _uploadAttachment(InputStream uploadedInputStream,
                FormDataContentDisposition fileDetail) {
        MessagesAMImpl am = (MessagesAMImpl) getMessagesAM(); 
        AttachmentDTO dto = new AttachmentDTO();
        AttachmentDTO retDTO = new AttachmentDTO();
        String fileName = fileDetail.getFileName();
        logger.info("----fileName "+ fileName);
        if(fileName != null){
            String[] fileSplits = fileName.split("\\.");
            logger.info("---"+ fileSplits+ ","+fileSplits.length);
            if(fileSplits != null && fileSplits.length > 0){
                String extension = fileSplits[fileSplits.length - 1];
                logger.info("file extension = "+ extension);
                if(validFileExtensions.containsKey(extension.toUpperCase())){
                    logger.info("extension allowed");
                    dto.setAttachmentName(fileName);
                    byte[] bytes;
                    try {
                        bytes = IOUtils.toByteArray(uploadedInputStream);
                        dto.setAttachmentData(bytes);
                    } catch (IOException e) {
                        throw new WebApplicationException(Response.Status.BAD_REQUEST);
                    }
                    retDTO = am.uploadAttachment(dto);
                }else{
                    logger.severe("Unsupported File Extension."+ extension);
                }
            }
        }
        
        return retDTO;
    }
    
    @POST
    @Path("/attachmentAckNew")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    public Response uploadAttachmentAckNew(@FormDataParam("file") InputStream uploadedInputStream,
                @FormDataParam("file") FormDataContentDisposition fileDetail,
                                        @FormDataParam("messageClientGuid") String messageClientGuid,
                                        @FormDataParam("attachmentClientGuid") String attachmentClientGuid){
        Response response = null;
        AttachmentDTO dto = this._uploadAttachmentNew(uploadedInputStream, fileDetail);
        dto.setMessageClientGuid(messageClientGuid);
        dto.setAttachmentClientGuid(attachmentClientGuid);
        ObjectMapper mapper = new ObjectMapper();
        String ret = "";
        if(dto != null){
            try {
                ret = mapper.writeValueAsString(dto);
            } catch (Exception e) {
                e.printStackTrace();
            }     
            response = Response.ok(ret).type(MediaType.TEXT_HTML).build();
        } else {
            response = Response.serverError().type(MediaType.TEXT_HTML).build();
        }
        return response;
        
    }
    
    /**
     * @param uploadedInputStream
     * @param fileDetail
     * @Process: saves ucm document in resource and then calls AM Method
     * @return
     */
    private AttachmentDTO _uploadAttachmentNew(InputStream uploadedInputStream,
                FormDataContentDisposition fileDetail) {
        MessagesAMImpl am = (MessagesAMImpl) getMessagesAM(); 
        AttachmentDTO dto = new AttachmentDTO();
        AttachmentDTO retDTO = new AttachmentDTO();
        String fileName = fileDetail.getFileName();
        String contentId = null;
        logger.info("----fileName "+ fileName);
        if(fileName != null){
            String[] fileSplits = fileName.split("\\.");
            logger.info("---"+ fileSplits+ ","+fileSplits.length);
            if(fileSplits != null && fileSplits.length > 0){
                String extension = fileSplits[fileSplits.length - 1];
                logger.info("file extension = "+ extension);
                if(validFileExtensions.containsKey(extension.toUpperCase())){
                    logger.info("extension allowed");
                    dto.setAttachmentName(fileName);
                    byte[] bytes;
                    try {
                        bytes = IOUtils.toByteArray(uploadedInputStream);
                        long maxSizeInMB = getMaxAttachmentSizeInMB();
                         if (bytes.length > 1048576 * maxSizeInMB) {
                             logger.severe("Attachment Size should not exceed "+maxSizeInMB+" Megabyte.");
                             throw new WebApplicationException(Response.Status.BAD_REQUEST);
                         }else {
                            try {
                                contentId = this.uploadDocInUCM(fileName, bytes);
                                if(contentId != null){
                                    dto.setAttachmentContentId(contentId);
                                    retDTO = am.uploadAttachmentNew(dto);    
                                }
                            } catch (NamingException e) {
                                e.printStackTrace();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    } catch (IOException e) {
                        throw new WebApplicationException(Response.Status.BAD_REQUEST);
                    }
                }else{
                    logger.severe("Unsupported File Extension."+ extension);
                }
            }
        }
        
        return retDTO;
    }
    
    @POST
    @Path("/attachmentAckDataUrl")
    public Response uploadAttachmentAckDataUrl(AttachmentDTO attachmentDTO){
        Response response = null;
        AttachmentDTO dto = this._uploadAttachmentDataUrl(attachmentDTO);
        dto.setMessageClientGuid(attachmentDTO.getMessageClientGuid());
        dto.setAttachmentClientGuid(attachmentDTO.getAttachmentClientGuid());
        ObjectMapper mapper = new ObjectMapper();
        String ret = "";
        if(dto != null){
            try {
                ret = mapper.writeValueAsString(dto);
            } catch (Exception e) {
                e.printStackTrace();
            }     
            response = Response.ok(ret).type(MediaType.TEXT_HTML).build();
        } else {
            response = Response.serverError().type(MediaType.TEXT_HTML).build();
        }
        return response;
        
    }
    
    /**
     * @param dto
     * @Process: Saves dataUrl to UCM in the resource and then calls AM Method
     * @return
     */
    private AttachmentDTO _uploadAttachmentDataUrl(AttachmentDTO dto) {
        MessagesAMImpl am = (MessagesAMImpl) getMessagesAM(); 
        AttachmentDTO retDTO = new AttachmentDTO();
        String fileName = dto.getAttachmentName();
        String contentId = null;
        logger.info("----fileName "+ fileName);
        if(fileName != null){
            String[] fileSplits = fileName.split("\\.");
            logger.info("---"+ fileSplits+ ","+fileSplits.length);
            if(fileSplits != null && fileSplits.length > 0){
                String extension = fileSplits[fileSplits.length - 1];
                logger.info("file extension = "+ extension);
                if(validFileExtensions.containsKey(extension.toUpperCase())){
                    logger.info("extension allowed");
                    dto.setAttachmentName(fileName);
                    byte[] bytes;
                    try {
                        String dataUrl = dto.getAttachmentDataUrl();
                        bytes = dataUrl.getBytes();
                        logger.info("file size = "+ bytes.length);
                        long maxSizeInMB = getMaxAttachmentSizeInMB();
                         if (bytes.length > 1048576 * maxSizeInMB) {
                             logger.severe("Attachment Size should not exceed "+maxSizeInMB+" Megabyte.");
                             throw new WebApplicationException(Response.Status.BAD_REQUEST);
                         }else {
                            try {
                                logger.info("------before decoding "+ bytes.length);
                                bytes = Base64.decodeBase64(bytes);
                                logger.info("------after decoding "+ bytes.length);
                                contentId = this.uploadDocInUCM(fileName, bytes);
                                logger.info("File uploaded successfully. ContentId = "+ contentId);
                                if(contentId != null){
                                    dto.setAttachmentContentId(contentId);
                                    dto.setAttachmentDataUrl(null);
                                    logger.info("trying to persist attachment row now");
                                    retDTO = am.uploadAttachmentNew(dto);    
                                    logger.info("attachment row persisted");
                                }
                            } catch (NamingException e) {
                                e.printStackTrace();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        throw new WebApplicationException(Response.Status.BAD_REQUEST);
                    }
                }else{
                    logger.severe("Unsupported File Extension."+ extension);
                }
            }
        }
        
        return retDTO;
    }
    
    private long getMaxAttachmentSizeInMB() {
        String maxSizeStringVal = (String)KrowdUtility.getInstance().getProperties().get("MSG_ATTACHMENT_MAX_SIZE");
        Long maxSizeInMB = 5L;
        try {
            maxSizeInMB = new Long(maxSizeStringVal);
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return maxSizeInMB;
    }
    
    //TODO: uploadAttachmentL7
    
    
    /**
     * Uploads to UCM and returns contentId
     * @param bytes
     * @return
     * @throws NamingException
     * @throws FileNotFoundException
     * @throws Exception
     */
    private String uploadDocInUCM(String contentName, byte[] bytes) throws NamingException,
                                                       FileNotFoundException,
                                                       Exception {
        Map<String, String> attributes = new HashMap<String, String>();
        attributes.put("dSecurityGroup","KrowDAdmin");
        attributes.put("dDocType","KrowDMessaging");
        attributes.put("xPackagedConversions", "KrowdMessaging");
        attributes.put("dDocAccount","");
        logger.info("MessageResource.uploadDocInUCM:: Trying to upload file "+ contentName + ", size = "+ bytes.length);
        oracle.stellent.ridc.IdcContext idcContext = new oracle.stellent.ridc.IdcContext("PhotoAlbumAdmin");
        String retContentId = UCMUtil.getInstance().createDocument(idcContext, contentName, null, bytes, attributes);
        logger.info("MessageResource.uploadDocInUCM:: "+ contentName + ", retId = "+ retContentId);
        return retContentId;
    }
    
    @DELETE
    @Path("/attachment/{attachmentId}")
    public Response deleteAttachment(@PathParam("attachmentId") Long _attachmentId){
        
        MessagesAMImpl am = (MessagesAMImpl) getMessagesAM(); 
        Long ret = am.deleteAttachment(_attachmentId);
              
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    /*******************************Compose Message*************************************/
    @GET
    @Path("/aliases")
    public Response getAliases(){
      
MessagesAMImpl am = (MessagesAMImpl) getMessagesAM();
        AliasDTO[] ret =am.getAlias();
        //sending composeDTO with aliases
    //        ComposeDTO ret = new ComposeDTO();
    //        ret.setAliases(aliases);
           
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("/draftsCount")
    public Response getDraftsCount(){
        
        MessagesAMImpl am = (MessagesAMImpl) getMessagesAM(); 
        int ret = am.getDraftsCount();       
              
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("/sendMessage")
    
    public Response sendMessage(ComposeDTO _compose){
        Long ret = _sendMessage(_compose);
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    private Long _sendMessage(ComposeDTO _compose){
        Long ret = null;
        if (_compose.isValidComposeDTO()) {
            MessagesAMImpl am = (MessagesAMImpl) getMessagesAM(); 
            try{
                ret = am.sendMessage(_compose); 
            }catch(Exception e){
                e.printStackTrace();
                ErrorMessage err = new ErrorMessage();
                err.setMessage(e.getMessage());
                throw new BusinessFaultRequestException(err);
            }
        } else {
            logger.severe("Invalid ComposeDTO Parameters: composeDTO = "+ _compose.toString());
            ErrorMessage err = new ErrorMessage();
            err.setMessage("Cannot send message. Invalid input.");
            throw new BusinessFaultRequestException(err);
        }
        
        
        return ret;
    }
    
    @POST
    @Path("/sendMessageAck")
    public Response sendMessageAck(ComposeDTO _compose){
        Long messageId = _sendMessage(_compose);
        String clientGuid = _compose.getClientGuid();
        Map retObj = new HashMap();
        retObj.put("messageId", messageId);
        retObj.put("clientGuid", clientGuid);
        retObj.put("postedDate", new Date());
        return Response.ok(retObj).type(MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("/saveDraft")
    public Response saveDraft(ComposeDTO _compose){
        
        MessagesAMImpl am = (MessagesAMImpl) getMessagesAM(); 
        Long ret = am.saveSendDraft(_compose);
              
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    /******************************Groups Methods ***********************************/
     @GET
     @Path("/userProfile")
     public Response getLoggedUserProfile(){
         MessagesADHelper ad = new MessagesADHelper();
         UserProfileDTO ret =  ad.getLoggedUserProfile();
         
         MessagesAMImpl am = (MessagesAMImpl) getMessagesAM();
         String userLocale = am.getUserLocale();
         ret.setLocale(userLocale);
         return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
     } 
    
    @GET
    @Path("/usergroups")
    public Response getUserGroups(@DefaultValue("10") @QueryParam("itemsPerPage") int _itemsPerPage,
                             @DefaultValue("1") @QueryParam("pageNumber") int _pageNumber,
                             @QueryParam("sortBy") String _sortBy){
        
        MessagesAMImpl messageAM = (MessagesAMImpl) getMessagesAM();
        GroupDTO[] ret = messageAM.getUserGroups(_itemsPerPage, _pageNumber, _sortBy, false);

        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("/group/{groupId}")
    public Response getGroup(@PathParam("groupId") Long _groupId){
        
        MessagesAMImpl am = (MessagesAMImpl) getMessagesAM(); 
        GroupDTO ret = am.getGroup(_groupId);
              
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    
    @GET
    @Path("/group/{groupId}/members")
    public Response getGroupMembers(@DefaultValue("0") @QueryParam("itemsPerPage") int _itemsPerPage,
                             @DefaultValue("10") @QueryParam("pageNumber") int _pageNumber, @PathParam("groupId") Long _groupId){
        
        MessagesAMImpl am = (MessagesAMImpl) getMessagesAM(); 
        UserDTO[] ret = am.getGroupMembers(_groupId, _itemsPerPage, _pageNumber); 
              
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    @PUT
    @Path("/group")
    public Response editGroup(GroupDTO _group){
        
        MessagesAMImpl am = (MessagesAMImpl) getMessagesAM(); 
        Long ret = am.editGroup(_group);
              
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("/group")
    public Response createGroup(GroupDTO _group){
        
        MessagesAMImpl am = (MessagesAMImpl) getMessagesAM(); 
        Long ret = am.createGroup(_group);
              
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("/deletegroup/{groupId}")
    public Response deleteGroup(@PathParam("groupId") Long _groupId){
        
        MessagesAMImpl am = (MessagesAMImpl) getMessagesAM(); 
        Long ret = am.deleteGroup(_groupId);
              
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    
    @GET
    @Path("/groupNames/{groupType}")
    public Response getGroupNames(@PathParam("groupType") String _groupType){
        
        MessagesAMImpl am = (MessagesAMImpl) getMessagesAM(); 
        String[] ret = am.getGroupNames(_groupType);
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    /********************************************Search Methods *************************************************/
    @POST
    @Path("/search/{itemsPerPage}/{pageNumber}")
    public Response simpleSearch(EmployeeSearchDTO _input,@PathParam("itemsPerPage") int _itemsPerPage,@PathParam("pageNumber") int _pageNumber){
        
        MessagesAMImpl am = (MessagesAMImpl) getMessagesAM(); 
        EmployeeSearchResultsDTO ret = am.searchUsers(_input, _itemsPerPage, _pageNumber, false);
              
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("/simpleRecipientSearch/{queryString}")
    public Response simpleRecipientSearch( @PathParam("queryString") String query ){
        MessagesADHelper adHelper = new MessagesADHelper();
        RecipientDTO[] ret = adHelper.simpleRecipientsSearch(query);
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    } 
    
    @GET
    @Path("/simpleUserSearch/{queryString}")
    public Response simpleUserSearch( @PathParam("queryString") String query ){
        MessagesADHelper adHelper = new MessagesADHelper();
        UserDTO[] ret = adHelper.simpleUserNameSearch(query);
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    } 
    
    
    
    @GET
    @Path("/addressbookSearch")
    public Response addressbookSearch(@DefaultValue("") @QueryParam("name") String displayName,@QueryParam("restId") String restId, @DefaultValue("") @QueryParam("brand") String brand){
       MessagesADHelper ad = _getMessagesAD();
       UserDTO[] ret =  ad.addressbookSearch(displayName,restId,brand);
       return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("/restaurantContactList")
    public Response getRestaurantContactList(@DefaultValue("") @QueryParam("name") String displayName){
       MessagesADHelper ad = _getMessagesAD();
        UserDTO[] ret = new UserDTO[0];
       String samAccountName = ADFContext.getCurrent().getSecurityContext().getUserName();
        KrowdUserCache cache = KrowdUserCache.getInstance();
        KrowdUserDTO krowdUser = cache.getUser(samAccountName, null);
        if(krowdUser != null){
            String restId = krowdUser.getLocationId();
            ret =  ad.addressbookSearch(displayName, restId,null);
        }
       return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("/mru")
    public Response getMRU(){
        
        MessagesAMImpl am = (MessagesAMImpl) getMessagesAM(); 
        RecipientDTO[] ret = am.getMRU();
              
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("/targetedSearch")
    public Response targetedSearch(@DefaultValue("") @QueryParam("groupName") String groupName){
        MessagesADHelper ad = _getMessagesAD();
        GroupPermissionDTO[] ret;
        ret = ad.securityGroupsSearch(groupName);
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }   
    
    @GET
    @Path("/userPermissionSearch")
    public Response userPermissionSearch(@DefaultValue("") @QueryParam("userName") String userName){
        MessagesADHelper ad = _getMessagesAD();
        GroupPermissionDTO[] ret;
        ret = ad.userPermissionsSearch(userName);
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    } 
    
    
    /****************************************Targeted Messages LOVs *********************************************/
    @POST
    @Path("/concepts")
    public Response getConcepts(ConceptDTO _input){
        KeyValDTO[] ret = new KeyValDTO[0];
        if(_input != null){
            
            MessagesAMImpl am = (MessagesAMImpl) getMessagesAM();
            ret = am.getConcepts(_input.getConcepts());   
        }
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("/restaurants")
    public Response getRestaurants(ConceptDTO _input){
        KeyValDTO[] ret = new KeyValDTO[0];
        if(_input != null){
            
            MessagesAMImpl am = (MessagesAMImpl) getMessagesAM();
            ret = am.getRestaurants(_input.getConcepts());   

        }
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
        
    @POST
    @Path("/employeeTypes")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getEmployeeTypes(EmployeeTypeDTO _input){
        KeyValDTO[] ret = new KeyValDTO[0];
        if(_input != null){
            
            MessagesAMImpl am = (MessagesAMImpl) getMessagesAM();
            ret = am.getEmployeeType(_input.getConcepts(), _input.getLocationIds());   
 
        }
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("/departments")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getDepartments(ConceptDTO _input){
        KeyValDTO[] ret = new KeyValDTO[0];
        if(_input != null){
            
            MessagesAMImpl am = (MessagesAMImpl) getMessagesAM();
            ret = am.getDepartments(_input.getConcepts());   
           
        }
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("/countries")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getCountries(ConceptDTO _input){
        KeyValDTO[] ret = new KeyValDTO[0];
        if(_input != null){
            
            MessagesAMImpl am = (MessagesAMImpl) getMessagesAM();
            ret = am.getCountries(_input.getConcepts());   
          
        }
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("/workStates")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getWorkStates(PhysicalLocationDTO _input){
        KeyValDTO[] ret = new KeyValDTO[0];
        if(_input != null){
            
            MessagesAMImpl am = (MessagesAMImpl) getMessagesAM();
            ret = am.getWorkStates(_input.getConcepts(), _input.getCountries());   
                  
        }
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("/homeCities")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getHomeCities(PhysicalLocationDTO _input){
        KeyValDTO[] ret = new KeyValDTO[0];
        if(_input != null){
            
            MessagesAMImpl am = (MessagesAMImpl) getMessagesAM();
            ret = am.getHomeCities(_input.getConcepts(), _input.getCountries(), _input.getWorkStates());   
                  
        }
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("/divisions")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getDivisions(LogicalLocationDTO _input){
        KeyValDTO[] ret = new KeyValDTO[0];
        if(_input != null){
            
            MessagesAMImpl am = (MessagesAMImpl) getMessagesAM();
            ret = am.getDivision(_input.getConcepts());   
                  
        }
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("/areas")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAreas(LogicalLocationDTO _input){
        KeyValDTO[] ret = new KeyValDTO[0];
        if(_input != null){
            
            MessagesAMImpl am = (MessagesAMImpl) getMessagesAM();
            ret = am.getArea(_input.getConcepts(), _input.getDivisions());   
                  
        }
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("/regions")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getRegions(LogicalLocationDTO _input){
        KeyValDTO[] ret = new KeyValDTO[0];
        if(_input != null){
            
            MessagesAMImpl am = (MessagesAMImpl) getMessagesAM();
            ret = am.getRegion(_input.getConcepts(), _input.getDivisions(), _input.getAreas());   
                  
        }
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("/managerLevels")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getManagerLevels(JobFamilyDTO _input){
        KeyValDTO[] ret = new KeyValDTO[0];
        if(_input != null){
            
            MessagesAMImpl am = (MessagesAMImpl) getMessagesAM();
            ret = am.getManagerLevel(_input.getConcepts());   
                  
        }
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("/jobFamilies")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getJobFamilies(JobFamilyDTO _input){
        KeyValDTO[] ret = new KeyValDTO[0];
        if(_input != null){
            
            MessagesAMImpl am = (MessagesAMImpl) getMessagesAM();
            ret = am.getJobFamily(_input.getConcepts(), _input.getManagerLevels());   
                  
        }
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("/jobFunctions")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getJobFunctions(JobFamilyDTO _input){
        KeyValDTO[] ret = new KeyValDTO[0];
        if(_input != null){
            
            MessagesAMImpl am = (MessagesAMImpl) getMessagesAM();
            ret = am.getJobFunction(_input.getConcepts(), _input.getManagerLevels(), _input.getJobFamilies());   
                  
        }
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("/jobSubFunctions")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getJobSubFunctions(JobFamilyDTO _input){
        KeyValDTO[] ret = new KeyValDTO[0];
        if(_input != null){
            
            MessagesAMImpl am = (MessagesAMImpl) getMessagesAM();
            ret = am.getJobSubFunction(_input.getConcepts(), _input.getManagerLevels(), _input.getJobFamilies(), _input.getJobFunctions());   
                  
        }
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }

    @GET
    @Path("/amstats")
    @Produces(MediaType.TEXT_HTML)
    public Response getAMStats(){
     //   MessagesAMImpl am = (MessagesAMImpl) getMessagesAM();//getMessagesAM();
//        am.getSession().getUserData().entrySet();
//        Set<String> mapKeys = am.getSession().getUserData().keySet();
//      
//        Iterator<String> iterator = mapKeys.iterator();
//        while (iterator.hasNext())
//        {
//            System.out.println(am.getSession().getUserData().get(iterator.next()));
//        }
//     
//       
//        Long MessageId = (Long) am.getMessageVO().getCurrentRow().getAttribute("MessageId");
//        System.out.println(MessageId+"MessageId");
       OutputStream os = null;
       String ret = "";
        try {
            os = httpResponse.getOutputStream();
            ApplicationPool pool = PoolMgr.getInstance().findPool("com.darden.krowd.targetedmessaging.model.applicationmodule.MessagesAMLocal", "com.darden.krowd.targetedmessaging.model.applicationmodule", "MessagesAMLocal", null);
            pool.dumpPoolStatistics(new PrintWriter(os, true));
            IOUtils.write(ret, os);
        } catch (IOException e) {
            e.printStackTrace();
            ret = e.getMessage();
        }
        

        return Response.ok(ret).type(MediaType.TEXT_HTML).build();
    }
    
    @GET
    @Path("/messageUserCacheStats")
    @Produces(MediaType.TEXT_HTML)
    public Response getLDapCacheUtilStats(){
        LDAPCacheUtil aPCacheUtil = LDAPCacheUtil.getInstance();
        String ret = aPCacheUtil.dumpMessageUserCacheStats();
        return Response.ok(ret).type(MediaType.TEXT_HTML).build();
    }
    
    @GET
    @Path("/messageCountCacheStats")
    @Produces(MediaType.TEXT_HTML)
    public Response getMessageCacheCountStats(){
        Cache msgCountCache = CacheUtil.getInstance().getCache(CacheUtil.CacheType.MESSAGE_COUNT_CACHE);
        logger.severe("---------msgCountCache ="+ msgCountCache);
        int ret = msgCountCache.size();
        logger.severe("---------getMessageCacheCountStats count ="+ ret);
        return Response.ok(ret+"").type(MediaType.TEXT_HTML).build();
    }    
    
    @GET
    @Path("/messageCountCacheInvalidate/{userId}")
    @Produces(MediaType.TEXT_HTML)
    public Response clearMessageCountCache(@PathParam("userId") String userId){
        Long cacheCount = -1L;
        boolean cacheCleared = false;
        if(userId != null){
            try{
                Cache msgCountCache = CacheUtil.getInstance().getCache(CacheUtil.CacheType.MESSAGE_COUNT_CACHE);
                cacheCount = (Long)msgCountCache.get(userId);
                msgCountCache.put(userId, null);    
                logger.severe("--------------Msg Count Cache Cleared for user :"+ userId);
                cacheCleared = true;
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        return Response.ok(cacheCount+", cache Cleared="+cacheCleared).type(MediaType.TEXT_HTML).build();
    }
    
    @GET
    @Path("/invalidateMessageCountCache")
    @Produces(MediaType.TEXT_HTML)
    public Response invalidateMessageCountCache(){
        int entryCount = -1;
        boolean cacheCleared = false;
        try{
            Cache msgCountCache = CacheUtil.getInstance().getCache(CacheUtil.CacheType.MESSAGE_COUNT_CACHE);
            entryCount = msgCountCache.size();
            msgCountCache.clear();
            logger.severe("--------------Msg Count Cache Cleared--------------");
            cacheCleared = true;
        }catch(Exception e){
            e.printStackTrace();
        }
        return Response.ok("cache Cleared="+cacheCleared+", Number of entries cleared="+ entryCount).type(MediaType.TEXT_HTML).build();
    }
    
    @GET
    @Path("/splashCountCacheStats")
    @Produces(MediaType.TEXT_HTML)
    public Response getSplashCacheCountStats(){
        Cache splashCountCache = CacheUtil.getInstance().getCache(CacheUtil.CacheType.SPLASH_COUNT_CACHE);
        logger.severe("---------splashCountCache ="+ splashCountCache);
        int ret = splashCountCache.size();
        logger.severe("---------getSplashCacheCountStats count ="+ ret);
        return Response.ok(ret+"").type(MediaType.TEXT_HTML).build();
    }   
    
    @GET
    @Path("/splashCountCacheInvalidate/{userId}")
    @Produces(MediaType.TEXT_HTML)
    public Response clearSplashCountCache(@PathParam("userId") String userId){
        Integer cacheCount = -1;
        boolean cacheCleared = false;
        if(userId != null){
            try{
                Cache splashCountCache = CacheUtil.getInstance().getCache(CacheUtil.CacheType.SPLASH_COUNT_CACHE);
                cacheCount = (Integer)splashCountCache.get(userId);
                splashCountCache.put(userId, null);    
                logger.severe("--------------Msg Count Cache Cleared for user :"+ userId);
                cacheCleared = true;
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        return Response.ok(cacheCount+", cache Cleared="+cacheCleared).type(MediaType.TEXT_HTML).build();
    }
    
    @GET
    @Path("/readingPaneQueryCacheStats")
    @Produces(MediaType.TEXT_HTML)
    public Response getReadingPaneQueryCacheStats(){
        Cache readingPaneQueryCache = CacheUtil.getInstance().getCache(CacheUtil.CacheType.APPLICATION);
        logger.severe("---------readingPaneQueryCache ="+ readingPaneQueryCache);
        int ret = readingPaneQueryCache.size();
        logger.severe("---------readingPaneQueryCache count ="+ ret);
        return Response.ok(ret+"").type(MediaType.TEXT_HTML).build();
    }
    
    @GET
    @Path("/readingPaneQueryCacheKeys")
    @Produces(MediaType.TEXT_HTML)
    public Response getReadingPaneQueryCacheKeys(){
        Cache readingPaneQueryCache = CacheUtil.getInstance().getCache(CacheUtil.CacheType.APPLICATION);
        logger.severe("---------readingPaneQueryCacheKeys ="+ readingPaneQueryCache);
        StringBuilder sb = new StringBuilder("::::Printing Keys:::: \n");
        if(readingPaneQueryCache != null){
            Set<Object> keys = readingPaneQueryCache.keySet();
            for(Object key: keys){
                sb.append(key.toString()+"\n");
            }
        }
        return Response.ok(sb.toString()+"").type(MediaType.TEXT_HTML).build();
    }
    
    @GET
    @Path("/readingPaneQueryCacheStatsInvalidate/{keyString}")
    @Produces(MediaType.TEXT_HTML)
    public Response clearReadingPaneQueryCache(@PathParam("keyString") String keyString){
        Integer cacheCount = -1;
        boolean cacheCleared = false;
        if(keyString != null){
            try{
                Cache readingPaneQueryCache = CacheUtil.getInstance().getCache(CacheUtil.CacheType.APPLICATION);
                cacheCount = (Integer)readingPaneQueryCache.get(keyString);
                readingPaneQueryCache.put(keyString, null);    
                logger.severe("--------------Msg dynamic query Cache Cleared for user :"+ keyString);
                cacheCleared = true;
            }catch(Exception e){
                e.printStackTrace();
            }
        } else {
            //Clear everything
            Cache readingPaneQueryCache = CacheUtil.getInstance().getCache(CacheUtil.CacheType.APPLICATION);
            readingPaneQueryCache.clear();
        }
        return Response.ok(cacheCount+", cache Cleared="+cacheCleared).type(MediaType.TEXT_HTML).build();
    }
    
    @GET
    @Path("/invalidateSplashCountCache")
    @Produces(MediaType.TEXT_HTML)
    public Response invalidateSplashCountCache(){
        boolean cacheCleared = false;
        int entryCount = -1;
        try{
            Cache splashCountCache = CacheUtil.getInstance().getCache(CacheUtil.CacheType.SPLASH_COUNT_CACHE);
            entryCount = splashCountCache.size();
            splashCountCache.clear();
            logger.severe("--------------Splash Count Cache Cleared--------------");
            cacheCleared = true;
        }catch(Exception e){
            e.printStackTrace();
        }
        return Response.ok("cache Cleared="+cacheCleared+", total entries cleared="+ entryCount).type(MediaType.TEXT_HTML).build();
    }
    
    @GET
    @Path("/userProfileCacheInvalidate/{userId}")
    @Produces(MediaType.TEXT_HTML)
    public Response clearUserProfileCache(@PathParam("userId") String userId){
        Integer cacheCount = -1;
        boolean cacheCleared = false;
        if(userId != null){
            try{
                Cache userProfileCache = CacheUtil.getInstance().getCache(CacheUtil.CacheType.USERPROFILE_CACHE);
                cacheCount = userProfileCache.get(userId) == null ? 0 : 1;
                userProfileCache.put(userId, null);    
                logger.severe("--------------Msg Count Cache Cleared for user :"+ userId);
                cacheCleared = true;
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        return Response.ok(cacheCount+", cache Cleared="+cacheCleared+", for user "+ userId).type(MediaType.TEXT_HTML).build();
    }
    
    @GET
    @Path("/profaneWords")
    public Response getProfaneWords(){        
        MessagesADHelper ad = _getMessagesAD();
        String[] ret = ad.getProfaneWords();        
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    } 
 
    @GET
    @Path("/harmfulExtensions")
    public Response getHarmfulExtensions(){        
        MessagesADHelper ad = _getMessagesAD();
        String[] ret = ad.getHarmfulExtensions();
        
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }    
    
    @POST
    @Path("/clearUserCache")
    public Response clearMessageUserCache(){
        boolean success = true;
        try{
            LDAPCacheUtil.getInstance().clearMessageUserCache();    
        }catch(Exception e){
            success = false;
        }
        return Response.ok(success).type(MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("/userCacheStats")
    public Response dumpMessageUserCacheStats(){
        String ret = "";
        ret = LDAPCacheUtil.getInstance().dumpMessageUserCacheStats();    
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
	
//    @GET
//    @Path("/employeeProfile/samAccountName/{samAccountName}")
//    public Response getEmployeeProfileWSamAccountName(@PathParam("samAccountName") String samAccountName){
//        MessagesAMImpl am = (MessagesAMImpl) getMessagesAM(); 
//        EmployeeProfileDTO ret = am.getEmployeeProfileWSamAccountName(samAccountName);
//        if(ret != null)    
//        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
//        else
//        return Response.ok("No User found for samAccountName " + samAccountName).type(MediaType.APPLICATION_JSON).build();
//         
//       
//    }
//        
//    @GET
//    @Path("/employeeProfile/psId/{employeeId}")
//    public Response getEmployeeProfileWEmployeeID(@PathParam("employeeId") String employeeId){
//        MessagesAMImpl am = (MessagesAMImpl) getMessagesAM(); 
//        EmployeeProfileDTO ret = am.getEmployeeProfileWEmployeeID(employeeId);
//        if(ret != null)    
//        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
//    else
//        return Response.ok("No User found for EmployeeId " + employeeId).type(MediaType.APPLICATION_JSON).build();
//    
//    }
//            
        
    @POST
    @Path("/employeeProfileSearch/{itemsPerPage}/{pageNumber}")
    public Response employeeProfileSearch(EmployeeSearchDTO _input,@PathParam("itemsPerPage") int _itemsPerPage,@PathParam("pageNumber") int _pageNumber){
        
        MessagesAMImpl am = (MessagesAMImpl) getMessagesAM(); 
        EmployeeProfileSearchResultsDTO ret = am.searchEmployeeProfile(_input, _itemsPerPage, _pageNumber,(HashMap)_input.getRepositories());
              
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
        @GET
    @Path("/groupMembers/{restNumber}/{brand}/{itemsPerPage}/{pageNumber}")
    public Response getGroupMemberProfiles(@PathParam("itemsPerPage") int _itemsPerPage,
                                           @PathParam("pageNumber") int _pageNumber,
                                           @PathParam("restNumber") String _restaurantNumber,
                                           @PathParam("brand") String _brand,
                                           @QueryParam("repositoryAD") String repositoryAD,
                                           @QueryParam("repositoryKD") String repositoryKD) {


        if (null !=  ADFContext.getCurrent().getSecurityContext()) {
            String[] roles = ADFContext.getCurrent().getSecurityContext().getUserRoles();

            // just to print user roles
            for (String r : roles) {
                logger.info("MessageResource:getGroupMemberProfiles::UserRole " + r);

            }


            if (!ADFContext.getCurrent().getSecurityContext().isUserInRole("Hourly")) {

                HashMap<String, String> repositoryHashmap = new HashMap<String, String>();
                if (repositoryAD != null && repositoryKD != null && !repositoryKD.isEmpty() &&
                    !repositoryAD.isEmpty()) {
                    repositoryAD = repositoryAD.replace("--", "#");
                    repositoryKD = repositoryKD.replace("--", "#");
                    repositoryHashmap.put("AD", repositoryAD);
                    repositoryHashmap.put("KD", repositoryKD);
                }
                MessagesAMImpl am = (MessagesAMImpl) getMessagesAM();
                EmployeeProfileSearchResultsDTO ret =
                    am.getGroupMembers(_itemsPerPage, _pageNumber, _restaurantNumber, _brand, repositoryHashmap);
               return Response.ok(ret)
                                   .type(MediaType.APPLICATION_JSON)
                                   .build();
            } else {
              return Response.status(404).type(MediaType.APPLICATION_JSON).build();
            }

        } else{
            HashMap<String, String> repositoryHashmap = new HashMap<String, String>();
            if (repositoryAD != null && repositoryKD != null && !repositoryKD.isEmpty() && !repositoryAD.isEmpty()) {
                repositoryAD = repositoryAD.replace("--", "#");
                repositoryKD = repositoryKD.replace("--", "#");
                repositoryHashmap.put("AD", repositoryAD);
                repositoryHashmap.put("KD", repositoryKD);
            }
            MessagesAMImpl am = (MessagesAMImpl) getMessagesAM();
            EmployeeProfileSearchResultsDTO ret =
                am.getGroupMembers(_itemsPerPage, _pageNumber, _restaurantNumber, _brand, repositoryHashmap);
            return Response.ok(ret)
                               .type(MediaType.APPLICATION_JSON)
                               .build();
        }



    }
    @GET
    @Path("/searchRestaurant/{restNumber}")
    public Response searchRestaurantIds( @PathParam("restNumber") String _restaurantNumber){
    
        MessagesAMImpl am = (MessagesAMImpl) getMessagesAM(); 
        RestaurantLocationDTO [] restaurantIds = am.searchRestaurantIds(_restaurantNumber); 
              
        return Response.ok(restaurantIds).type(MediaType.APPLICATION_JSON).build();
    }
        
    @GET
    @Path("/readReport/{messageId}")
    public Response getReadReportForMessage(@PathParam("messageId") Long messageId){
        
        MessagesAMImpl am =  getMessagesAM(); 
        List<ReadReportDTO> ret = am.getReadReport(messageId);
              
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    } 
    
    /**************************MyShift Ph2 Endpoints ****************************/
    @DELETE
    @Path("/conversation")
    public Response deleteMessages(@QueryParam("parentMessageId")List<Long> parentMessageIds){
        List<Long> deletedInboxIds = new ArrayList<Long>();
        if(parentMessageIds != null){
            MessagesAMImpl am = getMessagesAM();
            String channel = getChannel();
            for(Long parentMessageId : parentMessageIds){
                Long ret = am.deleteConversation(parentMessageId, channel);    
                deletedInboxIds.add(ret);
            }    
        }
        return Response.ok(deletedInboxIds).type(MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("/{parentMessageId}/recipients")
    public Response getRecipientsForConversation(@PathParam("parentMessageId")Long parentMessageId){
        
        MessagesAMImpl am =  getMessagesAM(); 
        List<RecipientDTO> recipients = am.getRecipientsForConversation(parentMessageId);
        RecipientDTO[] arr = new RecipientDTO[0];
        RecipientDTO[] recipientArr = recipients.toArray(arr);
        return Response.ok(recipientArr).type(MediaType.APPLICATION_JSON).build();
    }
    
    
    @PUT
    @Path("/{parentMessageId}/add-recipient")
    public Response addRecipient(@PathParam("parentMessageId")Long parentMessageId, RecipientDTO participant){
        Long createdMessageId = null;
        MessagesAMImpl am =  getMessagesAM(); 
        try{
            createdMessageId = am.addRecipient(parentMessageId, participant, true);    
        }catch(Exception e) {
            e.printStackTrace();
            ErrorMessage err = new ErrorMessage();
            err.setMessage(e.getMessage());
            throw new BusinessFaultRequestException(err);
        }
        
              
        return Response.ok(createdMessageId).type(MediaType.APPLICATION_JSON).build();
    }
    
    @DELETE
    @Path("/{parentMessageId}/remove-recipient/{participantUserId}")
    public Response removeRecipient(@PathParam("parentMessageId")Long parentMessageId, @PathParam("participantUserId") String participantUserId){
        
        MessagesAMImpl am =  getMessagesAM(); 
        Long deletedRowId = am.removeRecipient(parentMessageId, participantUserId);
              
        return Response.ok(deletedRowId).type(MediaType.APPLICATION_JSON).build();
    }
    
    @PUT
    @Path("/mute")
    public Response mute(@QueryParam("parentMessageId")List<Long> parentMessageIds){
        MessagesAMImpl am =  getMessagesAM();
        List<Long> retIds = new ArrayList<Long>();
        if(parentMessageIds != null){
            for(Long parentMessageId: parentMessageIds){
                Long retId = am.muteUnmuteConversation(parentMessageId, true);    
                retIds.add(retId);
            }
        }
        
        return Response.ok(retIds).type(MediaType.APPLICATION_JSON).build();
    }
    
    @PUT
    @Path("/unmute")
    public Response unmute(@QueryParam("parentMessageId")List<Long> parentMessageIds){
        MessagesAMImpl am =  getMessagesAM();
        List<Long> retIds = new ArrayList<Long>();
        if(parentMessageIds != null){
            for(Long parentMessageId: parentMessageIds){
                Long retId = am.muteUnmuteConversation(parentMessageId, false);    
                retIds.add(retId);
            }
        }
        
        return Response.ok(retIds).type(MediaType.APPLICATION_JSON).build();
    }
    
    
    @GET
    @Path("/chatroom/{firstUser}/{secondUser}")
    public Response getChatRoom(@PathParam("firstUser") String firstUser,
                                @PathParam("secondUser") String secondUser) {
        String isMessagingChatRoomThroughAM = KrowdUtility.getInstance().getProperties().getProperty("MESSAGING_CHATROOM_THROUGH_AM");
        if(firstUser == null || secondUser == null){
            ErrorMessage err = new ErrorMessage();
            err.setMessage("Invalid Parameters");
            throw new BusinessFaultRequestException(err);
        }
        Long parentMessageId = null;
        if(isMessagingChatRoomThroughAM != null && isMessagingChatRoomThroughAM.equalsIgnoreCase("TRUE")){
            MessagesAMImpl am =  getMessagesAM(); 
            parentMessageId = am.getChatRoom(firstUser, secondUser);
        } else {
            parentMessageId = new MessageDAO().getChatRoomId(firstUser, secondUser);
        }
        
        return Response.ok(parentMessageId).type(MediaType.APPLICATION_JSON).build();
    } 
    
    
    @GET
    @Path("/detailedReadReport/{messageId}")
    public Response getDetailedReadReportForMessage(@PathParam("messageId") Long messageId, 
                                                    @QueryParam("itemsPerPage")@DefaultValue("10") Integer itemsPerPage,
                                                    @QueryParam("pageNo")@DefaultValue("1") Integer pageNo){
        MessagesAMImpl am =  getMessagesAM(); 
        List<MessageReadReportDTO> report = am.getDetailedReadReportForMessage(messageId, itemsPerPage, pageNo);
        return Response.ok(report).type(MediaType.APPLICATION_JSON).build();
    } 
    
    @PUT
    @Path("/update-subject/{parentMessageId}")
    public Response updateSubjectLine(@PathParam("parentMessageId")Long parentMessageId, Map<String, String> body){
        MessagesAMImpl am =  getMessagesAM();
        Long retMessageId = null;
        String subject = body.get("subject");
        if(body != null && subject != null && subject.length() > 0 && parentMessageId != null) {
            retMessageId = am.updateSubjectLine(parentMessageId, subject);
        }
        
        return Response.ok(retMessageId).type(MediaType.APPLICATION_JSON).build();
    }
    
  
    
    
    @GET
    @Path("/location/{locationId}/contact-list/jobCodes")
    public Response getContactListForLocation(@PathParam("locationId")String locationId) {
        MessagesAMImpl am =  getMessagesAM();
        List<KeyValDTO> allJobCodes = am.getRestaurantJobCodes(locationId);  

        return Response.ok(allJobCodes).type(MediaType.APPLICATION_JSON).build();
    }
    
    
    @GET
    @Path("/location/{locationId}/contact-list")
    public Response getContactListForLocation(@PathParam("locationId")String locationId,
                                              @QueryParam("itemsPerPage")@DefaultValue("10") Integer itemsPerPage,
                                              @QueryParam("pageNo")@DefaultValue("1") Integer pageNo,
                                              @QueryParam("searchString") String searchString,
                                              @QueryParam("jobCode") String jobCode,
                                              @QueryParam("fetchAll")@DefaultValue("false") Boolean fetchAll
                                              ){
        String isMessagingContactListThroughAM = KrowdUtility.getInstance().getProperties().getProperty("MESSAGING_CONTACT_LIST_THROUGH_AM");
        List<UserDTO> contactList = new ArrayList<UserDTO>();
        if(isMessagingContactListThroughAM != null && isMessagingContactListThroughAM.equalsIgnoreCase("TRUE")){
            MessagesAMImpl am =  getMessagesAM();
            contactList = am.getRestaurantContactList(locationId, searchString, jobCode, itemsPerPage, pageNo, fetchAll);  
        } else {
            contactList = new MessageDAO().getRestaurantContactList(locationId, searchString, jobCode, itemsPerPage, pageNo, fetchAll);
        }
        

        return Response.ok(contactList).type(MediaType.APPLICATION_JSON).build();
    }
    
    /**
     * Alternate addressbookSearch implementation to get additional data from PS.
     * Created separate endpoint so current desktop is not impacted.
     */
    @GET
    @Path("/addressbookSearch2")
    public Response addressbookSearch2(@DefaultValue("") @QueryParam("name") String displayName,@QueryParam("restId") String restId, @DefaultValue("") @QueryParam("brand") String brand){
       MessagesAMImpl am = getMessagesAM();
       UserDTO[] ret =  am.addressbookSearch(displayName,restId,brand);
       return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    /////////////////////////SPLASH Related APIs////////////////////////////////
    @GET
    @Path("/splash-message/admin")
    public Response getSplashMessageSForAdmin(@DefaultValue("1") @QueryParam("pageNumber") int pageNumber,
                             @DefaultValue("10") @QueryParam("pageSize") int pageSize){
        SplashMessageAMImpl am =  getSplashMessageAM();
        List<SplashMessageDTO> messages = am.getSplashMessagesForAdmin(pageNumber, pageSize);
        return Response.ok(messages).type(MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("/splash-message/triggers/{channelCode}")
    public Response getTriggersForChannel(@DefaultValue("DASH") @QueryParam("channelCode") String channelCode){
        List<KeyValueDTO> triggerNames = new ArrayList<KeyValueDTO>();
        if(SPLASH_ALLOWED_TRIGGERS == null){
            if(channelCode.equalsIgnoreCase("DASH")){
                triggerNames.add(new KeyValueDTO("clockIn", "CLOCK_IN"));
                triggerNames.add(new KeyValueDTO("clockOut", "CLOCK_OUT"));
                triggerNames.add(new KeyValueDTO("managerSwipe", "MANAGER_SWIPE"));
            }
        }else{
            String jsonStr = SPLASH_ALLOWED_TRIGGERS;
//            jsonStr = "[\n" + 
//            " {\"key\": \"clockIn\", \"value\": \"CLOCK_IN\"},\n" + 
//            " {\"key\": \"clockOut\", \"value\": \"CLOCK_OUT\"},\n" + 
//            " {\"key\": \"managerSwipe\", \"value\": \"MANAGER_SWIpe\"}\n" + 
//            "]";
            ObjectMapper mapper = new ObjectMapper();
            try {
                List<HashMap> triggers = (List<HashMap>)mapper.readValue(jsonStr, List.class);
                for(HashMap trigger : triggers){
                    triggerNames.add(new KeyValueDTO(trigger.get("key").toString(), trigger.get("value").toString()));
                }
            } catch (JsonMappingException | JsonParseException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return Response.ok(triggerNames).type(MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("/splash-message")
    public Response saveSplashMessage(SplashMessageDTO dto){
        SplashMessageAMImpl am =  getSplashMessageAM();
        SplashMessageDTO message = null;
        try{
            message = am.saveSplashForAdmin(dto, false);    
        }catch(Exception e){
            e.printStackTrace();
            ErrorMessage err = new ErrorMessage();
            err.setMessage(e.getMessage());
            throw new BusinessFaultRequestException(err);
        }
        return Response.ok(message).type(MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("/splash-message/{splashMessageId}/launch")
    public Response launchSplashMessage(@PathParam("splashMessageId")Long splashMessageId,
                                        SplashMessageDTO dto){
        SplashMessageAMImpl am =  getSplashMessageAM();
        SplashMessageDTO retId = null;
        try{
            retId = am.saveSplashForAdmin(dto, true);    
        }catch(Exception e){
            e.printStackTrace();
            ErrorMessage err = new ErrorMessage();
            err.setMessage(e.getMessage());
            throw new BusinessFaultRequestException(err);
        }
        return Response.ok(retId).type(MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("/splash-message/launch/{tag}")
    public Response launchAdHocSplashMessage(@PathParam("tag")String tag,
                                             SplashMessageDTO dto){
        SplashMessageAMImpl am =  getSplashMessageAM();
        Long retId = null;
        try{
            if(tag != null && tag.equalsIgnoreCase("daily")){
                Calendar lastMidNight = new GregorianCalendar();
                // reset hour, minutes, seconds and millis
                lastMidNight.set(Calendar.HOUR_OF_DAY, 0);
                lastMidNight.set(Calendar.MINUTE, 0);
                lastMidNight.set(Calendar.SECOND, 0);
                lastMidNight.set(Calendar.MILLISECOND, 0);
                dto.setLaunchDate(lastMidNight.getTime());
                
                Calendar todayMidnight = new GregorianCalendar();
                // reset hour, minutes, seconds and millis
                todayMidnight.set(Calendar.HOUR_OF_DAY, 0);
                todayMidnight.set(Calendar.MINUTE, 0);
                todayMidnight.set(Calendar.SECOND, 0);
                todayMidnight.set(Calendar.MILLISECOND, 0);
                todayMidnight.add(Calendar.HOUR_OF_DAY, 24);
                dto.setExpiryDate(todayMidnight.getTime());
                
                SimpleDateFormat sdf = new SimpleDateFormat("dd MMMM yyyy");
                String today = sdf.format(new Date());
                dto.setMessageTitle(dto.getMessageTitle()+" ["+ today+"]");
            }
            retId = am.launchAdHocSplash(dto);    
        }catch(Exception e){
            e.printStackTrace();
            ErrorMessage err = new ErrorMessage();
            err.setMessage(e.getMessage());
            throw new BusinessFaultRequestException(err);
        }
        return Response.ok(retId).type(MediaType.APPLICATION_JSON).build();
    }

//    @POST
//    @Path("/splash-message/{splashMessageId}/stop")
//    public Response stopSplashMessage(@PathParam("splashMessageId")Long splashMessageId){
//        MessagesAMImpl am =  getMessagesAM();
//        Long retId = null;
//        try{
//            retId = am.updateSplashStatus(splashMessageId, "STOPPED");    
//        }catch(Exception e){
//            e.printStackTrace();
//            ErrorMessage err = new ErrorMessage();
//            err.setMessage(e.getMessage());
//            throw new BusinessFaultRequestException(err);
//        }
//        return Response.ok(retId).type(MediaType.APPLICATION_JSON).build();
//    }
    
    @GET
    @Path("/splash-message")
    public Response getSplashMessagesForUser(){
        Response response = null;
        List<UserSplashMessageDTO> messages = new ArrayList<UserSplashMessageDTO>();
        String isMessageCountCacheDisabled = KrowdUtility.getInstance().getProperties().getProperty("MESSAGING_SPLASH_COUNT_CACHE_DISABLED");
        /**
         * Cache logic: As long as there are pending views, the cache will not be used.
         * As soon as the views are exhausted/acknowledged, the data will be served from cache (empty array)
         */
        if(isMessageCountCacheDisabled == null || isMessageCountCacheDisabled.equalsIgnoreCase("FALSE")) {
            Cache cache = CacheUtil.getInstance().getCache(CacheUtil.CacheType.SPLASH_COUNT_CACHE);
            String userName = ADFContext.getCurrent().getSecurityContext().getUserName();
            Object cacheEntry = cache.get(userName);
            if(cacheEntry == null){
                messages = _getSplashForUserIntern();
                cache.put(userName, messages.size());//Put View count in cache
                response = Response.ok(messages).type(MediaType.APPLICATION_JSON).build();
            } else {
                int unreadViewsCount = (Integer)cacheEntry; 
                if(unreadViewsCount > 0){
                    messages = _getSplashForUserIntern();
                    cache.put(userName, messages.size());
                    response = Response.ok(messages).type(MediaType.APPLICATION_JSON).build();
                } else {
                    messages = new ArrayList<UserSplashMessageDTO>();//return empty array if all views are exhausted.
                    response = Response.ok(messages).header("Cache-COH-Entry", "true").type(MediaType.APPLICATION_JSON).build();
                }
            }    
        } else {
            messages = _getSplashForUserIntern();
            response = Response.ok(messages).type(MediaType.APPLICATION_JSON).build();
        }
        
        return response;
    }
    
    private List<UserSplashMessageDTO> _getSplashForUserIntern(){
        String isMessagingUnreadCountThroughAM = KrowdUtility.getInstance().getProperties().getProperty("MESSAGING_UNREAD_COUNT_THROUGH_AM");
        List<UserSplashMessageDTO> messages = new ArrayList<UserSplashMessageDTO>();
        String userName = ADFContext.getCurrent().getSecurityContext().getUserName();
        if(isMessagingUnreadCountThroughAM != null && isMessagingUnreadCountThroughAM.equalsIgnoreCase("TRUE")){
            SplashMessageAMImpl am =  getSplashMessageAM();
            messages = am.getSplashMessagesForKrowdUser(userName);
        } else {
            messages = new SplashDAO().getSplashMessagesForKrowdUser(userName);
        }
        
        return messages;
    }
    
    @GET
    @Path("/splash-message/{splashId}")
    public Response getSplashMessage(@PathParam("splashId")Long splashId) {
        SplashMessageAMImpl am =  getSplashMessageAM();
        SplashMessageDTO splash = am.getSplashMessage(splashId);
        return Response.ok(splash).type(MediaType.APPLICATION_JSON).build();
    }
    
    @PUT
    @Path("/splash-message/{splashMessageId}/acknowledge")
    public Response acknowledgeSplashMessage(@PathParam("splashMessageId")Long splashMessageId,
                                             @DefaultValue("Y") @QueryParam("ackValue") String ackValue){
        SplashMessageAMImpl am =  getSplashMessageAM();
        Long retId = am.acknowledgeSplash(splashMessageId, ackValue);
        return Response.ok(retId).type(MediaType.APPLICATION_JSON).build();
    }
    
    @DELETE
    @Path("/splash-message/{splashMessageId}")
    public Response deleteSplash(@PathParam("splashMessageId")Long splashMessageId){
        SplashMessageAMImpl am =  getSplashMessageAM();
        Long retId = am.deleteSplash(splashMessageId);
        return Response.ok(retId).type(MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("/splash-message/{splashMessageId}/report")
    public Response getSplashReport(@PathParam("splashMessageId")Long splashMessageId){
        SplashMessageAMImpl am =  getSplashMessageAM();
        SplashReportDTO dto = am.getSplashReport(splashMessageId);
        return Response.ok(dto).type(MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("/splash-message/{forUserId}/email-report")
    public Response sendSplashReportByEmail(@PathParam("forUserId")String forUserId, 
                                            List<String> emailIds){
        SplashMessageAMImpl am =  getSplashMessageAM();
        am.sendSplashReportEmail(forUserId, emailIds);
        return Response.ok("{\"message\":\"ok\"}").type(MediaType.APPLICATION_JSON).build();
    }
    
/*    @GET
    @Path("/splash-message/{splashMessageId}/exhaustedViewUsers")
    public Response getExhaustedViewsUserCount(@PathParam("splashMessageId")Long splashMessageId){
        SplashMessageAMImpl am =  getSplashMessageAM();
        Long count = am.getExhaustedViewsUserCount(splashMessageId);
        return Response.ok("{\"usersWithExhaustedViews\": \""+count+"\"}").type(MediaType.APPLICATION_JSON).build();
    }
*/
    
    @POST
    @Path("/splash-message/{splashMessageId}/exhaustedViewUsers")
    public Response addViewsToExhaustedViewsUser(@PathParam("splashMessageId")Long splashMessageId){
        SplashMessageAMImpl am =  getSplashMessageAM();
        Long count = am.addViewsToExhaustedViewsUser(splashMessageId);
        return Response.ok("{\"noOfRowsUpdated\": \""+count+"\"}").type(MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("/splash-message/{splashMessageId}/newPSUsers")
    public Response getUserCountFromNewPSUsers(@PathParam("splashMessageId")Long splashMessageId){
        SplashMessageAMImpl am =  getSplashMessageAM();
        Long count = am.getUserCountFromNewPSUsers(splashMessageId);
        return Response.ok("{\"newPSUsers\": \""+count+"\"}").type(MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("/splash-message/{splashMessageId}/addNewPSUsers")
    public Response addViewsForNewPSUsers(@PathParam("splashMessageId")Long splashMessageId){
        SplashMessageAMImpl am =  getSplashMessageAM();
        Long count = am.addViewsForNewPSUsers(splashMessageId);
        return Response.ok("{\"noOfRowsCreated\": \""+count+"\"}").type(MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("/splash-message/{splashMessageId}/locations/{locationId}/sendUpdate")
    public Response sendCampaignUpdateToLocation(@PathParam("splashMessageId")Long splashMessageId,
                                          @PathParam("locationId")String locationId){
        SplashMessageAMImpl am =  getSplashMessageAM();
        am.sendCampaignUpdateEventsForLaunchedCampaigns(splashMessageId, false, locationId);
        return Response.ok("{\"messageSent\": \"ok\"}").type(MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("/splash-message/{splashMessageId}/locations")
    public Response getSplashLocations(@PathParam("splashMessageId")Long splashMessageId){
        SplashMessageAMImpl am =  getSplashMessageAM();
        List<SplashLocationDTO> locations = am.getSplashLocationDetails(splashMessageId);
        return Response.ok(locations).type(MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("/splash-message/{splashMessageId}/publishUpdate/{locationId}")
    public Response addViewsForNewPSUsers(@PathParam("splashMessageId")Long splashMessageId,
                                          @PathParam("locationId")String locationId){
        SplashMessageAMImpl am =  getSplashMessageAM();
        String locId = am.publishSplashToLocation(splashMessageId, locationId);
        return Response.ok("{\"locationId\": \""+locId+"\"}").type(MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("/splash-message/{splashId}/report/download")
    @Produces(MediaType.APPLICATION_OCTET_STREAM)
    public Response getDownloadableSplashReport(@PathParam("splashId")Long splashId){
         SplashDAO dao = new SplashDAO();
         List<List<String>> rows = dao.getDownloadableReport(splashId);
         StringBuilder sb = new StringBuilder();
         for(List<String> row : rows){
             for(String cell: row){
                 sb.append(cell).append(",");
             }
             sb.append("\n");
         }
        byte[] bytes = sb.toString().getBytes();
        return Response.ok(bytes, MediaType.APPLICATION_OCTET_STREAM)
            .header("Content-Disposition", "attachment; filename=" + "Splash_Message_"+splashId+".csv").build();
     }
    
    @PUT
    @Path("/splash-message/{splashMessageId}/view")
    public Response viewSplashMessage(@PathParam("splashMessageId")Long splashMessageId,
                                      @DefaultValue("Y") @QueryParam("viewValue") String viewValue){
        SplashMessageAMImpl am =  getSplashMessageAM();
        Long retId = am.viewSplash(splashMessageId, viewValue);
        return Response.ok(retId).type(MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("/splash-message/media")
    public Response getAllSplashMedia() {
        MessagesAMImpl am =  getMessagesAM();
        List<Map<String, String>> media = new ArrayList<Map<String, String>>();
//        try {
//            media = am.getSplashMedia();
//        } catch (IdcClientException e) {
//            e.printStackTrace();
//        } catch (LoginException e) {
//            e.printStackTrace();
//        } catch (RepositoryException e) {
//            e.printStackTrace();
//        } catch (NamingException e) {
//            e.printStackTrace();
//        }
        return Response.ok(media).type(MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("/splash-message/verify-employee-ids")
    public Response validateEmployeeIds(List<String> employeeIds) {
        SplashMessageAMImpl am =  getSplashMessageAM();
        EmployeeValidationDTO dto = new EmployeeValidationDTO();
        if(employeeIds != null && employeeIds.size() > 0)
            dto = am.validateEmployeeIds(employeeIds);
        return Response.ok(dto).type(MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("/splash-message/get-employee-ids")
    public Response getEmployeeIds(List<String> employeeIds) {
        List<Map<String,String>> employees = new ArrayList<Map<String, String>>();
        if(employeeIds != null && employeeIds.size() > 0){
            for(String empId : employeeIds){
                KrowdUserDTO user = LDAPCacheUtil.getInstance().getEmployee(empId);
                if(user != null){
                    Map commonAttrs = user.getUserAttributes();
                    commonAttrs.put("concept", user.getConcept());
                    commonAttrs.put("locationId", user.getLocationId());
                    employees.add(commonAttrs);
                }
            }
        }
        return Response.ok(employees).type(MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("/splash-message/{splashId}/add-employeeIds")
    public Response addAdHocListToLaunchedSplash(@PathParam("splashId")Long splashId,
                                                 List<String> employeeIds){
        SplashMessageAMImpl am =  getSplashMessageAM();
        Long addedEmpIds = 0L;
        if(employeeIds != null && employeeIds.size() > 0)
            addedEmpIds = am.addAdHocListToLaunchedSplash(splashId, employeeIds);
        return Response.ok("{\"count\": \""+addedEmpIds+"\"}").type(MediaType.APPLICATION_JSON).build();                                             
    }
    
    @GET
    @Path("/splash-message/dash-preview/{splashId}")
    public Response getDashPreviewJSON(@PathParam("splashId")Long splashId) {
        SplashMessageAMImpl am =  getSplashMessageAM();
        CampaignDetailDTO detail = am.getCampaignDetail(splashId, "DASH");
        return Response.ok(detail).type(MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("/splash-message/send-preview")
    public Response sendPreviewToUser(SplashPreviewDTO dto) {
        SplashMessageAMImpl am =  getSplashMessageAM();
        am.sendPreviewMessageForSplash(dto);
        return Response.ok().type(MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("/splash-message/{splashId}/send-push-reminder")
    public Response sendPushForSplash(@PathParam("splashId")Long splashId, SplashPreviewDTO dto) {
        SplashMessageAMImpl am =  getSplashMessageAM();
        dto.setSplashId(splashId);
        int ret = am.sendSplashReminderPush(dto);
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("/splash-message/media")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    public Response addSplashMedia(@FormDataParam("file") InputStream uploadedInputStream,
                @FormDataParam("file") FormDataContentDisposition fileDetail){
        Response response = null;
        String retContentId = null;
        MessagesAMImpl am =  getMessagesAM();
        String fileName = fileDetail.getFileName();
        logger.info("----fileName "+ fileName);
        if(fileName != null){
            String[] fileSplits = fileName.split("\\.");
            logger.info("---"+ fileSplits+ ","+fileSplits.length);
            if(fileSplits != null && fileSplits.length > 0){
                String extension = fileSplits[fileSplits.length - 1];
                logger.info("file extension = "+ extension);
                if(validFileExtensions.containsKey(extension.toUpperCase())){
                    logger.info("extension allowed");
                    byte[] bytes;
                    try {
                        bytes = IOUtils.toByteArray(uploadedInputStream);
                        retContentId = am.uploadSplashMediaInUCM(fileName, bytes);
                    } catch (IOException e) {
                        e.printStackTrace();
                        throw new WebApplicationException(Response.Status.BAD_REQUEST);
                    } catch (NamingException e) {
                        e.printStackTrace();
                        throw new WebApplicationException(Response.Status.BAD_REQUEST);
                    } catch (Exception e) {
                        e.printStackTrace();
                        throw new WebApplicationException(Response.Status.BAD_REQUEST);
                    }
                }else{
                    logger.severe("Unsupported File Extension."+ extension);
                }
            }
        }
        
        return Response.ok("{\"retContentId\": \""+retContentId+"\"}").type(MediaType.APPLICATION_JSON).build();
        
    }
    
    @DELETE
    @Path("/splash-message/media/{contentId}")
    public Response deleteSplashMedia(@PathParam("contentId")String contentId){
        MessagesAMImpl am =  getMessagesAM();
        String retId = null;
        try {
            retId = am.deleteSplashMediaInUCM(contentId);
        } catch (LoginException e) {
            e.printStackTrace();
            throw new WebApplicationException(Response.Status.BAD_REQUEST);
        } catch (RepositoryException e) {
            e.printStackTrace();
            throw new WebApplicationException(Response.Status.BAD_REQUEST);
        } catch (NamingException e) {
            e.printStackTrace();
            throw new WebApplicationException(Response.Status.BAD_REQUEST);
        } catch (Exception e) {
            e.printStackTrace();
            throw new WebApplicationException(Response.Status.BAD_REQUEST);
        }
        return Response.ok(retId).type(MediaType.APPLICATION_JSON).build();
    }
    
    ///////////////////////////////////////////Moderation APIs//////////////////////////////////////////
    @POST
    @Path("/messages/admin/deleteEntireMessage/{parentMessageId}")
    public Response adminDeleteEntireMessage(@PathParam("parentMessageId")Long parentMessageId){
        MessagesAMImpl am =  getMessagesAM();
        Long retId = null;
        try{
            retId = am.adminDeleteEntireMessage(parentMessageId);
        }catch(Exception e){
            e.printStackTrace();
            ErrorMessage err = new ErrorMessage();
            err.setMessage(e.getMessage());
            throw new BusinessFaultRequestException(err);
        }
        return Response.ok(retId).type(MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("/messages/admin/deleteSpecificMessage/{messageId}")
    public Response adminDeleteSpecificMessage(@PathParam("messageId")Long messageId){
        MessagesAMImpl am =  getMessagesAM();
        Long retId = null;
        try{
            retId = am.adminDeleteSpecificMessage(messageId);
        }catch(Exception e){
            e.printStackTrace();
            ErrorMessage err = new ErrorMessage();
            err.setMessage(e.getMessage());
            throw new BusinessFaultRequestException(err);
        }
        return Response.ok(retId).type(MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("/messages/{messageId}/report")
    public Response reportMessage(@PathParam("messageId")Long messageId){
        MessagesAMImpl am =  getMessagesAM();
        Long retId = null;
        try{
            retId = am.reportMessageByUser(messageId);
        }catch(Exception e){
            e.printStackTrace();
            ErrorMessage err = new ErrorMessage();
            err.setMessage(e.getMessage());
            throw new BusinessFaultRequestException(err);
        }
        return Response.ok(retId).type(MediaType.APPLICATION_JSON).build();
    }

    @POST
    @Path("/messages/admin/removeMessageForUser/{userId}/{messageId}")
    public Response removeMessageForUser(@PathParam("userId")String userId, 
                                         @PathParam("messageId")Long messageId){
        MessagesAMImpl am =  getMessagesAM();
        Long retId = null;
        try{
            retId = am.adminDeleteMessageForUser(messageId, userId);
        }catch(Exception e){
            e.printStackTrace();
            ErrorMessage err = new ErrorMessage();
            err.setMessage(e.getMessage());
            throw new BusinessFaultRequestException(err);
        }
        return Response.ok(retId).type(MediaType.APPLICATION_JSON).build();
    }    
    
    private String getChannel() {
        String channel = "DESKTOP";
        String userAgent = this.httpRequest.getHeader("User-Agent");
        if(userAgent != null && userAgent.indexOf("Mobile") != -1){
            channel = "MOBILE";
        }
        
        return channel;
    }
    
    ////////////////////////////////////////TEST METHODS//////////////////////////////////////////////////////////
    @POST
    @Path("/testSplashImpression")
    @Consumes("text/html")
    public Response testMsgNotification(){
        String res = "not-ok";
        SplashImpressionDTO dto = new SplashImpressionDTO();
        dto.setAppId("DASH");
        dto.setEventName("CAMPAIGN_IMPRESSION");
        dto.setChannelCode("DASH");
        dto.setEventGuid("008ufje-8wehfie-4236gej-e7r3hf");
        dto.setLocationId("1005");
        dto.setRecipientId("seb0917");
        dto.setSplashId(21L);
        dto.setTriggerCode("CHECK_IN");
        List<ImpressionValuesDTO> values = new ArrayList<ImpressionValuesDTO>();
        ImpressionValuesDTO view = new ImpressionValuesDTO();
        view.setRespType("VIEW");
        view.setRespValue("Y");
        view.setImpressionTime(new Date());
        values.add(view);
        ImpressionValuesDTO ack = new ImpressionValuesDTO();
        ack.setRespType("ACK");
        ack.setRespValue("Y");
        ack.setImpressionTime(new Date());
        values.add(ack);
        dto.setImpressionValues(values);
        try {
            KrowdQueueSender sender = null;
            sender = new KrowdQueueSender();
            System.out.println("====sending "+ dto);
            sender.sendInternalSplashMessageEvent(dto);   
            sender.close();
            res = "ok";
            System.out.println("------------Event successfully Sent");
        } catch (NamingException e) {
            e.printStackTrace();
        } catch (JMSException e) {
            e.printStackTrace();
}
        return Response.ok(res).build();
    }

    @POST
    @Path("/testSplashImpressionPayload")
    @Consumes("text/html")
    public Response testSplashImpressionPayload(String text){
        List<SplashImpressionDTO> dtos;
        String exceptionMsg = null;
        try {
            dtos = new CampaignImpressionConverter().convert(text);
            System.out.println("------------- dtos = "+ dtos);
            KrowdQueueSender sender = null;
            if(dtos != null){
                for(SplashImpressionDTO dto : dtos){
                    sender = new KrowdQueueSender();
                    System.out.println("====sending "+ dto);
                    sender.sendInternalSplashMessageEvent(dto);   
                    sender.close();
                }
            }
            System.out.println("------------Event successfully Sent");
            } catch (JAXBException e) {
            e.printStackTrace();
            } catch (ParserConfigurationException e) {
            e.printStackTrace();
            } catch (SAXException e) {
            e.printStackTrace();
            } catch (IOException e) {
            e.printStackTrace();
            } catch (NamingException e) {
            e.printStackTrace();
            } catch (JMSException e) {
            e.printStackTrace();
            }
        return Response.ok("ok").build();
    }
    
    @POST
    @Path("/testCampaignUpdateEvent")
    public Response testCampaignUpdateEvent(){
        KrowdCampaignToSOAXMLConverter converter = new KrowdCampaignToSOAXMLConverter();
        CampaignDetailDTO dto;
        try {
            dto = converter._getDummyCampaign();
            String xml = converter.convert(dto);
            System.out.println(xml);
            
            GenericEventObject eventObj = new GenericEventObject();
            eventObj.setAppId("KROWD");
            eventObj.setEventName("CAMPAIGN_UPDATE");
            eventObj.setObjectText(xml);
            KrowdQueueSender sender = new KrowdQueueSender();
            sender.sendInternalSplashMessageEvent(eventObj);
            logger.severe(":::::::::Event sent internally to be sent to SOA:::::::::::");
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return Response.ok("ok").build();
    }
}

