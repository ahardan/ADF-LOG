package com.darden.krowd.portal.messaging.rest.service;

import com.darden.krowd.common.KrowdUtility;
import com.darden.krowd.messages.splash.model.applicationModule.SplashMessageAMImpl;

import com.darden.krowd.messages.splash.model.dto.CampaignDetailDTO;
import com.darden.krowd.messages.splash.model.dto.CampaignSummaryForEmployeeDTO;
import com.darden.krowd.messages.splash.model.dto.CampaignSummaryForLocationDTO;
import com.darden.krowd.messages.splash.model.dto.SplashImpressionDTO;

import com.darden.krowd.portal.messaging.rest.exceptions.BadRequestException;
import com.darden.krowd.portal.messaging.rest.exceptions.NotFoundException;
import com.darden.krowd.portal.messaging.rest.exceptions.BusinessFaultRequestException;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;


import oracle.adf.model.BindingContext;
import oracle.adf.model.DataControlFrame;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.share.logging.ADFLogger;

import java.util.List;
import java.util.ArrayList;

import javax.ws.rs.PathParam;

import org.apache.commons.codec.binary.Base64;


@Path("/ext/messages/campaign")
@Produces("application/json")
public class MessageExternalResource {

    private static final ADFLogger logger = ADFLogger.createADFLogger(MessageExternalResource.class);
    private static String PAGE_DEF = "com_darden_krowd_portal_RestPageDef";
    private static String SPLASH_DATACONTROL = "SplashMessageAMDataControl";
    private static final String MESSAGING_ALLOWED_ATTACHMENT_EXTENSIONS =
        KrowdUtility.getInstance()
                                                                                      .getProperties()
                                                                                      .getProperty("MESSAGING_ALLOWED_ATTACHMENT_EXTENSIONS");

    public MessageExternalResource() {
        super();
    }

    private SplashMessageAMImpl getSplashMessageAM() {
        BindingContext bindingContext = BindingContext.getCurrent();
        SplashMessageAMImpl am = null;
        DCDataControl dc = null;
        if (bindingContext != null) {
            String dcFrameName = bindingContext.getCurrentDataControlFrame();
            DataControlFrame dcframe = dcFrameName == null ? null : bindingContext.findDataControlFrame(dcFrameName);

            dc = dcframe == null ? null : dcframe.findDataControl(SPLASH_DATACONTROL);
            dc = dc == null ? bindingContext.findDataControl(SPLASH_DATACONTROL) : dc;
            DCBindingContainer amxs = bindingContext.findBindingContainer(PAGE_DEF);
            if (dc == null) {
                DCBindingContainer amx = bindingContext.findBindingContainer(PAGE_DEF);
                dc = amx.findDataControl(SPLASH_DATACONTROL);
                am = (SplashMessageAMImpl) dc.getDataProvider();
            } else {
                am = (SplashMessageAMImpl) dc.getDataProvider();
            }
        }
        return am;
    }

    @GET
    @Path("/splash-inbox")
    public Response getEmployeeCampaignSummary(@QueryParam("channel") String channel,
                                               @QueryParam("location") String location,
                                               @QueryParam("clockInJobCode") String clockInJobCode,
                                               @QueryParam("employeeId") String employeeId,
                                               @QueryParam("trigger") String trigger,
                                               @DefaultValue("3") @QueryParam("maxResults") int maxResults) {
        List<CampaignSummaryForEmployeeDTO> ret = new ArrayList<CampaignSummaryForEmployeeDTO>();
        String attrValErrorMessage = null;
        if (channel == null || channel.length() == 0) {
            attrValErrorMessage = "Parameter channel is Required.";
        } else if (location == null || location.length() == 0) {
            attrValErrorMessage = "Parameter location is Required.";
        } else if (employeeId == null || employeeId.length() == 0) {
            attrValErrorMessage = "Parameter employeeId is Required.";
        } else if (trigger == null || trigger.length() == 0) {
            attrValErrorMessage = "Parameter trigger is Required.";
        }
        if (attrValErrorMessage != null) {
            throw new BadRequestException(attrValErrorMessage);
        }
        try {
            SplashMessageAMImpl am = getSplashMessageAM();
            ret = am.getCampaignSummaryForEmployee(channel, location, employeeId, clockInJobCode, trigger);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessFaultRequestException(e);
        }

        return Response.ok(ret)
                       .type(MediaType.APPLICATION_JSON)
                       .build();
    }

    @GET
    @Path("/campaign-summary")
    public Response getLocationCampaignSummary(@QueryParam("channel") String channel,
                                               @QueryParam("location") String location) {
        String attrValErrorMessage = null;
        List<CampaignSummaryForLocationDTO> ret = new ArrayList<CampaignSummaryForLocationDTO>();
        if (channel == null || channel.length() == 0) {
            attrValErrorMessage = "Parameter channel is Required.";
        } else if (location == null || location.length() == 0) {
            attrValErrorMessage = "Parameter location is Required.";
        }
        if (attrValErrorMessage != null) {
            throw new BadRequestException(attrValErrorMessage);
        }
        try {
            SplashMessageAMImpl am = getSplashMessageAM();
            ret = am.getCampaignSummaryForLocation(channel, location);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessFaultRequestException(e);
        }

        return Response.ok(ret)
                       .type(MediaType.APPLICATION_JSON)
                       .build();
    }

    @GET
    @Path("/campaign-detail/{campaignId}")
    public Response getCampaignDetail(@PathParam("campaignId") Long campaignId, @QueryParam("channel") String channel) {
        CampaignDetailDTO ret = null;
        String attrValErrorMessage = null;
        if (channel == null || channel.length() == 0) {
            attrValErrorMessage = "Parameter channel is Required.";
        } else if (campaignId == null) {
            attrValErrorMessage = "Parameter campaignId is Required.";
        }
        if (attrValErrorMessage != null) {
            throw new BadRequestException(attrValErrorMessage);
        }

        try {
            SplashMessageAMImpl am = getSplashMessageAM();
            ret = am.getCampaignDetail(campaignId, channel);
            if(ret != null){
                String message = ret.getMessageText();
                if(message != null){
                    byte[] base64Bytes = Base64.encodeBase64(message.getBytes());
                    ret.setMessageText(new String(base64Bytes));
                }    
            } else {
                throw new NotFoundException("Campaign not found with campaignId " + campaignId);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessFaultRequestException(e);
        }
        return Response.ok(ret)
                       .type(MediaType.APPLICATION_JSON)
                       .build();
    }
    
    /**
     * TEST method for local testing. In production impressions will come from events
     * @param dto
     * @return
     */
    @PUT
    @Path("/splash-impression")
    public Response registerImpression(SplashImpressionDTO dto) {
        SplashMessageAMImpl am = getSplashMessageAM();
        Long ret = null;
        if(dto != null){
            ret = am.registerImpression(dto);
        }
        return Response.ok(ret)
                       .type(MediaType.APPLICATION_JSON)
                       .build();
    }
}
