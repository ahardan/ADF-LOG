package com.darden.krowd.portal.people.rest.service;


import com.darden.global.enterpriseobjects.core.common.v2.IdentificationType;
import com.darden.global.enterpriseobjects.core.common.v2.IdentifierType;
import com.darden.global.enterpriseobjects.core.commonebo.v1.PersonAddressCommunicationType;
import com.darden.global.enterpriseobjects.core.commonebo.v1.PersonEmailCommunicationType;
import com.darden.global.enterpriseobjects.core.commonebo.v1.PersonPhoneCommunicationType;
import com.darden.global.enterpriseobjects.core.commonebo.v1.PersonType;
import com.darden.global.enterpriseobjects.core.ebo.worker.v1.AcknowledgeEmployeeProfileDataAreaType;
import com.darden.global.enterpriseobjects.core.ebo.worker.v1.EmployeeProfileType;
import com.darden.global.enterpriseobjects.core.ebo.worker.v1.ShowEmployeeProfileDataAreaType;
import com.darden.krowd.common.KrowdUtility;
import com.darden.krowd.common.PortalConstants;
import com.darden.krowd.common.PropertiesUtil;
import com.darden.krowd.common.identity.LdapHelper;
import com.darden.krowd.common.model.applicationModule.common.UserProfileAM;
import com.darden.krowd.common.model.applicationModule.preferences.common.PreferencesAM;
import com.darden.krowd.common.util.CacheUtil;
import com.darden.krowd.model.ps.applicationModule.common.PeopleSoftAM;
import com.darden.krowd.model.serialize.ActivityNotification;
import com.darden.krowd.model.storeMds.MdsStoreObject;
import com.darden.krowd.model.storeMds.StoreMDS;
import com.darden.krowd.portal.people.rest.config.CacheAnnotations.CacheMaxAge;
import com.darden.krowd.portal.people.rest.exception.BadRequestException;
import com.darden.krowd.portal.people.rest.support.MessagesHypermediaGenerator;
import com.darden.krowd.rest.model.Bookmark;
import com.darden.krowd.rest.model.MapList;
import com.darden.krowd.rest.model.Notification;
import com.darden.krowd.rest.model.ObjectReference;
import com.darden.krowd.rest.model.QuickLinkDTO;
import com.darden.krowd.rest.model.QuickLinkListDTO;
import com.darden.krowd.rest.search.model.PersonList;
import com.darden.krowd.rest.search.model.PersonRow;
import com.darden.krowd.services.dao.BirthAndAnniversaryDatesDAO;
import com.darden.krowd.services.dao.ESSLinksDAO;
import com.darden.krowd.services.dao.OnTheMoveDAO;
import com.darden.krowd.services.helper.ServicesHelper;

import com.sun.jersey.api.json.JSONConfiguration;
import com.sun.jersey.api.json.JSONJAXBContext;
import com.sun.jersey.api.json.JSONMarshaller;
import com.sun.jersey.api.json.JSONUnmarshaller;
import com.sun.jersey.core.header.ContentDisposition;
import com.sun.jersey.core.header.FormDataContentDisposition;
import com.sun.jersey.multipart.FormDataBodyPart;
import com.sun.jersey.multipart.FormDataMultiPart;
import com.sun.jersey.multipart.FormDataParam;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.StringWriter;

import java.net.URI;
import java.net.URISyntaxException;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Enumeration;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.naming.InitialContext;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import javax.sql.DataSource;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import oracle.adf.model.BindingContext;
import oracle.adf.model.DataControlFrame;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.share.prefs.ADFPreferencesFactory;
import oracle.adf.share.security.SecurityContext;

import oracle.jbo.Key;
import oracle.jbo.Row;
import oracle.jbo.RowIterator;
import oracle.jbo.RowSet;
import oracle.jbo.RowSetIterator;
import oracle.jbo.ViewObject;
import oracle.jbo.domain.Number;

import oracle.security.idm.ComplexSearchFilter;
import oracle.security.idm.IMException;
import oracle.security.idm.Identity;
import oracle.security.idm.Property;
import oracle.security.idm.PropertySet;
import oracle.security.idm.RoleManager;
import oracle.security.idm.SearchResponse;
import oracle.security.idm.User;
import oracle.security.idm.UserProfile;

import oracle.webcenter.activitystreaming.ActivityActor;
import oracle.webcenter.activitystreaming.ActivityDisplayElement;
import oracle.webcenter.activitystreaming.ActivityException;
import oracle.webcenter.activitystreaming.ActivityObject;
import oracle.webcenter.activitystreaming.ActivityStreamingService;
import oracle.webcenter.activitystreaming.ActivityStreamingServiceFactory;
import oracle.webcenter.activitystreaming.FollowManager;
import oracle.webcenter.framework.service.ServiceObjectType;
import oracle.webcenter.jaxrs.framework.param.ItemsPerPageParam;
import oracle.webcenter.jaxrs.framework.param.PaginationParams;
import oracle.webcenter.jaxrs.framework.param.StartIndexParam;
import oracle.webcenter.jaxrs.framework.service.RestService;
import com.darden.krowd.framework.PersonReference;

import java.security.SecureRandom;

import javax.xml.stream.XMLInputFactory;

import oracle.webcenter.jaxrs.framework.uri.UriService;
import oracle.webcenter.peopleconnections.connections.Connection;
import oracle.webcenter.peopleconnections.connections.ConnectionsException;
import oracle.webcenter.peopleconnections.connections.ConnectionsManager;
import oracle.webcenter.peopleconnections.connections.ConnectionsServiceFactory;
import oracle.webcenter.peopleconnections.connections.Invitation;
import oracle.webcenter.peopleconnections.connections.InvitationsManager;
import oracle.webcenter.peopleconnections.profile.ProfileException;
import oracle.webcenter.peopleconnections.profile.ProfileFactory;
import oracle.webcenter.peopleconnections.profile.UserProfileManager;
import oracle.webcenter.peopleconnections.profile.WCUserProfile;
import oracle.webcenter.peopleconnections.profile.internal.model.ProfileInternalUtils;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.commons.lang3.StringUtils;

import org.apache.commons.codec.binary.Base64;

import org.codehaus.jackson.map.ObjectMapper;

import org.owasp.esapi.ESAPI;

@Path("/users")
@Produces("application/json")
public class PeopleResource {
    private static final String[] USER_SEARCH_BASES =
    new String[] { "OU=Field,DC=darden,DC=com",
    "OU=Field,OU=PortalDev,DC=darden,DC=com",
    "OU=Restaurants,DC=darden,DC=com",
    "OU=Restaurants,OU=PortalDev,DC=darden,DC=com",
    "OU=RSC,DC=darden,DC=com",
    "OU=RSC,OU=PortalDev,DC=darden,DC=com",
    "OU=Employees,DC=mydish,DC=darden,DC=com", 
    "OU=Employees,OU=PortalDev,DC=mydish,DC=darden,DC=com" };

    private static final String[] RESTAURANT_SEARCH_BASES =
    new String[] { "OU=RestaurantsOWA,DC=darden,DC=com",
                   "OU=RestaurantsVM,DC=darden,DC=com"};

    private static final int LDAP_COUNT_LIMIT = 20;
    private static final int LDAP_PROFILE_COUNT_LIMIT = 500;
    private static final int LDAP_PAGE_LIMIT = 1;
    private static final String CHEDDARS_KROWD_FULLSITE = "CHEDDARS_KROWD_FULLSITE";
    public static final String DARDEN_EMPL_ID="DARDEN-EMPL-ID";
    public static final String FIRST_NAME="FIRST_NAME";
    public static final String LAST_NAME="LAST_NAME";
    public static final String PROFILE_ATTRS = "Darden-Business-Unit##Darden-Company-Number##Darden-Job-Function##Darden-Job-Sub-Function##Darden-Region##division##physicalDeliveryOfficeName##Darden-Area##Darden-Job-Code##Darden-POS-ID##Darden-Work-State##displayName";
    private static final String KROWD_DATASOURCE_JNDI = "jdbc/KrowdDB";
    
    public static final Map<String,String> PROFILE_ATTRS_KEYS= new HashMap<String,String>();
    static {
        String[] profileAttrs = PROFILE_ATTRS.split("##");        
        for(String attr : profileAttrs){
            String value = attr.replace("-", "");
            char c[] = value.toCharArray();
            c[0] = Character.toLowerCase(c[0]);
            value = new String(c);
            PROFILE_ATTRS_KEYS.put(attr, value);
        }
    }
    
    private UserProfileManager userProfileManager;
    private ConnectionsManager connectionsManager;
    private InvitationsManager invitationsManager;
    private String currentUserGUID;
    private List<Invitation> sentInvitations;
    private List<Invitation> receivedInvitations;
    
    private List<Connection> userConnections = null;

    
    @Context private HttpServletRequest httpRequest;
    @Context private HttpServletResponse httpResponse;
    private static final ADFLogger logger = ADFLogger.createADFLogger(PeopleResource.class);
    
    private static String PAGE_DEF = "com_darden_krowd_portal_RestPageDef";  
    private static String USER_PROFILE_DATACONTROL = "UserProfileAMDataControl";
    private static String PEOPLESOFT_DATACONTROL = "PeopleSoftAMDataControl";
    private static String PREF_DATACONTROL = "PreferencesAMDataControl";
    
    @RestService
    protected UriService uriService;
    
    private static ArrayList<String> PERSON_REF_ATTRIBUTES = new ArrayList<String>() {{
    }};  
    
        private Object getFromCache(String key){
            return CacheUtil.getInstance().get(key,CacheUtil.CacheType.PEOPLE_CACHE);
        }
        
        private void putInCache(String key, Object object){    
            CacheUtil.getInstance().encodeAndPut(key, object, CacheUtil.CacheType.PEOPLE_CACHE);
        }
    
    
    private UserProfileAM getUserProfileAM(){
        BindingContext bindingContext = BindingContext.getCurrent();
        UserProfileAM am =null;
        DCDataControl dc = null; 
        if(bindingContext !=null){
            String dcFrameName = bindingContext.getCurrentDataControlFrame();
            DataControlFrame dcframe = dcFrameName == null? null : bindingContext.findDataControlFrame(dcFrameName);
            dc = dcframe == null ? null : dcframe.findDataControl(USER_PROFILE_DATACONTROL);        
            dc = dc == null ? bindingContext.findDataControl(USER_PROFILE_DATACONTROL) : dc;
            
            if(dc == null){
               DCBindingContainer amx = bindingContext.findBindingContainer(PAGE_DEF);
                dc = amx.findDataControl(USER_PROFILE_DATACONTROL); 
                am = (UserProfileAM)dc.getDataProvider();
            }else{
                am = (UserProfileAM)dc.getDataProvider();
            }
        }
        return am;
    }     
    
    private PreferencesAM getPreferencesAM(){
        BindingContext bindingContext = BindingContext.getCurrent();
        PreferencesAM am =null;
        DCDataControl dc = null; 
        if(bindingContext !=null){
            String dcFrameName = bindingContext.getCurrentDataControlFrame();
            DataControlFrame dcframe = dcFrameName == null? null : bindingContext.findDataControlFrame(dcFrameName);
            dc = dcframe == null ? null : dcframe.findDataControl(PREF_DATACONTROL);        
            dc = dc == null ? bindingContext.findDataControl(PREF_DATACONTROL) : dc;
            
            if(dc == null){
               DCBindingContainer amx = bindingContext.findBindingContainer(PAGE_DEF);
                dc = amx.findDataControl(PREF_DATACONTROL); 
                am = (PreferencesAM)dc.getDataProvider();
            }else{
                am = (PreferencesAM)dc.getDataProvider();
            }
        }
        return am;
    }
    
    private PeopleSoftAM getPeopleSoftAM(){
        BindingContext bindingContext = BindingContext.getCurrent();
        PeopleSoftAM am =null;
        DCDataControl dc = null; 
        if(bindingContext !=null){
            String dcFrameName = bindingContext.getCurrentDataControlFrame();
            DataControlFrame dcframe = dcFrameName == null? null : bindingContext.findDataControlFrame(dcFrameName);
            dc = dcframe == null ? null : dcframe.findDataControl(PEOPLESOFT_DATACONTROL);        
            dc = dc == null ? bindingContext.findDataControl(PEOPLESOFT_DATACONTROL) : dc;
            
            if(dc == null){
               DCBindingContainer amx = bindingContext.findBindingContainer(PAGE_DEF);
                dc = amx.findDataControl(PEOPLESOFT_DATACONTROL); 
                am = (PeopleSoftAM)dc.getDataProvider();
            }else{
                am = (PeopleSoftAM)dc.getDataProvider();
            }
        }
        return am;
    }     
    
    private ConnectionsManager getConnectionsManager(){
        if(this.connectionsManager == null)
         this.connectionsManager = ConnectionsServiceFactory.getInstance().getConnectionsManager(); 
        
        return this.connectionsManager;
    }
    
    private InvitationsManager getInvitationsManager() {
        if(this.invitationsManager == null){
            this.invitationsManager = ConnectionsServiceFactory.getInstance().getInvitationsManager();
        }
      return this.invitationsManager;
    }   
    
    private String getCurentUserGUID(){
        if(currentUserGUID == null)
            currentUserGUID = ADFContext.getCurrent().getSecurityContext().getUserProfile().getGUID();
        return currentUserGUID;
    }
    
    
    private UserProfileManager getUserProfileManager(){
        if(this.userProfileManager == null){
            try {
                this.userProfileManager = ProfileFactory.getProfileManager();
            } catch (ProfileException e) {
            }
        }
        return this.userProfileManager;
    }
    
    private List<PersonReference> getUserConnections(String userId){
        List<PersonReference> connRes = null;
        
        try{
            ConnectionsManager connectionsManager = ConnectionsServiceFactory.getInstance().getConnectionsManager();
            UserProfileManager profileManager = ProfileFactory.getProfileManager();
            WCUserProfile userProfile = profileManager.getProfile(userId);
            String userGuid = userProfile.getGuid();
            List<Connection> connections = connectionsManager.getConnections(userGuid);        
            connRes = new ArrayList<PersonReference>();
            
            for(Connection connection : connections){
                HashMap<String,Object> connInfo = new HashMap<String,Object>();
                connInfo.put("userId",connection.getConnecteeUserId());
                WCUserProfile connecteeProfile = connection.getConnecteeUserProfile();
                PersonReference perRef = PersonReference.GetPersonByGuid(connecteeProfile.getGuid());
                perRef = MessagesHypermediaGenerator.addLinks(uriService, perRef);
                connRes.add(perRef);            
            }

        }catch(Exception e){
            logger.severe(e);
        }
        return connRes;
    }
    
    private  Map<String,Object> toMap(Row row,boolean expandRs){
        
        if(row == null)
            return null;
        
        String[] attrs = row.getAttributeNames();
        Map map = new HashMap<String,Object>();
        Object val;
        
        for(String attributeName : attrs){
           val = row.getAttribute(attributeName);           
           if(val instanceof oracle.jbo.RowSet) {
               if(expandRs){
                   RowSet rwSet = (RowSet)val;
                   ArrayList<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
                   while(rwSet.hasNext()){
                       list.add(toMap(rwSet.next(),expandRs));
                   }
                    map.put(attributeName,list);
                    map.put("has"+attributeName,list.size()==0?false:true);
               }else{
                   map.put(attributeName,null);
               }
           }else{
               //PersonReference.GetPersonByGuid(comment.getAuthorId())
               if(PERSON_REF_ATTRIBUTES.contains(attributeName)){                
                if(val !=null){

                    String usersCSV = (String)(val==null?val:val.toString());  
                    String[]users = usersCSV.split(",");
                    if(users.length==0){
                        map.put(attributeName, null);
                    }else{
                        if(users.length==1){
                            map.put(attributeName,MessagesHypermediaGenerator.addLinks(uriService, PersonReference.GetPersonByLoginId(users[0])));  
                        }else{
                            ArrayList<PersonReference> result = new ArrayList<PersonReference>();
                            for(String user : users){
                                result.add(MessagesHypermediaGenerator.addLinks(uriService, PersonReference.GetPersonByLoginId(user)));
                            }
                            map.put(attributeName, result);
                        }
                    }
                }
               }else{
                   if(val != null){
                       map.put(attributeName, val.toString());
                    }
               }
           }
        }
        
        //Profile Picture Mock attribute
        map.put("isPicturePresent", new SecureRandom().nextBoolean());
        
        
        return map;
    }       

    public PeopleResource() {
        super();
    }
    


    private  List<Map<String,Object>> toMap(RowIterator ri,
                                                                   int maxRows,
                                                                   int startRow,
                                                                   boolean singleRow){
        Row[] rows;
        if (singleRow) { // indicates a single row representation
            rows = new Row[] { ri.getCurrentRow() };
        } else {
            ri.reset();
            ri.setRangeSize(maxRows);
            ri.setRangeStart(startRow);
            rows = ri.getAllRowsInRange();
        }
        List<Map<String,Object>> result = new ArrayList<Map<String,Object>>();
        for (Row row : rows) {
            result.add(toMap(row,false));
        }
        return result;
    }
    
    @POST
    @Path("/profile/photo")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    public Response updatePhoto(FormDataMultiPart formData) {       
        
        byte[] bytes;
        try {
            String userId = ADFContext.getCurrent().getSecurityContext().getUserName();            
            UserProfileManager profileManager = ProfileFactory.getProfileManager();
            WCUserProfile userProfile = profileManager.getProfileForUpdate(userId);            
            FormDataBodyPart fdbpFileUpload = formData.getField("file");            
            InputStream is = fdbpFileUpload.getValueAs(InputStream.class);                        
            bytes = IOUtils.toByteArray(is);
            userProfile.updatePhoto(bytes);            
            userProfile.save();
            CacheUtil.getInstance().remove("PROFILE_PHOTO_"+userId.toUpperCase()+"_MEDIUM", CacheUtil.CacheType.PEOPLE_CACHE);
            CacheUtil.getInstance().remove("PROFILE_PHOTO_"+userId.toUpperCase()+"_LARGE", CacheUtil.CacheType.PEOPLE_CACHE);
            CacheUtil.getInstance().remove("PROFILE_PHOTO_"+userId.toUpperCase()+"_ORIGINAL", CacheUtil.CacheType.PEOPLE_CACHE);
            CacheUtil.getInstance().remove(userId, CacheUtil.CacheType.USERPROFILE_CACHE);
            return Response.ok().build();
        } catch (Exception e) {
            throw new BadRequestException(e);
        }
    }        
    
    @GET
    @Path("/profile/photo/{size}")
    @Produces("*/*")
    public Response getProfilePhoto(@PathParam("size") String size) {       
        
        byte[] bytes;
        try {
            String userId = ADFContext.getCurrent().getSecurityContext().getUserName();            
            bytes = (byte[])CacheUtil.getInstance().get("PROFILE_PHOTO_"+userId.toUpperCase()+"_"+size.toUpperCase(), CacheUtil.CacheType.PEOPLE_CACHE);            
            
            if(bytes == null){
                UserProfileManager profileManager = ProfileFactory.getProfileManager();
                WCUserProfile userProfile = profileManager.getProfile(userId);              
                WCUserProfile.PhotoSize defaultSize = WCUserProfile.PhotoSize.MEDIUM;
                WCUserProfile.PhotoSize photoSize = null;
                try{
                    photoSize = WCUserProfile.PhotoSize.valueOf(size);
                }catch(Exception e){
                    logger.severe(e);
                    photoSize = defaultSize;
                }
                
                bytes = userProfile.getPhoto(photoSize);   
                if(bytes != null && bytes.length >0){
                    CacheUtil.getInstance().encodeAndPut("PROFILE_PHOTO_"+userId.toUpperCase()+"_"+size.toUpperCase(), bytes, CacheUtil.CacheType.PEOPLE_CACHE);
                }else{
                    if(WCUserProfile.PhotoSize.LARGE == photoSize){
                        bytes = Base64.decodeBase64(PLACEHOLDER_LARGE.getBytes());
                    }else{
                        bytes = Base64.decodeBase64(PLACEHOLDER_MEDIUM.getBytes());
                    }
                    CacheUtil.getInstance().encodeAndPut("PROFILE_PHOTO_"+userId.toUpperCase()+"_"+size.toUpperCase(), bytes, CacheUtil.CacheType.PEOPLE_CACHE);
                }
            }
            return Response.ok(new ByteArrayInputStream(bytes)).type("image/x-png").build();            
        } catch (Exception e) {
            bytes = Base64.decodeBase64(PLACEHOLDER_MEDIUM.getBytes());
            return Response.ok(new ByteArrayInputStream(bytes)).type("image/x-png").build();            
        }
    }        
    
    @GET
    @Path("/connections")
    @Produces("application/json")
    public Response getConnections(){ 
        try {
            String userId = ADFContext.getCurrent().getSecurityContext().getUserName();
            if(StringUtils.isBlank(userId))
                throw new BadRequestException("User ID cannot be blank"); 
            List<PersonReference>  connRes = getUserConnections(userId);
            return Response.status(200).entity(connRes).build();
        } catch (Exception e) {
            logger.severe(e);
            throw new BadRequestException(e);    
        }            
    } 
    
    @GET
    @Path("/app/chcp.json")
    @Produces("application/json")
    @CacheMaxAge(time = 360, unit = TimeUnit.MINUTES)
    public Response getCHCP(){ 
        try {

            String version = httpRequest.getHeader("X-KROWDAPP-VERSION");
            String build = httpRequest.getHeader("X-KROWDAPP-BUILD");
            String release = httpRequest.getHeader("X-KROWDAPP-RELEASE");

            UserProfileAM am = getUserProfileAM();
            Map result = am.getCHCPAttributes(version, build,release);
            
            if(result == null){
                result = new HashMap<String,String>();                
                result.put("name", "KrowD");
                result.put("s3bucket", "krowdmobile");
                result.put("s3region", "us-east-1");
                result.put("ios_identifier", "com.darden.krowd.mobile");
                result.put("android_identifier", "com.darden.krowd.mobile");
                result.put("update", "resume");            
                result.put("min_native_interface",build);                
                result.put("release",release);  
            }
            
            return Response.status(Response.Status.OK).entity(result).type(MediaType.APPLICATION_JSON).build();
        } catch (Exception e) {
            logger.severe(e);
            throw new BadRequestException(e);    
        }            
    } 
        
    private List<PersonReference> toPersonReferences(List<String> userNames){
        List<PersonReference> personList = new ArrayList<PersonReference>();
        if(userNames != null){
            PersonReference perRef =null;
            for(String userName:userNames){
                try{
                    perRef = PersonReference.GetPersonByLoginId(userName);
                    if(perRef !=null){
                        perRef = MessagesHypermediaGenerator.addLinks(uriService, perRef);
                        personList.add(perRef);                        
                    }
                }catch(Exception e){
                    logger.severe(e);
                }
            }
        }
        return personList;
    }

    private List<PersonReference> identitiesToPersonReferences(List<Identity> identities){
        List<PersonReference> personList = new ArrayList<PersonReference>();
        if(identities != null){
            PersonReference perRef;
            for(Identity identity:identities){
                try {
                    String guid = identity.getGUID();
                    perRef = PersonReference.GetPersonByGuid(guid);
                    perRef = MessagesHypermediaGenerator.addLinks(uriService, perRef);
                    personList.add(perRef);
                } catch (IMException e) {
                    logger.severe(e);
                }
            }
        }
        return personList;
    }
    
    private List<PersonReference> filterPersonReferences(List<PersonReference> persons, String searchStr){
        if(searchStr ==null || StringUtils.isBlank(searchStr) || persons==null || persons.size()==0)
            return persons;
        else{
            String[] parts = searchStr.split("\\s+");
            Pattern pattern=null;
            if(parts.length==0)
                return persons;
            if(parts.length==1){
                pattern = Pattern.compile(".*"+parts[0]+".*", Pattern.CASE_INSENSITIVE);
            }
            if(parts.length>1){
                pattern = Pattern.compile(parts[0]+".*"+parts[1]+".*", Pattern.CASE_INSENSITIVE);
            }
            Matcher matcher;
            List<PersonReference> result = new ArrayList<PersonReference>();
            for(PersonReference perRef : persons){
                if(perRef !=null){
                    matcher = pattern.matcher(perRef.getDisplayName());
                    if(matcher.matches())
                        result.add(perRef);                    
                }
            }
            return result;
        }
    }
    
    
    
    private ArrayList<String> getRoles(User user) {
        ArrayList<String> rolesList = null;
        
        try{
            RoleManager roleManager = LdapHelper.getInstance().getIdentityStore().getRoleManager();
            SearchResponse searchResponse = roleManager.getGrantedRoles(user.getPrincipal(), false);
            rolesList = new ArrayList<String>();
            while(searchResponse.hasNext()){
                Identity identity = searchResponse.next();
                String roleName = identity.getName();
                rolesList.add(roleName);          
            }
            rolesList.add(ADFContext.getCurrent().getSecurityContext().getUserName());
        }catch(Exception e){
            logger.severe(e);
        }
        return rolesList;
    }
    
    public String getGroup(User user){
        List<String> userRoles = getRoles(user);
        return getGroup(user, userRoles);
    }    
    
    private boolean isAdmin(String[] userRoles){        
        if(userRoles == null){
            return false;
        }
        
        List<String> rolesList = Arrays.asList(userRoles);
        return isAdmin(rolesList);
    }
    
    private boolean isMessageOneWayRole(List<String> rolesList) {
        if(rolesList == null)
            return false;
        try {           
            if (rolesList.contains("Targeted_Messaging_OneWay_Message_Role")){
                return true;
            }else{
                return false;
            }
        } catch (Exception e) {
            logger.severe(e);
            return false;
        }
    }
    private boolean isAdmin(List<String> rolesList){        
        if(rolesList == null){
            return false;
        }
        
        try {           
            if (rolesList.contains("ECM_IT_Contributor") || 
                rolesList.contains("ECM_IC_Contributor") || 
                rolesList.contains("Portal - Super Admin") || 
                rolesList.contains("Administrators")){
                return true;
            }else{
                return false;
            }
        } catch (Exception e) {
            logger.severe(e);
            return false;
        }
    }    

    public String getGroup(User user, List<String> userRoles) {
        UserProfile userProfile = null;
        
        try{
            userProfile = user ==null?null:user.getUserProfile();    
        }catch(Exception e){
            logger.severe(e);
        }
        
        if(userRoles != null && user != null){
            try{
                if (userRoles.contains("Portal - RSC Emp")){
                    String businessUnit = (String)userProfile.getPropertyVal("Darden-Business-Unit");
                    if (businessUnit.compareTo("YHUSA") == 0)
                        return "RSCY";
                    else
                        return "RSC";
                }
                else if (userRoles.contains("Portal - RSC Emp � Canada")){
                    return "CRSC";
                }
                else{
                    String businessUnit = (String)userProfile.getPropertyVal("Darden-Business-Unit");
                    String area = (String)userProfile.getPropertyVal("Darden-Area");
                    String region = (String)userProfile.getPropertyVal("Darden-Region");
                    String office = (String)userProfile.getPropertyVal("physicalDeliveryOfficeName");
                    String managerLevel = (String)userProfile.getPropertyVal("Darden-Manager-Level");                    
                    return businessUnit + "|" + area + "|" + region + "|" + office + "|" + managerLevel;
                }                            
            }catch(Exception e){
                logger.severe(e);
            }
            return null;
        }else{
            return null;
        }            
    }    
    
    @GET
    @CacheMaxAge(time = 360, unit = TimeUnit.MINUTES)
    @Path("/roles")
    public ArrayList<String> getRoles(@QueryParam("userId") String userId){
        boolean self=false;
        if (userId == null || StringUtils.isBlank(userId)) {
            userId = ADFContext.getCurrent().getSecurityContext().getUserName();
            self=true;
        }        
        
        try {            
            if(self){
                String[] userRoles = ADFContext.getCurrent().getSecurityContext().getUserRoles();
                ArrayList<String> items = new ArrayList<String>();
                for (String role: userRoles) {
                    items.add(role);
                }                
                return items;
            }else{
                User user;
                user = LdapHelper.getInstance().getUser(userId);            
                return getRoles(user);
            }
        } catch (Exception e) {
            return null;
        }
    }
    
    
    @GET
    @CacheMaxAge(time = 360, unit = TimeUnit.MINUTES)
    @Path("/bdaysannvs")
    public Response getBirthdays(@QueryParam("userId")
        String userId, @QueryParam("fromDate")
        String fromDate, @QueryParam("toDate")
        String toDate,@DefaultValue("true") @QueryParam("fromCache") boolean fromCache) {        
        SimpleDateFormat sdf =
            new SimpleDateFormat(PortalConstants.KROWD_DATE_FORMAT);
        if (userId == null || StringUtils.isBlank(userId)) {
            userId = ADFContext.getCurrent().getSecurityContext().getUserName();
        }
        
        if(null == fromDate || StringUtils.isBlank(fromDate)){
            GregorianCalendar fromDateGC = new GregorianCalendar();
            fromDate = sdf.format(fromDateGC.getTime());
        }
        
        if(null == toDate || StringUtils.isBlank(toDate)){
            int daysFromDB = Integer.parseInt(KrowdUtility.getInstance().getProperties().getProperty(PortalConstants.BA_NUM_DAYS));
            GregorianCalendar toDateGC = new GregorianCalendar();
            toDateGC.add(Calendar.DAY_OF_MONTH, daysFromDB);    
            toDate = sdf.format(toDateGC.getTime());
        }
        
        try {
            User user= LdapHelper.getInstance().getUser(userId);
            String emplId = (String)user.getUserProfile().getPropertyVal("Darden-Empl-ID");
            String group = getGroup(user);
            Object frmCache = (fromCache?getFromCache("BA##"+fromDate+"##"+toDate+"##"+group):null); 
            if(null != frmCache){
                String result = (String)frmCache;
                return Response.ok().entity(result).type(MediaType.APPLICATION_JSON).build(); 
            } else {
                ServicesHelper sevHelper = new ServicesHelper();
                BirthAndAnniversaryDatesDAO result = sevHelper.getBirthdaysAndAnniversaries(emplId, fromDate,toDate,group);
                ObjectMapper objMapper = new ObjectMapper();
                String responseJson = objMapper.writeValueAsString(result);
                putInCache("BA##"+fromDate+"##"+toDate+"##"+group, responseJson);
                return Response.ok().entity(responseJson).type(MediaType.APPLICATION_JSON).build(); 
            }                            
        } catch (Exception e) {
            throw new BadRequestException(e);
        }        
    }
    
    @GET
    @CacheMaxAge(time = 360, unit = TimeUnit.MINUTES)
    @Path("/onthemove")
    public Response getOnTheMoves(@QueryParam("userId")
        String userId, @QueryParam("fromDate")
        String fromDate, @QueryParam("toDate")
        String toDate,@DefaultValue("true") @QueryParam("fromCache") boolean fromCache) {
        SimpleDateFormat sdf =
            new SimpleDateFormat(PortalConstants.KROWD_DATE_FORMAT);
        if (userId == null || StringUtils.isBlank(userId)) {
            userId = ADFContext.getCurrent().getSecurityContext().getUserName();
        }
        
        if(null == fromDate || StringUtils.isBlank(fromDate)){
            int daysFromDB = Integer.parseInt(KrowdUtility.getInstance().getProperties().getProperty(PortalConstants.OTM_NUM_DAYS));
            GregorianCalendar fromDateGC = new GregorianCalendar();
            fromDateGC.add(Calendar.DAY_OF_MONTH, daysFromDB);
            fromDate = sdf.format(fromDateGC.getTime());
        }
        
        if(null == toDate || StringUtils.isBlank(toDate)){
            GregorianCalendar toDateGC = new GregorianCalendar();
            toDate = sdf.format(toDateGC.getTime());
        }        
        
        try {
            User user = LdapHelper.getInstance().getUser(userId);
            String emplId = (String)user.getUserProfile().getPropertyVal("Darden-Empl-ID");
            UserProfile userProfile = user.getUserProfile();
            String concept = (String)userProfile.getPropertyVal("Darden-Business-Unit");
            List<String> userRoles = getRoles(user);            
            String managerLevel = (String)userProfile.getPropertyVal("Darden-Manager-Level"); 
            
            boolean isRsc = userRoles == null? false: isRsc(userRoles,managerLevel);
            boolean isOps = userRoles == null? false: isOps(userRoles);
            
            Object frmCache = (fromCache?getFromCache("OTM##"+fromDate+"##"+toDate+"##"+concept+"##"+isRsc+"##"+isOps):null);
            if(null != frmCache){
                String result = (String)frmCache;
                return Response.ok().entity(result).type(MediaType.APPLICATION_JSON).build(); 
            } else {
                ServicesHelper sevHelper = new ServicesHelper();
                OnTheMoveDAO result = sevHelper.getOnTheMoves(emplId, fromDate,toDate,concept,isRsc,isOps);
                ObjectMapper objMapper = new ObjectMapper();
                String responseJson = objMapper.writeValueAsString(result);                
                putInCache("OTM##"+fromDate+"##"+toDate+"##"+concept+"##"+isRsc+"##"+isOps, responseJson);
                return Response.ok().entity(responseJson).type(MediaType.APPLICATION_JSON).build(); 
            }
        } catch (Exception e) {
            throw new BadRequestException(e);
        }        
    }    
    
    private boolean isRsc(User user) throws Exception {
        String managerLevel = (String)user.getUserProfile().getPropertyVal("Darden-Manager-Level");
        List<String> userRoles = getRoles(user);
        return isRsc(userRoles, managerLevel);
    }
    
    private boolean isRsc(List<String> roles,String managerLevel){        
        if(managerLevel != null && (managerLevel.compareTo("G")==0 || managerLevel.compareTo("H")==0))
            return true;
        else{
            if ( roles != null && (roles.contains(PortalConstants.Portal_RSC_Emp) || roles.contains(PortalConstants.Portal_RSC_Emp_Canada)))
                return true;
            else
                return false;
        }        
    }
    
    private boolean isOps(User user) throws Exception {
        List<String> userRoles = getRoles(user);
        return userRoles==null? false : isOps(userRoles);
    }    
    
    private boolean isOps(List<String> roles){
        if (roles !=null && (!roles.contains(PortalConstants.Portal_Hourly) && !roles.contains(PortalConstants.Portal_RSC_Emp)))
            return true; 
        else
            return false;        
    }


        @GET   
        @Path("/preferences/{context}")
        public Response getPreferences(@PathParam("context")String context) {
            if (context == null || StringUtils.isBlank(context)) {
                throw new BadRequestException("Context values : {user,useroversystem,shareduser,sharedsystem,system} is mandatory");
            }
            else{
                try {
                    ADFPreferencesFactory prefsFactory = new ADFPreferencesFactory();
                    Preferences prefs = null;
                    if(context.equalsIgnoreCase("USER")){
                        prefs = prefsFactory.userRoot();
                    }else if(context.equalsIgnoreCase("SHAREDUSER")){
                        prefs = prefsFactory.sharedUserRoot();
                    }else if(context.equalsIgnoreCase("SHAREDSYSTEM")){
                        prefs = prefsFactory.sharedSystemRoot();
                    }else if(context.equalsIgnoreCase("SYSTEM")){
                        prefs = prefsFactory.systemRoot();
                    }else if(context.equalsIgnoreCase("USEROVERSYSTEM")){
                        prefs = prefsFactory.userOverSystemRoot();                   
                    }else{
                        throw new BadRequestException("Valid Context values : {user,useroversystem,shareduser,sharedsystem,system} is mandatory");
                    }  
                    
                    return Response.status(Response.Status.OK).entity(getMapFromPreferences(prefs)).type(MediaType.APPLICATION_JSON).build();                                        
                } catch (Exception e) {
                    throw new BadRequestException(e);
                }
            }
        }  
        
        private void setPreferencesFromMap(Preferences preferences,HashMap<String,String> map){
            if(map != null && preferences != null){
                for(Map.Entry entry : map.entrySet()){
                    preferences.put((String)entry.getKey(), (String)entry.getValue());
                }
            }
        }
        
        private Map<String,String> getMapFromPreferences(Preferences preferences){
            Map<String,String> resp = new HashMap<String,String>();
            
            if(preferences != null){
                String keys[];
                try {
                    keys = preferences.keys();
                    
                    for(int i=0; i<keys.length;i++){
                        resp.put(keys[i],preferences.get(keys[i],null));
                    }
                    
                } catch (BackingStoreException e) {
                    logger.severe(e);
                }
            }
            
            return resp;
        }

        @POST
        @Path("/preferences/{context}")
        public Response setPreferences(@PathParam("context")String context,HashMap<String,String> params) {
            if (context == null || StringUtils.isBlank(context)) {
                
                throw new BadRequestException("Context values : {user,useroversystem,shareduser,sharedsystem,system} is mandatory");
            }
            else{
                try {
                    ADFPreferencesFactory prefsFactory = new ADFPreferencesFactory();
                    Preferences prefs = null;
                    if(context.equalsIgnoreCase("USER")){
                        prefs = prefsFactory.userRoot();
                        setPreferencesFromMap(prefs,params);                        
                    }else if(context.equalsIgnoreCase("SHAREDUSER")){
                        prefs = prefsFactory.sharedUserRoot();
                        setPreferencesFromMap(prefs,params);                    
                    }else if(context.equalsIgnoreCase("SHAREDSYSTEM")){
                        prefs = prefsFactory.sharedSystemRoot();
                        setPreferencesFromMap(prefs,params);                    
                    }else if(context.equalsIgnoreCase("SYSTEM")){
                        prefs = prefsFactory.systemRoot();
                        setPreferencesFromMap(prefs,params);                    
                    }else if(context.equalsIgnoreCase("USEROVERSYSTEM")){
                        prefs = prefsFactory.userOverSystemRoot();
                        setPreferencesFromMap(prefs,params);                    
                    }else{
                        throw new BadRequestException("Context values : {user,useroversystem,shareduser,sharedsystem,system} is mandatory");
                    }        
                    
                    return Response.status(Response.Status.OK).type(MediaType.APPLICATION_JSON).build();                                        
                    
                } catch (Exception e) {
                    throw new BadRequestException(e);
                }
            }
        }    
                

    @POST
    @Path("/profile") 
    public Response updateUserProfile(@DefaultValue("anonymous") @QueryParam("userId")  String userId,@DefaultValue("PST") @QueryParam("source") String source,@QueryParam("processCode") String code,String employeeProfile){
        
        if(userId.compareToIgnoreCase("anonymous")==0)
            userId = ADFContext.getCurrent().getSecurityContext().getUserName();

        
        try{
            ServicesHelper sevHelper = new ServicesHelper();
            User user = LdapHelper.getInstance().getUser(userId);
            String emplId = (String)user.getUserProfile().getPropertyVal("Darden-Empl-ID");            
            
            String UPDATEEMERGENCYCONTACTINFO = "UpdateECChange";
            String UPDATEHOMEMAILINGINFO = "UpdateAddress,UpdatePhone,UpdateEmail";
            String UPDATEPROFILEHEADER = "UpdatePhone,UpdateEmail";
            String UPDATEBIRTHANDANNIVERSARYPREFERENCE = "UpdateSSOptions";
            
            Map<String,String> ns2json = new HashMap<String, String>();            
            ns2json.put("http://www.darden.com/Global/EnterpriseObjects/Core/Custom/EBO/Worker/V1", "ns1");   
            ns2json.put("http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd","ns10");
            ns2json.put("http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2","ns2");
            ns2json.put("http://www.darden.com/Global/EnterpriseObjects/Core/CommonEBO/V1","ns3");
            ns2json.put("http://www.darden.com/Global/EnterpriseObjects/Core/EBO/Worker/V1","ns4");
            ns2json.put("http://schemas.xmlsoap.org/ws/2003/03/addressing","ns5");
            ns2json.put("http://www.w3.org/2000/09/xmldsig#","ns6");
            ns2json.put("http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd","ns7");
            ns2json.put("urn:oasis:names:tc:xacml:2.0:context:schema:cd:04","ns8");
            ns2json.put("urn:oasis:names:tc:xacml:2.0:policy:schema:cd:04","ns9");                        
            
            
            JSONJAXBContext marshallingContext=new JSONJAXBContext(JSONConfiguration.mapped().xml2JsonNs(ns2json).arrays("ns3.PersonEmergencyContactInformation","ns3.EmergencyContactPhone","ns2.EmailCommunication","ns2.PhoneCommunication","ns3.PersonAddressCommunication","ns3.PersonEmergencyContactInformation").build(),ShowEmployeeProfileDataAreaType.class);                    
            JSONUnmarshaller um = marshallingContext.createJSONUnmarshaller(); 
            InputStream stream = new ByteArrayInputStream(employeeProfile.getBytes());
            ShowEmployeeProfileDataAreaType newProfileInfo = um.unmarshalFromJSON(stream, ShowEmployeeProfileDataAreaType.class);            
            EmployeeProfileType empProfType = newProfileInfo.getShowEmployeeProfileResponse().getEmployeeProfileDetails();            
            AcknowledgeEmployeeProfileDataAreaType ack =null;            
            
            
            IdentificationType identificationType = new IdentificationType();
            IdentifierType identifierType = new IdentifierType();
            identifierType.setValue(emplId);
            identificationType.setID(identifierType);
                        
            EmployeeProfileType upProf = new EmployeeProfileType();
            upProf.setIdentification(identificationType);            
            PersonType per = new PersonType();            
            upProf.setPerson(per);                
            
            if(code.compareToIgnoreCase("ss")==0){
                per.setHideAnniversaryDate(empProfType.getPerson().isHideAnniversaryDate());
                per.setHideBirthDate(empProfType.getPerson().isHideBirthDate());                 
                ack= sevHelper.processUserProfile(emplId,"UpdateSSOptions",upProf);
            }
            
            if(code.compareToIgnoreCase("ec")==0){
                List<PersonType.PersonEmergencyContactInformation> ecInfoList =  empProfType.getPerson().getPersonEmergencyContactInformation();
                for(PersonType.PersonEmergencyContactInformation ecInfo : ecInfoList){
                    per.getPersonEmergencyContactInformation().add(ecInfo);
                }
                ack= sevHelper.processUserProfile(emplId,"UpdateECChange",upProf);
            }
            
            if(code.compareToIgnoreCase("phone")==0){
                List<PersonPhoneCommunicationType> cInfoList =  empProfType.getPerson().getPersonPhoneCommunication();
                for(PersonPhoneCommunicationType cInfo : cInfoList){
                    per.getPersonPhoneCommunication().add(cInfo);
                }
                ack= sevHelper.processUserProfile(emplId,"UpdatePhone",upProf);                
            }

            if(code.compareToIgnoreCase("email")==0){
                List<PersonEmailCommunicationType> emailList =  empProfType.getPerson().getPersonEmailCommunication();
                for(PersonEmailCommunicationType emailInfo : emailList){
                    per.getPersonEmailCommunication().add(emailInfo);
                }
                ack= sevHelper.processUserProfile(emplId,"UpdateEmail",upProf);                
            }
            
            if(code.compareToIgnoreCase("address")==0){
                List<PersonAddressCommunicationType> addressList =  empProfType.getPerson().getPersonAddressCommunication();
                for(PersonAddressCommunicationType addressInfo : addressList){
                    per.getPersonAddressCommunication().add(addressInfo);
                }
                ack= sevHelper.processUserProfile(emplId,"UpdateAddress",upProf);                
            }            
            
            if(ack !=null){
                return Response.status(Response.Status.OK).entity(ack.getEmployeeEditProfileResponse().get(0)).type("application/json").build();
            }else{
                throw new BadRequestException("Failed to update Peoplesoft Profile Information.");
            }            
            /*JSONJAXBContext ackMarshallingContext=new JSONJAXBContext(JSONConfiguration.mapped().xml2JsonNs(ns2json).build(),AcknowledgeEmployeeProfileDataAreaType.class);                    
            JSONMarshaller m = ackMarshallingContext.createJSONMarshaller();
            StringWriter jsonWriter = new StringWriter();
            m.marshallToJSON(ack,jsonWriter);
            String json = jsonWriter.toString();
            return Response.status(Response.Status.OK).entity(json).type("application/json").build();   
            */
        }catch(Exception e){
            logger.severe(e);
            throw new BadRequestException(e);
        }
    }    
    
    public static String toCamelCase(String s){
       String[] parts = s.split("(_|-)");
       String camelCaseString = parts[0].toLowerCase();
       String part;
       for (int i=1;i<parts.length;i++){
          part = parts[i];
          camelCaseString = camelCaseString + toProperCase(part);     
       }
       return camelCaseString;
    }    

    private static String toProperCase(String s) {
        return s.substring(0, 1).toUpperCase() +
                   s.substring(1).toLowerCase();
    }   
    
    private String getPSProfileJSON(String userId) throws Exception {
        if(userId == null){
            return null;
        }else{
            ServicesHelper sevHelper = new ServicesHelper();
            User user = LdapHelper.getInstance().getUser(userId);
            String emplId = (String)user.getUserProfile().getPropertyVal("Darden-Empl-ID");
            ShowEmployeeProfileDataAreaType empInfo = null;  
            empInfo = sevHelper.getUserProfile(emplId); 
            
            Map<String,String> ns2json = new HashMap<String, String>();            
            ns2json.put("http://www.darden.com/Global/EnterpriseObjects/Core/Custom/EBO/Worker/V1", "ns1");   
            ns2json.put("http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd","ns10");
            ns2json.put("http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2","ns2");
            ns2json.put("http://www.darden.com/Global/EnterpriseObjects/Core/CommonEBO/V1","ns3");
            ns2json.put("http://www.darden.com/Global/EnterpriseObjects/Core/EBO/Worker/V1","ns4");
            ns2json.put("http://schemas.xmlsoap.org/ws/2003/03/addressing","ns5");
            ns2json.put("http://www.w3.org/2000/09/xmldsig#","ns6");
            ns2json.put("http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd","ns7");
            ns2json.put("urn:oasis:names:tc:xacml:2.0:context:schema:cd:04","ns8");
            ns2json.put("urn:oasis:names:tc:xacml:2.0:policy:schema:cd:04","ns9");                                
            
            //JSONJAXBContext marshallingContext=new JSONJAXBContext(JSONConfiguration.natural().build(),ShowEmployeeProfileDataAreaType.class);
            //JSONJAXBContext marshallingContext=new JSONJAXBContext(JSONConfiguration.natural().rootUnwrapping(false).humanReadableFormatting(true).build(),ShowEmployeeProfileDataAreaType.class);        
            JSONJAXBContext marshallingContext=new JSONJAXBContext(JSONConfiguration.mapped().xml2JsonNs(ns2json).arrays("ns3.PersonEmergencyContactInformation","ns3.EmergencyContactPhone","ns2.EmailCommunication","ns2.PhoneCommunication","ns3.PersonAddressCommunication","ns3.PersonEmergencyContactInformation").build(),ShowEmployeeProfileDataAreaType.class);        
            JSONMarshaller m = marshallingContext.createJSONMarshaller();
            StringWriter jsonWriter = new StringWriter();
            m.marshallToJSON(empInfo,jsonWriter);
            String json = jsonWriter.toString();
            return json;
        }
    }
    
    private Map<String,Object> getPSProfile(String userId){
        SecurityContext securityContext = ADFContext.getCurrent().getSecurityContext();
        String currentUser = securityContext.getUserName();
        if(userId == null || StringUtils.isBlank(userId)){
            userId = currentUser;    
        }
        try{
            User user = LdapHelper.getInstance().getUser(userId);
            UserProfile profile = user.getUserProfile();
            String dardenEmplId = (String)profile.getPropertyVal("Darden-Empl-ID");
            if(dardenEmplId != null){
                PeopleSoftAM am = getPeopleSoftAM();
                
                List<String> emps = new ArrayList<String>();
                emps.add(dardenEmplId);

                List<Map<String,Object>> result = am.getEmployees(emps, null,null,null,null,null, null,null,null, 0, 5);
                
                if(result != null && !result.isEmpty()){
                    return result.get(0);
                }else{
                    return null;
                }
            }else{
                return null;
            }
        }catch(Exception e){
            return null;
        }
    }
    
    private Map<String,Object> getADProfile(String userId) throws Exception {                
        SecurityContext securityContext = ADFContext.getCurrent().getSecurityContext();
        String currentUser = securityContext.getUserName();
        if(userId == null || StringUtils.isBlank(userId)){
            userId = currentUser;    
        }
                                    
        User user = LdapHelper.getInstance().getUser(userId);
        UserProfile profile = user.getUserProfile();
        PropertySet props = profile.getAllUserProperties();
        Iterator itr = props.getAll();
        Property prop;                    
        Map<String,Object> vals = new HashMap<String,Object>();
        List<Object> values;
        Object val;
            while(itr.hasNext()){
                prop = (Property)itr.next();
                values = prop.getValues();
                if(values !=null && values.size()>0){
                    val = values.get(0);
                    vals.put(toCamelCase(prop.getName()),val==null?null:val.toString());
                }
            }                
        
        String dn = profile.getUniqueName();
        
        vals.put("dn",dn);
        vals.put("guid",profile.getGUID());
        vals.put("name",profile.getName());
        vals.put("principal",profile.getPrincipal());
        vals.put("uniqueName",profile.getUniqueName());
        vals.put("userId",profile.getUserID());
        vals.put("userName",profile.getUserName());
        
        String managerLevel = (String)profile.getPropertyVal("Darden-Manager-Level");
        String jobFunction = (String)profile.getPropertyVal("Darden-Job-Function");
        //String jobSubFunction = (String)profile.getPropertyVal("Darden-Job-Sub-Function");

        Map<String,Object> derived = new HashMap<String,Object>();                        
        String[] rolesArr = null;
        List<String> roles = null;
        if(currentUser.compareToIgnoreCase(userId) == 0){
            rolesArr = securityContext.getUserRoles();
            roles = Arrays.asList(rolesArr);
        }else{
            roles = getRoles(user);
            rolesArr = ((roles == null) ? null : roles.toArray(new String[0]));
        }

        if(rolesArr != null){
            vals.put("userRoles", rolesArr);
            derived.put("roleGroup",getGroup(user,roles));
            derived.put("isRscRole",isRsc(roles,managerLevel));
            derived.put("isOpsRole",isOps(roles));
            derived.put("isAdmin",isAdmin(roles));                
            derived.put("isMessageOneWayRole", isMessageOneWayRole(roles));
        }                            
        
        boolean isRsc = false;
        boolean isHourly = false;
        boolean isRestManager = false;
        boolean isMIT = false;
        
        if(dn.toUpperCase().contains("OU=USERS,OU=RSC,DC=DARDEN,DC=COM")){
            isRsc=true;
        }else{
            if(jobFunction !=null){
                jobFunction = jobFunction.trim();                            
                if(jobFunction.compareToIgnoreCase("HOURLY EMPLOYEE")==0){
                    isHourly=true;
                }else{
                    if(jobFunction.compareToIgnoreCase("MANAGER")==0 || 
                       jobFunction.compareToIgnoreCase("MANAGER IN TRAINING")==0 ||
                       jobFunction.compareToIgnoreCase("GENERAL MANAGER")==0
                    ){
                        if(jobFunction.compareToIgnoreCase("MANAGER IN TRAINING")==0){
                            isMIT=true;
                        }
                        isRestManager = true;
                    }else{
                        isRsc=true;
                    }
                }                            
            }else{
                for(String role : rolesArr){
                    if(role.compareTo("Portal - General Manager") == 0 || role.compareTo("Portal - Manager") == 0){
                        isRestManager = true;
                    }
                    if(role.compareTo("Portal - Employee") == 0){
                        isHourly = true;
                    }
                    if(role.compareTo("Portal - MIT") == 0){
                        isMIT = true;
                    }                        
                }                
            }
        }
        
        derived.put("isRsc",isRsc);
        derived.put("isHourly",isHourly);
        derived.put("isRestManager",isRestManager);
        derived.put("isMIT",isMIT);            
        vals.put("derived",derived);            
        return vals;
    }

    private Map<String, Object> getKDProfile(String userId) {
        if (userId == null) {
            return null;
        } else {
            String version = httpRequest.getHeader("X-KROWDAPP-VERSION");
            String build = httpRequest.getHeader("X-KROWDAPP-BUILD");
            String release = httpRequest.getHeader("X-KROWDAPP-RELEASE");
            Properties properties = KrowdUtility.getInstance().getProperties();
            String cheddarsKrowdFullSite = (String)properties.get(CHEDDARS_KROWD_FULLSITE);
            boolean cskRedirectEnabled = (cheddarsKrowdFullSite == null)? false : (cheddarsKrowdFullSite.compareToIgnoreCase("YES") == 0 ? false : true);

            UserProfileAM am = getUserProfileAM();
            Row row = am.getProfileByUserName(userId);
            Map<String, Object> profileData = toMap(row, false);

            if (profileData != null) {
                profileData.put("cskRedirectEnabled",cskRedirectEnabled);
                Map chcp = am.getCHCPAttributes(version, build, release);
                String storeUrl = getStoreRedirect(httpRequest, httpResponse);
                if (chcp != null) {
                    profileData.put("appUpdate", chcp);
                }
                
                if(storeUrl != null){
                    profileData.put("storeUrl",storeUrl);
                }

                String ackStatus = profileData.get("AckStatus") + "";
                if (ackStatus.compareTo("2") == 0) {

                    if (version != null && build != null && release != null) {
                        StringBuilder sb = new StringBuilder();
                        sb.append(version).append(".").append(build).append(".").append(release);
                        String versionStr = sb.toString().trim();
                        logger.info("----------------------- Version Str-----------------" +
                                    versionStr);
                        boolean bypass = false;
                        try {
                            PropertiesUtil propertiesUtil =
                                PropertiesUtil.getInstance();
                            Properties props = propertiesUtil.getProperties();
                            String ack2bypass =
                                props.getProperty("ACK2BYPASS_BUILDS");
                            logger.info("----------------------- ACK2BYPASS_BUILDS-----------------" +
                                        ack2bypass);
                            if (ack2bypass != null) {
                                String[] builds = ack2bypass.split("#");
                                for (String bypassBuild : builds) {
                                    if (versionStr.compareToIgnoreCase(bypassBuild.trim()) ==
                                        0) {
                                        bypass = true;
                                        break;
                                    }
                                }
                            }
                        } catch (Exception e) {
                            logger.severe(e);
                        }

                        logger.info("----------------------- BYPASS-----------------" +
                                    bypass);
                        if (bypass) {
                            profileData.remove("AckStatus");
                            profileData.put("AckStatus", "1");
                        }
                    }
                }
            }else{
                profileData = new HashMap<String,Object>();
                profileData.put("cskRedirectEnabled",cskRedirectEnabled);                
            }
            
            return profileData;
        }
    }
    
    @GET
    @CacheMaxAge(time = 360, unit = TimeUnit.MINUTES)
    @Path("/profile")     
    public Response getUserProfile(@DefaultValue("anonymous") @QueryParam("userId")  String userId,@QueryParam("source") List<String> sources,@DefaultValue("false") @QueryParam("prefs") boolean prefs,@DefaultValue("KROWD_MOBILE_APP") @QueryParam("app") String app){
        if(sources == null || sources.size() == 0){
            try{
                if(userId.compareToIgnoreCase("anonymous")==0)
                    userId = ADFContext.getCurrent().getSecurityContext().getUserName();
                
                String json = getPSProfileJSON(userId);
                return Response.status(Response.Status.OK).entity(json).type("application/json").build();                                                
            }catch(Exception e){
                logger.severe(e);
                throw new BadRequestException(e);                
            }            
        }else{
            if(sources.size() == 1 && sources.get(0).compareToIgnoreCase("PST")==0){
                try{
                    if(userId.compareToIgnoreCase("anonymous")==0)
                        userId = ADFContext.getCurrent().getSecurityContext().getUserName();
                                        
                    String json = getPSProfileJSON(userId);
                    return Response.status(Response.Status.OK).entity(json).type("application/json").build();                                                
                }catch(Exception e){
                    logger.severe(e);
                    throw new BadRequestException(e);                
                }                            
            }else{
                Map<String, Object> result = new HashMap<String,Object>();
                for(String source : sources){
                    if(source.compareToIgnoreCase("AD")==0){
                        Map<String,Object> vals = null;
                        try{
                            if(userId.compareToIgnoreCase("anonymous")==0)
                                userId = null;                            
                            vals = getADProfile(userId);
                        }catch(Exception e){
                            logger.severe(e);
                        }
                        result.put("AD",vals);                        
                    }
                    
                    if(source.compareToIgnoreCase("WC")==0){
                        WCUserProfile userProfile = null;
                        try {
                            if(userId.compareToIgnoreCase("anonymous")==0)
                                userId = ADFContext.getCurrent().getSecurityContext().getUserName();
                                                        
                            UserProfileManager profileManager = ProfileFactory.getProfileManager();
                            userProfile = profileManager.getProfile(userId);
                        } catch (ProfileException e) {
                            logger.severe(e);
                        }                    
                        result.put("WC",userProfile);                                
                    }

                    if(source.compareToIgnoreCase("KD")==0){                    
                        if(userId.compareToIgnoreCase("anonymous")==0)
                            userId = ADFContext.getCurrent().getSecurityContext().getUserName();
                                                
                        Map<String,Object> profileData = getKDProfile(userId);
                        if(profileData != null){
                            if(prefs){
                                List<String> samIds = new ArrayList<String>();
                                samIds.add(userId);               
                                PreferencesAM am = getPreferencesAM();
                                Map<String,Object> masterPrefs = am.getMasterPrefs(app);
                                profileData.put("prefs", masterPrefs);
                                Map<String,Map<String,Object>> usersPrefs = am.getUsersPrefs(samIds, app);
                                if(null != usersPrefs){
                                    profileData.put("prefs", usersPrefs.get(userId));
                                }                               
                            }
                        }
                        result.put("KD", profileData);
                    }    
                    
                    if(source.compareToIgnoreCase("PS")==0){                    
                        if(userId.compareToIgnoreCase("anonymous")==0)
                            userId = ADFContext.getCurrent().getSecurityContext().getUserName();                                                
                        Map<String,Object> profileData = getPSProfile(userId);
                        result.put("PS", profileData);
                    }                                        
                }
                
                if(result.size() == 1){
                    String firstKey = result.keySet().iterator().next();
                    return Response.status(Response.Status.OK).type(MediaType.APPLICATION_JSON).entity(result.get(firstKey)).build(); 
                }else{
                    return Response.status(Response.Status.OK).type(MediaType.APPLICATION_JSON).entity(result).build(); 
                }
            }
        }
    }
    
    private ActivityObject createActivityObject(String serviceId, String objectType, String objectId)
    {
      ActivityObject obj = null;
      try {
        ActivityStreamingService as = ActivityStreamingServiceFactory.getInstance().getActivityStreamingService();
        ServiceObjectType serviceObjType = as.findObjectType(serviceId, objectType);
        obj = as.createObject(objectId, serviceObjType, objectId);
        obj.setServiceID(serviceId);
      } catch (ActivityException e) {
          logger.severe(e);
      }
      return obj;
    }   
        
    
    @POST
    @Path("/services/{serviceId}/objectTypes/{objectType}/objects/({objectId})/follow")
    public ObjectReference followObject(@PathParam("serviceId") String serviceId, @PathParam("objectType") String objectType, @PathParam("objectId") String objectId){        
        try {
            ActivityStreamingServiceFactory activityStreamingFactory = ActivityStreamingServiceFactory.getInstance();
            ActivityStreamingService activityStreamingService =  activityStreamingFactory.getActivityStreamingService();        
            FollowManager followManager =  activityStreamingService.getFollowManager();            
            String userId = ADFContext.getCurrent().getSecurityContext().getUserName();
            PersonReference personReference = PersonReference.GetPersonByLoginId(userId);            
            ActivityObject activityObject = createActivityObject(serviceId, objectType, objectId);
            ActivityActor activityActor = activityStreamingService.createActor(personReference.getGuid());
            followManager.followObject(activityActor,activityObject);            
            return new ObjectReference(activityObject);
        } catch (ActivityException e) {
            logger.severe(e);
            throw new BadRequestException(e);
        }
    }
    
    @DELETE
    @Path("/services/{serviceId}/objectTypes/{objectType}/objects/({objectId})/follow")
    public ObjectReference unFollowObject(@PathParam("serviceId") String serviceId, @PathParam("objectType") String objectType, @PathParam("objectId") String objectId,@QueryParam("userId") String userId){        
        try {
            ActivityStreamingServiceFactory activityStreamingFactory = ActivityStreamingServiceFactory.getInstance();
            ActivityStreamingService activityStreamingService =  activityStreamingFactory.getActivityStreamingService();        
            FollowManager followManager =  activityStreamingService.getFollowManager();            
            ActivityObject activityObject = createActivityObject(serviceId, objectType, objectId);
            
            if(userId == null){
                followManager.unfollowObject(activityObject);
            }else{
                if(userId.compareToIgnoreCase("self")==0){
                    userId = ADFContext.getCurrent().getSecurityContext().getUserName();
                }
                PersonReference personReference = PersonReference.GetPersonByLoginId(userId);                    
                followManager.unfollowObject(activityStreamingService.createActor(personReference.getGuid()),activityObject);            
            }
            
            return new ObjectReference(activityObject);
        } catch (ActivityException e) {
            logger.severe(e);
            throw new BadRequestException(e);
        }
    }    
    
    @GET
    @Path("/following")
    public List<ObjectReference> getFollowedObjects(@QueryParam("userId") String userId,@QueryParam("objectsecured") boolean objectsecured) {          
        List<ObjectReference> objects = new ArrayList<ObjectReference>();
        
        if(userId ==null)
            userId = ADFContext.getCurrent().getSecurityContext().getUserName();
        
        try{
            PersonReference personReference = PersonReference.GetPersonByLoginId(userId);            
            ActivityStreamingServiceFactory activityStreamingFactory = ActivityStreamingServiceFactory.getInstance();
            ActivityStreamingService activityStreamingService =  activityStreamingFactory.getActivityStreamingService();
            FollowManager followManager =  activityStreamingService.getFollowManager();
            List<ActivityObject> followedObjects = followManager.getFollowedObjects(activityStreamingService.createActor(personReference.getGuid()),objectsecured);
            
            if(followedObjects !=null){
                for(ActivityObject activityObject : followedObjects){
                    objects.add(new ObjectReference(activityObject));
                }
            }
        }catch(Exception e){
            logger.severe(e);
            throw new BadRequestException(e);
        }
        return objects;
    }    
    
    @GET
    @Path("/services/{serviceId}/objectTypes/{objectType}/objects/({objectId})/doesfollow")
    public boolean doesFollow(@PathParam("serviceId") String serviceId, @PathParam("objectType") String objectType, @PathParam("objectId") String objectId,@QueryParam("userId") String userId) {          
        if(userId ==null || userId.compareToIgnoreCase("self")==0)
            userId = ADFContext.getCurrent().getSecurityContext().getUserName();
        
        try{
            PersonReference personReference = PersonReference.GetPersonByLoginId(userId);            
            ActivityStreamingServiceFactory activityStreamingFactory = ActivityStreamingServiceFactory.getInstance();
            ActivityStreamingService activityStreamingService =  activityStreamingFactory.getActivityStreamingService();
            FollowManager followManager =  activityStreamingService.getFollowManager();
            ActivityObject activityObject = createActivityObject(serviceId, objectType, objectId);            
            return followManager.doesFollowObject(activityStreamingService.createActor(personReference.getGuid()),activityObject);
        }catch(Exception e){
            logger.severe(e);
            throw new BadRequestException(e);
        }
    }     
    
    @GET
    @CacheMaxAge(time = 360, unit = TimeUnit.MINUTES)
    @Path("/esslinks")
    public ESSLinksDAO getEssLinks(@QueryParam("userId") String userId) {  
        
        if (userId == null || StringUtils.isBlank(userId)) {
            userId = ADFContext.getCurrent().getSecurityContext().getUserName();
        }
                
        ServicesHelper sevHelper = new ServicesHelper();
        User user;
        try {
            user = LdapHelper.getInstance().getUser(userId);                
            String emplId = (String)user.getUserProfile().getPropertyVal("Darden-Empl-ID");
            //String emplId = (String)ADFContext.getCurrent().getSecurityContext().getUserProfile().getProperty("Darden-Empl-ID");
            //String emplId = "101512788";
            ESSLinksDAO result = sevHelper.getEmployeeSelfServiceLinks(emplId);
            return result;                
        } catch (Exception e) {
            throw new BadRequestException(e);
        }
    }
     
    @GET
    @CacheMaxAge(time = 360, unit = TimeUnit.MINUTES)
    @Path("/managerlinks")
    public ESSLinksDAO getManagerLinks(@QueryParam("userId") String userId) {          
        if (userId == null || StringUtils.isBlank(userId)) {
            userId = ADFContext.getCurrent().getSecurityContext().getUserName();
        }
                
        ServicesHelper sevHelper = new ServicesHelper();
        User user;
        try {
            user = LdapHelper.getInstance().getUser(userId);                
            String emplId = (String)user.getUserProfile().getPropertyVal("Darden-Empl-ID");
            //String emplId = (String)ADFContext.getCurrent().getSecurityContext().getUserProfile().getProperty("Darden-Empl-ID");
            //String emplId = "101512788";
            ESSLinksDAO result = sevHelper.getManagerLinks(emplId);
            return result;                
        } catch (Exception e) {
            throw new BadRequestException(e);
        }
    }     
    
    @PUT
    @Path("/notification")
    public Response updateNotification(Notification notification){
        try{
            logger.info("---Updating read status for Notification ----"+notification);
            String userName = ADFContext.getCurrent().getSecurityContext().getUserName();
            List<ActivityNotification> userNoti = StoreMDS.getNotifications(userName);
            ActivityNotification userNot=null;
            int foundAtIdx=-1;
            if(userNoti !=null){
                for(int i=0;i<userNoti.size();i++){
                    userNot = userNoti.get(i);
                    if(notification.compare(userNot)){
                        foundAtIdx=i;
                        break;  
                    }
                }
            }
            if(userNot !=null){
                MdsStoreObject mds = StoreMDS.updateNotification(foundAtIdx,userName);
                List<ActivityNotification> activityNotifications = mds.getActivityNotification();
                List<Notification> notifications = processActivityNotifications(activityNotifications);
                return Response.ok(notifications).build();                
            }else{
                return Response.status(Response.Status.BAD_REQUEST).build();
            }
        }catch(Exception e){
            throw new BadRequestException(e);
        }
    }

    @POST
    @Path("/delete-notification")
    public Response deleteNotification(Notification notification){
        try{
            logger.info("---Deleting read status for Notification ----"+notification);
            String userName = ADFContext.getCurrent().getSecurityContext().getUserName();
            List<ActivityNotification> userNoti = StoreMDS.getNotifications(userName);
            ActivityNotification userNot=null;
            int foundAtIdx=-1;
            if(userNoti !=null){
                for(int i=0;i<userNoti.size();i++){
                    userNot = userNoti.get(i);
                    if(notification.compare(userNot)){
                        foundAtIdx=i;
                        break;  
                    }
                }
            }

            if(userNot !=null){
                MdsStoreObject mds = StoreMDS.removeNotification(foundAtIdx,userName);
                List<ActivityNotification> activityNotifications = mds.getActivityNotification();
                List<Notification> notifications = processActivityNotifications(activityNotifications);
                return Response.ok(notifications).build();                
            }else{
                return Response.status(Response.Status.BAD_REQUEST).build();
            }
        }catch(Exception e){
            throw new BadRequestException(e);
        }
    }
    
    private Notification processPersonReferences(Notification notification){
        if(notification.isAsObject()){
            List<PersonReference> personRefs = notification.getActivity().getActors();
            for(PersonReference personRef : personRefs){
                personRef = MessagesHypermediaGenerator.addLinks(uriService, personRef);
            }            
        }
        PersonReference creator = notification.getCreator();
        PersonReference actor = notification.getActor();
        
        if(creator !=null){
            creator = MessagesHypermediaGenerator.addLinks(uriService,creator);
        }
        if(actor !=null){
            actor = MessagesHypermediaGenerator.addLinks(uriService,actor);
        }
        
        return notification;
    }
    
    private List<Notification> processActivityNotifications(List<ActivityNotification> userNoti){
        List<Notification> notifications = null;
        if (userNoti != null){
             //Collections.reverse(userNoti);                     
             notifications=new ArrayList<Notification>();
             
             ActivityStreamingServiceFactory factory = ActivityStreamingServiceFactory.getInstance();
             ActivityStreamingService activityService = factory.getActivityStreamingService();
             ActivityDisplayElement actDisEl;
             Notification notification;
             ActivityNotification userNot;
             for(int i=0;i<userNoti.size();i++){
                 userNot = userNoti.get(i);
                 if(userNot.getActivityId()!=null){
                     try{
                         actDisEl = activityService.findActivity(null,userNot.getActivityId());
                         notification = new Notification(actDisEl,userNot);
                         notification=processPersonReferences(notification);
                         notifications.add(notification);
                     }catch(Exception e){
                         logger.severe(e);
                         notification = new Notification(null,userNot);
                         notification=processPersonReferences(notification);
                         notifications.add(notification);                         
                     }
                 }else{
                     notification = new Notification(null,userNot);
                     notification=processPersonReferences(notification);
                     notifications.add(notification);
                 }                         
             }
         }
         return notifications;
    }
    
    @GET
    @CacheMaxAge(time = 360, unit = TimeUnit.MINUTES)
    @Path("/notifications")
    public Response getNotifications(@QueryParam("userId") String userId) {          
        if (userId == null || StringUtils.isBlank(userId)) {
            userId = ADFContext.getCurrent().getSecurityContext().getUserName();
        }
        
        List<Notification> notifications = null;
          
        try{
            List<ActivityNotification> userNoti = StoreMDS.getNotifications(userId);
            notifications = processActivityNotifications(userNoti);
            return Response.ok(notifications).build();
        }catch(Exception e){
            throw new BadRequestException(e);
        }

    }    
    
    @GET
    @CacheMaxAge(time = 360, unit = TimeUnit.MINUTES)
    @Path("/notifications/prefs")
    public Response getNotificationPrefs(){

        List<String> prefs = null;
           
            try{
                String userName = ADFContext.getCurrent().getSecurityContext().getUserName();
                prefs = StoreMDS.getNotificationsPreferences(userName);
                return Response.ok(prefs).build();
            }catch(Exception e){
                throw new BadRequestException(e);
            }

    }   
    
    
    private HashMap<oracle.jbo.domain.Number,Bookmark> generateLinksMap(List<HashMap> quickLinks,String lang){
      HashMap<oracle.jbo.domain.Number,Bookmark> map = null;      
      if(quickLinks != null && !quickLinks.isEmpty()){             
           map = new HashMap<oracle.jbo.domain.Number,Bookmark>();             
           for(HashMap linkMap : quickLinks){
               map.put((Number)linkMap.get("QlId"), new Bookmark(linkMap,lang));
           }
      }
      return map;
    }   
    
    
    private Map<oracle.jbo.domain.Number,QuickLinkDTO> generateLinksMapBookmark(List<HashMap> quickLinks,String lang){
     Map<oracle.jbo.domain.Number,QuickLinkDTO> map = null;      
      if(quickLinks != null && !quickLinks.isEmpty()){             
           map = new HashMap<oracle.jbo.domain.Number,QuickLinkDTO>();             
           for(Map linkMap : quickLinks){
               map.put((Number)linkMap.get("QlId"), new QuickLinkDTO(linkMap));
           }
      }
      return map;
    }   
    
    private ArrayList<oracle.jbo.domain.Number> filterImproperlyAssignedQuicklinks(List<oracle.jbo.domain.Number> allUserLinks, List<HashMap> quickLinks) {
        List<oracle.jbo.domain.Number> userLinks = new ArrayList<oracle.jbo.domain.Number>();        
        for(HashMap linkMap:quickLinks) {                        
            Number linkId = (Number)linkMap.get("QlId");            
                for (Number id:allUserLinks)   {
                    if (linkId.equals(id)) {                        
                        userLinks.add(id);
                        break;
                }
            }
        }        
        return (ArrayList<Number>)userLinks;
    }     
    
    @GET
    @Path("/tiles")
    public Response getAppTiles(){
        try{
            UserProfileAM am = getUserProfileAM();
            String[] userRoles = ADFContext.getCurrent().getSecurityContext().getUserRoles();        
            List<HashMap> appTiles = am.retrieveAppTiles(userRoles); 
            return Response.ok(appTiles).build();
        }catch(Exception e){
            throw new BadRequestException(e);
        }
    }
    
    @GET
    @CacheMaxAge(time = 360, unit = TimeUnit.MINUTES)
    @Path("/bookmarks")
    public Response getBookmarks(@DefaultValue("en") @QueryParam("lang") String lang){              
            try{
                List<oracle.jbo.domain.Number> userLinks = null;
                UserProfileAM am = getUserProfileAM();
                am.setLocale(lang);
                String userName = ADFContext.getCurrent().getSecurityContext().getUserName();

                String[] userRoles = ADFContext.getCurrent().getSecurityContext().getUserRoles();        
                List<HashMap> quickLinks = getUserProfileAM().retrieveQuickLinks(userRoles); 
                Collections.sort(quickLinks,new Comparator<HashMap>(){
                        public int compare(HashMap first,HashMap second){
                            String firstDisplayName=first.get("DisplayName").toString();
                            String secondDisplayName=second.get("DisplayName").toString();
                            return firstDisplayName.compareTo(secondDisplayName);
                        }
                    }
                );             
                Map<oracle.jbo.domain.Number,Bookmark> quickLinksMap = generateLinksMap(quickLinks,lang);
                Bookmark bookmark;
                List<oracle.jbo.domain.Number> allUserLinks = am.retrieveSelectedLinks(userName);   
                if (allUserLinks != null) {
                    userLinks = filterImproperlyAssignedQuicklinks(allUserLinks, quickLinks);
                }
                if(userLinks !=null && !userLinks.isEmpty()){
                    for(oracle.jbo.domain.Number qlId : userLinks){
                        bookmark = quickLinksMap.get(qlId);
                        if(bookmark!=null){
                            bookmark.setFavorite(true);
                        }
                    }
                }

                return Response.ok(quickLinksMap.values()).build();
            }catch(Exception e){
                throw new BadRequestException(e);
            }

    }
 
    @PUT
    @Path("/notifications/prefs")
    public Response setNotificationPrefs(ArrayList<String> prefs){

        try{
            String userName = ADFContext.getCurrent().getSecurityContext().getUserName();
            StoreMDS.storeInMDS(userName,-1,prefs,null);
            return Response.ok(prefs).build();
        }catch(Exception e){
            throw new BadRequestException(e);
        }
    }   
    
    private List<String[]> getQueryParamVals(String operator,List<String> param){
        if(param !=null && param.size() >0){
            List<String[]> vals = new ArrayList<String[]>();
            
            for(String args : param){
                vals.add(new String[]{operator,args});
            }
            return vals;
        }else{
            return null;
        }
    }
    
    private List<String> getRestaurants(List<String> description){
        List<String[]> queryParamVals;
        ArrayList<Identity> identities;
        
        if(description !=null && description.size() >0){
            HashMap<String[],List<String[]>> akaQueryParams = new HashMap<String[],List<String[]>>();
            
            queryParamVals = getQueryParamVals("_like_",description);
            akaQueryParams.put(new String[]{"Darden-AKA"}, queryParamVals);
            
            try {
                LdapHelper ldapHelper = LdapHelper.getInstance();
                ldapHelper.setCountLimit(null);
                ldapHelper.setPageLimit(null);
                ldapHelper.setUserSearchBase(RESTAURANT_SEARCH_BASES);
                identities =ldapHelper.getIdentitiesWithComplexAttributes(akaQueryParams,
                                                                      ComplexSearchFilter.TYPE_AND);
                ldapHelper.resetUserSearchBase();
                if(identities != null && identities.size()!=0){
                    List<String> restNumbers = new ArrayList<String>();
                    String restNum;
                    for(Identity restaurant : identities){
                        restNum =
                                (String)((User)restaurant).getUserProfile().getPropertyVal("physicalDeliveryOfficeName");
                        if(StringUtils.isNotBlank(restNum) && !restNumbers.contains(restNum)){
                            restNumbers.add(restNum);
                        }
                    }
                    
                    if(restNumbers.size()!=0){
                        return restNumbers;
                    }else{
                        return null;
                    }
                }else{
                    return null;
                }
            } catch (Exception e) {
                return null;
            }            
        }else{
            return null;
        }
    }
    
    
    private String generatePhotoURI(String guid, String size) {
      String encodedGuid = null;

      if (guid != null)
        encodedGuid = ProfileInternalUtils.asciiToHex(guid);

        StringBuilder uriBuilder =
            new StringBuilder(64).append("/").append("profilephoto").append("/").append(encodedGuid).append('/').append(size);
      String photoUID = "xxxxxxx";
      try{
            UserProfileManager userProfileManager = this.getUserProfileManager();
            WCUserProfile profile =  userProfileManager.getProfileByGUID(guid);
            photoUID = profile.getPhotoUID();
      }catch(Exception e) {

      }

      uriBuilder.append('/').append(photoUID);
      uriBuilder.append("?_xResourceMethod=wsrp");

      return uriBuilder.toString();
    }   
    
    private boolean _isConnected(String targetUserGuid) {
        if(connectionsManager == null){
            connectionsManager = getConnectionsManager();            
        }

        try {
            String guid = getCurentUserGUID();
            if(userConnections == null){
                userConnections = connectionsManager.getConnections(guid);
            }
            
            if(userConnections!=null && userConnections.size()>0){
                logger.info("_isConnected : connectionsManager="+connectionsManager + ", guid = "+ guid + ","+ userConnections.size());
                String connectedUserId;
                for(Connection conn : userConnections){
                    connectedUserId = conn.getConnecteeUserId();
                    logger.info("is a connection: "+ connectedUserId);
                    if(connectedUserId.compareTo(targetUserGuid)==0){
                        return true;
                    }
                }
                return false;
            }else{
                return false;
            }
        } catch (ConnectionsException e) {
            logger.severe(e);
        }
        
        return false;
    }
    
    private boolean _isInvited(String targetUserGuid){
        boolean isInvited = false;
        InvitationsManager invitationsManager = this.getInvitationsManager();
        if(sentInvitations == null){
            try {
                sentInvitations = invitationsManager.getSentInvitations();
            } catch (ConnectionsException e) {
            }
        }
        
        if(sentInvitations != null){
            String inviteeId;
            for(Invitation invite : sentInvitations){
                inviteeId = invite.getInviteeUserid();
                if(targetUserGuid.compareTo(inviteeId)==0){
                    isInvited = true;
                    break;
                }
            }
        }
        
        if(!isInvited){
            if(receivedInvitations == null){
                try {
                    receivedInvitations =
                            invitationsManager.getReceivedInvitations();
                } catch (ConnectionsException e) {
                }
                
            }
            
            if(receivedInvitations != null){
                String invitorId;
                for(Invitation invite : receivedInvitations){
                    invitorId = invite.getInvitorUserid();
                    if(targetUserGuid.compareTo(invitorId)==0){
                        isInvited = true;
                        break;
                    }
                }                
            }
        }
        
        return isInvited;        
    }
    
    
    private List<PersonRow> createPersonRows(int beginInx,int itemsPerPage,ArrayList<Identity> identities) {
        List<PersonRow> rows = new ArrayList<PersonRow>();
        
        if(identities !=null && identities.size()>0){
            int endInx = identities.size();        
            int pageEndIndex = beginInx + itemsPerPage;
            
            if(pageEndIndex > endInx){
                pageEndIndex = endInx;
            }
            logger.info("Creating Person Rows for records : "+ identities.size());
            for (int i = beginInx; i < pageEndIndex; i++) {
                PersonRow person = new PersonRow((User)identities.get(i));
                person.processUser();
                person.setPhotoURI(generatePhotoURI(person.getGuid(), "LARGE"));
                person.setEncodedGuid(ProfileInternalUtils.asciiToHex(person.getGuid()));
                logger.info("Checking for connection : "+ person.getUserName() + ", guid = "+ person.getGuid());
                boolean isConnected = _isConnected(person.getGuid());
                person.setConnected(isConnected);

                if (!isConnected) {
                    person.setInvited(_isInvited(person.getGuid()));
                }

                rows.add(person);
            }
        }        
        return rows;        
    }    
    
    @GET
    @CacheMaxAge(time = 360, unit = TimeUnit.MINUTES)
    @Path("/departments")
    public Response searchDepartments(@QueryParam("concept") List<String> brand,
                                  @QueryParam("department") List<String> department,
                                  @QueryParam("division") List<String> division,
                                  @QueryParam("area") List<String> area,
                                  @QueryParam("region") List<String> region,
                                  @QueryParam("restaurant") List<String> restaurant,
                                  @DefaultValue("0") @QueryParam("startIndex") StartIndexParam startIndex,
                                  @DefaultValue("25") @QueryParam("itemsPerPage") ItemsPerPageParam itemsPerPage){  
        try{
            PaginationParams pagination = new PaginationParams(startIndex, itemsPerPage);

            if(
                (brand == null || brand.isEmpty()) && 
                (department == null || department.isEmpty())&& 
                (restaurant == null || restaurant.isEmpty())&& 
                (division == null || division.isEmpty())&& 
                (area == null || area.isEmpty())&& 
                (region == null || region.isEmpty())
            ){
                String userId = ADFContext.getCurrent().getSecurityContext().getUserName();            
                User user = LdapHelper.getInstance().getUser(userId);
                UserProfile profile = user.getUserProfile();                
                restaurant = new ArrayList<String>();
                restaurant.add(profile.getPropertyVal("physicalDeliveryOfficeName")+"");
            }
            
            PeopleSoftAM am = getPeopleSoftAM();
            List<Map<String,Object>> results = am.getDepartments(department,restaurant, division,area,region, brand,null, pagination.getStartIndexValue(),pagination.getItemsPerPageValue());
            return Response.ok(results).type(MediaType.APPLICATION_JSON).build();            
        }catch(Exception e){
            logger.severe(e);
            throw new BadRequestException(e);
        }
        }    

    @GET
    @CacheMaxAge(time = 360, unit = TimeUnit.MINUTES)
    @Path("/jobcodes")
    public Response searchJobCodes(@QueryParam("concept") List<String> brand,
                                  @QueryParam("restaurant") List<String> restaurant,
                                  @QueryParam("jobCode") List<String> jobCode,                                   
                                  @DefaultValue("0") @QueryParam("startIndex") StartIndexParam startIndex,
                                  @DefaultValue("25") @QueryParam("itemsPerPage") ItemsPerPageParam itemsPerPage){  
            PaginationParams pagination = new PaginationParams(startIndex, itemsPerPage);
            try{
                if(
                    (brand == null || brand.isEmpty()) && 
                    (jobCode == null || jobCode.isEmpty())&& 
                    (restaurant == null || restaurant.isEmpty())
                ){
                    String userId = ADFContext.getCurrent().getSecurityContext().getUserName();            
                    User user = LdapHelper.getInstance().getUser(userId);
                    UserProfile profile = user.getUserProfile();                    
                    restaurant = new ArrayList<String>();
                    restaurant.add(profile.getPropertyVal("physicalDeliveryOfficeName")+"");
                }
                PeopleSoftAM am = getPeopleSoftAM();
                List<Map<String,Object>> results = am.getJobCodes(restaurant,brand,jobCode, null,pagination.getStartIndexValue(),pagination.getItemsPerPageValue());
                return Response.ok(results).type(MediaType.APPLICATION_JSON).build();                
            }catch(Exception e){
                logger.severe(e);
                throw new BadRequestException(e);
            }
        }    
    
    @GET
    @CacheMaxAge(time = 360, unit = TimeUnit.MINUTES)
    @Path("/search")
    public Response searchPeople( @QueryParam("firstName") List<String> firstName,
                                  @QueryParam("middleName") List<String> middleName,
                                  @QueryParam("lastName") List<String> lastName,
                                  @QueryParam("title") List<String> title,
                                  @QueryParam("concept") List<String> brand,
                                  @QueryParam("department") List<String> department,
                                  @QueryParam("division") List<String> division,
                                  @QueryParam("area") List<String> area,
                                  @QueryParam("region") List<String> region,
                                  @QueryParam("jobCode") List<String> jobCode,
                                  @QueryParam("restaurant") List<String> restaurant,
                                  @QueryParam("description") List<String> description,
                                  @QueryParam("country") List<String> country,
                                  @QueryParam("state") List<String> state,
                                  @QueryParam("city") List<String> city,
                                  @QueryParam("employeeId") List<String> employeeId,
                                  @QueryParam("userName") List<String> username,
                                  @DefaultValue("AD") @QueryParam("source") String source,
                                  @DefaultValue("0") @QueryParam("startIndex") StartIndexParam startIndex,
                                  @DefaultValue("25") @QueryParam("itemsPerPage") ItemsPerPageParam itemsPerPage){        
        
        PaginationParams pagination = new PaginationParams(startIndex, itemsPerPage);

        if(source.compareToIgnoreCase("AD") == 0){
            HashMap<String[],List<String[]>> queryParams = new HashMap<String[],List<String[]>>();
            List<String[]> queryParamVals;            
            if(restaurant == null || restaurant.size()==0){
                if(description !=null && description.size() >0){
                    restaurant = getRestaurants(description);
                }            
            }
                            
            queryParamVals = getQueryParamVals("_startswith_",firstName);
            if(queryParamVals !=null){
                queryParams.put(new String[]{UserProfile.FIRST_NAME,
                                               UserProfile.DISPLAY_NAME}, queryParamVals);
            }
            
            queryParamVals = getQueryParamVals("_startswith_",middleName);
            if(queryParamVals !=null){
                queryParams.put(new String[]{UserProfile.DISPLAY_NAME}, queryParamVals);
            }        

            queryParamVals = getQueryParamVals("_startswith_",lastName);
            if(queryParamVals !=null){
                queryParams.put(new String[]{UserProfile.LAST_NAME}, queryParamVals);
            }        
            
            queryParamVals = getQueryParamVals("_like_",title);
            if(queryParamVals !=null){
                queryParams.put(new String[]{ "Darden-Job-Function",
                                               "Darden-Sub-Function",
                                               UserProfile.TITLE}, queryParamVals);
            }        
            
            
            queryParamVals = getQueryParamVals("_eq_",brand);
            if(queryParamVals !=null){
                queryParams.put(new String[]{ "company", "Darden-Business-Unit"}, queryParamVals);
            }         

            queryParamVals = getQueryParamVals("_eq_",restaurant);
            if(queryParamVals !=null){
                queryParams.put(new String[]{ "physicalDeliveryOfficeName"}, queryParamVals);
            }         

            queryParamVals = getQueryParamVals("_eq_",country);
            if(queryParamVals !=null){
                queryParams.put(new String[]{ "co"}, queryParamVals);
            }         

            queryParamVals = getQueryParamVals("_eq_",state);
            if(queryParamVals !=null){
                queryParams.put(new String[]{ UserProfile.BUSINESS_STATE }, queryParamVals);
            }       
            

            queryParamVals = getQueryParamVals("_eq_",city);
            if(queryParamVals !=null){
                queryParams.put(new String[]{ UserProfile.BUSINESS_CITY }, queryParamVals);
            }       
            
            queryParamVals = getQueryParamVals("_eq_",employeeId);
            if(queryParamVals !=null){
                queryParams.put(new String[]{ "Darden-Empl-ID" }, queryParamVals);
            }       
            
            queryParamVals = getQueryParamVals("_eq_",username);
            if(queryParamVals !=null){
                queryParams.put(new String[]{ UserProfile.USER_NAME,UserProfile.USER_ID }, queryParamVals);
            }       
            
            try {
                LdapHelper ldapHelper = LdapHelper.getInstance();
                ldapHelper.setCountLimit(LDAP_COUNT_LIMIT);
                ldapHelper.setPageLimit(LDAP_PAGE_LIMIT);
                ldapHelper.setUserSearchBase(USER_SEARCH_BASES);
                ArrayList<Identity> identities = ldapHelper.getIdentitiesWithComplexAttributes(queryParams,ComplexSearchFilter.TYPE_AND);
                ldapHelper.resetUserSearchBase();
                List<PersonRow> result = createPersonRows(pagination.getStartIndexValue(),pagination.getItemsPerPageValue(),identities);            
                int totalCount = identities==null?0:identities.size();
                logger.info("Total number of users returned = "+ identities.size());
                PersonList list = new PersonList(result,pagination.getStartIndexValue(),totalCount);
                return Response.ok(list).build();
            } catch (Exception e) {
                logger.severe(e);
                LdapHelper ldapHelper;
                try {
                    ldapHelper = LdapHelper.getInstance();
                    ldapHelper.resetUserSearchBase();
                } catch (Exception f) {
                    logger.severe(f);
                }                
                throw new BadRequestException(e);
            }              
        }
        
        if(source.compareToIgnoreCase("PS") == 0){
            try{
                if(
                    (employeeId == null || employeeId.isEmpty()) && 
                    (brand == null || brand.isEmpty()) && 
                    (department == null || department.isEmpty())&& 
                    (restaurant == null || restaurant.isEmpty())&& 
                    (division == null || division.isEmpty())&& 
                    (area == null || area.isEmpty())&& 
                    (jobCode == null || jobCode.isEmpty())&& 
                    (region == null || region.isEmpty())
                ){
                    String userId = ADFContext.getCurrent().getSecurityContext().getUserName();            
                    User user = LdapHelper.getInstance().getUser(userId);
                    UserProfile profile = user.getUserProfile();                    
                    restaurant = new ArrayList<String>();
                    restaurant.add(profile.getPropertyVal("physicalDeliveryOfficeName")+"");
                }
                
                PeopleSoftAM am = getPeopleSoftAM();
                List<Map<String, Object>> results =
                    am.getEmployees(employeeId, department, restaurant, division,
                                    area, region, jobCode, brand, null,
                                    pagination.getStartIndexValue(),
                                    pagination.getItemsPerPageValue());
                return Response.ok(results).type(MediaType.APPLICATION_JSON).build();
                
            }catch(Exception e){
                logger.severe(e);
                throw new BadRequestException(e);
            }
        }
        
        throw new BadRequestException("Invalid source.");

    }    
    
    
    private List<String> getContacts(){
        ADFPreferencesFactory factory = new ADFPreferencesFactory();
        byte[] usersByteArray = new byte[0];
        List<String> personList = new ArrayList<String>();
        usersByteArray = factory.userRoot().getByteArray("MyContacts", usersByteArray);
        if(usersByteArray.length>0){
            LinkedList<String> contacts = (LinkedList<String>)SerializationUtils.deserialize(usersByteArray);
            if(contacts != null){
                String userName;
                for(int i=0;i<contacts.size();){
                    userName = contacts.get(i);
                    personList.add(userName);
                    i=i+2;
                }
            }
        }
        return personList;
    }
    
    private List<PersonReference> mergeContacts(List<PersonReference> toList, List<PersonReference> fromList){
        if(toList == null){
            if(fromList == null)
                return null;
            else
                return fromList;
        }else{
            if(fromList == null)
                return toList;
            else{                
                for(PersonReference fPerRef : fromList){
                    for(int i=0;i<toList.size();i++){
                        if(toList.get(i).getGuid().compareTo(fPerRef.getGuid())==0){
                            toList.remove(i);
                            break;
                        }
                    }
                }
                fromList.addAll(toList);
                return fromList;
            }
        }
    }
    
    @GET
    @CacheMaxAge(time = 360, unit = TimeUnit.MINUTES)
    @Path("/ssearch")
    public List<PersonReference> searchPeople(@QueryParam("query") String query){        
        if(query == null){
            List<PersonReference> contacts = toPersonReferences(getContacts());
            if(contacts == null || contacts.isEmpty() || contacts.size()<10){
                String userName = ADFContext.getCurrent().getSecurityContext().getUserName();
                try {
                    if(contacts == null)
                        contacts = getUserConnections(userName);
                    else
                        contacts = mergeContacts(contacts, getUserConnections(userName));
                } catch (Exception e) {
                    logger.severe(e);
                } 
            }            
            return contacts;
        }else{
            query = query.toUpperCase();
            //HttpSession session = httpRequest.getSession();//commented  
            //subh,CWE ID:384-Session Fixation 
            //httpRequest.getSession()- Returns the current session associated with this request, or if the request does not have a session, creates one.
            httpRequest.getSession().invalidate();//invalidating the pre-existing session
            HttpSession session = httpRequest.getSession();//creating a new session
            //

            List<PersonReference> contacts = (List<PersonReference>)session.getAttribute("SEARCH_CONTACTS_"+query);
            if(contacts !=null) 
                return contacts;
            contacts = toPersonReferences(getContacts());
            contacts = filterPersonReferences(contacts,query);
            if(contacts==null || contacts.isEmpty() || contacts.size()<10){
                String userName = ADFContext.getCurrent().getSecurityContext().getUserName();
                try {
                    if(contacts == null){
                        contacts = getUserConnections(userName);
                        contacts = filterPersonReferences(contacts,query);
                    }else{
                        List<PersonReference> tContacts = getUserConnections(userName);
                        tContacts = filterPersonReferences(tContacts,query);
                        contacts = mergeContacts(contacts, tContacts);
                    }
                } catch (Exception e) {
                    logger.severe(e);
                } 
                
                if(contacts == null || contacts.isEmpty() || contacts.size()<10){
                    String[] parts = query.split("\\s+");               
                    List<PersonReference> tContacts = new ArrayList<PersonReference>();
                    try { 
                        LdapHelper ldapHelper = LdapHelper.getInstance();
                        ldapHelper.resetUserSearchBase();
                        ldapHelper.setCountLimit(LDAP_COUNT_LIMIT);
                        ldapHelper.setPageLimit(LDAP_PAGE_LIMIT);
                        ldapHelper.setUserSearchBase(USER_SEARCH_BASES);
                        
                        List<Identity> identities =null;
                        
                        if(parts.length==1 && parts[0].length()>3){                    
                            HashMap<String[],List<String[]>> params = new HashMap<String[],List<String[]>>();
                            
                            //first , display
                            String[] operFD = new String[]{"_startswith_",parts[0]};
                            ArrayList<String[]> operFDList = new ArrayList<String[]>();
                            operFDList.add(operFD);
                            
                            //last
                            String[] operL = new String[]{"_startswith_",parts[0]};
                            ArrayList<String[]> operLList = new ArrayList<String[]>();
                            operLList.add(operL);
                            
                            
                            params.put(new String[] {UserProfile.FIRST_NAME,UserProfile.DISPLAY_NAME},operFDList);
                            params.put(new String[] {UserProfile.LAST_NAME},operLList);
                            identities = ldapHelper.getIdentitiesWithComplexAttributes(params,ComplexSearchFilter.TYPE_OR);                            

                        }
                        if(parts.length>1 && (parts[0].length()>3 || parts[1].length()>3)){
                            HashMap<String[],List<String[]>> params = new HashMap<String[],List<String[]>>();
                            
                            //first , display
                            String[] operFD = new String[]{"_startswith_",parts[0]};
                            ArrayList<String[]> operFDList = new ArrayList<String[]>();
                            operFDList.add(operFD);
                            
                            //last
                            String[] operL = new String[]{"_startswith_",parts[1]};
                            ArrayList<String[]> operLList = new ArrayList<String[]>();
                            operLList.add(operL);
                            
                            
                            params.put(new String[] {UserProfile.FIRST_NAME,UserProfile.DISPLAY_NAME},operFDList);
                            params.put(new String[] {UserProfile.LAST_NAME},operLList);
                            identities = ldapHelper.getIdentitiesWithComplexAttributes(params,ComplexSearchFilter.TYPE_AND);                            
                        }
                        
                        if(identities !=null){
                            if(LDAP_COUNT_LIMIT<identities.size()){
                             identities=identities.subList(0,LDAP_COUNT_LIMIT);   
                            }
                            tContacts = identitiesToPersonReferences(identities);    
                        }                        
                        
                    } catch (Exception e) {
                        logger.severe(e);
                    }
                    if(contacts == null)
                        contacts = tContacts;
                    else{
                        contacts = mergeContacts(contacts, tContacts);
                    }
                }
                session.setAttribute("SEARCH_CONTACTS_"+query, contacts);
                return contacts;
            }else{
                session.setAttribute("SEARCH_CONTACTS_"+query, contacts);
                return contacts;
            }
        }
    }
    
    @GET
    @Path("/allquicklinks")
    public Response retrieveAllQuickLinks() {
        try {
            UserProfileAM am = getUserProfileAM();
            am.setLocale("en");
            String[] userRoles = ADFContext.getCurrent().getSecurityContext().getUserRoles();
            List<HashMap> quickLinks = am.retrieveQuickLinks(userRoles);
            Collections.sort(quickLinks, new Comparator<HashMap>() {
                    public int compare(HashMap first, HashMap second) {
                        String firstDisplayName =
                            first.get("DisplayName").toString();
                        String secondDisplayName =
                            second.get("DisplayName").toString();
                        return firstDisplayName.compareTo(secondDisplayName);
                    }
                });
            List<QuickLinkDTO> quickLinkList = new ArrayList<QuickLinkDTO>();
            for(Map quickLink:quickLinks){
                QuickLinkDTO quickLinkDTO = new QuickLinkDTO(quickLink); 
                quickLinkList.add(quickLinkDTO);
            }
            QuickLinkDTO[] ret=quickLinkList.toArray(new QuickLinkDTO[quickLinkList.size()]);
            return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
        } catch (Exception e) {
            throw new BadRequestException(e);
        }
    }

    @GET
    @Path("/userquicklinks")
    public Response retrieveUserQuickLinks(@DefaultValue("en") @QueryParam("lang") String locale) {
        try {
            List<oracle.jbo.domain.Number> quickLinksUI = new ArrayList<oracle.jbo.domain.Number>();
            UserProfileAM am = getUserProfileAM();
//            am.setLocale("en");
            // setting local to retrieve lang specific quicklinks.
            am.setLocale(locale);
            String[] userRoles = ADFContext.getCurrent().getSecurityContext().getUserRoles();
            String userName = ADFContext.getCurrent().getSecurityContext().getUserName();
            //1. Derrive ALL Quick Links
            List<HashMap> allAvailableQuickLinks = am.retrieveQuickLinks(userRoles);
            Collections.sort(allAvailableQuickLinks, new Comparator<HashMap>() {
                    public int compare(HashMap first, HashMap second) {
                        String firstDisplayName =
                            first.get("DisplayName").toString();
                        String secondDisplayName =
                            second.get("DisplayName").toString();
                        return firstDisplayName.compareTo(secondDisplayName);
                    }
                });
            Map<oracle.jbo.domain.Number,QuickLinkDTO> allAvailableQuickLinksMap = generateLinksMapBookmark(allAvailableQuickLinks,"en");
            
            //2. Now Derrive Personalized Links
            List<oracle.jbo.domain.Number> personalizedLinks = am.retrieveSelectedLinks(userName);   
            //2.1 Filter improperly assigned links
            if (personalizedLinks != null) {
                personalizedLinks = filterImproperlyAssignedQuicklinks(personalizedLinks, allAvailableQuickLinks);
            }
            
            
            // 2.2 If no personalized Links exist, Derrive the default links to be shown as personalized
            //TODO:Check if this is still a valid requirement for 4.2
            if (personalizedLinks == null || personalizedLinks.isEmpty()){
                logger.info("userLinks for user is null");
                personalizedLinks = new ArrayList<oracle.jbo.domain.Number>();
                for(HashMap linkMap: allAvailableQuickLinks) {
                    String mandatory = (String) linkMap.get("IsMandatory");
                    String def = (String) linkMap.get("IsDefault");
                    oracle.jbo.domain.Number qlId = (Number)linkMap.get("QlId"); // this is related_ql_id from DB
                    if (mandatory != null && mandatory.compareToIgnoreCase("Y") == 0) {
                        personalizedLinks.add((Number)linkMap.get("QlId")); // this is related_ql_id from DB
                    }
                    
                    if(def != null && def.compareToIgnoreCase("Y") == 0 && !containsLink(personalizedLinks, qlId)){
                        personalizedLinks.add((Number)linkMap.get("QlId")); // this is related_ql_id from DB
                    }
                }
//                for(HashMap linkMap: allAvailableQuickLinks) {
//                    String def = (String) linkMap.get("IsDefault");
//                    oracle.jbo.domain.Number qlId = (Number)linkMap.get("QlId"); // this is related_ql_id from DB
//                    if (def != null && def.compareToIgnoreCase("Y") == 0 && !containsLink(userLinks, qlId)) {
//                        userLinks.add(qlId);
//                    }
//                }
            }
            //2.3 removing duplicate from personalized quick links
            if(personalizedLinks != null){
                logger.info("userLinks for user at the end before removing duplicates: "+personalizedLinks);
                personalizedLinks= new ArrayList<oracle.jbo.domain.Number>(new LinkedHashSet<oracle.jbo.domain.Number>(personalizedLinks));
                //Collections.sort(userLinks);
                logger.info("userLinks for user at the end after removing duplicates: "+personalizedLinks);
            }
            
            //3. Prepare for UI
            List<QuickLinkDTO> personalizedQLList = new ArrayList<QuickLinkDTO>();
            List<QuickLinkDTO> allAvailableQLList = new ArrayList<QuickLinkDTO>();
            List<QuickLinkDTO> mandatoryQLList = new ArrayList<QuickLinkDTO>();
            //3.1 prepare a personalized Map for comparision
            Map<oracle.jbo.domain.Number, oracle.jbo.domain.Number> personalizedLinksMap = new HashMap<oracle.jbo.domain.Number, oracle.jbo.domain.Number>();
            for(oracle.jbo.domain.Number qlId : personalizedLinks){
                personalizedLinksMap.put(qlId, qlId);
            }
            Set<oracle.jbo.domain.Number> allLinks = allAvailableQuickLinksMap.keySet();
            for(oracle.jbo.domain.Number linkId : allLinks){
                QuickLinkDTO dto = allAvailableQuickLinksMap.get(linkId);
                if(dto.isMandatory()){
                    mandatoryQLList.add(dto);
                }else if(personalizedLinksMap.containsKey(new oracle.jbo.domain.Number(dto.getId()))){
                    personalizedQLList.add(dto);
                }else{
                    allAvailableQLList.add(dto);
                }
                
            }
//            for(HashMap linkMap: allAvailableQuickLinks) {
//                oracle.jbo.domain.Number qlId = (Number)linkMap.get("QlId");
//                if(personalizedLinks.contains(qlId)){
//                    quickLinksUI.add(qlId);
//                }
//            }
            
            
//            for(HashMap linkMap: allAvailableQuickLinks) {
//                oracle.jbo.domain.Number qlId = (Number)linkMap.get("QlId");
//                if(!userLinks.contains(qlId)){
//                    quickLinksUI.add(qlId);
//                }
//            }

//            if (userLinks != null && !userLinks.isEmpty()) {
//                for (oracle.jbo.domain.Number qlId : userLinks) {
//                   QuickLinkDTO  quickLinkDTO = quickLinksMap.get(qlId);
//                    if (quickLinkDTO != null) {
//                        quickLinkUserList.add(quickLinkDTO);
//                    }
//                }
//            }
//            if (quickLinksUI != null && !quickLinksUI.isEmpty()) {
//                for (oracle.jbo.domain.Number qlId : quickLinksUI) {
//                   QuickLinkDTO  quickLinkDTO = quickLinksMap.get(qlId);
//                    if (quickLinkDTO != null) {
//                        quickLinkAvailableForUserList.add(quickLinkDTO);
//                    }
//                }
//            }
            
            QuickLinkListDTO resultList = new QuickLinkListDTO();
            resultList.setMandatoryQuickLinks(mandatoryQLList);
            resultList.setPersonalizedQuickLinks(personalizedQLList);
            resultList.setAvailableQuickLinks(allAvailableQLList);
            return Response.ok(resultList).type(MediaType.APPLICATION_JSON).build();
        } catch (Exception e) {
            throw new BadRequestException(e);
        }
    }
    
    @POST
    @Path("/saveQuickLinkPersonalization")
    public Response saveQuickLinkPersonalization(Integer[] quickLinkIds) {
        logger.info("Got Personalized Links : "+ quickLinkIds);
        String userName = ADFContext.getCurrent().getSecurityContext().getUserName();
        UserProfileAM am = getUserProfileAM();
        am.setLocale("en");
        List<Number> selectedLinkIds = new ArrayList<Number>();
        for(int i=0;i<quickLinkIds.length;i++){
            selectedLinkIds.add(new Number(quickLinkIds[i].intValue()));
        }
        logger.info("Saving Personalized Links for user : "+userName +"  Links : "+ selectedLinkIds + ", "+selectedLinkIds.size());
        boolean result = am.saveSelectedQuickLinks(userName, selectedLinkIds);    
        logger.info("Result after saving Selected QuickLinks "+result);
        return Response.ok(result).type(MediaType.APPLICATION_JSON).build();
    }
    
    
    private boolean containsLink(List<oracle.jbo.domain.Number> userLinks,oracle.jbo.domain.Number linkId){
        boolean found=false;
        if(userLinks != null && linkId != null){
            for(oracle.jbo.domain.Number userLinkId : userLinks){
                if(userLinkId.compareTo(linkId)==0){
                    found=true;
                    break;
                }
            }
        }
        return found;                    
    }
    
    @GET
    @Path("/userPasswordEmail")
    public Response getUserPasswordEmail() {
        UserProfileAM am = getUserProfileAM(); 
        String userName = ADFContext.getCurrent().getSecurityContext().getUserName();
        String ret = am.getUserPasswordEmail(userName);       
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("/userPasswordEmail")    
    public Response setUserPasswordEmail(String eMail) {
        UserProfileAM am = getUserProfileAM();    
        String userName = ADFContext.getCurrent().getSecurityContext().getUserName();
        boolean ret = am.setUserPasswordEmail(userName,eMail);       
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    
    
    public static void main(String[] args) throws JAXBException {
        String profileXML = "<ns1:ShowEmployeeProfileDataAreaTypeRoot xmlns:ns1=\"http://www.darden.com/Global/EnterpriseObjects/Core/EBO/Worker/V1\"><ns1:ShowEmployeeProfileResponse><ns1:EmployeeProfileDetails><ns1:WorkerEmployment><corecom:Identification xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"><corecom:ID>101512788</corecom:ID></corecom:Identification><ns1:StartDate>2013-04-22</ns1:StartDate><ns1:EmploymentTerm><ns1:EmploymentAssignment><corecom:Status xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"><corecom:Code>A</corecom:Code></corecom:Status><corecom:DepartmentReference xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"><corecom:DepartmentIdentification><corecom:ID>0971</corecom:ID></corecom:DepartmentIdentification><corecom:OrganizationUnitIdentification><corecom:ID>DRUSA</corecom:ID></corecom:OrganizationUnitIdentification></corecom:DepartmentReference><corecom:LocationReference xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"><corecom:LocationIdentification><corecom:ID>RSC - Restaurant Support Cntr</corecom:ID></corecom:LocationIdentification><corecom:Address><corecom:LineOne>3827 Pine Gate Trail</corecom:LineOne><corecom:LineTwo></corecom:LineTwo><corecom:CityName>Orlando</corecom:CityName><corecom:StateName>FL</corecom:StateName><corecom:CountryCode>USA</corecom:CountryCode><corecom:PostalCode>32824</corecom:PostalCode></corecom:Address></corecom:LocationReference><ns1:EmploymentAssignmentSupervision><ns1:SupervisionWorkerDirectReports><ns1:DirectReportID></ns1:DirectReportID><ns1:DirectReportName></ns1:DirectReportName></ns1:SupervisionWorkerDirectReports><ns1:ReportsToID>990008937</ns1:ReportsToID><ns1:ReportsToName>Test Copeland</ns1:ReportsToName></ns1:EmploymentAssignmentSupervision></ns1:EmploymentAssignment><ns1:WorkerJobCodes><ns1:JobCode>7948</ns1:JobCode><ns1:JobTitle>Sr Systems Engineer Portal</ns1:JobTitle><ns1:JobCodeSeq>0</ns1:JobCodeSeq></ns1:WorkerJobCodes></ns1:EmploymentTerm></ns1:WorkerEmployment><ns1:WorkerCertification><corecom:Identification xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"><corecom:ID></corecom:ID></corecom:Identification><corecom:Certification xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"><corecom:Name></corecom:Name><corecom:TypeOfCert></corecom:TypeOfCert><corecom:IssueDate></corecom:IssueDate><corecom:ExpirationDate></corecom:ExpirationDate></corecom:Certification></ns1:WorkerCertification><corecomEBO:Person xmlns:corecomEBO=\"http://www.darden.com/Global/EnterpriseObjects/Core/CommonEBO/V1\"><corecomEBO:BirthDateTime>1981-08-29</corecomEBO:BirthDateTime><corecomEBO:GenderCode>M</corecomEBO:GenderCode><corecomEBO:HighestEducLevel>09</corecomEBO:HighestEducLevel><corecomEBO:EthnicGroup></corecomEBO:EthnicGroup><corecomEBO:HideBirthDate>false</corecomEBO:HideBirthDate><corecomEBO:HideAnniversaryDate>false</corecomEBO:HideAnniversaryDate><corecomEBO:PersonName><corecom:PersonName xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"><corecom:FirstName>Rakesh</corecom:FirstName><corecom:MiddleName></corecom:MiddleName><corecom:FamilyName>Gajula</corecom:FamilyName><corecom:Prefix></corecom:Prefix><corecom:Suffix></corecom:Suffix></corecom:PersonName></corecomEBO:PersonName><corecomEBO:PersonAddressCommunication><corecom:AddressCommunication xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"><corecom:Address><corecom:LineOne>3827 Pine Gate Trail</corecom:LineOne><corecom:LineTwo></corecom:LineTwo><corecom:CityName>Orlando</corecom:CityName><corecom:StateName>FL</corecom:StateName><corecom:CountryCode>USA</corecom:CountryCode><corecom:PostalCode>32824</corecom:PostalCode></corecom:Address></corecom:AddressCommunication></corecomEBO:PersonAddressCommunication><corecomEBO:PersonPhoneCommunication><corecom:PhoneCommunication xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"><corecom:CompleteNumber>321/704-6585</corecom:CompleteNumber><corecom:ExtensionNumber></corecom:ExtensionNumber><corecom:TypeCode>CELL</corecom:TypeCode><corecom:PreferredIndicator>N</corecom:PreferredIndicator></corecom:PhoneCommunication><corecom:PhoneCommunication xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"><corecom:CompleteNumber>321/323-9427</corecom:CompleteNumber><corecom:ExtensionNumber></corecom:ExtensionNumber><corecom:TypeCode>HOME</corecom:TypeCode><corecom:PreferredIndicator>Y</corecom:PreferredIndicator></corecom:PhoneCommunication><corecom:PhoneCommunication xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"><corecom:CompleteNumber>321/821-0128</corecom:CompleteNumber><corecom:ExtensionNumber></corecom:ExtensionNumber><corecom:TypeCode>OTR</corecom:TypeCode><corecom:PreferredIndicator>N</corecom:PreferredIndicator></corecom:PhoneCommunication><corecom:PhoneCommunication xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"><corecom:CompleteNumber>407/245-4697</corecom:CompleteNumber><corecom:ExtensionNumber></corecom:ExtensionNumber><corecom:TypeCode>WORK</corecom:TypeCode><corecom:PreferredIndicator>N</corecom:PreferredIndicator></corecom:PhoneCommunication></corecomEBO:PersonPhoneCommunication><corecomEBO:PersonEmailCommunication><corecom:EmailCommunication xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"><corecom:URI></corecom:URI><corecom:UseCode></corecom:UseCode><corecom:PreferredIndicator></corecom:PreferredIndicator></corecom:EmailCommunication></corecomEBO:PersonEmailCommunication><corecomEBO:PersonEmergencyContactInformation><corecomEBO:ECName></corecomEBO:ECName><corecomEBO:ECSameAddressEmpl>N</corecomEBO:ECSameAddressEmpl><corecomEBO:ECPreferred>Y</corecomEBO:ECPreferred><corecomEBO:ECCountry></corecomEBO:ECCountry><corecomEBO:ECAddress1></corecomEBO:ECAddress1><corecomEBO:ECAddress2></corecomEBO:ECAddress2><corecomEBO:ECCity></corecomEBO:ECCity><corecomEBO:ECState></corecomEBO:ECState><corecomEBO:ECPostal></corecomEBO:ECPostal><corecomEBO:ECRelationship></corecomEBO:ECRelationship><corecomEBO:ECSamePhoneEmpl>N</corecomEBO:ECSamePhoneEmpl><corecomEBO:ECAddressTypeEmpl></corecomEBO:ECAddressTypeEmpl><corecomEBO:ECPhoneTypeEmpl></corecomEBO:ECPhoneTypeEmpl><corecomEBO:EmergencyContactPhone><corecomEBO:ECPhoneType>PRIM</corecomEBO:ECPhoneType><corecomEBO:ECPhone></corecomEBO:ECPhone><corecomEBO:ECPhoneExtension></corecomEBO:ECPhoneExtension></corecomEBO:EmergencyContactPhone></corecomEBO:PersonEmergencyContactInformation></corecomEBO:Person><ns1:ErrorMessage><corecom:ReportingDateTime xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"></corecom:ReportingDateTime><corecom:ErrorCode xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"></corecom:ErrorCode><corecom:ErrorText xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"></corecom:ErrorText><corecom:ErrorActor xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"></corecom:ErrorActor><corecom:ErrorDetail xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"></corecom:ErrorDetail></ns1:ErrorMessage></ns1:EmployeeProfileDetails></ns1:ShowEmployeeProfileResponse></ns1:ShowEmployeeProfileDataAreaTypeRoot>";
        JAXBContext jc = JAXBContext.newInstance(ShowEmployeeProfileDataAreaType.class);
        Unmarshaller unmarshaller = jc.createUnmarshaller();
        //subh, CWE ID: 611 - Improper Restriction of XML External Entity Reference
        try
        {
            XMLInputFactory xmlInputFactory = XMLInputFactory.newFactory();
            xmlInputFactory.setProperty(XMLInputFactory.SUPPORT_DTD, false);
            xmlInputFactory.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            logger.info(ex.getMessage());
        }
        //
        ShowEmployeeProfileDataAreaType obj =  (ShowEmployeeProfileDataAreaType)unmarshaller.unmarshal(new ByteArrayInputStream(profileXML.getBytes()));
        System.out.println(obj);
        
        
        
        Map<String,String> ns2json = new HashMap<String, String>();
        ns2json.put("http://www.darden.com/Global/EnterpriseObjects/Core/EBO/Worker/V1", "ps");        
        
        //JSONJAXBContext marshallingContext=new JSONJAXBContext(JSONConfiguration.natural().build(),ShowEmployeeProfileDataAreaType.class);
        //JSONJAXBContext marshallingContext=new JSONJAXBContext(JSONConfiguration.natural().rootUnwrapping(false).humanReadableFormatting(true).build(),ShowEmployeeProfileDataAreaType.class);        
        JSONJAXBContext marshallingContext=new JSONJAXBContext(JSONConfiguration.mapped().xml2JsonNs(ns2json).build(),ShowEmployeeProfileDataAreaType.class);        
        /*JSONMarshaller m = marshallingContext.createJSONMarshaller();
        StringWriter jsonWriter = new StringWriter();
        m.marshallToJSON(obj,jsonWriter);
        String json = jsonWriter.toString();
        
        System.out.println(json);*/
        
        String json = "{\"ps.ShowEmployeeProfileResponse\":{\"ps.EmployeeProfileDetails\":{\"ps.WorkerEmployment\":{\"Identification\":{\"ID\":\"101512788\"},\"ps.StartDate\":\"2013-04-22\",\"ps.EmploymentTerm\":{\"ps.EmploymentAssignment\":{\"Status\":{\"Code\":\"A\"},\"DepartmentReference\":{\"DepartmentIdentification\":{\"ID\":\"0971\"},\"OrganizationUnitIdentification\":{\"ID\":\"DRUSA\"}},\"LocationReference\":{\"LocationIdentification\":{\"ID\":\"RSC - Restaurant Support Cntr\"},\"Address\":{\"LineOne\":\"3827 Pine Gate Trail\",\"LineTwo\":\"\",\"CityName\":\"Orlando\",\"StateName\":\"FL\",\"CountryCode\":\"USA\",\"PostalCode\":\"32824\"}},\"ps.EmploymentAssignmentSupervision\":{\"ps.SupervisionWorkerDirectReports\":{\"ps.DirectReportID\":\"\",\"ps.DirectReportName\":\"\"},\"ps.ReportsToID\":\"990008937\",\"ps.ReportsToName\":\"Test Copeland\"}},\"ps.WorkerJobCodes\":{\"ps.JobCode\":\"7948\",\"ps.JobTitle\":\"Sr Systems Engineer Portal\",\"ps.JobCodeSeq\":\"0\"}}},\"ps.WorkerCertification\":{\"Identification\":{\"ID\":\"\"},\"Certification\":{\"Name\":\"\",\"TypeOfCert\":\"\"}},\"Person\":{\"BirthDateTime\":\"1981-08-29\",\"GenderCode\":\"M\",\"HighestEducLevel\":\"09\",\"EthnicGroup\":\"\",\"HideBirthDate\":\"false\",\"HideAnniversaryDate\":\"false\",\"PersonName\":{\"PersonName\":{\"FirstName\":\"Rakesh\",\"MiddleName\":\"\",\"FamilyName\":\"Gajula\",\"Prefix\":\"\",\"Suffix\":\"\"}},\"PersonAddressCommunication\":{\"AddressCommunication\":{\"Address\":{\"LineOne\":\"3827 Pine Gate Trail\",\"LineTwo\":\"\",\"CityName\":\"Orlando\",\"StateName\":\"FL\",\"CountryCode\":\"USA\",\"PostalCode\":\"32824\"}},\"AddrDeleteIndicator\":\"false\"},\"PersonPhoneCommunication\":{\"PhoneCommunication\":[{\"CompleteNumber\":\"321/704-6585\",\"ExtensionNumber\":\"\",\"TypeCode\":\"CELL\",\"PreferredIndicator\":\"false\"},{\"CompleteNumber\":\"321/323-9427\",\"ExtensionNumber\":\"\",\"TypeCode\":\"HOME\",\"PreferredIndicator\":\"false\"},{\"CompleteNumber\":\"321/821-0128\",\"ExtensionNumber\":\"\",\"TypeCode\":\"OTR\",\"PreferredIndicator\":\"false\"},{\"CompleteNumber\":\"407/245-4697\",\"ExtensionNumber\":\"\",\"TypeCode\":\"WORK\",\"PreferredIndicator\":\"false\"}],\"PhoneDeleteIndicator\":\"false\"},\"PersonEmailCommunication\":{\"EmailCommunication\":{\"URI\":\"\",\"UseCode\":\"\"},\"EmailDeleteIndicator\":\"false\"},\"PersonEmergencyContactInformation\":{\"ECName\":\"\",\"ECSameAddressEmpl\":\"N\",\"ECPreferred\":\"Y\",\"ECCountry\":\"\",\"ECAddress1\":\"\",\"ECAddress2\":\"\",\"ECCity\":\"\",\"ECState\":\"\",\"ECPostal\":\"\",\"ECRelationship\":\"\",\"ECSamePhoneEmpl\":\"N\",\"ECAddressTypeEmpl\":\"\",\"ECPhoneTypeEmpl\":\"\",\"ECDeleteIndicator\":\"false\",\"EmergencyContactPhone\":{\"ECPhoneType\":\"PRIM\",\"ECPhone\":\"\",\"ECPhoneExtension\":\"\"}}},\"ps.ErrorMessage\":{\"ErrorCode\":\"\",\"ErrorText\":\"\",\"ErrorActor\":\"\",\"ErrorDetail\":null}}}}";
        
        JSONUnmarshaller um = marshallingContext.createJSONUnmarshaller(); 
        InputStream stream = new ByteArrayInputStream(json.getBytes());
        //Object newProfileInfo  = um.unmarshalJAXBElementFromJSON(stream, ShowEmployeeProfileDataAreaType.class);
        ShowEmployeeProfileDataAreaType newProfileInfo = um.unmarshalFromJSON(stream, ShowEmployeeProfileDataAreaType.class);
        
        PeopleResource res = new PeopleResource();
        
        
    }
    
    @GET
    @Path("/networkAccessType")
    public Response isUserInNetwork(){
        String headerType = httpRequest.getHeader("Krowd-NetworkAccessType");  
        logger.severe("headerType == "+ headerType);
        if(headerType == null){
            headerType = "Not Available";
        }
        
        logger.info("/********debug********/");
        Enumeration enm = httpRequest.getHeaderNames();
        while(enm.hasMoreElements()){
            String header = enm.nextElement().toString();
            logger.info(">>  "+ header + " : "+ httpRequest.getHeader(header));
        }
        logger.info("/***** debug ends***/");
        return Response.ok(headerType).type(MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("/query")
    @Produces("application/json")
    public Response queryGet( @QueryParam("id") List<String> emplIds,@DefaultValue("false") @QueryParam("prefs") boolean prefs,@DefaultValue("KROWD_MOBILE_APP") @QueryParam("app") String app,@DefaultValue("true") @QueryParam("cache") boolean cache){
        List<String> appNames = new ArrayList<String>();
        Map<String,Map<String,Object>> empIdProfiles;
        Response response;
        String userId = ADFContext.getCurrent().getSecurityContext().getUserName();
        
        if(emplIds == null || emplIds.size() <=0){   
            logger.info("------ No Employee Ids have been passed--------");
            oracle.adf.share.security.identitymanagement.UserProfile userProfile = ADFContext.getCurrent().getSecurityContext().getUserProfile();
            String emplId = (String)userProfile.getProperty("Darden-Empl-ID");
            logger.info("------ Stage 1: Determined Employee Id as : "+emplId);
            if(emplId == null){
                logger.info("------ Stage 1: Failed----------");
                try{                    
                    User user = LdapHelper.getInstance().getUser(userId);
                    emplId = (String)user.getUserProfile().getPropertyVal("Darden-Empl-ID");                
                    logger.info("------ Stage 2: Determined Employee Id as : "+emplId);
                    if(null == emplId){
                        emplId = "";
                        logger.info("------ Stage 3: Initialized Employee Id as empty: "+emplId);
                    }
                }catch(Exception e){
                    logger.severe(e);
                }
            }
            
            //no emplId users
            if(null != emplId && (emplId.trim().isEmpty())){
                Map<String,Object> profile = null;
                //check in cache
                profile = (Map<String, Object>) CacheUtil.getInstance().get(userId,CacheUtil.CacheType.PEOPLE_CACHE);
                
                if(null == profile){
                    profile =  new HashMap<String,Object>();
                    profile.put("employeeId", userProfile.getProperty(DARDEN_EMPL_ID));
                    profile.put("samAccountName", userId);
                    profile.put("imageUrl", constructImageURL(userProfile.getGUID(),"LARGE"));
                    profile.put("firstName",userProfile.getProperty(FIRST_NAME));
                    profile.put("lastName",userProfile.getProperty(LAST_NAME));                
                    for (Map.Entry<String, String> entry : PROFILE_ATTRS_KEYS.entrySet()) {
                        String value = (String)userProfile.getProperty(entry.getKey());
                        if(null != value && !(value.trim().isEmpty())){
                            profile.put(entry.getValue(), value);              
                        }                
                    }
                    if(prefs){
                        List<String> samIds = new ArrayList<String>();
                        samIds.add(userId);
                        PreferencesAM am = getPreferencesAM();
                        Map<String,Object> masterPrefs = am.getMasterPrefs(app);
                        profile.put("prefs", masterPrefs);
                        Map<String,Map<String,Object>> usersPrefs = am.getUsersPrefs(samIds, app);
                        if(null != usersPrefs){
                            profile.put("prefs", usersPrefs.get(userId));
                        }                        
                    }
                    //save in cache.
                    CacheUtil.getInstance().put(userId,profile,CacheUtil.CacheType.PEOPLE_CACHE);
                }
                
                empIdProfiles = new HashMap<String,Map<String,Object>>();
                empIdProfiles.put(userId, profile);
                response = getProfileResponse(empIdProfiles, false);
                return response;                
            }
            
            if(emplId != null && !(emplId.trim().isEmpty())){
                emplIds = new ArrayList<String>();
                emplIds.add(emplId);
            }
        }
        
        //formatting for post call
        if(null != app && !(app.trim().isEmpty())){
            appNames.add(app);
        }        
        empIdProfiles = query(emplIds, prefs, appNames, cache);
        
        if(prefs){
            Map<String,Map<String,Object>> empIdProfilesNew = new HashMap<String,Map<String,Object>>();
            //transform prefs as required by KrowdApp
            for(Map.Entry<String,Map<String,Object>> empIdProfile: empIdProfiles.entrySet()){
                List<Map<String,Object>> soaPrefsList = (List<Map<String,Object>>) empIdProfile.getValue().get("prefs");
                Map<String,Object> appPrefs = transformPrefs(soaPrefsList, app);
                Map<String,Object> empIdProfileNew = new HashMap<String,Object>();
                empIdProfileNew.putAll(empIdProfile.getValue());
                empIdProfileNew.put("prefs",appPrefs);
                empIdProfilesNew.put(empIdProfile.getKey(),empIdProfileNew);
            }
            response = getProfileResponse(empIdProfilesNew, false);
        } else {
            response = getProfileResponse(empIdProfiles, false);
        }        
        return response;
    }
    
    private Map<String,Map<String,Object>> query(List<String> emplIds,boolean prefs,List<String> appNames,boolean cache) {
        Map<String,Map<String,Object>> empIdProfiles = null;
        Map<String,Map<String,Object>> cachedEmpIdProfiles = null;
        PreferencesAM am = null;       
        List<Map<String,Object>> appWiseMasterPrefsSOA = null;
        Map<String,Map<String,Object>> samIdProfiles = null;
        List<String> samIds = null;        
        List<String> noCachedEmpIds = null;
        
        if(null != emplIds && emplIds.size()>0){
            empIdProfiles = new HashMap<String,Map<String,Object>>();
            noCachedEmpIds = new ArrayList<String>();
            cachedEmpIdProfiles = new HashMap<String,Map<String,Object>>();
            //get from cache based on prefrenece needed or not, (or) fill error profiles
            logger.info("-----------------------------------------------Before Cache call");
            createCachedProfiles(emplIds, prefs, noCachedEmpIds, empIdProfiles, cachedEmpIdProfiles,cache);
            logger.info("------------------------------------------------After Cache call");
            //profiles not in cache
            if(null != noCachedEmpIds && (noCachedEmpIds.size() > 0)){
                if(prefs){
                    am = getPreferencesAM();
                    Map<String,Map<String,Map<String,Object>>> appWiseMasterPrefs = am.getMasterPrefs(appNames);
                    //transform as required by SOA    
                    appWiseMasterPrefsSOA = transformPrefs(appWiseMasterPrefs);
                    
                    samIdProfiles = new HashMap<String,Map<String,Object>>();
                    samIds = new ArrayList<String>();
                }
                //AD call
                logger.info("------------------------------------------------before AD call");
                List<Identity> identities = getIdentities(noCachedEmpIds);
                logger.info("------------------------------------------------After AD call");
                createProfiles(identities, empIdProfiles, samIdProfiles, samIds, appWiseMasterPrefsSOA);                
                //users preference db call
                if(prefs){
                    logger.info("------------------------------------------------before DB call");                    
                    Map<String,Map<String,Map<String,Map<String,Object>>>> appWiseUsersPrefs = null;                    
                    appWiseUsersPrefs = am.getUsersPrefs(samIds,appNames);
                    if(null != appWiseUsersPrefs && appWiseUsersPrefs.size() > 0 ){
                        for(Map.Entry<String,Map<String,Map<String,Map<String,Object>>>> appWiseUserPrefs : appWiseUsersPrefs.entrySet()){
                            Map<String,Object> profile = samIdProfiles.get(appWiseUserPrefs.getKey());
                            //transform as required by SOA
                            List<Map<String,Object>> soaPrefs = transformPrefs(appWiseUserPrefs.getValue());
                            profile.put("prefs", soaPrefs);
                        }
                    }
                    logger.info("------------------------------------------------after DB call");                    
                }                
                //fill the cache only for SOA
                Set<Map.Entry<String,Map<String,Object>>> empIdProfilesEntries = empIdProfiles.entrySet();
                for(Map.Entry<String,Map<String,Object>> empIdProfilesEntry : empIdProfilesEntries){
                    CacheUtil.getInstance().put(empIdProfilesEntry.getKey(),empIdProfilesEntry.getValue(), CacheUtil.CacheType.PEOPLE_CACHE);
                }

                //copy cached profiles to response
                empIdProfiles.putAll(cachedEmpIdProfiles);
            } else {
                //assign cached profiles to repsonse
                empIdProfiles = cachedEmpIdProfiles;
            } 
        } else {
            throw new BadRequestException("No Employee Id is provided");
        }
        return empIdProfiles;
    }
    
    private void createCachedProfiles(List<String> emplIds, boolean prefs, List<String> noCachedEmpIds, Map<String,Map<String,Object>> empIdProfiles, Map<String,Map<String,Object>> cachedEmpIdProfiles, boolean cache){
        Map<String,Object> errProfile = new HashMap<String,Object>();
        errProfile.put("error", Boolean.TRUE);
        errProfile.put("errorDetail", "Profile details are not available");
        for(String empId : emplIds){
            if(null != empId && !(empId.trim().isEmpty())){
                Map<String,Object> cachedProfile = null;
                if(cache){
                    cachedProfile = (Map<String,Object>)CacheUtil.getInstance().get(empId,CacheUtil.CacheType.PEOPLE_CACHE);
                }
                if(null != cachedProfile && cachedProfile.size() > 0){
                    if(prefs){
                        if(null != cachedProfile.get("prefs")){
                            cachedEmpIdProfiles.put(empId, cachedProfile);
                        } else {
                            noCachedEmpIds.add(empId);
                            empIdProfiles.put(empId, errProfile);
                        }
                    } else {
                        if(null != cachedProfile.get("prefs")){
                            Map<String,Object> noPrefProfile = new HashMap<String,Object>();
                            noPrefProfile.putAll(cachedProfile);
                            noPrefProfile.remove("prefs");
                            cachedEmpIdProfiles.put(empId, noPrefProfile);
                        } else {
                            cachedEmpIdProfiles.put(empId, cachedProfile);
                        }                            
                    }
                } else {
                    noCachedEmpIds.add(empId);
                    empIdProfiles.put(empId, errProfile);
                }
            }
        }
    }
    
    private List<Identity> getIdentities(List<String> noCachedEmpIds) {
        HashMap<String[],List<String[]>> queryParams = new HashMap<String[],List<String[]>>();
        List<String[]> queryParamVals;
        queryParamVals = getQueryParamVals("_eq_",noCachedEmpIds);
        if(queryParamVals !=null){
            queryParams.put(new String[]{ "Darden-Empl-ID" }, queryParamVals);
        }
        try{
            LdapHelper ldapHelper = LdapHelper.getInstance();                
            ldapHelper.setCountLimit(LDAP_PROFILE_COUNT_LIMIT);
            ldapHelper.setPageLimit(LDAP_PAGE_LIMIT);
            ldapHelper.setUserSearchBase(USER_SEARCH_BASES);
            List<Identity> identities = ldapHelper.getIdentitiesWithComplexAttributes(queryParams, ComplexSearchFilter.TYPE_OR);                               
            ldapHelper.resetUserSearchBase();
            return identities;
        }
        catch (Exception e){
            logger.severe(e);
            LdapHelper ldapHelper;
            try {
                ldapHelper = LdapHelper.getInstance();
                ldapHelper.resetUserSearchBase();
            } catch (Exception f) {
                logger.severe(f);
            }                
            throw new BadRequestException(e);
        }
    }
        
    private void createProfiles(List<Identity> identities, Map<String,Map<String,Object>> empIdProfiles, Map<String,Map<String,Object>> samIdProfiles , List<String> samIds, List<Map<String,Object>> appWiseMasterPrefs) {
        Map<String,Object> profile = null;
        boolean prefs = false;
        
        if(null != identities && identities.size() > 0) {           
            if((null != appWiseMasterPrefs && appWiseMasterPrefs.size() > 0)){
                prefs = true;
            }
            Map<String,String> displayNameMap = new HashMap<String,String>();

            try {
                displayNameMap = getPSDisplayNames(identities);
            } catch (SQLException e) {
                logger.warning(e);
            }
            logger.info("---- Display Name Map size---"+displayNameMap.size());
            for(Identity identity : identities){
                try{
                    User userIdentity = (User)identity;
                    profile = new HashMap<String, Object>();
                    UserProfile userProfile = userIdentity.getUserProfile();
                    profile.put("employeeId", userProfile.getPropertyVal(DARDEN_EMPL_ID));
                    profile.put("samAccountName", userIdentity.getPrincipal().getName());
                    profile.put("imageUrl", constructImageURL(userIdentity.getGUID(),"LARGE"));
                    profile.put("firstName",userProfile.getPropertyVal(FIRST_NAME));
                    profile.put("lastName",userProfile.getPropertyVal(LAST_NAME));   
                    for (Map.Entry<String, String> entry : PROFILE_ATTRS_KEYS.entrySet()) {
                        String value = (String)userProfile.getPropertyVal(entry.getKey());
                        if(null != value && !(value.trim().isEmpty())){
                            profile.put(entry.getValue(), value);              
                        }                
                    }
                    //Add NickName from PeopleSoft and override displayName
                    String employeeId = (String)userProfile.getPropertyVal(DARDEN_EMPL_ID);
                    profile.put("displayName", displayNameMap.get(employeeId));
                    
                    if(prefs){
                        profile.put("prefs", appWiseMasterPrefs);                                               
                        samIdProfiles.put(userIdentity.getPrincipal().getName(), profile);
                        samIds.add(userIdentity.getPrincipal().getName());
                    }                    
                    empIdProfiles.put((String)userProfile.getPropertyVal(DARDEN_EMPL_ID), profile);                    
                }
                catch(Exception e){
                    logger.severe(e);
                }                              
            }
        }        
    }
    
    private Map<String,String> getPSDisplayNames(List<Identity> identities)throws SQLException{
        Map<String,String> displayNames = new HashMap<String,String>();
        PreparedStatement stmt = null;
        java.sql.Connection conn = null;
        try{
            conn = getConnection(KROWD_DATASOURCE_JNDI);
            if(null != conn){
                StringBuilder builder = new StringBuilder();
                for( int i = 0 ; i < identities.size(); i++ ) {
                    builder.append("?,");
                }
                
                String employeeQuery = "select EMPLOYEE_ID, FIRST_NAME, LAST_NAME, NICK_NAME from KROWD_PS.PS_EMPLOYEE_DATA where EMPLOYEE_ID in (" + builder.deleteCharAt( builder.length() -1 ).toString() + ")";
                stmt = conn.prepareStatement(employeeQuery);
                
                int index = 1;
                for( Identity identity : identities ) {
                    User userIdentity = (User)identity;
                    UserProfile userProfile = userIdentity.getUserProfile();
                    String employeeId = userProfile.getPropertyVal(DARDEN_EMPL_ID)+"";
                    stmt.setString(index++, employeeId);
                }                
                ResultSet rs = stmt.executeQuery();                
                while(rs.next()){
                    String employeeId = rs.getString("EMPLOYEE_ID");
                    String firstName = rs.getString("FIRST_NAME");
                    String lastName = rs.getString("LAST_NAME");
                    String nickName = rs.getString("NICK_NAME");
                    firstName = firstName == null ? "" : firstName.trim();
                    lastName = lastName == null ? "" : lastName.trim();
                    nickName = nickName == null ? "" : nickName.trim();
                    if(nickName.length() > 0){
                        displayNames.put(employeeId,nickName + " " + lastName);
                    } else {
                        displayNames.put(employeeId,firstName + " " + lastName);
                    }
                }            
                rs.close() ;
                stmt.close() ;
            }            
        } catch (Exception e) {
            logger.severe(e);
            throw new BadRequestException(e);
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
        return displayNames;
    }
    
    private Response getProfileResponse(Map<String,Map<String,Object>> empIdProfiles, boolean isPost){        
        if(empIdProfiles.size() > 0 ){
            if(1 == empIdProfiles.size()){
                Map<String,Object> ret = empIdProfiles.values().iterator().next();
                if(ret.containsKey("error")){
                    if(isPost){
                        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
                    } else {
                        return Response.status(404).type(MediaType.APPLICATION_JSON).build();
                    }                    
                }
                if(isPost){
                    Map<String,Collection> ret1 = new HashMap<String,Collection>();
                    ret1.put("employees", empIdProfiles.values());
                    return Response.ok(ret1).type(MediaType.APPLICATION_JSON).build();
                } else {
                    return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
                }                
            } else {
                if(isPost){
                    Map<String,Collection> ret = new HashMap<String,Collection>();
                    ret.put("employees", empIdProfiles.values());
                    return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
                } else {
                    return Response.ok(empIdProfiles).type(MediaType.APPLICATION_JSON).build();
                }
            }
            
        } else {
            return Response.status(404).type(MediaType.APPLICATION_JSON).build();
        }   
    }
    
    public String constructImageURL(String guid, String size) {
        String imageURL = null;
        if(guid != null && guid.length() != 0){
            String userHex = ProfileInternalUtils.asciiToHex(guid);
            imageURL   =  userHex + "/"+size;
        }
        return imageURL;
    }
    
    
    @POST
    @Path("/query")
    @Produces("application/json")
    public Response queryPost(Map<String,Object> payload,@DefaultValue("true") @QueryParam("cache") boolean cache){
        List<String> emplIds = null;
        List<String> appNames = null;
        boolean prefs = false;
        emplIds = extractParams(payload, "ids", "id");
        appNames = extractParams(payload, "prefs", "app");
        if(null !=appNames && appNames.size()>0){
            prefs = true;
        }
        Map<String,Map<String,Object>> empIdProfiles = query(emplIds, prefs, appNames, cache);
        Response response = getProfileResponse(empIdProfiles, true);
        return response;
    }
    
    private List<Map<String,Object>> transformPrefs(Map<String,Map<String,Map<String,Object>>> appWisePrefs){
        List<Map<String,Object>> soaAppWisePrefs = new ArrayList<Map<String,Object>>();
        if(null != appWisePrefs && appWisePrefs.size()>0){
            for(Map.Entry<String,Map<String,Map<String,Object>>> appWisePref : appWisePrefs.entrySet()){
                Map<String,Object> soaAppWisePref = new HashMap<String,Object>();
                soaAppWisePref.put("appId", appWisePref.getKey());                            
                List<Map<String,Object>> soaPrefs = new ArrayList<Map<String,Object>>();
                for(Map.Entry<String,Map<String,Object>> pref : appWisePref.getValue().entrySet()){
                    soaPrefs.add(pref.getValue());
                }
                soaAppWisePref.put("prefs", soaPrefs);
                soaAppWisePrefs.add(soaAppWisePref);
            }   
        }        
        return soaAppWisePrefs;
    }
    
    private Map<String,Object> transformPrefs(List<Map<String,Object>> soaPrefsList, String appName){
        Map<String,Object> prefs = new HashMap<String, Object>();
        for(Map<String,Object> soaPrefs: soaPrefsList){
            String appId  = (String)soaPrefs.get("appId");
            if(appName.equalsIgnoreCase(appId)){
                List<Map<String,Object>> prefsObjs = (List<Map<String,Object>>) soaPrefs.get("prefs");
                for(Map<String,Object> prefObj: prefsObjs){
                    prefs.put((String)prefObj.get("prefType"), prefObj.get("prefValue"));
                }
                break;
            }            
        }
        return prefs;
    }
    
    private List<String> extractParams(Map<String,Object> payload, String type, String subType){
        List<String> paramsValues = null;
        if(null != payload && payload.size() > 0){
            Object paramsPayload = payload.get(type);
            if(null != paramsPayload && ((List)paramsPayload).size() > 0 ){
                paramsValues = new ArrayList<String>();
                for(Map<String,String> li : (List<Map<String,String>>) paramsPayload){
                    if(null != li && li.size()>0){
                        paramsValues.add(li.get(subType).trim());
                    }                    
                }
            }
        }
        return paramsValues;
    }

     
     @GET
     @Path("/logout")
     public Response logoutGet(@Context HttpServletRequest req, @Context HttpServletResponse res,@DefaultValue("false") @QueryParam("NoCookie") boolean NoCookie){
         if(NoCookie){
             return Response.ok(true).type(MediaType.APPLICATION_JSON).build();
         } else {
             return logout(req, res);
         }
     }
     
     
     private Response logout (HttpServletRequest req, HttpServletResponse res){
         boolean status = false;
         String cookies = KrowdUtility.getInstance().getProperties().getProperty("LOGOUT_COOKIES");
         if(null != req){             
             cookies=cookies.replace("\r","").replace("\n","");
             String[] customCookies = cookies.split("##");
             logger.info("Custom Cookies size:"+customCookies.length);
             for (String cookie : customCookies) {
                 //res.addHeader("Set-Cookie", cookie);//commented
                 //subh, CWE ID: 113- Improper Neutralization of CRLF Sequences in HTTP Headers ('HTTP Response Splitting') 
                 ESAPI.httpUtilities().setCurrentHTTP(req,res);
                 ESAPI.httpUtilities().addHeader(res,"Set-Cookie",cookie);
                 //
                 logger.info("Custom cookie is set:"+cookie);
             }
             status = true;
         }
         return Response.ok(status).type(MediaType.APPLICATION_JSON).build();
     }
     
     private void printCookieDetails(Cookie cookie){
         logger.info(cookie.getName()+"###"+cookie.getComment()+"###"+cookie.getDomain()+"###"+cookie.getMaxAge()+"###"+cookie.getPath()+"###"+cookie.getSecure()+"###"+cookie.getVersion()+"###"+cookie.getValue());
     }
    
    /* start - Ops Anncs code */
    
    private static String OPS_ANNCS_QUERY = "SELECT fldTitle,fldText,fldEffectiveDate,fldUserName\n" + 
        "FROM tbl_Content\n" + 
        "WHERE\n" + 
        "fldCompany= ? AND \n" + 
        "(fldRestaurant = ?\n" + 
        "OR (fldRegion = ? AND fldRestaurant='')\n" + 
        "OR (fldDivision = ? AND fldRegion='' AND fldRestaurant='')\n" + 
        "OR (fldRegion='' AND fldDivision='' AND fldRestaurant='')\n" + 
        ")\n" + 
        "AND (fldDestination = 'R')\n" + 
        "AND (fldEffectiveDate <= GetDATE())\n" + 
        "AND (fldExpirationDate >= DATEADD(day,-1,GetDATE()))\n" + 
        "ORDER BY fldEffectiveDate DESC";
    private static final String OPS_ANNC_DATASOURCE_JNDI = "jdbc/DishDBDS"; 
    
    @GET
    @Path("/opsanncs")
    public Response opsAnncs(){
        List<Map<String,String>> anncs = null;
        oracle.adf.share.security.identitymanagement.UserProfile profile = ADFContext.getCurrent().getSecurityContext().getUserProfile();  
        String pCompany = (String)profile.getProperty("company");
        String pRestaurant =(String)profile.getProperty("physicalDeliveryOfficeName");
        String pRegion = (String)profile.getProperty("Darden-Rsegion");
        String pDivision = (String)profile.getProperty("division");
        try {
             anncs = getAnnouncementsIntern(pCompany, pRestaurant, pRegion, pDivision);                            
        } catch (Exception e){
            logger.severe(e);
            throw new BadRequestException(e);
        }        
        return Response.ok(anncs).type(MediaType.APPLICATION_JSON).build();
    }
    
    private List<Map<String,String>> getAnnouncementsIntern(String pCompany,String pRestaurant,String pRegion,String pDivision) throws SQLException {
        PreparedStatement stmt = null;
        java.sql.Connection conn = null;
        List<Map<String,String>> annoucments = new ArrayList<Map<String,String>>();           
        try{
            conn = getConnection(OPS_ANNC_DATASOURCE_JNDI);
            if(null != conn){
                stmt = conn.prepareStatement(OPS_ANNCS_QUERY);
                stmt.setString(1, pCompany);
                stmt.setString(2, pRestaurant);
                stmt.setString(3, pRegion);
                stmt.setString(4, pDivision);                
                ResultSet rs = stmt.executeQuery();                
                while(rs.next()){
                    Map annc = new HashMap<String,String>();
                    annc.put("title", rs.getString("fldTitle"));
                    annc.put("desc", rs.getString("fldText"));
                    annc.put("date", convertDate(rs.getString("fldEffectiveDate")));
                    annc.put("author", rs.getString("fldUserName"));
                    annoucments.add(annc);
                }            
                rs.close() ;
                stmt.close() ;
            }            
        } catch (Exception e) {
                logger.severe(e);
                throw new BadRequestException(e);
            } finally {
                if (conn != null) {
                    conn.close();
                }
            }
        return annoucments;
    }

    private java.sql.Connection getConnection(String dataSourceJndi) {
        java.sql.Connection con = null;
        try {
            javax.naming.Context initialContext = new InitialContext();
            if (initialContext == null) {
                logger.info("JNDI problem. Cannot get InitialContext.");
            }
            DataSource datasource =
                (DataSource)initialContext.lookup(dataSourceJndi);
            if (datasource != null) {
                con = datasource.getConnection();
            } else {
                logger.info("Failed to lookup datasource.");
            }
        } catch (Exception ex) {
            logger.severe(ex);
            throw new BadRequestException(ex);
        }
        return con;
    }

    private static String convertDate(String dateReceivedFromDB) {
        String splitDate[] = dateReceivedFromDB.split("[\\W]");
        if (splitDate.length >= 3) {
            String convertToDate =
                splitDate[1] + "-" + splitDate[2] + "-" + splitDate[0];
            return convertToDate;
        } else {
            return dateReceivedFromDB;
        }
    }  
        /* end - Ops Anncs code */
    
    @GET
    @Path("/invalidateStringsCache") 
    public Response invalidateCache(@QueryParam("key") List<String> keys){
        /* This resource can be used to clear stringCache entirely or any keys or keys list */
        String[] userRoles = ADFContext.getCurrent().getSecurityContext().getUserRoles();
        boolean isAdminUser = isAdmin(userRoles) ;        

        if(isAdminUser){
            CacheUtil.getInstance().invalidate(CacheUtil.CacheType.PEOPLE_CACHE);
            return Response.status(200).entity("Caches flushed...").build();
        }else{
            throw new BadRequestException("Available only for Admins.");
        }
    }
    
    private String getStoreRedirect(HttpServletRequest request, HttpServletResponse response ){
        String redirectURL = null;
        Cookie[] persistentCookies = request.getCookies();
        if(persistentCookies != null){
            for (int iCount = 0; iCount < persistentCookies.length; iCount++) {
                if ((persistentCookies[iCount].getName().equalsIgnoreCase("storeURL"))) {
                    //checkRedirect = true;
                    redirectURL = persistentCookies[iCount].getValue();
                    persistentCookies[iCount].setDomain(".darden.com");
                    persistentCookies[iCount].setPath("/");
                    persistentCookies[iCount].setMaxAge(0);                            
                    //response.addCookie(persistentCookies[iCount]);//commented
                    //subh,CWE ID: 113- Improper Neutralization of CRLF Sequences in HTTP Headers ('HTTP Response Splitting') 
                    ESAPI.httpUtilities().setCurrentHTTP(request, response);
                    ESAPI.httpUtilities().addCookie(response, persistentCookies[iCount]);
                    //
                    break;
                }
            }
        }
        return redirectURL;
    }        

    @POST
    @Path("/applauncher/create") 
    @Produces(MediaType.APPLICATION_JSON)
    public Response createAppLauncherId(HashMap<String,String> params){
        Cookie[] cookies = httpRequest.getCookies();
        List<Map<String,String>> cookiesList = new ArrayList<Map<String,String>>();
        Map<String,String> cookieMap;
        String cookieName;
        for(Cookie cookie : cookies){
            cookieName = cookie.getName();
            cookieMap = new HashMap<String,String>();
            cookieMap.put("NAME",cookieName);
            cookieMap.put("VALUE",cookie.getValue());
            if(cookieName.toUpperCase().indexOf("SESSIONID") >= 0){
                cookieMap.put("SECURE","TRUE");
            }else{
                cookieMap.put("SECURE","FALSE");
            }
            cookiesList.add(cookieMap);
        }
        Date now = new Date();
        Map<String,Object> launcher = new HashMap<String,Object>();
        launcher.put("URL",params.get("url"));
        launcher.put("TIMESTAMP",now);
        launcher.put("COOKIES",cookiesList);
        
        UUID uuid = UUID.randomUUID();
        String uuidStr = uuid.toString();
        CacheUtil.getInstance().put(uuidStr,launcher,CacheUtil.CacheType.PEOPLE_CACHE);
        // putInCache(uuidStr,launcher);
        
        Map<String,Object> res = new HashMap<String,Object>();
        res.put("launchToken", uuidStr);
        res.put("expiry",new Date(now.getTime() + 10000));
        res.put("url",params.get("url"));
        return Response.status(Response.Status.OK).entity(res).build();
    }    

    @GET
    @Path("/applauncher/launch/{id}") 
    public Response launchApp(@PathParam("id") String id){
        Map<String,Object> launcObj =  (Map<String,Object>) CacheUtil.getInstance().get(id,CacheUtil.CacheType.PEOPLE_CACHE);
        
        if(launcObj == null){
            return Response.status(Response.Status.BAD_REQUEST).build();
        }
        CacheUtil.getInstance().remove(id, CacheUtil.CacheType.PEOPLE_CACHE);
        Date createdDate = (Date)launcObj.get("TIMESTAMP");
        Date now = new Date();
        if(now.getTime() - createdDate.getTime() <= 10000){
            List<Map<String,String>> cookieList = (List<Map<String, String>>)launcObj.get("COOKIES");
            Map<String,String> cookieMap;
            if(cookieList != null && cookieList.size() >0){
                for(int i=0; i<cookieList.size(); i++){
                    cookieMap = cookieList.get(i);
                    Cookie smcookie = new Cookie(cookieMap.get("NAME"),cookieMap.get("VALUE"));
                    smcookie.setPath("/");
                    if(cookieMap.get("SECURE").compareTo("TRUE") == 0){
                        smcookie.setSecure(true);
                        smcookie.setDomain(httpRequest.getServerName());
                    }else{
                        smcookie.setDomain(".darden.com");
                        smcookie.setSecure(false);
                    }
                    httpResponse.addCookie(smcookie);                
                }
                URI uri;
                try {
                    uri = new URI((String)launcObj.get("URL"));
                    return Response.temporaryRedirect(uri).build();
                } catch (URISyntaxException e) {
                    logger.severe(e);
                    return Response.status(Response.Status.BAD_REQUEST).build();
                }            
            }else{
                return Response.status(Response.Status.BAD_REQUEST).build();
            }            
        }else{
            return Response.status(Response.Status.BAD_REQUEST).build();
        }
    }    
    
    private MapList getRows(ViewObject vo, PaginationParams pagination,boolean expandRs){
        MapList ret = new MapList(null,pagination.getStartIndexValue(),-1);
        if(vo != null && pagination != null){
            RowSetIterator rwsetItr = vo.createRowSetIterator(null);
            try{
                rwsetItr.setIterMode(RowIterator.ITER_MODE_LAST_PAGE_PARTIAL);
                rwsetItr.setRangeSize(pagination.getItemsPerPageValue());
                
                int startIndexValue = pagination.getStartIndexValue();
                startIndexValue = startIndexValue>0?startIndexValue-1:startIndexValue;
                rwsetItr.setRangeStart(startIndexValue);        
                Row[] rows  = rwsetItr.getAllRowsInRange();
                
                List<Map<String,Object>> result = new ArrayList<Map<String,Object>>();
                for (Row row : rows) {
                    result.add(toMap(row,expandRs));
                }
                ret = new MapList(result,pagination.getStartIndexValue(),-1);                
            }catch(Exception e){
                logger.severe(e);
            }
            rwsetItr.closeRowSetIterator();
        }            
        return ret;
    }
    
    @GET
    @Path("/app/builds")
    public Response getAppBuilds(@DefaultValue("0") @QueryParam("startIndex") StartIndexParam _startIndex, @DefaultValue("10") @QueryParam("itemsPerPage") ItemsPerPageParam _itemsPerPage){
        UserProfileAM am =  getUserProfileAM();
        PaginationParams pagination = new PaginationParams(_startIndex, _itemsPerPage);
        ViewObject buildVO = am.findViewObject("AppBuildVO1");
        MapList ret = getRows(buildVO, pagination,false);
        return Response.ok(ret).build();         
    }    

    @POST
    @Path("/app/builds")
    public Response createAppBuild(HashMap<String,Object> appBuild){
        
        String[] userRoles = ADFContext.getCurrent().getSecurityContext().getUserRoles();
        boolean isAdminUser = isAdmin(userRoles) ;        
        if(!isAdminUser){
            return Response.status(Response.Status.UNAUTHORIZED).build();
        }
        
        UserProfileAM am =  getUserProfileAM();
        
        if(appBuild != null){
            String iosIdentifier = (String)appBuild.get("IosIdentifier");
            String androidIdentifier = (String)appBuild.get("AndroidIdentifier");
            String updateMode = (String)appBuild.get("UpdateMode");
            String type = (String)appBuild.get("Type");            
            String release = (String)appBuild.get("Release");            
            String url = (String)appBuild.get("Url");            
            String build = (String)appBuild.get("Build");            
            String appName = (String)appBuild.get("AppName");            
            String version = (String)appBuild.get("Version");            
            
            am.createAppBuild(appName==null?"KrowD":appName,
                              iosIdentifier==null?"com.darden.krowd.mobile":iosIdentifier,
                              androidIdentifier==null?"com.darden.krowd.mobile":androidIdentifier,
                              version,build,release,type,url,updateMode==null?"resume":updateMode);
            ViewObject vo = am.findViewObject("AppBuildVO1");
            Row row = vo.getCurrentRow();
            return Response.ok(toMap(row,false)).build();         
            
        }else{
         throw new BadRequestException("Build Target is mandatory.");   
        }        
    }   
    
    @PUT
    @Path("/app/build/{id}")
    public Response updateAppBuild(@PathParam("id") int id,HashMap<String,Object> appBuild){
        
        String[] userRoles = ADFContext.getCurrent().getSecurityContext().getUserRoles();
        boolean isAdminUser = isAdmin(userRoles) ;        
        if(!isAdminUser){
            return Response.status(Response.Status.UNAUTHORIZED).build();
        }
        
        UserProfileAM am =  getUserProfileAM();
        ViewObject buildVO = am.findViewObject("AppBuildVO1");
        Row[] rows = buildVO.findByKey(new Key(new Object[]{id}),1);
        if(rows != null && rows.length >0){
            Row row = rows[0];
            
            if(appBuild != null){
                String type = (String)appBuild.get("Type");            
                String release = (String)appBuild.get("Release");            
                String url = (String)appBuild.get("Url");            
                String build = (String)appBuild.get("Build");            
                String version = (String)appBuild.get("Version");       
                
                row.setAttribute("Type",type);
                row.setAttribute("Release",release);
                row.setAttribute("Url",url);
                row.setAttribute("Build",build);
                row.setAttribute("Version",version);
                
                am.commit();
                
                return Response.ok(toMap(row,false)).build();                         
            }else{
             throw new BadRequestException("Build Target is mandatory.");   
            }                    
        }else{
            return Response.status(Response.Status.NOT_FOUND).build();
        }
    }    
    
    
    @GET
    @Path("/app/build/{id}")
    public Response getAppBuild(@PathParam("id") int id){
        UserProfileAM am =  getUserProfileAM();
        ViewObject buildVO = am.findViewObject("AppBuildVO1");
        Row[] rows = buildVO.findByKey(new Key(new Object[]{id}),1);
        if(rows != null && rows.length >0){
            Row row = rows[0];
            Map map = toMap(row,false);
            return Response.ok(map).build();                     
        }else{
            return Response.status(Response.Status.NOT_FOUND).build();
        }
    }    

    @DELETE
    @Path("/app/build/{id}")
    public Response deleteAppBuild(@PathParam("id") int id){
        
        String[] userRoles = ADFContext.getCurrent().getSecurityContext().getUserRoles();
        boolean isAdminUser = isAdmin(userRoles) ;        
        if(!isAdminUser){
            return Response.status(Response.Status.UNAUTHORIZED).build();
        }
        
        UserProfileAM am =  getUserProfileAM();
        ViewObject buildVO = am.findViewObject("AppBuildVO1");
        Row[] rows = buildVO.findByKey(new Key(new Object[]{id}),1);
        if(rows != null && rows.length >0){
            Row row = rows[0];
            row.remove();
            am.commit();
            return Response.ok().build();                     
        }else{
            return Response.status(Response.Status.NOT_FOUND).build();
        }
    }    
    
    @GET
    @Path("/app/buildTargets")
    public Response getAppBuildTargets(@DefaultValue("0") @QueryParam("startIndex") StartIndexParam _startIndex, @DefaultValue("10") @QueryParam("itemsPerPage") ItemsPerPageParam _itemsPerPage){
        UserProfileAM am =  getUserProfileAM();
        PaginationParams pagination = new PaginationParams(_startIndex, _itemsPerPage);
        ViewObject buildVO = am.findViewObject("AppBuildTargetVO");
        MapList ret = getRows(buildVO, pagination,true);
        return Response.ok(ret).build();         
    }   
    
    @POST
    @Path("/app/buildTargets")
    public Response createAppBuildTarget(HashMap<String,Object> buildTarget){

        String[] userRoles = ADFContext.getCurrent().getSecurityContext().getUserRoles();
        boolean isAdminUser = isAdmin(userRoles) ;        
        if(!isAdminUser){
            return Response.status(Response.Status.UNAUTHORIZED).build();
        }

        UserProfileAM am =  getUserProfileAM();
        
        if(buildTarget != null){
            String physicalDeliveryOffice = (String)buildTarget.get("PhysicalDeliveryOffice");
            String area = (String)buildTarget.get("Area");
            String release = (String)buildTarget.get("Release");
            String jobFunction = (String)buildTarget.get("JobFunction");            
            String region = (String)buildTarget.get("Region");            
            String managerLevel = (String)buildTarget.get("ManagerLevel");            
            String businessUnit = (String)buildTarget.get("BusinessUnit");            
            String isActive = (String)buildTarget.get("IsActive");            
            String build = (String)buildTarget.get("Build");            
            String userName = (String)buildTarget.get("Username");            
            String jobSubFunction = (String)buildTarget.get("JobSubFunction"); 
            String version = (String)buildTarget.get("Version"); 
            String company = (String)buildTarget.get("Company"); 
            Object _appBuildId = buildTarget.get("AppBuildId"); 
            
            oracle.jbo.domain.Number appBuildId;
            boolean active = isActive == null?false:(isActive.compareToIgnoreCase("Y")==0?true:false);
            try {
                appBuildId = new Number(_appBuildId);
                am.createAppBuildTarget(userName,physicalDeliveryOffice,region,businessUnit,company,managerLevel,jobFunction,jobSubFunction,area,active,version,build,release,appBuildId);            
                ViewObject vo = am.findViewObject("AppBuildTargetVO");
                Row row = vo.getCurrentRow();
                return Response.ok(toMap(row,true)).build();         
            } catch (SQLException e) {
                throw new BadRequestException(e);
            }
        }else{
            throw new BadRequestException("Build Target is mandatory");
        }        
    }   
    
    @GET
    @Path("/app/buildTarget/{id}")
    public Response getAppBuildTarget(@PathParam("id") int id){
        UserProfileAM am =  getUserProfileAM();
        ViewObject buildVO = am.findViewObject("AppBuildTargetVO");
        Row[] rows = buildVO.findByKey(new Key(new Object[]{id}),1);
        if(rows != null && rows.length >0){
            Row row = rows[0];
            Map map = toMap(row,false);
            return Response.ok(map).build();                     
        }else{
            return Response.status(Response.Status.NOT_FOUND).build();
        }        
    }

    @PUT
    @Path("/app/buildTarget/{id}")
    public Response updateAppBuildTarget(@PathParam("id")
        int id, HashMap<String, Object> buildTarget) {
        String[] userRoles = ADFContext.getCurrent().getSecurityContext().getUserRoles();
        boolean isAdminUser = isAdmin(userRoles) ;
        if(!isAdminUser){
            return Response.status(Response.Status.UNAUTHORIZED).build();
        }
        
        UserProfileAM am = getUserProfileAM();
        ViewObject buildVO = am.findViewObject("AppBuildTargetVO");
        Row[] rows = buildVO.findByKey(new Key(new Object[] { id }), 1);
        if (rows != null && rows.length > 0) {
            Row row = rows[0];

            if (buildTarget != null) {
                String physicalDeliveryOffice =
                    (String)buildTarget.get("PhysicalDeliveryOffice");
                String area = (String)buildTarget.get("Area");
                String release = (String)buildTarget.get("Release");
                String jobFunction = (String)buildTarget.get("JobFunction");
                String region = (String)buildTarget.get("Region");
                String managerLevel = (String)buildTarget.get("ManagerLevel");
                String businessUnit = (String)buildTarget.get("BusinessUnit");
                String isActive = (String)buildTarget.get("IsActive");
                String build = (String)buildTarget.get("Build");
                String userName = (String)buildTarget.get("Username");
                String jobSubFunction =
                    (String)buildTarget.get("JobSubFunction");
                String version = (String)buildTarget.get("Version");
                String company = (String)buildTarget.get("Company");
                Object _appBuildId = buildTarget.get("AppBuildId");

                oracle.jbo.domain.Number appBuildId;
                try {
                    appBuildId = new Number(_appBuildId);
                    row.setAttribute("PhysicalDeliveryOffice",
                                     physicalDeliveryOffice);
                    row.setAttribute("Area", area);
                    row.setAttribute("Release", release);
                    row.setAttribute("JobFunction", jobFunction);
                    row.setAttribute("Region", region);
                    row.setAttribute("ManagerLevel", managerLevel);
                    row.setAttribute("BusinessUnit", businessUnit);
                    row.setAttribute("IsActive", isActive == null?"N":(isActive.compareToIgnoreCase("Y")==0?"Y":"N"));
                    row.setAttribute("Build", build);
                    row.setAttribute("Username", userName);
                    row.setAttribute("JobSubFunction", jobSubFunction);
                    row.setAttribute("Version", version);
                    row.setAttribute("Company", company);
                    row.setAttribute("AppBuildId", appBuildId);
                    am.commit();
                    return Response.ok(toMap(row, true)).build();
                } catch (SQLException e) {
                    throw new BadRequestException(e);
                }
            } else {
                throw new BadRequestException("Build Target is mandatory");
            }
        }else{
            return Response.status(Response.Status.NOT_FOUND).build();
        }
    }
    
    @GET
    @Path("/invalidateProfileCache") 
    public Response invalidateProfileCache(@QueryParam("userId") String userId, @QueryParam("emplId") String emplId){
        /* this resource is used to clear profile cache where key in emplId.
         * Preference is userId than emplId
         * Default logged in user cache will be cleared*/
        if (userId == null || StringUtils.isBlank(userId)) {
            userId = ADFContext.getCurrent().getSecurityContext().getUserName();
        } else {
            userId = userId.trim();
            User user;
            try {
                user = LdapHelper.getInstance().getUser(userId);
                emplId = (String)user.getUserProfile().getPropertyVal(DARDEN_EMPL_ID);
            } catch (Exception e) {
                logger.severe(e);
            }            
        }
        
        if (emplId == null || StringUtils.isBlank(emplId)) {
            emplId = (String)ADFContext.getCurrent().getSecurityContext().getUserProfile().getProperty(DARDEN_EMPL_ID);
            //users will no empl id
            if(StringUtils.isBlank(emplId)){
                emplId = userId;
            }
        } else {
            emplId = emplId.trim();
        }
        
        if(null !=emplId && StringUtils.isNotEmpty(emplId)){
            CacheUtil.getInstance().remove(emplId,CacheUtil.CacheType.PEOPLE_CACHE);
            return Response.ok("{\"message\": \"success\"}").type(MediaType.APPLICATION_JSON).build();                    
        } else {                
            return Response.status(404).type(MediaType.APPLICATION_JSON).build();
        }
    }
    
    @PUT
    @Path("/changePassword")
    public Response changePassword(@QueryParam("userId") String userId,HashMap<String,String> userInfo){
        String distinguishedName = null;        
        SecurityContext securityContext = ADFContext.getCurrent().getSecurityContext();
        User user;
        String currentUser = securityContext.getUserName();
        
        if (userId == null || StringUtils.isBlank(userId)) {  
            userId = currentUser;
        }
        
        userId = userId.trim();
        try {
            user = LdapHelper.getInstance().getUser(userId);  
            distinguishedName = user.getUniqueName();
            if(distinguishedName != null){
                if(currentUser.compareToIgnoreCase(userId) != 0){
                    String[] userRoles = securityContext.getUserRoles();
                    boolean isAdminUser = isAdmin(userRoles) ;
                    if(!isAdminUser){
                        return Response.status(Response.Status.UNAUTHORIZED).build();
                    }                      
                }
                
                String oldPassword = userInfo.get("oldPassword");
                String newPassword = userInfo.get("newPassword");
                if(oldPassword != null && newPassword != null){
                    try {
                        logger.info("------ Changing Password for ---"+distinguishedName);                        
                        LdapHelper.changePassword(LdapHelper.getLDAPContext(),distinguishedName,oldPassword,newPassword);
                        return Response.status(Response.Status.OK).build();
                    } catch (Exception e) {
                        logger.severe(e);
                        throw new BadRequestException(e);
                    }                
                }else{
                    throw new BadRequestException("oldPassword & newPassword atributes are mandatory.");
                }                  
            } else{
                throw new BadRequestException("Unable to query the DistinguishedName for the User.");
            }         
        } catch (Exception e) {
            logger.severe(e);
            throw new BadRequestException(e);
        }        
    }
    private static final String PLACEHOLDER_MEDIUM = "iVBORw0KGgoAAAANSUhEUgAAAEsAAABuCAAAAABKRLGzAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAbJJREFUaN7t2A1ugkAQhuHe/zieYyCoFJVoV7TEf0ELVbFsa9M0aQzufoMUmnTfAzyJCTs760Oruh5a71VlLGMZy1h/yJLp9rt0m99jyVWXfuRMjqWtxKXr/F0pK59QUf6BbyVdKs4Kc54lQ4tu1suask49UuXmDEuQujFunSyNZR1gKyBdogkrt7WWlYFWTPrmoBUAlotZ0gEsSiu0BGQJgoKsQf1WiFgjzFohVoBZArHCCq0FaEnAmmEWbWu2pqC1BKwn0NoAlg9aMWB5oPVSs9UGrVfAskDrDFgORrWRMzSscOYk2I881m1hg2IA7gBRR29F6M6UaaDheIPvhQ7zWNdlab6xhGOtmMdHZZ2VK5jNeysoL9xHnpUoP4nmLOWGEjCtZ4U1YlqqG9eVPGvB25dqs9bKWZ+xrEj97hAnhrXTjDB7zXhva59EKWyNtVO634Q1K7GA3bA2yLVmX/1TUWyB1y05S6mzUnA9+Tyau7qsbO4Rp0F2wzov+8Stsy+y3qZUql50ZeXR0KKyedHvWDIWNt2VF39Zh8Ch+/Mu1t6narpYRMYylrGMZaz/YFXXB94Te8Gt60+KAAAAAElFTkSuQmCC";
    private static final String PLACEHOLDER_LARGE = "iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAAAAACIM/FCAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAACPhJREFUeNrtndty5LgNhn+AVEtqH+awleSp8rLJO+Vm14d2q1sSSQC5mHGyk3hjW+SYsiNdukpqf4XDDxCkRH/Dx7g8/vohOP7OH8Qg2EA2kA1kA9lANpANZAPZQDaQDWQD2UA2kA1knZf/+T9hAEBG7xnETJOqEIjZO353IBKgDACmKWpQgLxrfNu+K5AUQgz2zZPMVNKjRbht/c779wIS0+Fhiru5NQAwMlNShjFIm6vmq7TvAcTiFM7nKSbVyb79icBKAoowqHbp+nQpLa8dJBxODxzM2Mgek7uBQACIzNJpvm0vuovOrxnEohxu0gxr+L/TLzwAg0RKaU7TFXtaK4idTqejJoCU/khNzGAWNWC46C9olSDK08MwiDb/MsFTF3kAFgPL6TP3xusD0XQ7nmMgKD2r8gZLsMPc7/fN2kAk3dymROyM7fnyTh0Q4/zwVT4TrQlE53E4hcDMBHtBMBFIIeqOMVzs3XpALNzfTmYeeIE5vt/C6mFjGL74jlYCorPcnmcBnMFeDk8gxby7oS97XgWIjcNvM6VXWON3cc/Cv81/uVoFSEg3IREz7NW3EoEjHy/3TPVBwnAfkzLZImsSSO3oLvv6IHEcIxPbUsdk2Fl8iSIy8xHhMIvBMn7ewjSVCPe8Z2gIghwXN7Zk01jbtWQ6Z1jjMeZlmNHXtUg4TOZcFoqRZ70bpS7IfJg0t4Q1tjjMVBVE5xjUZfoWm+l5ClVBKMUiy25GKUo9ENMpFuqMKA1Bq4FQPImxleCgNE5Wz7VSSMYFSJgtTCPVAwkhoIRBDCRziNVANA0BRQpXhspDqgbC85SsSKwbSJpzqgUyJ7JiQw+TeZY6IJoEpTCYXZpHrQMioylKXQaLoZJFkgoRFQoSZo2nOhYxkXIGgZGmOFcCiancKjTDQhSp41qiJZfTDajjWiLRtORquipquVZRi4A5b0F7KYhLosolUYi5ikWCSKHk+50DbRXXUpKSGCByqU6wT1pwd4mCmHwNkBRd0fgwcn2N9KvpnMBFQyQ3cfDCUI+Fty2Z464CSAohgbioRbhKsKeEshah3K0Qy0AkJSkYI6TKzDVACja5j090rgZIkfWs/4yRGiBcdnuqksF7V8O1nCMrGu7Zz+LljqDlel2F866KRYiKB7uvYhFyhYWdWlcDpHjWIpMqrS67ovUJAylkDkT9Qk8ou+GVSO7M73NU1i/8YS0aIcyR7ti1b24RFStKQrDZxi4nc62m1hJL8e2D3UQK11pwQJa/Lmx1gcIgRpnN7mKLKLhs5mLKSoULY0SEShvF8qYtCy0CFI52UuTVbwtjxKx0sAM1XKt81lIgrxBdBuINWt4gFVzLRIxKO1eV9GsKdYWdq8qgZ1YtLYkg9/YgAULlY6TCxMqh/GU1Rm/SUHEMn1fxLLybSx8kZN/kmXnZP9QLexTMv6a+u6wxetPrnrTcFg5ScNfvKoA0fd+YFdsxoCa+7WtYhPd78gVJQHbVVpmP+OtP7ErtdCLA+SazTVtoT+Jf9I6kSMCTwre73DS49H6vf6L7pJI7J1GCJufaT6gEgsb9eXcTsisVVphRe5G7hr0chBxdu+MpSlbRas6ZOlz02QdEc9b2+q6/OcSMhXkz7z2I+suLBvVAQHQpd3l9CTe9c67NFMNcEAA7zshbJGRt33tyBc61Z4IYOENLyJy7LvSmlMzsmdomY3algLNCdXQmiOsd5yyoULF111yQdscZqwbKbjUgLSFj6EPcrAPEtzuXM7yKxbr/TBBqL3PW1bjczuFcF2XN6COMqV0LCPYt+WVDXoVbkUVg7Sde1iqSEXdxNSBN1+1s4b5Kdq5bDQh1/eIMSt6n1YCgudx5XrBxjBTE5QaqBSqdZtcpdAGKZe/ILGoRYNf4pYVjublXCZCmdQvyr3HRUWQBEGNaOq03XRMIk1vaJoZy582KPMgW3mV6SmsCoWW+xSSShrkQiK9nEYDEzo3zqwn2pYePjSmdBllTsC98Crk034+rca2M/UnGiW+0s86tAYSIGLrwbWEcH4bdp3Th1xDsjMUnF4g0QC3On3PnxCVACBkvbwMhYu4Pv1zkzayK5L7+PmMB2AOaInu72tV3rawRCZSgeAj75LP+iRJ6mFf6MbsG0/lWURlE58yKyYjI9HQIdUF0uJ+NKfNVdGzT3VQVJIXjGPOfwzqPo1UEEbm7H9VyV9qIoXoaYj2QdPubJMvfF2hMOt4d56UPyk2/0/k2hYy3mf7gXBNSutxXAQnDfZqpCAeR6iiWsLPmzUH0dDhGLnSO2mAINp66/UX3xiASjncKX2rjLHlDmubjF6Hdq4uFHBALv94bCh6/MJgiuuNw7vtu93Yg0683grJHKxkAB8jhK/nXzVgXgsQYJY6DiSt7RNQIpKqpeQh971/zUvlFIILTfKAjCTkufo7EGAyM4Uxf+OIngsTEIw1xDjGJ4/Icj1aR0Dyk4xWa3U8BsXk6h1NKXlXh6WdwfIt6Vug44/Z6v+9Kg4hQlCFMcRYVNgfYT+IACB5IRooYxeMFXfCLQWwMYxoSazRVMmX5uR8lMxiZyhTGm6u2f35T8ItAVF2Mx3gKMREc2KH4qbcnC2IHWJx93Kd4Tc8ckXgBiIQQpjiyJEkwFibDm1wGKAklDLE5tdeyywORB3o4jt8+fuS+LWK93cXYKSglfuimz9j9Dzfwz6jeTDFIjKrGxOrsTTG+9/NqFDkcQ9c1f/wxHP+c6rnZAcZMBri3pnhUSHikNN33l/Lpj1pR/6zqafJgNhQ/nPsahQQlE54h5092/WKQH1TPnKuH8EMnLGxj1Pv+/KTc+2dVbwUUjxKpGtRwfFLufVXVe202BrGG+KTc+8qq98oWEoDak3Lva6vea41iuntS7j1gAFVVvdc29k/KvYeEGEOqq3qvLPGfknuPYZqHOdZWvWy59zhMcU71VS9X7j3uBIZ1qN5yuQc8ZvD3kH9317/lvsO3I7fvkeIHuVd4uHeL8Tu5j+UWbivL/Vt8DfxN5P6DfJ+d/Ef50Lx9FBBsIBvIBrKBbCAbyAaygWwgG8j/EYjHPz4GyD8BuD4UMZqns0wAAAAASUVORK5CYII=";
}
