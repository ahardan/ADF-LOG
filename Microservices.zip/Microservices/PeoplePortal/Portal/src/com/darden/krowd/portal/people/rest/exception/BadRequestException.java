package com.darden.krowd.portal.people.rest.exception;

import java.io.PrintWriter;
import java.io.StringWriter;

import java.util.*;
import javax.ws.rs.*;
import javax.ws.rs.core.*;
import javax.ws.rs.core.Response.*;
 
/** Thrown to return a 400 Bad Request response with a list of error messages in the body. */
public class BadRequestException extends WebApplicationException
{
    public static final int GENERIC_APP_ERROR_CODE = 5001;       
    private static final long serialVersionUID = -2191179733969059302L;

    private List<String> errors;
 
    public BadRequestException(String... errors)
    {
        this(Arrays.asList(errors));
    }
 
    public BadRequestException(List<String> errors)
    {
        super(Response.status(Status.BAD_REQUEST).type(MediaType.APPLICATION_JSON)
                .entity(new GenericEntity<List<String>>(errors)
                {}).build());
        this.errors = errors;
    }
    
    public BadRequestException(Throwable ex){
        super(Response.status(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode())
                        .entity(ErrorMessage.getErrorMessageInstance(ex))
                        .type(MediaType.APPLICATION_JSON)
                        .build());                  
        StackTraceElement[] elements = ex.getStackTrace();
        this.errors = new ArrayList<String>();
        for(StackTraceElement element : elements){
            this.errors.add(element.getFileName()+":"+element.getClassName()+":"+element.getMethodName()+":"+element.getLineNumber());
        }        
    }
    
    public List<String> getErrors()
    {
        return errors;
    }
}