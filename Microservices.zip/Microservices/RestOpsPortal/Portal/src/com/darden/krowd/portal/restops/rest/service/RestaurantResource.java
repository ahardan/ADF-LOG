package com.darden.krowd.portal.restops.rest.service;

import com.darden.common.responsestatus.ResponseStatusType;
import com.darden.ebo.locationv3.LocationIDType;
import com.darden.ebo.locationv3.LocationType;
import com.darden.ebo.locationv3.LocationsType;
import com.darden.global.enterpriseobjects.core.ebo.area.v1.GetAreasResponseType;
import com.darden.global.enterpriseobjects.core.ebo.division.v2.GetDivisionsResponseType;
import com.darden.global.enterpriseobjects.core.ebo.location.v1.GetLocationsResponseType;
import com.darden.global.enterpriseobjects.core.ebo.region.v1.GetRegionsResponseType;
import com.darden.krowd.common.util.CacheUtil;
import com.darden.krowd.reports.model.applicationModule.common.ReportsAM;
import com.darden.krowd.portal.restops.rest.exception.BadRequestException;
import com.darden.krowd.services.helper.ServicesHelper;

import com.darden.krowd.services.locationquery.BusinessFault;
import com.darden.krowd.services.locationquery.LocationQueryServiceInterface;
import com.darden.krowd.services.locationquery.TechnicalFault;
import com.darden.krowd.services.util.ServicesUtil;

import com.darden.message.locationqueryservice.LocationFilterType;
import com.darden.message.locationqueryservice.LocationSelectType;
import com.darden.message.locationqueryservice.SearchRequestType;

import com.darden.message.locationqueryservice.SearchResponseType;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import oracle.adf.model.BindingContext;
import oracle.adf.model.DataControlFrame;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCDataControl;

import org.apache.commons.lang3.StringUtils;

import org.codehaus.jackson.map.ObjectMapper;


@Path("/restops")
@Produces("application/json")
public class RestaurantResource {

    @Context private HttpServletRequest httpRequest;

    private static final Map<String,String> CORPCODE_MAP = new HashMap<String,String>(){{
        put("RLUSA", "RL1");
        put("OGUSA", "TOG");
        put("BBUSA", "005");
        put("52USA", "007");
        put("LHUSA", "012");
        put("CGUSA", "013");
        put("CSUSA", "020");
        put("EVUSA", "017");
        put("RLCAN", "RLC");
        put("OGCAN", "OGC");
        put("YHUSA", "010");
        put("CBUSA", "021");
    }};

    private static final String PAGE_DEF = "com_darden_krowd_portal_RestPageDef";
    private static final String REPORTS_DATACONTROL = "ReportsAMDataControl"; 

    public RestaurantResource() {
        super();
    }

    /*
     *             }
            peopleSoftUserId =
                    (String)currentUserProfile.getProperty("Darden-Empl-ID");
            krowdLogger.severe("peopleSoftUserId ::"+peopleSoftUserId);
            rscDivision =
                    (String)currentUserProfile.getProperty("Darden-Job-Function");
            corporationId = (String)currentUserProfile.getProperty("company");
            divisionId = (String)currentUserProfile.getProperty("division");
            departmentName =
                    (String)currentUserProfile.getProperty("department");
            restaurantNumber =
                    (String)currentUserProfile.getProperty("physicaldeliveryofficename");
            aliasName = (String)currentUserProfile.getProperty("Darden-AKA");
            assistantTmp = (String)currentUserProfile.getProperty("assistant");
            brandName = (String)currentUserProfile.getProperty("Darden-Business-Unit");
            dardenRegion=(String)currentUserProfile.getProperty("Darden-Region");
            dardenArea=(String)currentUserProfile.getProperty("Darden-Area");
     */

    //http://localhost:7101/kd-rest/rest/restaurant/divisions/TOG/10
    //{"Division":[{"DivisionId":224,"ConceptId":2,"Description":"Orlando","ReferenceCode":"10","DivisionType":"","EffectiveDate":1339732800000,"CreatedDate":1339804961000,"LastModifiedDate":1339804961000}]}


    //http://localhost:7101/kd-rest/rest/restaurant/locations/TOG/1748
    //{"Location":[{"LocationId":21748,"RestaurantNumber":"1748","CorporationId":2,"RegionId":752,"DivisionId":224,"AreaId":974,"OriginalLocationId":0,"Description":"Cape Coral, FL","Address1":"1910 Pine Island Road NE","Address2":"","City":"Cape Coral","PostalCode":"33909","StateAbbr":"FL","TimeZone":"2","LocationType":"S","EffectiveDate":1374033600000,"CreatedDate":1374081207000,"LastUpdatedDate":1374588121000,"OpenDate":1208750400000}]}


    //http://localhost:7101/kd-rest/rest/restaurant/areas/TOG/10/A1
    //{"Area":[{"AreaId":974,"RegionId":0,"Description":"Orlando Area ","ReferenceCode":"A1","EffectiveDate":1381291200000,"CreatedDate":1381323588000,"LastUpdatedDate":1381323588000}]}


    private ReportsAM getReportsAM(){
        BindingContext bindingContext = BindingContext.getCurrent();
        ReportsAM am =null;
        DCDataControl dc = null;
        if(bindingContext !=null){
            String dcFrameName = bindingContext.getCurrentDataControlFrame();
            DataControlFrame dcframe = dcFrameName == null? null : bindingContext.findDataControlFrame(dcFrameName);
            dc = dcframe == null ? null : dcframe.findDataControl(REPORTS_DATACONTROL);
            dc = dc == null ? bindingContext.findDataControl(REPORTS_DATACONTROL) : dc;

            if(dc == null){
               DCBindingContainer amx = bindingContext.findBindingContainer(PAGE_DEF);
                dc = amx.findDataControl(REPORTS_DATACONTROL);
                am = (ReportsAM)dc.getDataProvider();
            }else{
                am = (ReportsAM)dc.getDataProvider();
            }
        }
        return am;
    }

    @GET
    @Path("/opsreport/{reportType}")
    public Response getOpsReport(@PathParam("reportType") String reportType,
                                                     @QueryParam("region") List<Long> regions,
                                                     @QueryParam("restaurant") List<Long> restaurants){
        if(reportType.compareToIgnoreCase("weekly")==0){
            Map<String,Map<Long,Map<String,Object>>> results = new HashMap<String,Map<Long,Map<String,Object>>>();
            ReportsAM am = getReportsAM();
            if(regions != null && !regions.isEmpty()){
                results.put("regions",am.getWeeklyResultsForRegions(regions));
            }
            if(restaurants != null && !restaurants.isEmpty()){
                results.put("restaurants",am.getWeeklyResultsForRestaurants(restaurants));
            }
            return Response.ok().entity(results).build();
        }else if(reportType.compareToIgnoreCase("daily")==0){
            Map<String,Map<Long,Map<String,Object>>> results = new HashMap<String,Map<Long,Map<String,Object>>>();
            ReportsAM am = getReportsAM();
            if(regions != null && !regions.isEmpty()){
                results.put("regions",am.getDailyResultsForRegions(regions));
            }
            if(restaurants != null && !restaurants.isEmpty()){
                results.put("restaurants",am.getDailyResultsForRestaurants(restaurants));
            }
            return Response.ok().entity(results).build();
        }else{
            throw new BadRequestException("reportType must be weekly or daily.");
        }
    }

    private String getCacheKey(String type,Integer corpId,
                               String corpCode,
                               Integer divisionId,
                               String divisionCode,
                               Integer areaId,
                               String areaCode,
                               Integer regionId,
                               String regionCode,
                               Integer locationId,
                               String restaurantNumber,
                               Boolean includeChildren){
        StringBuilder sb = new StringBuilder();
        sb.append(type);
        if(corpId !=null){
            sb.append("-").append(corpId);
        }

        if(StringUtils.isNotBlank(corpCode)){
            sb.append("-").append(corpCode);
        }

        if(divisionId !=null){
            sb.append("-").append(divisionId);
        }

        if(StringUtils.isNotBlank(divisionCode)){
            sb.append("-").append(divisionCode);
        }

        if(areaId !=null){
            sb.append("-").append(areaId);
        }

        if(StringUtils.isNotBlank(areaCode)){
            sb.append("-").append(areaCode);
        }

        if(regionId !=null){
            sb.append("-").append(regionId);
        }

        if(StringUtils.isNotBlank(regionCode)){
            sb.append("-").append(regionCode);
        }

        if(locationId !=null){
            sb.append("-").append(locationId);
        }

        if(StringUtils.isNotBlank(restaurantNumber)){
            sb.append("-").append(restaurantNumber);
        }

        if(includeChildren !=null){
            sb.append("-").append(includeChildren);
        }

        return sb.toString();
    }

    @GET
    @Path("/divisions")
    public Response getDivisions(@QueryParam("corpId") Integer corpId,
                                 @QueryParam("corpCode") String corpCode,
                                 @QueryParam("divisionId") Integer divisionId,
                                 @QueryParam("divisionCode") String divisionCode, //referenceCode
                                 @QueryParam("areaId") Integer areaId,
                                 @QueryParam("areaCode") String areaCode,
                                 @QueryParam("regionId") Integer regionId,
                                 @QueryParam("regionCode") String regionCode,
                                 @QueryParam("locationId") Integer locationId,
                                 @QueryParam("restaurantNumber") String restaurantNumber,
                                 @DefaultValue("false") @QueryParam("includeChildrean") boolean includeChildren,
                                 @DefaultValue("true") @QueryParam("cache") boolean cache){
        //referenceCode is the divisionCode
        corpCode = CORPCODE_MAP.get(corpCode);
        if(corpCode == null && corpId == null)
            throw new BadRequestException("Corp Code or Corp ID is mandatory.");
        else{
            corpCode = StringUtils.isBlank(corpCode)?null:corpCode;
            divisionCode = StringUtils.isBlank(divisionCode)?null:divisionCode;
            areaCode = StringUtils.isBlank(areaCode)?null:areaCode;
            regionCode = StringUtils.isBlank(regionCode)?null:regionCode;
            restaurantNumber = StringUtils.isBlank(restaurantNumber)?null:restaurantNumber;
            String cacheKey = getCacheKey("DIVISIONS", corpId, corpCode, divisionId, divisionCode, areaId, areaCode, regionId, regionCode, locationId, restaurantNumber, includeChildren);
            String responseJson = cache ? (String)CacheUtil.getInstance().get(cacheKey,CacheUtil.CacheType.APPLICATION) : null;
            if(responseJson == null){
                ServicesHelper servicesHelper = new ServicesHelper();
                try {
                    GetDivisionsResponseType respType = servicesHelper.getRestaurantDivisions(corpId, corpCode, divisionId, divisionCode, areaId, areaCode, regionId, regionCode, locationId, restaurantNumber, includeChildren);
                    if(respType != null){
                        ObjectMapper objMapper = new ObjectMapper();
                        responseJson = objMapper.writeValueAsString(respType);
                        CacheUtil.getInstance().put(cacheKey,responseJson,CacheUtil.CacheType.APPLICATION);
                    }
                } catch (Exception e) {
                    throw new BadRequestException(e);
                }
            }
            return Response.ok().entity(responseJson).type(MediaType.APPLICATION_JSON).build();
        }
    }


    @GET
    @Path("/restaurantinfo/corp/{corpCode}/restaurant/{restaurantNumber}")
    public Response getLocationInfo(@PathParam("corpCode") String corpCode,
                                    @PathParam("restaurantNumber") String restaurantNumber,
                                    @DefaultValue("true") @QueryParam("cache") boolean cache){

        corpCode = CORPCODE_MAP.get(corpCode);
        if(corpCode == null)
            throw new BadRequestException("Corp Code is mandatory.");
        else{
            String cacheKey = getCacheKey("RESTAURANTINFO", null, corpCode, null, null, null, null, null, null, null, restaurantNumber, false);
            String responseJson = cache ? (String)CacheUtil.getInstance().get(cacheKey,CacheUtil.CacheType.APPLICATION) : null;
            if(responseJson == null){
                ServicesUtil servicesutil = ServicesUtil.getInstance();
                LocationQueryServiceInterface locationQueryService = servicesutil.getLocationQueryService();
                SearchRequestType searchRequestType = new SearchRequestType();
                searchRequestType.setIncludeClosedLocations(Boolean.FALSE);

                LocationSelectType locationSelectType = new LocationSelectType();
                List<String> sectionList = locationSelectType.getSection();
                sectionList.add("Location");
                searchRequestType.setSelect(locationSelectType);


                LocationFilterType locationFilterType = new LocationFilterType();
                LocationsType locationsType = new LocationsType();
                List<LocationType> locationTypes = locationsType.getLocation();
                LocationType locationType = new LocationType();
                LocationIDType locationIdType = new LocationIDType();

                locationIdType.setNumber(restaurantNumber);
                locationIdType.setCorporationID(corpCode);
                locationType.setLocationID(locationIdType);
                locationTypes.add(locationType);
                locationFilterType.setLocations(locationsType);
                searchRequestType.setFilter(locationFilterType);
                try {
                   SearchResponseType respType = locationQueryService.search(searchRequestType);
                    if(respType != null){
                        ResponseStatusType responseStatusType = respType.getResponseStatus();
                        String status = responseStatusType.getStatus();
                        if(status != null && status.compareToIgnoreCase("SUCCESS")==0){
                            ObjectMapper objMapper = new ObjectMapper();
                            responseJson = objMapper.writeValueAsString(respType.getLocations());
                            CacheUtil.getInstance().put(cacheKey,responseJson,CacheUtil.CacheType.APPLICATION);
                            return Response.ok().entity(responseJson).type(MediaType.APPLICATION_JSON).build();
                        }else{
                            throw new BadRequestException("Location Query service Error");
                        }
                    }else{
                        return Response.noContent().build();
                    }
                } catch (Exception e) {
                    throw new BadRequestException(e);
                }
            }else{
                return Response.ok().entity(responseJson).type(MediaType.APPLICATION_JSON).build();
            }
        }
    }

    @GET
    @Path("/locations")
    public Response getLocations(@QueryParam("corpId") Integer corpId,
                                 @QueryParam("corpCode") String corpCode,
                                 @QueryParam("divisionId") Integer divisionId,
                                 @QueryParam("divisionCode") String divisionCode, //referenceCode
                                 @QueryParam("areaId") Integer areaId,
                                 @QueryParam("areaCode") String areaCode,
                                 @QueryParam("regionId") Integer regionId,
                                 @QueryParam("regionCode") String regionCode,
                                 @QueryParam("locationId") Integer locationId,
                                 @QueryParam("restaurantNumber") String restaurantNumber,
                                 @DefaultValue("true") @QueryParam("cache") boolean cache){
        //referenceCode is the divisionCode
        corpCode = CORPCODE_MAP.get(corpCode);
        if(corpCode == null && corpId == null)
            throw new BadRequestException("Corp Code or Corp ID is mandatory.");
        else{
            corpCode = StringUtils.isBlank(corpCode)?null:corpCode;
            divisionCode = StringUtils.isBlank(divisionCode)?null:divisionCode;
            areaCode = StringUtils.isBlank(areaCode)?null:areaCode;
            regionCode = StringUtils.isBlank(regionCode)?null:regionCode;
            restaurantNumber = StringUtils.isBlank(restaurantNumber)?null:restaurantNumber;
            String cacheKey = getCacheKey("LOCATIONS", corpId, corpCode, divisionId, divisionCode, areaId, areaCode, regionId, regionCode, locationId, restaurantNumber,null);

            String responseJson = cache ? (String)CacheUtil.getInstance().get(cacheKey,CacheUtil.CacheType.APPLICATION) : null;
            if(responseJson == null){
                ServicesHelper servicesHelper = new ServicesHelper();
                try {
                    GetLocationsResponseType respType = servicesHelper.getRestaurantLocations(corpId, corpCode, divisionId, divisionCode, areaId, areaCode, regionId, regionCode, locationId, restaurantNumber);
                    if(respType != null){
                        ObjectMapper objMapper = new ObjectMapper();
                        responseJson = objMapper.writeValueAsString(respType);
                        CacheUtil.getInstance().put(cacheKey,responseJson,CacheUtil.CacheType.APPLICATION);
                    }
                } catch (Exception e) {
                    throw new BadRequestException(e);
                }
            }
            return Response.ok().entity(responseJson).type(MediaType.APPLICATION_JSON).build();
        }
    }

    @GET
    @Path("/areas")
    public Response getAreas(@QueryParam("corpId") Integer corpId,
                                 @QueryParam("corpCode") String corpCode,
                                 @QueryParam("divisionId") Integer divisionId,
                                 @QueryParam("divisionCode") String divisionCode, //referenceCode
                                 @QueryParam("areaId") Integer areaId,
                                 @QueryParam("areaCode") String areaCode,
                                 @QueryParam("regionId") Integer regionId,
                                 @QueryParam("regionCode") String regionCode,
                                 @QueryParam("locationId") Integer locationId,
                                 @QueryParam("restaurantNumber") String restaurantNumber,
                                 @DefaultValue("false") @QueryParam("includeChildrean") boolean includeChildren,
                                 @DefaultValue("true") @QueryParam("cache") boolean cache){
        //referenceCode is the divisionCode
        corpCode = CORPCODE_MAP.get(corpCode);
        if(corpCode == null && corpId == null)
            throw new BadRequestException("Corp Code or Corp ID is mandatory.");
        else{
            corpCode = StringUtils.isBlank(corpCode)?null:corpCode;
            divisionCode = StringUtils.isBlank(divisionCode)?null:divisionCode;
            areaCode = StringUtils.isBlank(areaCode)?null:areaCode;
            regionCode = StringUtils.isBlank(regionCode)?null:regionCode;
            restaurantNumber = StringUtils.isBlank(restaurantNumber)?null:restaurantNumber;
            String cacheKey = getCacheKey("AREAS", corpId, corpCode, divisionId, divisionCode, areaId, areaCode, regionId, regionCode, locationId, restaurantNumber,includeChildren);

            String responseJson = cache ? (String)CacheUtil.getInstance().get(cacheKey,CacheUtil.CacheType.APPLICATION) : null;
            if(responseJson == null){
                ServicesHelper servicesHelper = new ServicesHelper();
                try {
                    GetAreasResponseType respType = servicesHelper.getRestaurantAreas(corpId, corpCode, divisionId, divisionCode, areaId, areaCode, regionId, regionCode, locationId, restaurantNumber,includeChildren);
                    if(respType != null){
                        ObjectMapper objMapper = new ObjectMapper();
                        responseJson = objMapper.writeValueAsString(respType);
                        CacheUtil.getInstance().put(cacheKey,responseJson,CacheUtil.CacheType.APPLICATION);
                    }
                } catch (Exception e) {
                    throw new BadRequestException(e);
                }
            }
            return Response.ok().entity(responseJson).type(MediaType.APPLICATION_JSON).build();
        }
    }

    @GET
    @Path("/regions")
    public Response  getRegions(@QueryParam("corpId") Integer corpId,
                                 @QueryParam("corpCode") String corpCode,
                                 @QueryParam("divisionId") Integer divisionId,
                                 @QueryParam("divisionCode") String divisionCode, //referenceCode
                                 @QueryParam("areaId") Integer areaId,
                                 @QueryParam("areaCode") String areaCode,
                                 @QueryParam("regionId") Integer regionId,
                                 @QueryParam("regionCode") String regionCode,
                                 @QueryParam("locationId") Integer locationId,
                                 @QueryParam("restaurantNumber") String restaurantNumber,
                                 @DefaultValue("false") @QueryParam("includeChildrean") boolean includeChildren,
                                 @DefaultValue("true") @QueryParam("cache") boolean cache){
        //referenceCode is the divisionCode
        corpCode = CORPCODE_MAP.get(corpCode);
        if(corpCode == null && corpId == null)
            throw new BadRequestException("Corp Code or Corp ID is mandatory.");
        else{
            corpCode = StringUtils.isBlank(corpCode)?null:corpCode;
            divisionCode = StringUtils.isBlank(divisionCode)?null:divisionCode;
            areaCode = StringUtils.isBlank(areaCode)?null:areaCode;
            regionCode = StringUtils.isBlank(regionCode)?null:regionCode;
            restaurantNumber = StringUtils.isBlank(restaurantNumber)?null:restaurantNumber;
            String cacheKey = getCacheKey("REGIONS", corpId, corpCode, divisionId, divisionCode, areaId, areaCode, regionId, regionCode, locationId, restaurantNumber,includeChildren);

            String responseJson = cache ? (String)CacheUtil.getInstance().get(cacheKey,CacheUtil.CacheType.APPLICATION) : null;
            if(responseJson == null){
                ServicesHelper servicesHelper = new ServicesHelper();
                try {
                    GetRegionsResponseType respType = servicesHelper.getRestaurantRegions(corpId, corpCode, divisionId, divisionCode, areaId, areaCode, regionId, regionCode, locationId, restaurantNumber,includeChildren);
                    if(respType != null){
                        ObjectMapper objMapper = new ObjectMapper();
                        responseJson = objMapper.writeValueAsString(respType);
                        CacheUtil.getInstance().put(cacheKey,responseJson,CacheUtil.CacheType.APPLICATION);
                    }
                } catch (Exception e) {
                    throw new BadRequestException(e);
                }
            }
            return Response.ok().entity(responseJson).type(MediaType.APPLICATION_JSON).build();
        }
    }


}