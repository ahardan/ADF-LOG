package com.darden.krowd.notifications.codecs;

import com.darden.krowd.common.gcm.Message;

import java.io.IOException;

import java.util.Map;

import org.atmosphere.config.managed.Encoder;

import org.codehaus.jackson.map.ObjectMapper;

public class MessageEncoder implements Encoder<Message, String>{
    private final ObjectMapper mapper = new ObjectMapper();
    
    public MessageEncoder() {
        super();
    }
    
    @Override
    public String encode(Message m) {
        try {
            Map<String,Object> map = m.toMap();
            return mapper.writeValueAsString(map);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } 
    }

}
