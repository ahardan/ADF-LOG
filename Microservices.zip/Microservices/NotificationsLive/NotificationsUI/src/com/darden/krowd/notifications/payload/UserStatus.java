package com.darden.krowd.notifications.payload;

import com.darden.krowd.common.notification.KrowdBusinessObjectEvent;
import com.darden.krowd.notifications.codecs.JacksonEncoder;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class UserStatus implements JacksonEncoder.Encodable, Serializable{
    @SuppressWarnings("compatibility:3624818799025274985")
    private static final long serialVersionUID = 1841337768457801910L;
    private List<String> onlineUsers = null;
    private String type;
    
    public UserStatus() {
        super();
    }
    
    public void processUsers(ConcurrentHashMap<String, ConcurrentHashMap<String, List<String>>> nodeUsersMap){
        if(nodeUsersMap != null){
            Set<Map.Entry<String,ConcurrentHashMap<String,List<String>>>> nodeEntries = nodeUsersMap.entrySet();
            onlineUsers = new ArrayList<String>();
            for(Map.Entry<String,ConcurrentHashMap<String,List<String>>> nodeEntry : nodeEntries){
                ConcurrentHashMap<String, List<String>> usersMap = nodeEntry.getValue();
                if(usersMap != null){
                    Set<Map.Entry<String,List<String>>> userEntries = usersMap.entrySet();
                    for(Map.Entry<String,List<String>> user: userEntries){
                        onlineUsers.add(user.getKey());
                    }                    
                }
            }
        }                
    }
        
    /*public Notification(ConcurrentHashMap<String, ConcurrentHashMap<String, List<String>>> nodeUsersMap) {
        super();
        if(nodeUsersMap != null){
            Set<Map.Entry<String,ConcurrentHashMap<String,List<String>>>> nodeEntries = nodeUsersMap.entrySet();
            connectedUsers = new HashMap<String,HashMap<String,List<String>>>();
            for(Map.Entry<String,ConcurrentHashMap<String,List<String>>> nodeEntry : nodeEntries){
                ConcurrentHashMap<String, List<String>> usersMap = nodeEntry.getValue();
                if(usersMap != null){
                    Set<Map.Entry<String,List<String>>> userEntries = usersMap.entrySet();
                    HashMap<String,List<String>> tMap = new HashMap<String,List<String>>();
                    connectedUsers.put(nodeEntry.getKey(),tMap);
                    for(Map.Entry<String,List<String>> user: userEntries){
                        tMap.put(user.getKey(),user.getValue());
                    }                    
                }
            }
        }
    }*/

    public List<String> getOnlineUsers() {
        return onlineUsers;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }
}
