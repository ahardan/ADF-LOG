package com.darden.krowd.notifications.services;


import com.darden.krowd.common.notification.KrowdActor;
import com.darden.krowd.common.notification.KrowdBusinessObject;
import com.darden.krowd.common.notification.KrowdBusinessObjectEvent;
import com.darden.krowd.common.notification.KrowdCustomProperty;
import com.darden.krowd.common.util.EventPublisher;
import com.darden.krowd.model.handlers.KrowdMessagingPushNotificationHandler;
import com.darden.krowd.notifications.codecs.JacksonEncoder;
import com.darden.krowd.notifications.codecs.MessageEncoder;
import com.darden.krowd.notifications.codecs.UserStatusDecoder;
import com.darden.krowd.notifications.payload.UserStatus;

import java.io.IOException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.PostConstruct;

import javax.inject.Inject;

import javax.jms.Connection;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import javax.jms.Session;
import javax.jms.Topic;
import javax.jms.TopicConnection;

import oracle.adf.share.logging.ADFLogger;

import org.atmosphere.config.service.Disconnect;
import org.atmosphere.config.service.Get;
import org.atmosphere.config.service.ManagedService;
import org.atmosphere.config.service.Message;
import org.atmosphere.config.service.PathParam;
import org.atmosphere.config.service.Ready;
import org.atmosphere.config.service.Singleton;
import org.atmosphere.cpr.AtmosphereConfig;
import org.atmosphere.cpr.AtmosphereFramework;
import org.atmosphere.cpr.AtmosphereFrameworkListener;
import org.atmosphere.cpr.AtmosphereResource;
import org.atmosphere.cpr.AtmosphereResourceEvent;
import org.atmosphere.cpr.AtmosphereResourceEventListenerAdapter;
import org.atmosphere.cpr.AtmosphereResourceFactory;
import org.atmosphere.cpr.AtmosphereResourceSessionFactory;
import org.atmosphere.cpr.BroadcasterFactory;
import org.atmosphere.cpr.MetaBroadcaster;

import org.codehaus.jackson.map.ObjectMapper;


@Singleton
@ManagedService(path = "/live/notifications")
public class NotificationService {    
    private static final ADFLogger logger = ADFLogger.createADFLogger(NotificationService.class);
    private static final String BROADCASTER_NAME = "/live/notifications";
    private String uuid = UUID.randomUUID().toString();
    private final ConcurrentHashMap<String, ConcurrentHashMap<String, List<String>>> userMap = new ConcurrentHashMap<String, ConcurrentHashMap<String, List<String>>>();
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Inject
    private AtmosphereResourceFactory resourceFactory;

    @Inject
    private MetaBroadcaster metaBroadcaster;
    
    @Inject
    private AtmosphereConfig config;

    @Inject
    private AtmosphereFramework f;

    @Inject
    private BroadcasterFactory bFactory;

    @Inject
    private AtmosphereResourceSessionFactory sessionFactory;    

    // Atmosphere Topic
    private Connection atmosConnection = null;
    private Session atmosSession = null;
    private MessageConsumer atmosConsumer = null;

    private Timer timer;
    private TimerTask timerTask;
    
    public NotificationService(){
        super();
    }

    @PostConstruct
    public void onInit() {
        f.frameworkListener(new AtmosphereFrameworkListener(){
                public void onPreInit(AtmosphereFramework atmosphereFramework) {
                }

                public void onPostInit(AtmosphereFramework atmosphereFramework) {
                    postInit();
                    setupHeartBeat();
                }

                public void onPreDestroy(AtmosphereFramework atmosphereFramework) {
                    destroy();
                }

                public void onPostDestroy(AtmosphereFramework atmosphereFramework) {
                }
            });                
    }
    
    private void postInit(){
        this.setAtmosphereSubscription();
    }
    
    private void setupHeartBeat(){
        timer = new Timer();
        timerTask = new TimerTask() {
                @Override
                public void run() {
                    performHeartBeat();
                }
            };
        timer.scheduleAtFixedRate(timerTask,2000,5000);             
    }
    
    private KrowdBusinessObjectEvent buildBusinessObjectEvent(String type){
        if(type.compareTo("HEARTBEAT")==0){
            ConcurrentHashMap<String,List<String>> currentNodeUsers = this.userMap.get(this.uuid);
            if(currentNodeUsers != null){
                KrowdBusinessObjectEvent boe = new KrowdBusinessObjectEvent();
                boe.setAppId("KROWD");
                boe.setEventId(UUID.randomUUID().toString());
                boe.setEventName("HEARTBEAT");
                boe.setMessage("Heart Beat");
                
                KrowdBusinessObject bo = new KrowdBusinessObject();
                bo.setId(UUID.randomUUID().toString());
                bo.setName("CONNECTED_USERS");
                bo.setType("PRESENCE");

                boe.setPrimaryObject(bo);
                
                Set<String> userKeySet = currentNodeUsers.keySet();
                KrowdActor krowdActor;
                for(String user : userKeySet){
                    krowdActor = new KrowdActor();
                    krowdActor.setId(user);
                    krowdActor.setName(user);
                    boe.addSecondaryActor(krowdActor);
                }
                List<KrowdCustomProperty> customPropertyList = new ArrayList<KrowdCustomProperty>();                
                KrowdCustomProperty customProp = new KrowdCustomProperty();
                customProp.setName("SourceID");
                customProp.setValue(uuid);
                customPropertyList.add(customProp);
                
                boe.setCustomProperties(customPropertyList);
                
                return boe;                
            }else{
                return null;
            }
        }
        
        return null;
    }
    
    private void performHeartBeat(){
        KrowdBusinessObjectEvent boe = buildBusinessObjectEvent("HEARTBEAT");
        Map<String,Object> msgProps = new HashMap<String,Object>();
        msgProps.put("SourceID",uuid);
        
        if(boe != null){
            boolean isPublished = EventPublisher.broadcast(boe,msgProps);
            if(!isPublished){
                logger.severe("=== Unable to Send Heart Beat===");
            }
        }
    }

    private void setAtmosphereSubscription() {
        String selector = "("+ EventPublisher.ATMOSPHERE_BROADCASTER_KEY +" = '"+EventPublisher.ATMOSPHERE_BROADCASTER_ID+"')";

        try {
            Topic atmosTopic = EventPublisher.getAtmosphereTopic();
            atmosConnection = EventPublisher.createAtmosphereTopicConnection();
            atmosSession = ((TopicConnection)atmosConnection).createTopicSession(false,Session.AUTO_ACKNOWLEDGE);
            atmosConnection.start();

            atmosConsumer = atmosSession.createConsumer(atmosTopic, selector);
            atmosConsumer.setMessageListener(new MessageListener() {
                    public void onMessage(javax.jms.Message msg) {
                        try {
                            ObjectMessage objMessage = (ObjectMessage)msg;
                            KrowdBusinessObjectEvent payload = (KrowdBusinessObjectEvent)objMessage.getObject();
                            if(payload!= null){
                                String eventName = payload.getEventName();
                                if(eventName !=null){
                                    if(eventName.compareTo("HEARTBEAT") ==0){
                                        String sourceId = msg.getStringProperty("SourceID");
                                        if(sourceId.compareTo(uuid) == 0){
                                            //logger.info("-----Ignoring Self HEARTBEAT----");
                                        }else{
                                            reconcileConnectedUsersMap(payload);
                                        }
                                    }else{
                                        handleBroadcastEvent(payload);
                                    }                                    
                                }else{
                                    logger.severe("---------Cannot process BOE as Event Name is NULL----");
                                }
                            }                                                            
                        } catch (Exception e) {
                            logger.severe("---------Exception while processing message on queue listener----"+ e.getMessage());
                            logger.severe(e);   
                        }
                    }
                });
        } catch (Exception e) {
            logger.severe(e);
        }
    }
    
    private void handleBroadcastEvent(KrowdBusinessObjectEvent event){
        String eventName = event.getEventName();
        AtmosphereResource r = null;
        if(eventName.compareTo("KROWD_MESSAGING") == 0){
            com.darden.krowd.common.gcm.Message message = KrowdMessagingPushNotificationHandler.prepareIOSPayload(event);
            List<KrowdActor> recepients = event.getSecondaryActors();
            if(recepients !=null && recepients.size() >0){
                logger.info("----------- Send out -----------{0}",message);
                ConcurrentHashMap<String, List<String>> currentNodeUsersMap = this.userMap.get(uuid);
                if(currentNodeUsersMap != null && currentNodeUsersMap.size() > 0){
                    List<String> resourceUUIDList = null;
                    for(int i=0; i< recepients.size(); i++){
                        resourceUUIDList = currentNodeUsersMap.get(recepients.get(i).getId());
                        if(resourceUUIDList != null){
                            for(int j=0; j<resourceUUIDList.size(); j++){
                                r = resourceFactory.find(resourceUUIDList.get(j));
                                if(r != null ){
                                    logger.info("---- Resource Status-----{0} {1} {2}",new Object[]{r.isCancelled(), r.isResumed(), r.isSuspended()});
                                    String result = "{'error': 'Unable to translate'}";
                                    try{
                                        result = objectMapper.writeValueAsString(message.toMap());
                                    }catch(Exception e){
                                        logger.severe(e);
                                    }
                                    bFactory.lookup(BROADCASTER_NAME).broadcast(result,r);
                                }else{
                                    logger.info("----------- Receipient resource UUID not found ----------{0}",resourceUUIDList.get(j));
                                }
                            }
                        }else{
                            logger.info("----------- Receipient has no associate resources ----------{0}",recepients.get(i).getId());
                        }
                    }                    
                }else{
                    logger.info("----------- Current Node has no Online Users----------");
                }
            }
        }else{
            logger.info("----Received Event--------------{0}",eventName);  
        }
        
    }
    
    private void reconcileConnectedUsersMap(KrowdBusinessObjectEvent heartBeatBOE){
        if(heartBeatBOE != null){
            String eventName = heartBeatBOE.getEventName();
            if(eventName !=null && eventName.compareTo("HEARTBEAT")==0){
                List<KrowdCustomProperty> boeProps = heartBeatBOE.getCustomProperties();
                if(boeProps !=null && boeProps.size() >0){
                    String sourceID = null;
                    KrowdCustomProperty boeProp = null;
                    for(int i=0; i<boeProps.size(); i++){
                        boeProp = boeProps.get(i);
                        if(boeProp.getName().compareTo("SourceID")==0){
                            sourceID = boeProp.getValue();
                            // logger.info("------- Source ID from HeartBeat --- {0}",sourceID);
                        }
                    }
                    
                    if(sourceID !=null && sourceID.compareTo(uuid) !=0){
                        ConcurrentHashMap<String, List<String>> nodeUsersMap = this.userMap.get(sourceID);
                        List<KrowdActor> onlineUsers = heartBeatBOE.getSecondaryActors();                        
                        if(onlineUsers != null && !onlineUsers.isEmpty()){
                            // logger.info("---- Online users detected in source {0} ---",sourceID);
                            
                            if(nodeUsersMap == null){
                                nodeUsersMap = new ConcurrentHashMap<String, List<String>>();
                                this.userMap.put(sourceID, nodeUsersMap); 
                            }else{
                                nodeUsersMap.clear();
                            }
                            
                            KrowdActor kActor = null;
                            for(int i=0; i< onlineUsers.size(); i++){
                                kActor = onlineUsers.get(i);
                                if(kActor != null && kActor.getId() != null){
                                    //logger.info("---- Online user {0} on source {1}",new Object[]{kActor.getId(), sourceID});
                                    nodeUsersMap.put(kActor.getId(), new ArrayList<String>());    
                                }                                
                            }
                        }else{
                            if(nodeUsersMap != null && !nodeUsersMap.isEmpty()){
                                nodeUsersMap.clear();
                                this.userMap.remove(sourceID);
                            }
                            //logger.info("------- No Connected users for Source ID {0}",sourceID);
                        }
                    }else{
                        logger.info("----------- Source ID not found in Heart Beat---------");
                    }
                }                                
            }
        }
    }
    
    private void addUserToConnectedUsersMap(String sourceID,String userName, String resourceUUID){
        ConcurrentHashMap<String, List<String>> currentNodeUsersMap = this.userMap.get(sourceID);
        if(currentNodeUsersMap == null){
            currentNodeUsersMap = new ConcurrentHashMap<String, List<String>>();
            this.userMap.put(sourceID, currentNodeUsersMap);            
        }
        
        List<String> userConnections = currentNodeUsersMap.get(userName);
        
        if(userConnections == null){
            userConnections = new ArrayList<String>();
            userConnections.add(resourceUUID);
            //logger.info("------ Adding resourceID for user {0}, {1}",new Object[]{userName, resourceUUID});
            currentNodeUsersMap.put(userName, userConnections);
        }else{
            if(userConnections.contains(resourceUUID)){
                logger.info("------ ResourceID for user {0}, {1} already exists",new Object[]{userName, resourceUUID});
                //logger.info("Resource entry already exists for the user "+ userName);
            }else{
                //logger.info("------ Adding resourceID for user {0}, {1}",new Object[]{userName, resourceUUID});
                userConnections.add(resourceUUID);
            }
        }
    }
    
    private void removeUserFromConnectedUsersMap(String sourceId, String userName, String resourceUUID){
        ConcurrentHashMap<String, List<String>> currentNodeUsersMap = this.userMap.get(sourceId);
        
        if(currentNodeUsersMap != null){
            List<String> userConnections = currentNodeUsersMap.get(userName);
            if(userConnections  != null){
                int idx = userConnections.indexOf(resourceUUID);
                if(idx > -1){
                    userConnections.remove(idx);
                }
                
                if(userConnections.isEmpty()){
                    //logger.info("------ Removing resourceID for user {0}, {1}",new Object[]{userName, resourceUUID});
                    currentNodeUsersMap.remove(userName);
                }else{
                    logger.info("-------- No more resources found for user {0}",userName);
                }
            }else{
                logger.info("------- No userMap entry for user {0}",userName);
            }
        }
    }

    @Get
    public void onOpen(final AtmosphereResource resource) { //will be called for every browser session
        resource.addEventListener(new AtmosphereResourceEventListenerAdapter() {

                /*public void onSuspend(AtmosphereResourceEvent event) {
                    //logger.info("Inside onSuspend ..... {0}", event);
                    AtmosphereResource resource = event.getResource(); 
                    String resourceUUID = resource.uuid();
                    addUserToConnectedUsersMap(uuid,getUserName(event), resourceUUID);                    
                    //logger.info("-------- ADD : Entries in userMap {0} --",userMap);
                }*/

                public void onDisconnect(AtmosphereResourceEvent event) {
                    /*if(event.isClosedByClient() || event.isClosedByApplication()){
                        logger.info("Inside the onDisconnect - CloseBrowser .. {0}", event);
                    }else{
                        logger.info("Inside the onDisconnect .. {0}", event);
                    }*/                    
                    AtmosphereResource resource = event.getResource();        
                    String resourceUUID = resource.uuid();
                    removeUserFromConnectedUsersMap(uuid,getUserName(event), resourceUUID);                                               
                    //logger.info("-------- DEL : Entries in userMap {0} --",userMap);
                }

                public void onClose(AtmosphereResourceEvent event) {
                    //logger.info("Inside the onClose .. {0}", event);
                    AtmosphereResource resource = event.getResource();        
                    String resourceUUID = resource.uuid();
                    removeUserFromConnectedUsersMap(uuid,getUserName(event), resourceUUID);                    
                }
                
                /*public void onBroadcast(AtmosphereResourceEvent event) {
                    logger.info("Inside the onBroadcast .. {0}", event);
                }
                
                public void onResume(AtmosphereResourceEvent event) {
                    logger.info("Inside the onResume .. {0}", event);
                }

                public void onThrowable(AtmosphereResourceEvent event) {
                    logger.info("Inside the onThrowable .. {0}", event);
                }*/

                /*public void onHeartBeat(AtmosphereResourceEvent event) {
                    logger.info("Inside the onHeartBeat .. {0}", event);
                }*/

            });
    }

    @Ready(encoders = { JacksonEncoder.class })
    public UserStatus onReady(final AtmosphereResource r) {
        //logger.info("Browser {0} connected.", r);   
        String resourceUUID = r.uuid();
        addUserToConnectedUsersMap(uuid,getUserName(r), resourceUUID);
        UserStatus status = new UserStatus();
        status.processUsers(userMap);
        return status;
    }

    @Disconnect
    public void onDisconnect(AtmosphereResourceEvent event) {
        //logger.info("-------- On Disconnect Event--------- {0}",event);
        AtmosphereResource resource = event.getResource();        
        String resourceUUID = resource.uuid();
        removeUserFromConnectedUsersMap(uuid,getUserName(event), resourceUUID);   
    }

    /*@Resume
    public void onResume(AtmosphereResourceEvent event) {
        logger.info("-------- On Resume Event--------- {0}",event);
        AtmosphereResource resource = event.getResource();        
        String resourceUUID = resource.uuid();
        String userName = getUserName(event);
        addUsertoConnectedUsersMap(userName, resourceUUID);     
    }*/
    
    private String getUserName(AtmosphereResourceEvent event){
        AtmosphereResource resource = event==null? null : event.getResource();  
        return getUserName(resource);
    }

    private String getUserName(AtmosphereResource resource){
        String userName = "anonymous";
        if(resource != null){
            java.security.Principal principal = resource.getRequest().getUserPrincipal();
            if(principal != null){
                userName = principal.getName();
            }
        }
        return userName;
    }

    /*@Message(encoders = { JacksonEncoder.class })
    public Message onMessage(Message message) throws IOException {
        return message;
    }*/

    @Message(encoders = { MessageEncoder.class },
             decoders = { UserStatusDecoder.class })
    public UserStatus onStatusUpdate(UserStatus message) throws IOException {
        UserStatus status = new UserStatus();
        status.processUsers(userMap);
        return status;
    }

    public void destroy() {
        logger.info("------------- UUID In Destroy------------"+this.uuid);
        
        logger.info("Closing Atmosphere JMS");
        if(timerTask != null){
            timerTask.cancel();
        }

        if(timer != null){            
            timer.cancel();
            timer.purge();
            timer = null;
        }
        if (atmosConnection != null) {
            try {
                atmosConnection.stop();
                atmosConnection.close();
            } catch (Exception e) {
                logger.severe(e);
            } finally {
                atmosConnection = null;
            }
        }

        if (atmosSession != null) {
            try {
                atmosSession.close();
            } catch (Exception e) {
                logger.severe(e);
            } finally {
                atmosSession = null;
            }
        }

        if (atmosConsumer != null) {
            try {
                atmosConsumer.close();
            } catch (Exception e) {
                logger.severe(e);
            } finally {
                atmosConsumer = null;
            }
        }

        logger.info("Done Closing Atmosphere JMS");
    }

}
