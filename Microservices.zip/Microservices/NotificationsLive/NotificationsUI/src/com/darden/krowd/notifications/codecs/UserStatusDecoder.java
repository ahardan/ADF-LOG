package com.darden.krowd.notifications.codecs;


import com.darden.krowd.notifications.payload.UserStatus;

import java.io.IOException;

import org.atmosphere.config.managed.Decoder;

import org.codehaus.jackson.map.ObjectMapper;


public class UserStatusDecoder implements Decoder<String, UserStatus> {

    private final ObjectMapper mapper = new ObjectMapper();
    
    @Override
    public UserStatus decode(String s) {
        try {
            return mapper.readValue(s, UserStatus.class);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}