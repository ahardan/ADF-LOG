package com.darden.krowd.notifications.codecs;

import com.darden.krowd.common.notification.KrowdBusinessObjectEvent;

import java.io.IOException;

import java.util.Map;

import org.atmosphere.config.managed.Encoder;

import org.codehaus.jackson.map.ObjectMapper;


public class BusinessObjectEventEncoder implements Encoder<KrowdBusinessObjectEvent, String>{
    private final ObjectMapper mapper = new ObjectMapper();
    
    public BusinessObjectEventEncoder() {
        super();
    }
    
    @Override
    public String encode(KrowdBusinessObjectEvent boe) {
        try {
            return mapper.writeValueAsString(boe);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } 
    }

}
