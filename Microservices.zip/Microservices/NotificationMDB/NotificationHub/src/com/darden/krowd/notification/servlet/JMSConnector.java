package com.darden.krowd.notification.servlet;

import com.darden.krowd.common.KrowdUtility;
import com.darden.krowd.notification.connections.ExternalCEFQueue;
import com.darden.krowd.notification.connections.InternalCEFQueue;

import com.darden.krowd.notification.connections.SOANotificationTopic;

import java.util.ArrayList;
import java.util.List;

import javax.jms.JMSException;
import javax.naming.NamingException;

import oracle.adf.share.logging.ADFLogger;

public class JMSConnector{
    ADFLogger logger = ADFLogger.createADFLogger(JMSConnector.class);
    private static final String noOfIntConsumersPerApp = KrowdUtility.getInstance().getProperties().getProperty("ISHIFT_INT_QUEUE_NO_OF_CONSUMERS");
    private static final String noOfExtConsumersPerApp = KrowdUtility.getInstance().getProperties().getProperty("ISHIFT_EXT_QUEUE_NO_OF_CONSUMERS");
    private static JMSConnector connector;
    List<ExternalCEFQueue> extQueues = new ArrayList<ExternalCEFQueue>();
    List<InternalCEFQueue> intQueues = new ArrayList<InternalCEFQueue>();
    private JMSConnector() {
        try {
            
            int noOfExtConsumers = getNoOfExtConsumers();
            for(int i=0; i< noOfExtConsumers; i++){
                extQueues.add(new ExternalCEFQueue());    
            }
            
            int noOfIntConsumers = getNoOfIntConsumers();
            for(int i=0; i< noOfIntConsumers; i++){
                intQueues.add(new InternalCEFQueue());    
            }
        } catch (NamingException e) {
            e.printStackTrace();
        } catch (JMSException e){
            e.printStackTrace();        
        }
    }
    
    private int getNoOfExtConsumers(){
        int noOfExtConsumers = 1;
        if(noOfExtConsumersPerApp != null){
            try{
                noOfExtConsumers = Integer.parseInt(noOfExtConsumersPerApp);                
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        return noOfExtConsumers;
    }
    
    private int getNoOfIntConsumers(){
        int noOfIntConsumers = 1;
        if(noOfIntConsumersPerApp != null){
            try{
                noOfIntConsumers = Integer.parseInt(noOfIntConsumersPerApp);                
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        return noOfIntConsumers;
    }
    
    
    public static JMSConnector buildInstance(){
        if(connector != null){
            return connector;
        }else{
            return new JMSConnector();
        }
    }
    
    public void closeConnections() throws NamingException, JMSException {
        //InternalCEFQueue.ensureConnection().closeConnections();
        for(ExternalCEFQueue q : extQueues){
            q.closeConnections();    
        }
        
        for(InternalCEFQueue q : intQueues){
            q.closeConnections();    
        }
        
        //SOANotificationTopic.ensureConnection().closeConnections();
    }
}
