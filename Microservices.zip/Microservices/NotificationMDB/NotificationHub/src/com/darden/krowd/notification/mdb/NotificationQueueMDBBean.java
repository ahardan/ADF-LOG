package com.darden.krowd.notification.mdb;


import com.darden.krowd.common.KrowdUtility;
import com.darden.krowd.notification.handler.BusinessObjectEventHandler;
import com.darden.krowd.notifications.model.applicationModule.NotificationsAMImpl;
import com.darden.krowd.notifications.model.applicationModule.common.NotificationsAM;

import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.ObjectCodec;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;

import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;



/**
 * @smishra: Reference Implementation: http://www.jobinesh.com/2013/04/what-you-may-need-to-know-while-calling.html
 */
/*@MessageDriven(mappedName = "jms/social/cefQueue",
               activationConfig = { @ActivationConfigProperty(propertyName =
                                                              "acknowledgeMode",
                                                              propertyValue =
                                                              "Auto-acknowledge"),
                                    @ActivationConfigProperty(propertyName =
                                                              "destinationType",
                                                              propertyValue =
                                                              "javax.jms.Queue") })*/
//@Interceptors(value = ADFContextInterceptor.class)
@Deprecated
public class NotificationQueueMDBBean implements MessageListener {
    private static final ADFLogger logger =
        ADFLogger.createADFLogger(NotificationQueueMDBBean.class);
    //private static final String KROWD_NOTIFICATION_ACTIVITY_TYPE_FILTER = "KROWD_NOTIFICATION_ACTIVITY_TYPE_FILTER";
    //String krowdNotificationActivityTypesFilter = (String)KrowdUtility.getInstance().getProperties().get(KROWD_NOTIFICATION_ACTIVITY_TYPE_FILTER);

    public void onMessage(Message message) {
//        logger.severe("_____message Recieved NotificationQueueMDB");
//        ObjectMessage objectMessage = (ObjectMessage)message;
//        BusinessObjectEvent bizObjEv;
//        try {
//            bizObjEv = (BusinessObjectEvent)objectMessage.getObject();
//            BusinessObjectEventHandler handler = new BusinessObjectEventHandler();
//            Date messageTime = new Date(message.getJMSTimestamp());
//            handler.handle(bizObjEv, messageTime);
//        } catch (JMSException ex) {
//            logger.severe("JMSException ::: " + ex.getMessage());
//            ex.printStackTrace();
//        }
    }
}


