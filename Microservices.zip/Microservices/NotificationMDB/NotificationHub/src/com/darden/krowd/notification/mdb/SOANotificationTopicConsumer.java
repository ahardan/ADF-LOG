package com.darden.krowd.notification.mdb;

import com.darden.commonwsdl.common.xsd.notificationservicev2.SendNotificationEventRequestType;
import com.darden.krowd.common.notification.KrowdBusinessObjectEvent;
import com.darden.krowd.common.util.KrowdQueueSender;
import com.darden.krowd.notification.connections.SOANotificationTopic;

import com.darden.krowd.model.converter.SoaEBOToBusinessObjectConverter;

import com.darden.krowd.notifications.model.applicationModule.common.NotificationsAM;

import java.io.IOException;

import java.util.UUID;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import javax.jms.TextMessage;

import javax.naming.NamingException;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;

import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;

import oracle.jbo.client.Configuration;
import oracle.jbo.common.ampool.ApplicationPool;
import oracle.jbo.common.ampool.PoolMgr;
import oracle.jbo.common.ampool.SessionCookie;


import org.xml.sax.SAXException;

@MessageDriven(name = "KrowdNotificationConsumer", activationConfig = { 
@ActivationConfigProperty(propertyName = "destinationJndiName", propertyValue = "jms.topic.NotificationEventV1"), 
@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Topic"), 
@ActivationConfigProperty(propertyName = "connectionFactoryJndiName", propertyValue = "	jms.cf.KrowdNotificationEventV1Subscriber"), 
@ActivationConfigProperty(propertyName = "initialContextFactory", propertyValue = "weblogic.jndi.WLInitialContextFactory"), 
@ActivationConfigProperty(propertyName = "topicMessagesDistributionMode", propertyValue = "One-Copy-Per-Application"), 
@ActivationConfigProperty(propertyName = "subscriptionDurability", propertyValue = "Durable") }) 
public class SOANotificationTopicConsumer implements MessageListener{
    ADFLogger logger = ADFLogger.createADFLogger(SOANotificationTopicConsumer.class);
    public SOANotificationTopicConsumer() {
        super();
    }

    public void onMessage(Message msg) {
        logger.info("-- Message recieved in SOANotificationTopicConsumer");
        if (msg instanceof TextMessage) {
            TextMessage message = (TextMessage)msg;
            KrowdBusinessObjectEvent boe;
            String exceptionMsg = null;
            try {
                boe = new SoaEBOToBusinessObjectConverter().convert(message.getText());
                logger.info("Xml to BOE: "+ boe);
                if(boe != null){
                    KrowdQueueSender sender = null;
                    sender = new KrowdQueueSender();
                    sender.sendExternalEvent(boe);   
                    sender.close();
                    logger.info(" Event sent to Internal Queue and connection closed");
                }
            } catch (JAXBException e) {
                e.printStackTrace();
                exceptionMsg = e.getMessage();
                logger.severe(e.getMessage());
            } catch (ParserConfigurationException e) {
                e.printStackTrace();
                exceptionMsg = e.getMessage();
                logger.severe(e.getMessage());
            } catch (SAXException e) {
                e.printStackTrace();
                exceptionMsg = e.getMessage();
                logger.severe(e.getMessage());
            } catch (IOException e) {
                e.printStackTrace();
                exceptionMsg = e.getMessage();
                logger.severe(e.getMessage());
            } catch (JMSException e) {
                e.printStackTrace();
                exceptionMsg = e.getMessage();
                logger.severe(e.getMessage());
            } catch (NamingException e) {
                e.printStackTrace();
                exceptionMsg = e.getMessage();
                logger.severe(e.getMessage());
            } catch (Exception e){//For Any NPEs
                e.printStackTrace();
                exceptionMsg = e.getMessage();
                logger.severe(e.getMessage());
            }
            if(exceptionMsg != null){
                logger.severe(exceptionMsg);       
                logger.severe("-------Error Consuming Messsage. Will not retry. Logging into error log----");
                // Log ERROR in the ERROR table
                NotificationsAM am = null;
                //SessionCookie sc = null;
                try{
//                        sc = _getUserSessionCookie();
//                        NotificationsAM am =
//                            (NotificationsAM)sc.useApplicationModule();
                                    am = 
                    (NotificationsAM)Configuration.createRootApplicationModule("com.darden.krowd.notifications.model.applicationModule.NotificationsAMLocal",
                                                                                                                               "NotificationsAMLocal");
                        TextMessage origMessage = (TextMessage)msg;
                        am.logQueueError(exceptionMsg, origMessage.getText());
                    } catch (Exception ex) {
                        logger.severe("Generic Exception ::: " + ex.getMessage());
                        ex.printStackTrace();
                    } finally {
//                        if (sc != null) {
//                            if (!sc.isApplicationModuleReleased()) {
//                                sc.releaseApplicationModule(sc.SHARED_MANAGED_RELEASE_MODE);
//                            }
//                        }
                        if(am != null){
                            Configuration.releaseRootApplicationModule(am, false);
                        }
                    }
            }
        }
    }
    
//    private SessionCookie _getUserSessionCookie() {
//        //        PoolMgr poolMgr = PoolMgr.getInstance();
//        logger.info("-----soa Handler PoolMgr = " + PoolMgr.getInstance());
//        ApplicationPool pool =
//            PoolMgr.getInstance().findPool("com.darden.krowd.notifications.model.applicationModule.NotificationsAMLocal",
//                                           "com.darden.krowd.notifications.model.applicationModule",
//                                           "NotificationsAMLocal", null);
//        UUID uid = UUID.randomUUID();
//        SessionCookie cookie =
//            pool.findOrCreateSessionCookie(ADFContext.getCurrent().getADFApplicationUID(),
//                                           uid.toString(), null);
//        return cookie;
//    }

}
