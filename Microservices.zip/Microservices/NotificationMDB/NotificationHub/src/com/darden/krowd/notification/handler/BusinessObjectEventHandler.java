package com.darden.krowd.notification.handler;

import com.darden.krowd.common.KrowdUtility;
import com.darden.krowd.common.cache.LDAPCacheUtil;
import com.darden.krowd.common.dto.KrowdUserDTO;
import com.darden.krowd.common.notification.KrowdActor;
import com.darden.krowd.common.notification.KrowdBusinessObjectEvent;
import com.darden.krowd.common.notification.KrowdCustomProperty;
import com.darden.krowd.notifications.model.applicationModule.NotificationsAMImpl;
import com.darden.krowd.notifications.model.applicationModule.common.NotificationsAM;

import com.darden.krowd.targetedmessaging.model.applicationmodule.common.MessagesAM;

import java.io.FileInputStream;

import java.io.IOException;
import java.io.ObjectInputStream;

import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import oracle.adf.share.ADFContext;

import oracle.adf.share.logging.ADFLogger;

import oracle.jbo.client.Configuration;
import oracle.jbo.common.ampool.ApplicationPool;
import oracle.jbo.common.ampool.PoolMgr;
import oracle.jbo.common.ampool.SessionCookie;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

public class BusinessObjectEventHandler {
    private static final ADFLogger logger =
        ADFLogger.createADFLogger(BusinessObjectEventHandler.class);
    private static final String KROWD_APP_ROLLOUT_RULES_CONFIG = KrowdUtility.getInstance().getProperties().getProperty("KROWD_APP_ROLLOUT_RULES_CONFIG");
    Map<String, List<String>> rolloutExclusionRules;
    Map<String, Map<String, String>> allowedActivityTypes;

    public BusinessObjectEventHandler() {
        super();
        int totalEventsSupported = 0;
        allowedActivityTypes = new HashMap<String, Map<String, String>>();
        String[] webcenterAllowedEvents = (KrowdUtility.getInstance().getProperties().getProperty("NOTIFICATION_WEBCENTER_ALLOWED_EVENTS")).split("##");
        Map<String, String> allowedEvents = new HashMap<String, String>();
        for(String event : webcenterAllowedEvents){
            allowedEvents.put(event, event);
            totalEventsSupported++;
        }
        allowedActivityTypes.put("webcenter", allowedEvents);
        String[] ishiftAllowedEvents = (KrowdUtility.getInstance().getProperties().getProperty("NOTIFICATION_ISHIFT_ALLOWED_EVENTS")).split("##");
        allowedEvents = new HashMap<String, String>();
        for(String event : ishiftAllowedEvents){
            allowedEvents.put(event, event);
            totalEventsSupported++;
        }
        allowedActivityTypes.put("ISHIFT", allowedEvents);
        String[] krowdAllowedEvents = (KrowdUtility.getInstance().getProperties().getProperty("NOTIFICATION_KROWD_ALLOWED_EVENTS")).split("##");
        allowedEvents = new HashMap<String, String>();
        for(String event : krowdAllowedEvents){
            allowedEvents.put(event, event);
            totalEventsSupported++;
        }
        allowedActivityTypes.put("KROWD", allowedEvents);
        
        String[] timeOffAllowedEvents = (KrowdUtility.getInstance().getProperties().getProperty("NOTIFICATION_LMS_ALLOWED_EVENTS")).split("##");
        allowedEvents = new HashMap<String, String>();
        for(String event : timeOffAllowedEvents){
            allowedEvents.put(event, event);
            totalEventsSupported++;
        }
        allowedActivityTypes.put("LMS", allowedEvents);
        
        logger.info("BusinessObjectEventHandler totalEventsSupported = "+ totalEventsSupported);
        
        if(KROWD_APP_ROLLOUT_RULES_CONFIG != null && KROWD_APP_ROLLOUT_RULES_CONFIG.length() > 0){
            rolloutExclusionRules = new HashMap<String, List<String>>();
            try {
                ObjectMapper mapper = new ObjectMapper();
                rolloutExclusionRules = (Map)mapper.readValue(KROWD_APP_ROLLOUT_RULES_CONFIG, Object.class);
            } catch (JsonParseException e) {
                e.printStackTrace();
            } catch (JsonMappingException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }   
        }
    }

    public void handle(KrowdBusinessObjectEvent bizObjEv, Date jmsTimestamp) throws Exception {
        //SessionCookie sc = null;
        NotificationsAM notificationsAM = null;
        MessagesAM messagesAM = null;
        try {
            Map<String, String> allowedEventsForApp = allowedActivityTypes.get(bizObjEv.getAppId());
            boolean isEventNameSupported = allowedEventsForApp != null && allowedEventsForApp.containsKey(bizObjEv.getEventName());
            logger.info(":^:^:^:>>>>> appId = " + bizObjEv.getAppId() +
                          " ,::: eventName = " + bizObjEv.getEventName() + 
                          ", isEventNameSupported= "+ isEventNameSupported);
            
            if (bizObjEv.getEventName() != null && isEventNameSupported) {
                logger.info(":::NotificationMDB::onMessage: Event Name : " +
                              bizObjEv.getEventName());
                if (!activityTimeSpecifiedInPayload(bizObjEv)) {
                    logger.info("BusinessObjectEventHandler:: Activity Time not specified in SOA Payload. Replacing with JMSTimestamp"+ jmsTimestamp);
                    addActivityTimeToPayload(jmsTimestamp, bizObjEv);
                }

//                sc = _getUserSessionCookie();
//                NotificationsAM notificationsAM =
//                    (NotificationsAM)sc.useApplicationModule();
                if(_isEventExcludedFromRolloutRules(bizObjEv)){
                    notificationsAM = 
                        (NotificationsAM)Configuration.createRootApplicationModule("com.darden.krowd.notifications.model.applicationModule.NotificationsAMLocal",
                                                                                                                                   "NotificationsAMLocal");
                    logger.info("______NotificationBroadcaster Queue onMessage notificationAM = " +
                                  notificationsAM);
                    if (notificationsAM != null) {
                        if(bizObjEv.getEventName().equalsIgnoreCase("KROWD_MESSAGING") 
                            || bizObjEv.getEventName().equalsIgnoreCase("KROWD_SPLASH")
                        || bizObjEv.getEventName().equalsIgnoreCase("KROWD_SPLASH_PREVIEW")){
                            logger.info("Only Pushing notifications");
                            notificationsAM.pushNotifications(bizObjEv);
                        }else if(bizObjEv.getEventName().equalsIgnoreCase("NEW_USER_REGISTRATION")) {
                            logger.info("NEW_USER_REGISTRATION event processing");
                            messagesAM = 
                                (MessagesAM)Configuration.createRootApplicationModule("com.darden.krowd.targetedmessaging.model.applicationmodule.MessagesAMLocal",
                                                                                                                                           "MessagesAMLocal");
                            logger.info("______NotificationBroadcaster Queue onMessage MessagesAM = " +
                                          messagesAM);        
                            KrowdActor primaryActor = bizObjEv.getPrimaryActor();
                            if(primaryActor != null && primaryActor.getId() != null)
                                messagesAM.seedSplashMessagesForNewlyRegisteredUser(primaryActor.getId());
                        }else {
                            logger.info("Creating inbox rows and Pushing notifications");
                            notificationsAM.saveBusinessObjectEvent(bizObjEv);
                        }
                    }
                    //TODO: Broadcast in Topic for Atmosphere
                    //broadcaster.notifyResources(new Notification(bizObjEv,broadcasterId),true);                    
                } else {
                    logger.severe(":::: appId = " + bizObjEv.getAppId() +
                                  " ,::: eventName = " + bizObjEv.getEventName() +" is not supported currently for user's location.");
                }
            } else {
                logger.severe(":::: appId = " + bizObjEv.getAppId() +
                              " ,::: eventName = " + bizObjEv.getEventName() +" combination not supported currently.");
            }
        } catch (Exception e) {
            logger.severe("Generic Exception ::: " + e.getMessage());
            e.printStackTrace();
            throw e;
        } finally {
//            if (sc != null) {
//                if (!sc.isApplicationModuleReleased()) {
//                    sc.releaseApplicationModule(sc.SHARED_MANAGED_RELEASE_MODE);
//                }
//            }
            if(notificationsAM != null){
                Configuration.releaseRootApplicationModule(notificationsAM, true);    
            }
            
            if(messagesAM != null){
                Configuration.releaseRootApplicationModule(messagesAM, true);    
            }            
        }
    }
    
    /**
     *    Example:
     *    Will allow the event only for configured restaurants, otherwise return false 
     *    {
            "TIMEOFF": ["1005", "1006"], 
            "EMPSCHEDULE": ["1005", "1006"] 
           }
     * @param eventName
     * @return
     */
    private boolean _isEventExcludedFromRolloutRules(KrowdBusinessObjectEvent boe){
        boolean isEventSupportedForRestaurant = true;
        String eventName = boe.getEventName();
        if(rolloutExclusionRules != null){
            KrowdActor sender = boe.getPrimaryActor();
            logger.info("Trying to get userdetail for userId "+ sender.getId());
            KrowdUserDTO senderUser = LDAPCacheUtil.getInstance().getUser(sender.getId());
            String senderUserLocationId = senderUser.getLocationId();
            logger.info("user location = "+ senderUserLocationId);
            Set<String> eventNames = rolloutExclusionRules.keySet();
            for(String ruleEventName : eventNames){
                List<String> restaurantIds = rolloutExclusionRules.get(ruleEventName);//approve, deny
                if(eventName.equalsIgnoreCase(ruleEventName)){//configuration exists for eventName
                    logger.info("eventName = "+ ruleEventName +" configured for rollout. Will check eligible restaurants now.");
                    Map<String, String> restMap = new HashMap<String, String>();
                    for(String locId : restaurantIds){//approve: 1005, 1122
                        restMap.put(locId, locId);
                    }
                    logger.info("No of locations = "+ restMap.size()+", configured for eventName = "+ eventName);
                    if(restMap.containsKey(senderUserLocationId)){
                        isEventSupportedForRestaurant = true;
                        logger.info("TRUE:: Evaluating rollout criteria primary sender's locationId = "+ senderUserLocationId);
                        break;
                    } else {
                        isEventSupportedForRestaurant = false;
                        logger.info("FALSE:: Evaluating rollout criteria primary sender's locationId = "+ senderUserLocationId);
                        break;
                    }   
                }
            }
        }
        return isEventSupportedForRestaurant;
    }

//    private SessionCookie _getUserSessionCookie() {
//        //        PoolMgr poolMgr = PoolMgr.getInstance();
//        logger.info("-----PoolMgr = " + PoolMgr.getInstance());
//        ApplicationPool pool =
//            PoolMgr.getInstance().findPool("com.darden.krowd.notifications.model.applicationModule.NotificationsAMLocal",
//                                           "com.darden.krowd.notifications.model.applicationModule",
//                                           "NotificationsAMLocal", null);
//        UUID uid = UUID.randomUUID();
//        SessionCookie cookie =
//            pool.findOrCreateSessionCookie(ADFContext.getCurrent().getADFApplicationUID(),
//                                           uid.toString(), null);
//        return cookie;
//    }

    private boolean activityTimeSpecifiedInPayload(KrowdBusinessObjectEvent boe) {
        boolean timeSpecified = false;
        List<KrowdCustomProperty> properties = boe.getPrimaryObject() == null ? null : boe.getPrimaryObject().getCustomProperties();
        if (properties == null) {
            timeSpecified = false;
        } else {
            for (KrowdCustomProperty p : properties) {
                if (p.getName().equalsIgnoreCase(NotificationsAMImpl.CUSTOM_PROPERTIES.ACTIVITY_TIME.toString())) {
                    if (p.getValue() != null) {
                        timeSpecified = true;
                    }
                }
            }
        }
        return timeSpecified;
    }

    private void addActivityTimeToPayload(Date jmsTimestamp,
                                          KrowdBusinessObjectEvent bizObjEv) {
        //Code to add ACTIVITY_TIME
        SimpleDateFormat sdf =
            new SimpleDateFormat(NotificationsAMImpl.ACTIVITY_TIME_SDF6);
        /**
         * @gsdsmm2 Assuming that there was no delay in submitting the event to the queue, it is
         * a safe approximation to treat the jms timestamp as the activity time.
         * This is due to the fact that the activityTIme doesnt come in the default business event
         * object raised by webcenter.
         */
        String dateInStringFormat = sdf.format(jmsTimestamp);
        KrowdCustomProperty actTimeProperty = new KrowdCustomProperty();
        actTimeProperty.setName(NotificationsAMImpl.CUSTOM_PROPERTIES.ACTIVITY_TIME.toString());
        actTimeProperty.setValue(dateInStringFormat);
        
        if(bizObjEv.getPrimaryObject() != null){
            if ( bizObjEv.getPrimaryObject().getCustomProperties() == null) {
                java.util.List<KrowdCustomProperty> cs =
                    new ArrayList<KrowdCustomProperty>();
                cs.add(actTimeProperty);
                bizObjEv.getPrimaryObject().setCustomProperties(cs);
            } else {
                bizObjEv.getPrimaryObject().getCustomProperties().add(actTimeProperty);
            }    
        }
        
    }
    
    public static void main(String[] args)throws Exception{
        BusinessObjectEventHandler h = new BusinessObjectEventHandler();
        try {
                 FileInputStream fileIn = new FileInputStream("c:\\tear\\boe.ser");
                 ObjectInputStream in = new ObjectInputStream(fileIn);
                 KrowdBusinessObjectEvent e = (KrowdBusinessObjectEvent) in.readObject();
                 h.handle(e, new Date());
                 in.close();
                 fileIn.close();
              }catch(IOException i) {
                 i.printStackTrace();
                 return;
              }catch(ClassNotFoundException c) {
                 System.out.println("Employee class not found");
                 c.printStackTrace();
                 return;
              }
    }
}
