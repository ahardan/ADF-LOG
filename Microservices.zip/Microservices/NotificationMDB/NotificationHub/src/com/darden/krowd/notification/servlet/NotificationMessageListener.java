package com.darden.krowd.notification.servlet;

import com.darden.krowd.common.notification.KrowdBusinessObjectEvent;
import com.darden.krowd.model.converter.BOEToKrowdBOEConverter;
import com.darden.krowd.notification.handler.BusinessObjectEventHandler;

import com.darden.krowd.notification.mdb.SOANotificationTopicConsumer;

import java.util.Date;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;

import javax.jms.QueueSession;

import oracle.adf.share.logging.ADFLogger;

import oracle.social.network.cef.BusinessObjectEvent;


public class NotificationMessageListener implements MessageListener{
    ADFLogger logger = ADFLogger.createADFLogger(NotificationMessageListener.class);
    private QueueSession qSession;
    public NotificationMessageListener(QueueSession qSession) {
        super();
        this.qSession = qSession;
    }
    
    //Message handler to take care of both internal and external events.
    //Internal events raised by Webcenter are BusinessObjectEvents
    //Internal Events raised by krowd code are KrowdBusinessObjectEvents
    public void onMessage(Message msg) {
        BusinessObjectEvent boeEvent = null;
        KrowdBusinessObjectEvent krowdBoeEvent = null;
        ObjectMessage messageWrapper = null;
        if (msg instanceof ObjectMessage) {
            try {
                messageWrapper = (ObjectMessage)msg;
                if(messageWrapper.getObject() instanceof BusinessObjectEvent){
                    logger.info("-- BusinessObjectEvent message recieved by NotificationMessageListener " + messageWrapper.getObject());
                    boeEvent = (BusinessObjectEvent)messageWrapper.getObject();
                    krowdBoeEvent = new BOEToKrowdBOEConverter().convert(boeEvent);
                }else if(messageWrapper.getObject() instanceof KrowdBusinessObjectEvent){
                    logger.info("-- KrowdBusinessObjectEvent message recieved by NotificationMessageListener " + messageWrapper.getObject());
                    krowdBoeEvent = (KrowdBusinessObjectEvent)messageWrapper.getObject();
                }

                logger.info("---------got event in NotificationMessageListener webcenter boe event = "+ boeEvent);                
                BusinessObjectEventHandler handler = new BusinessObjectEventHandler();
                Date messageTime = new Date(msg.getJMSTimestamp());
                handler.handle(krowdBoeEvent, messageTime);
                logger.info("---------got event in NotificationMessageListener krowd boe event = "+ krowdBoeEvent);
                //msg.acknowledge();//CLIENT_ACKNOWLEDGE
                qSession.commit();
                logger.info("--------------------------Message Acknowledged-----------------------");
            } catch (Exception e){
                try {
                    qSession.rollback();
                    logger.severe(":::BOE rolled back.");
                } catch (JMSException f) {
                    logger.severe(":::Couldnot rollback message. Message will be commited in next commit----"+ e.getMessage());
                }
                logger.severe("---------Exception while processing message on queue listener----"+ e.getMessage());
                e.printStackTrace();        
            }
        }
    }
}
