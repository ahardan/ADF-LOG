package com.darden.krowd.notification.connections;

import com.darden.commonwsdl.common.xsd.notificationservicev2.SendNotificationEventRequestType;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import java.util.Hashtable;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import javax.jms.Session;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicSession;
import javax.jms.TopicSubscriber;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import oracle.adf.share.logging.ADFLogger;

import oracle.security.audit.util.Base64;

public class SOANotificationTopic implements MessageListener{
    ADFLogger logger = ADFLogger.createADFLogger(SOANotificationTopic.class);
    public final static String JNDI_FACTORY = "weblogic.jndi.WLInitialContextFactory";

    private static final String TOPIC_FACTORY = "jms.cf.KrowdNotificationEventV1Subscriber";
    private static final String TOPIC_JNDI = "jms.topic.NotificationEventV1";

    private TopicConnectionFactory tconFactory;
    private TopicConnection tcon;
    private TopicSession tsession;
    private TopicSubscriber treceiver;
    private Topic topic;
    private boolean quit = false;
    private static SOANotificationTopic SOATopic = null;
    
    private SOANotificationTopic() throws NamingException, JMSException {
        InitialContext ctx = getInitialContext();
        tconFactory = (TopicConnectionFactory)ctx.lookup(TOPIC_FACTORY);
        tcon = tconFactory.createTopicConnection();
        tcon.setClientID("KrowdNotificationClientV1");
        tsession = tcon.createTopicSession(false, Session.AUTO_ACKNOWLEDGE);
        topic = (Topic)ctx.lookup(TOPIC_JNDI);
        treceiver = tsession.createDurableSubscriber(topic, "KROWD_NOTIFICATION_SUBSCRIBER");
        treceiver.setMessageListener(this);
        tcon.start();
        logger.severe("-----------------------------SOA Notification Topic Listener started---------------------------");
    }
    
    public static SOANotificationTopic ensureConnection() throws NamingException,
                                                                 JMSException {
        if(SOATopic == null){
            SOATopic = new SOANotificationTopic();
        }
        
        return SOATopic;
    }
    
    public void onMessage(Message msg) {
        try {
            SendNotificationEventRequestType event;
            String msgText;
            if (msg instanceof ObjectMessage) {
                event = (SendNotificationEventRequestType)((ObjectMessage)msg).getObject();
                try {
                    System.out.println(SOANotificationTopic.toBase64String(event));
                    //msg.acknowledge();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                msgText= "";
            } else {
                msgText = msg.toString();
            }
            logger.info("\n\t&lt;Msg_Receiver&gt; " + msgText);
            if (msgText.equalsIgnoreCase("quit")) {
                synchronized (this) {
                    quit = true;
                    this.notifyAll(); // Notify main thread to quit
                }
            }
        } catch (JMSException jmse) {
            jmse.printStackTrace();
        }
    }

    public void closeConnections() throws JMSException {
        treceiver.close();
        tsession.close();
        tcon.close();
        logger.severe("-----------------------------SOA Notification Topic Listener CLOSED---------------------------");
    }

    private static InitialContext getInitialContext() throws NamingException {
        Hashtable env = new Hashtable();
        env.put(Context.INITIAL_CONTEXT_FACTORY, JNDI_FACTORY);
        return new InitialContext(env);
    }
    

    /** Write the object to a Base64 string. */
    private static String toBase64String( Serializable o ) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream( baos );
        oos.writeObject( o );
        oos.close();
        return Base64.toBase64(baos.toByteArray(),false); 
    }    
}
