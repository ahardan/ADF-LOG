package com.darden.krowd.portal.content.rest.service;


import com.darden.krowd.RIDCCommon.util.UCMUtil;
import com.darden.krowd.common.ContentQueryRepoUtil;
import com.darden.krowd.common.ProfileConstants;
import com.darden.krowd.common.ridc.SearchDataObject;
import com.darden.krowd.content.xml.wcm.data.DocumentType;
import com.darden.krowd.content.xml.wcm.data.ElementType;
import com.darden.krowd.cpm.rest.ContentRESTImpl;
import com.darden.krowd.cpm.rest.pojo.KDContentItem;
import com.darden.krowd.portal.content.rest.exception.BadRequestException;
import com.darden.krowd.rest.model.Activity;
import com.darden.krowd.rest.model.CommentItem;
import com.darden.krowd.rest.model.ContentItem;
import com.darden.krowd.rest.model.ContentItemList;
import com.darden.krowd.rest.model.LikeItem;
import com.darden.krowd.rest.model.ObjectReference;

import com.sun.jersey.core.header.FormDataContentDisposition;
import com.sun.jersey.multipart.FormDataParam;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.StringWriter;

import java.net.FileNameMap;
import java.net.URLConnection;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.jcr.LoginException;
import javax.jcr.RepositoryException;

import javax.naming.NamingException;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.share.security.SecurityContext;

import oracle.jcr.impl.BinaryValue;

import oracle.stellent.ridc.IdcContext;
import oracle.stellent.ridc.model.DataObject;
import oracle.stellent.ridc.model.impl.DataObjectEncodingUtils;

import oracle.wcps.cache.Cache;
import oracle.wcps.cache.CacheFactory;

import oracle.webcenter.activitystreaming.ActivityActor;
import oracle.webcenter.activitystreaming.ActivityElement;
import oracle.webcenter.activitystreaming.ActivityException;
import oracle.webcenter.activitystreaming.ActivityObject;
import oracle.webcenter.activitystreaming.ActivityPermission;
import oracle.webcenter.activitystreaming.ActivityStreamingService;
import oracle.webcenter.activitystreaming.ActivityStreamingServiceFactory;
import oracle.webcenter.comments.CommentsException;
import oracle.webcenter.comments.CommentsManager;
import oracle.webcenter.comments.CommentsServiceFactory;
import oracle.webcenter.content.integration.ID;
import oracle.webcenter.content.integration.Node;
import oracle.webcenter.content.integration.PropertyChoice;
import oracle.webcenter.content.integration.PropertyDefinition;
import oracle.webcenter.content.integration.federated.ContentManagerFactory;
import oracle.webcenter.content.integration.federated.internal.ContentContextHelper;
import oracle.webcenter.content.integration.spi.ucm.UCMCacheHelper;
import oracle.webcenter.content.integration.spi.ucm.UCMNode;
import oracle.webcenter.framework.service.ActivityType;
import oracle.webcenter.framework.service.Scope;
import oracle.webcenter.framework.service.ServiceContext;
import oracle.webcenter.framework.service.ServiceObjectType;
import oracle.webcenter.framework.service.Utility;
import oracle.webcenter.jaxrs.framework.param.ItemsPerPageParam;
import oracle.webcenter.jaxrs.framework.param.PaginationParams;
import oracle.webcenter.jaxrs.framework.param.StartIndexParam;
import oracle.webcenter.likes.Like;
import oracle.webcenter.likes.LikesException;
import oracle.webcenter.likes.LikesManager;
import oracle.webcenter.likes.LikesServiceFactory;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;


@Path("/content")
@Produces("application/json")
public class ContentResource {
    private static final ADFLogger logger = ADFLogger.createADFLogger(ContentResource.class);
    private static final Pattern WCM_URL_PATTERN = Pattern.compile("[\\[<]!--\\$wcmUrl\\([^\\)]+\\)--[\\]>]");
    //@Context private HttpServletRequest httpRequest;
    
    private CacheFactory cacheFactory;
    
    public ContentResource() {
        super();
    }
    
    private CacheFactory getCacheFactory(){
        if(cacheFactory==null)
            cacheFactory = CacheFactory.getInstance("content");
        return cacheFactory;
    }
    
    private Cache getCache(){
        return getCacheFactory().getCache("com.darden.krowd.contentQueryCache");
    }
    
    private List<String[]> getSortParams(List<String> sortBy){
        if(sortBy != null && !sortBy.isEmpty()){
            List<String[]> sortParams = new ArrayList<String[]>();
            for(String sortField : sortBy){
                if(sortField !=null){
                    if(sortField.contains(":")){
                        sortParams.add(sortField.split(":"));                                            
                    }else{
                        sortParams.add(new String[]{sortField,"ASC"});                                            
                    }
                }
            }
            return sortParams;
        }
        return null;
    }
    
    @GET
    @Path("/path/{filePath : .+}")
    @Produces("*/*")
    public Response getImage(@PathParam("filePath") String filePath) {        
        if(StringUtils.isBlank(filePath))
            throw new BadRequestException("File Path cannot be Blank");            

        try 
        {
            UCMUtil ucmUtil = UCMUtil.getInstance();  
            String dDocName = null;
            if(filePath.startsWith("/"))
                dDocName = ucmUtil.getContentIDByPath(filePath);
            else
                dDocName = ucmUtil.getContentIDByPath("/"+filePath);
            
            DataObject dataObject = ucmUtil.getDataObject(dDocName);
            
            SearchDataObject sdo = new SearchDataObject(dataObject);
            String webUrl = sdo.getWebURL();
            String fileName = FilenameUtils.getName(webUrl);
            byte[] bytes = ucmUtil.getContentAsBytes(dDocName);            
            String mimeType = URLConnection.guessContentTypeFromName(fileName);
            return Response.ok(new ByteArrayInputStream(bytes)).type(mimeType).build();            
        } catch (Exception e) {
            throw new BadRequestException(e); 
        }        
    }   
    
    @POST
    @Path("/services/{serviceId}/objectTypes/{objectType}/objects/({objectId})/comments")
    public Response createComment(CommentItem _comment, @PathParam("serviceId") String serviceId, @PathParam("objectType") String objectType, @PathParam("objectId") String objectId){
        logger.info("comment:serviceId " + serviceId + " objectType " + objectType + " objectId " + objectId);
        
        if(_comment == null || _comment.getText() == null){
            throw new BadRequestException("Comment Text is mandatory.");
        }else{
            ActivityObject activityObject = createActivityObject(serviceId, objectType, objectId);    
            try{
                CommentsManager commentsManager = CommentsServiceFactory.getInstance().getCommentsManager();
                oracle.webcenter.comments.Comment comment = commentsManager.postComment(activityObject,_comment.getText(),null);
                logger.info("INIT Comment Created with "+comment==null?"NULL":comment.getId());
                return Response.status(Response.Status.OK)
                                    .entity(new CommentItem(comment)).type("application/json")
                                    .build();
                
            }catch(CommentsException e){
                logger.severe("Error creating comment");
                logger.severe(e);
                throw new BadRequestException(e);
            }
        }        
    }   
    
    @GET
    @Path("/test")
    public Response testMethod(@QueryParam("serviceId") String serviceId,@QueryParam("activityType") String activityType){
        Scope activityScope =  ServiceContext.getContext().getScope();
        System.out.println(activityScope);
        
        ActivityStreamingServiceFactory activityStreamingServiceFactory = ActivityStreamingServiceFactory.getInstance();
        ActivityStreamingService as = activityStreamingServiceFactory.getActivityStreamingService();
        ActivityType type;

        try {
            type = as.findActivityType("com.darden.krowd.content.dardentv", "share-dardentv-activity");
            System.out.println(type);
        } catch (ActivityException e) {
            logger.severe(e);
        }
        return Response.status(Response.Status.OK)
                            .build();         
    }
    
    @POST
    @Path("/activities")
    public Response createActivity(Activity _activity){
        if(_activity ==null){
            throw new BadRequestException("Activity is mandatory");
        }
        
        if(_activity.getId() !=null){
            throw new BadRequestException("Activity ID cannot be present.");
        }
        
        if ((_activity.getServiceId() == null) || (_activity.getActivityType() == null)){
            throw new BadRequestException("Service Id & Activity Type are mandatory");
        }     
        
        String scopeId = _activity.getScope();
        Scope activityScope = null;
        if ((scopeId != null) && (!scopeId.isEmpty()) && (!"defaultScope".equalsIgnoreCase(scopeId))){
            activityScope = ServiceContext.getContext().findScopeByGUID(scopeId);
            if (activityScope == null){
                throw new BadRequestException("Unable to resolve scope");
            }
        }
        
        if (activityScope == null){
          activityScope = ServiceContext.getContext().getScope();
        }        
        
        
        try{
            ActivityStreamingServiceFactory activityStreamingServiceFactory = ActivityStreamingServiceFactory.getInstance();
            ActivityStreamingService as = activityStreamingServiceFactory.getActivityStreamingService();
                        
            String strServiceID = _activity.getServiceId();
            String strActivityType = _activity.getActivityType();            
            ActivityType type = as.findActivityType(strServiceID, strActivityType);    
            
            List<ActivityActor> actors = new ArrayList<ActivityActor>();        
            SecurityContext secContext = ADFContext.getCurrent().getSecurityContext();
            String userGuid = secContext.getUserProfile().getGUID();            
            actors.add(as.createActor(userGuid));
            List<ActivityObject> actObjects = new ArrayList<ActivityObject>();
            List<ObjectReference> objects = _activity.getObjects();
            if(objects !=null && objects.size()>0){                
                for(ObjectReference objRef : objects){
                    ServiceObjectType objectType = as.findObjectType(objRef.getServiceId(), objRef.getType());
                    ActivityObject actObj = as.createObject(objRef.getId(), objectType, objRef.getDisplayName());
                    actObjects.add(actObj);
                }
            }
            
            ActivityPermission permission = null;
            String strPermission = _activity.getPermission();
            if ((strPermission != null) && (!strPermission.isEmpty())){
              permission = ActivityPermission.valueOf(strPermission);
            }

            if (permission == null){
              permission = ActivityPermission.SHARED;
            }            

            ActivityElement element = as.createActivityElement(Utility.getApplicationName(), activityScope, strServiceID, type, actors, actObjects, permission, new Date());

            element.setDetail(_activity.getDetail());
            as.publish(element);
            _activity.setCreatedDate(element.getActivityTime());
            _activity.setId(element.getActivityID());            
        }catch(Exception e){
            throw new BadRequestException(e);
        }
        
        return Response.status(Response.Status.OK)
                            .entity(_activity).type("application/json")
                            .build();        
    }


    @POST
    @Path("/services/{serviceId}/objectTypes/{objectType}/objects/({objectId})/likes")
    public Response createLike(@PathParam("serviceId") String serviceId, @PathParam("objectType") String objectType, @PathParam("objectId") String objectId){
        logger.info("Like:serviceId " + serviceId + " objectType " + objectType + " objectId " + objectId);

        ActivityObject activityObject = createActivityObject(serviceId, objectType, objectId);    
        try{
            SecurityContext secContext = ADFContext.getCurrent().getSecurityContext();
            String userGuid = secContext.getUserProfile().getGUID();            
            LikesManager likesManager = LikesServiceFactory.getInstance().getLikesManager();
            Like like = likesManager.like(activityObject, userGuid, null);
            logger.info("INIT Like Created with "+like==null?"NULL":like.getLikeId());
            return Response.status(Response.Status.OK)
                                .entity(new LikeItem(like)).type("application/json")
                                .build();
            
        }catch(LikesException e){
            logger.severe("Error creating like");
            logger.severe(e);
            throw new BadRequestException(e);
        } 
    }  
    
    //TODO : NOT Working
    @POST
    @Path("/id1/{contentId}")
    public Response updateFile1(@PathParam("contentId") String contentId,HashMap<String,String> props){
        if(StringUtils.isBlank(contentId))
            throw new BadRequestException("Content ID cannot be Blank");            

        try 
        { 
            UCMUtil ucmUtil = UCMUtil.getInstance();  
            String dDocName = null;
            dDocName = ucmUtil.getUCMDocName(contentId);
            DataObject dataObject = ucmUtil.getDocumentInfo(dDocName);                        
            String type = dataObject.get("xWebsiteObjectType");
            
            if(type != null && type.compareToIgnoreCase("Data File")==0){
                oracle.webcenter.content.integration.Node node = ucmUtil.getWCContentNode(dDocName);    
                if(node != null){
                    String regionDefinition=(node.getProperty("xRegionDefinition").getValue().getStringValue());
                    regionDefinition = regionDefinition.toUpperCase();
                    oracle.webcenter.content.integration.Property[] properties = node.getProperties();
                    String propName;
                    String camelCasePropName;
                    oracle.webcenter.content.integration.Value val;
                    boolean updated=false;
                    for(oracle.webcenter.content.integration.Property property : properties){
                        propName = property.getName()==null?null:property.getName().trim().toUpperCase();
                        val = property.getValue();
                        if(val !=null && propName != null && propName.startsWith(regionDefinition) && val.getStringValue() != null){
                            propName = propName.substring(regionDefinition.length()+1);
                            camelCasePropName = ContentItem.toCamelCase(propName);
                            if(props.containsKey(camelCasePropName)){
                                property.setValue(new oracle.webcenter.content.integration.Value(props.get(camelCasePropName)));
                                node.setProperty(property);
                                props.remove(camelCasePropName);
                                updated = true;
                            }
                        }
                    }
                    
                    PropertyDefinition[] definitions = node.getContentType().getPropertyDefinitions();
                    oracle.webcenter.content.integration.Property prp = node.getProperty("xCategory");
                    prp.setValue(new oracle.webcenter.content.integration.Value("TNRMLCATEGORY14"));
                    
                    for(PropertyDefinition defi : definitions){
                        if(defi.getName().compareToIgnoreCase("xCategory")==0){
                            PropertyChoice[] choices = defi.getPropertyChoices();
                            for(PropertyChoice choice : choices){
                                logger.severe(choice.getValue().toString());
                            }
                            logger.severe(prp.getValue().toString());

                        }
                    }
                    if(updated){
//                        UCMBridge ucmBridge = UCMBridge.getBridge(UCMUtil.getPrimaryConnection());
//                        MutableObject dDocNamePlaceholder = (MutableObject)ContentContextHelper.getContentContext().getParameter(IUCMContext.DDOCNAME_KEY);
//                        MutableObject dIDPlaceholder = (MutableObject)ContentContextHelper.getContentContext().getParameter(IUCMContext.DID_KEY);                    
//                        DocumentManager.updateDocument(ucmBridge, StellentUtils.getDefaultIdcContext(UCMUtil.getPrimaryConnection()), UCMUtil.getPrimaryConnection(), node, dDocNamePlaceholder, dIDPlaceholder);                        
                        
                        ContentManagerFactory.getNodeManager().save(ContentContextHelper.getContentContext(),node);
                    }
                    
                    return Response.ok().build();
                }else{
                    throw new BadRequestException("Content Node Found");
                }
            }else{
                throw new BadRequestException("Unable to suupport this Content ID "+contentId);
            }                  

        } catch (Exception e) {
            throw new BadRequestException(e);
        }                
    }
    
    private HashMap<String,String> resolveSSObject(String dDocName){
        if(dDocName == null)
            return null;
        UCMUtil ucmUtil = UCMUtil.getInstance();  
        try{
            String xml = ucmUtil.getContentAsString(dDocName);
            JAXBContext jaxbContext = JAXBContext.newInstance("com.darden.krowd.content.xml.wcm.data");
            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
            JAXBElement<DocumentType>  document = (JAXBElement<DocumentType>)unmarshaller.unmarshal( new ByteArrayInputStream(xml.getBytes()) );
            DocumentType docT = document.getValue();
            List<Object> elements = docT.getElementItemsType();
            String elemName;
            String elemVal;
            ElementType elementT;
            Matcher m;
            String matchingStr;
            HashMap<String,String> result = new HashMap<String,String>();
            String url;
            for(Object element : elements){
                elementT = (ElementType)element;
                elemName = ContentItem.toCamelCase(elementT.getName());
                elemVal = elementT.getValue();   
                result.put(elemName,elemVal);
                try{
                    if(elemVal!=null){
                      m=WCM_URL_PATTERN.matcher(elemVal);
                      while(m.find()) {
                          matchingStr = elemVal.substring(m.start(),m.end());
                          url =evalIdocExt(matchingStr);
                          elemVal = elemVal.replace(matchingStr,url);
                      }
                    }
                    result.put(elemName,elemVal);
                }catch(Exception e){
                    logger.severe(e);
                }
            }
            return result;
        }catch(Exception e){
            logger.severe(e);
        }    
        return null;
    }
    
    private String evalIdocExt(String idocExpr){
        try{
            String[] parts = idocExpr.substring(idocExpr.indexOf("(")+1, idocExpr.indexOf(")")).split(",");
            if(parts[0].compareTo("'resource'")==0){
                String dDocName = parts[1].substring(1,parts[1].length()-1);
                UCMUtil ucmUtil = UCMUtil.getInstance();  
                DataObject dao = ucmUtil.getDocumentInfo(dDocName);
                SearchDataObject sdao = new SearchDataObject(dao);
                return sdao.getDocUrl();
            }
        }catch(Exception e){
            logger.severe(e);
        }
        return null;
    }

    @POST
    @Path("/id/{contentId}")
    public Response updateFile(@PathParam("contentId") String contentId,HashMap<String,String> props){
        if(StringUtils.isBlank(contentId))
            throw new BadRequestException("Content ID cannot be Blank");             

        try 
        { 
            UCMUtil ucmUtil = UCMUtil.getInstance();  
            String dDocName = null;
            dDocName = ucmUtil.getUCMDocName(contentId);
            DataObject dataObject = ucmUtil.getDocumentInfo(dDocName);                        
            String type = dataObject.get("xWebsiteObjectType");
            
            if(type != null && type.compareToIgnoreCase("Data File")==0){
                oracle.webcenter.content.integration.Node node = ucmUtil.getWCContentNode(dDocName);    
                if(node != null){
                    String xml = ucmUtil.getContentAsString(dDocName);
                    JAXBContext jaxbContext = JAXBContext.newInstance("com.darden.krowd.content.xml.wcm.data");
                    Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
                    JAXBElement<DocumentType>  document = (JAXBElement<DocumentType>)unmarshaller.unmarshal( new ByteArrayInputStream(xml.getBytes()) );
                    DocumentType docT = document.getValue();
                    List<Object> elements = docT.getElementItemsType();
                    String elemName;
                    String elemVal;
                    ElementType elementT;
                    boolean updated=false;
                    for(Object element : elements){
                        elementT = (ElementType)element;
                        elemName = ContentItem.toCamelCase(elementT.getName());
                        elemVal = props.get(elemName);
                        if(elemVal != null && elemVal.compareTo(elementT.getValue())!=0){
                            elementT.setValue(props.get(elemName));
                            updated=true;
                        }
                    }
                    if(updated){
                        StringWriter sw = new StringWriter();                     
                        Marshaller m = jaxbContext.createMarshaller();
                        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE );
                        m.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
                        m.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
                        m.marshal(document, sw);                      
                        String str = sw.toString();
                        str = str.replaceAll("&quot;","\""); 
                        str = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n"+str;
                        ucmUtil.updateDocumentByContentId(str.getBytes(),contentId); 
                    }
                    return Response.status(Response.Status.OK).entity(docT).type("application/json").build();                          
                }else{
                    throw new BadRequestException("Content Node Found");
                }
            }else{
                throw new BadRequestException("Unable to suupport this Content ID "+contentId);
            }                  

        } catch (Exception e) {
            logger.severe(e);
            throw new BadRequestException(e);
        }                
    }    
    
    @GET
    @Path("/id/{contentId}/attribute/{attributeName}")
    @Produces("*/*")
    public Response getAttrVal(@PathParam("contentId") String contentId,@PathParam("attributeName") String attributeName){
        
        if(StringUtils.isBlank(contentId))
            throw new BadRequestException("Content ID cannot be Blank");            
        try { 
            UCMUtil ucmUtil = UCMUtil.getInstance();  
            String dDocName = null;
            dDocName = ucmUtil.getUCMDocName(contentId);
            DataObject dataObject = ucmUtil.getDocumentInfo(dDocName);                        
            String type = dataObject.get("xWebsiteObjectType");

            if(type != null && type.compareToIgnoreCase("Data File")==0){
                oracle.webcenter.content.integration.Node node = ucmUtil.getWCContentNode(dDocName);    
                if(node != null){
                    String regionDefinition=(node.getProperty("xRegionDefinition").getValue().getStringValue());
                    regionDefinition = regionDefinition.toUpperCase();
                    oracle.webcenter.content.integration.Property[] properties = node.getProperties();
                    String propName;
                    String camelCasePropName;
                    oracle.webcenter.content.integration.Value val;
                    for(oracle.webcenter.content.integration.Property property : properties){
                        propName = property.getName()==null?null:property.getName().trim().toUpperCase();
                        val = property.getValue();
                        if(val !=null && propName != null && propName.startsWith(regionDefinition) && val.getStringValue() != null){
                            propName = propName.substring(regionDefinition.length()+1);
                            camelCasePropName = ContentItem.toCamelCase(propName);
                            if(attributeName.compareToIgnoreCase(camelCasePropName)==0){
                                if(val.getValue() instanceof BinaryValue){
                                    return Response.ok().entity(val.getBinaryValue().getValue()).type(val.getBinaryValue().getContentType()).build();
                                }else{
                                    return Response.ok().entity(val.getStringValue()).type("text/html").build();
                                }
                            }
                        }
                    }
                    throw new BadRequestException("Attribute "+attributeName+" cannot be found.");
                }else{
                    throw new BadRequestException("Content Node Found");
                }
            }else{
                throw new BadRequestException("Content is not a Data File.");
            }                  
            
        } catch (Exception e) {
            logger.severe(e);
            throw new BadRequestException(e);
        }          
    }
    
    
    @GET
    @Path("/id/{contentId}")
    @Produces("*/*")
    public Response getFile(@PathParam("contentId") String contentId, 
                            @DefaultValue("DEFAULT") @QueryParam("service") String service,
                            @DefaultValue("true") @QueryParam("lc") boolean processLikesComemnt,
                            @QueryParam("attr") String attr) {         
        
        if(StringUtils.isBlank(contentId))
            throw new BadRequestException("Content ID cannot be Blank");            

        try 
        { 
            UCMUtil ucmUtil = UCMUtil.getInstance();  
            String dDocName = null;
            dDocName = ucmUtil.getUCMDocName(contentId);
            DataObject dataObject = ucmUtil.getDocumentInfo(dDocName);                        
            String type = dataObject.get("xWebsiteObjectType");
            String likeId;
            
            if(service.compareToIgnoreCase("DEFAULT")==0){
                if(type != null && type.compareToIgnoreCase("Data File")==0){
                    oracle.webcenter.content.integration.Node node = ucmUtil.getWCContentNode(dDocName);    
                    if(node != null){
                        if(attr != null){
                            ContentItem contentItem = new ContentItem(node,false);
                            HashMap<String,Object> cntAttrs = contentItem.getAttributes();
                            Object val = cntAttrs.get(attr);
                            return Response.ok().entity(val).type("text/html").build();
                        }else{
                            SecurityContext secContext = ADFContext.getCurrent().getSecurityContext();
                            String userGuid = secContext.getUserProfile().getGUID();
                            ContentItem contentItem = new ContentItem(node,processLikesComemnt);                              
                            if(processLikesComemnt){
                                likeId = getLikeId(contentItem.getLikes(), userGuid);
                                contentItem.setLikeId(likeId);
                                if(likeId ==null){
                                    contentItem.setILikeIt(false);                                        
                                }else{
                                    contentItem.setILikeIt(true);    
                                }                                
                            }else{
                                contentItem.setILikeIt(false);
                            }
                            return Response.status(Response.Status.OK).entity(contentItem).type("application/json").build();
                        }
                    }else{
                        throw new BadRequestException("Content Node Found");
                    }
                }else if(dDocName != null && (dDocName.contains("DRESSNAPP_") || dDocName.contains("dressnapp_"))){
                    oracle.webcenter.content.integration.Node node;
                    try {
                        node = ucmUtil.getWCContentNode(dDocName);
                    if(node != null){
                        SecurityContext secContext = ADFContext.getCurrent().getSecurityContext();
                        String userGuid = secContext.getUserProfile().getGUID();
                        ContentItem contentItem = new ContentItem(node,processLikesComemnt);                              
                        if(processLikesComemnt){
                            likeId = getLikeId(contentItem.getLikes(), userGuid);
                            contentItem.setLikeId(likeId);
                            if(likeId ==null){
                                contentItem.setILikeIt(false);                                        
                            }else{
                                contentItem.setILikeIt(true);    
                            }                                
                        }else{
                            contentItem.setILikeIt(false);
                        }
                        return Response.status(Response.Status.OK).entity(contentItem).type("application/json").build(); 
                    }
                    } catch (Exception e) {
                        throw new BadRequestException(e);
                    }
                }else{
                    SearchDataObject sdo = new SearchDataObject(dataObject);
                    byte[] bytes = ucmUtil.getContentAsBytes(dDocName);           
                    String mimeType = sdo.getDocFormat();                    
                    return Response.ok(new ByteArrayInputStream(bytes)).type(mimeType).build();
                }                  
            }
            
            if(service.compareToIgnoreCase("DOC_INFO_BY_NAME")==0){
                return Response.status(Response.Status.OK).entity(dataObject).type("application/json").build();  
            }
            
            if(service.compareToIgnoreCase("GET_FILE")==0){
                if(type != null && type.compareToIgnoreCase("Data File")==0){
                    String xml = ucmUtil.getContentAsString(dDocName);
                    JAXBContext jaxbContext = JAXBContext.newInstance("com.darden.krowd.content.xml.wcm.data");
                    Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
                    Object  object = unmarshaller.unmarshal( new ByteArrayInputStream(xml.getBytes()) );
                    return Response.status(Response.Status.OK).entity(object).type("application/json").build();  
                }else{
                    SearchDataObject sdo = new SearchDataObject(dataObject);
                    byte[] bytes = ucmUtil.getContentAsBytes(dDocName);           
                    String mimeType = sdo.getDocFormat();                    
                    return Response.ok(new ByteArrayInputStream(bytes)).type(mimeType).build();                    
                }
            }
            
            throw new BadRequestException("Bad Service requested"); 
          
        } catch (Exception e) {
            logger.severe(e);
            throw new BadRequestException(e);
        }        
    }     
    
 
    @DELETE
    @Path("/path/{filePath : .+}")
    public Response deleteFile(
    @PathParam("filePath") String filePath) {        
        if(StringUtils.isBlank(filePath))
            throw new BadRequestException("File Path cannot be Blank");            

        try {
            UCMUtil ucmUtil = UCMUtil.getInstance();  
            String dDocName = null;
            if(filePath.startsWith("/"))
                dDocName = ucmUtil.getContentIDByPath(filePath);
            else
                dDocName = ucmUtil.getContentIDByPath("/"+filePath);
            
            ucmUtil.deleteDocument(dDocName);
            String output = "File deleted : " + filePath;
            return Response.status(200).entity(output).build();
        } catch (Exception e) {
            throw new BadRequestException(e);
        }
    }    
    
    
    @POST
    @Path("/path/{folderPath : .+}")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces({MediaType.APPLICATION_JSON})
    public Response postFile(
    @PathParam("folderPath") String folderPath,
    @FormDataParam("file") InputStream uploadedInputStream,
    @FormDataParam("file") FormDataContentDisposition fileDetail) {        
        
        if(StringUtils.isBlank(folderPath))
            throw new BadRequestException("Path cannot be Blank");            
        
        byte[] bytes;
        try {
            UCMUtil ucmUtil = UCMUtil.getInstance();      
            String fileName = fileDetail.getFileName();   
            
            String filePath = null;
            if(folderPath.startsWith("/"))
                filePath = folderPath+"/"+fileName;
            else
                filePath = "/"+folderPath+"/"+fileName;
            
             String contentId = null;
            boolean contentExists = false;
            
            try{
                contentId = ucmUtil.getContentIDByPath(filePath);    
                contentExists=true;
            }catch(Exception e){
                logger.severe("Content with filePath "+filePath+" is not found.");
                contentExists=false;
            }

            bytes = IOUtils.toByteArray(uploadedInputStream);
            
            if(contentExists){
                //perform update
                ucmUtil.updateDocumentByContentId(bytes, contentId);
                String output = "File uploaded : " + filePath;
                return Response.status(200).entity(output).build();            
            }else{
                //perform create
                FileNameMap fileNameMap = URLConnection.getFileNameMap();
                String mimeType = fileNameMap.getContentTypeFor(fileDetail.getFileName());                        
                ucmUtil.createDocument(bytes,fileDetail.getFileName(),mimeType,"/"+folderPath);
                String output = "File "+fileDetail.getFileName()+" uploaded : " + folderPath;
                return Response.status(200).entity(output).build();                
            }            
        } catch (Exception e) {
            throw new BadRequestException(e);
        }
    }    
    
    @GET
    @Path("/invalidate")    
    public Response invalidate(@QueryParam("dDocName") String dDocName,@QueryParam("dId") Integer dId){
        UCMUtil ucmUtil = UCMUtil.getInstance();
        if(ucmUtil.isContributor()){
            if(dDocName !=null){
                UCMCacheHelper.invalidateNodeEntry(new ID(dDocName), ucmUtil.getPrimaryConnection());
                if(dId!=null){
                    if(getCache().containsKey(dId.intValue())){
                        getCache().remove(dId.intValue());
                    }
                }
            }else{
                getCache().clear();
                //UCMCacheHelper.clearAllCaches();    
                ucmUtil.getCache().clear();
                UCMCacheHelper.flushNodeCaches(ucmUtil.getPrimaryConnection());
            }
            return Response.status(200).entity("Caches flushed...").build();
        }else{
            throw new BadRequestException("Available only for Contributors.");
        }
    }
    
    @GET
    @Path("/cache")    
    public Response setCacheProps(@QueryParam("enable") boolean enable){
        UCMUtil ucmUtil = UCMUtil.getInstance();
        Cache cache = ucmUtil.getCache();
        if(ucmUtil.isContributor()){
            ucmUtil.enableCache(enable);
            return Response.status(200).entity("Content Cache ..."+enable + "(current cache is + "+ cache.toString()+")").build();
        }else{
            throw new BadRequestException("Available only for Contributors. Current Cache is: "+ cache.toString());
        }
    }    
    
    @GET
    @Path("/query")
    public Response  query(@QueryParam("q") String query,
                                    @QueryParam("key") String key,
                                    @DefaultValue("en") @QueryParam("lang") String lang,
                                    @QueryParam("sortBy") List<String> sortBy,
                                    @QueryParam("forPast") Integer forPast,
                                    @DefaultValue("DY") @QueryParam("forPastUnits") String forPastUnits,                                   
                                    @DefaultValue("0") @QueryParam("startIndex") StartIndexParam startIndex,
                                    @DefaultValue("25") @QueryParam("itemsPerPage") ItemsPerPageParam itemsPerPage,                                    
                                    @DefaultValue("false") @QueryParam("nocache") boolean nocache,
                                    @DefaultValue("true") @QueryParam("lc") boolean processLikesComemnt){
            
        // Added the logic to fetch only xml contents from UCM.
        logger.info("-- Query Recieved via Rest URL -- "+query);
        query = (null != query && !query.toString().contains("xWebsiteObjectType"))? query + " <AND> xWebsiteObjectType <matches> `Data File`" : query;
        logger.info("-- Query Fired to UCM -- "+query);
        
        if(StringUtils.isNotBlank(key)){ 
            //key Name Provided
            try{                
                SecurityContext secContext = ADFContext.getCurrent().getSecurityContext(); 
                String userGuid = secContext.getUserProfile().getGUID();
                PaginationParams pagination = new PaginationParams(startIndex, itemsPerPage);
                UCMUtil ucmUtil = UCMUtil.getInstance();
                String appendQuery=null;
                Date pastDate = calculatePastDate(forPast,forPastUnits);
                if(pastDate !=null){
                    appendQuery = "  <AND> dInDate >= `:dInDate`";
                    appendQuery = appendQuery.replaceAll(":dInDate", DataObjectEncodingUtils.encodeDate(pastDate));
                }
                if(sortBy == null || sortBy.isEmpty()){
                    sortBy = new ArrayList<String>();
                    sortBy.add("dInDate:DESC");
                }
                
                if(nocache){
                    ContentQueryRepoUtil.getInstance().refresh();
                }
                int startRow = pagination.getStartIndexValue()+1;
                logger.info("-- Firing query to UCM --",appendQuery);
                List<SearchDataObject> objs = ucmUtil.searchByKey(key, appendQuery,pagination.getItemsPerPageValue()+"",startRow+"",null, getSortParams(sortBy),new Locale(lang));
                logger.info("-- Received response from UCM --");
                List<ContentItem> result = processSearchDataObjects(userGuid, processLikesComemnt, objs);
                ContentItemList contentItemList = new ContentItemList(result,pagination.getStartIndexValue(),-1);
                return Response.ok(contentItemList).build();
            }catch(Exception e){
                logger.severe(e);
                throw new BadRequestException(e);
            }        
        }else{
            if(StringUtils.isNotBlank(query)){
                try{                
                    SecurityContext secContext = ADFContext.getCurrent().getSecurityContext();
                    String userGuid = secContext.getUserProfile().getGUID();
                    UCMUtil ucmUtil = UCMUtil.getInstance();  
                    
                    String appendQuery=null;
                    Date pastDate = calculatePastDate(forPast,forPastUnits);
                    if(pastDate !=null){
                        appendQuery = "  <AND> dInDate >= `:dInDate`";
                        appendQuery = appendQuery.replaceAll(":dInDate", DataObjectEncodingUtils.encodeDate(pastDate));
                        query = query+appendQuery;
                    }
                    
                    if(sortBy == null || sortBy.isEmpty()){
                        sortBy = new ArrayList<String>();
                        sortBy.add("dInDate:DESC");
                    }                    
                    
                    PaginationParams pagination = new PaginationParams(startIndex, itemsPerPage);
                    int startRow = pagination.getStartIndexValue()+1;
                    logger.info("-- Firing query to UCM --",query);
                    List<SearchDataObject> objs = ucmUtil.search(query,pagination.getItemsPerPageValue()+"",startRow+"",null,getSortParams(sortBy),new Locale(lang)); 
                    logger.info("-- Received response from UCM --");
                    List<ContentItem> result = processSearchDataObjects(userGuid, processLikesComemnt, objs);
                    ContentItemList contentItemList = new ContentItemList(result,pagination.getStartIndexValue(),-1);
                    return Response.ok(contentItemList).build();
                }catch(Exception e){
                    logger.severe(e);
                    throw new BadRequestException(e);
                }
            }else{
                throw new BadRequestException("qry path parameter or t(shortName) is mandatory");
            }
        }
    }


    @POST
    @Path("/createContent")
    public Response createContent(KDContentItem kdContent) {
       String response =
        new ContentRESTImpl().createSpecificContent(kdContent);
        return Response.ok(response).build();
    }
    
    
    
    private Date calculatePastDate(Integer inPast,String forPastUnits){
        Date date=null;
        if(inPast !=null){
            try{
                if(inPast>0){
                    forPastUnits = forPastUnits.toUpperCase();
                    Calendar cal = Calendar.getInstance();
                    if(forPastUnits.compareTo("MI")==0){
                        cal.add(Calendar.MINUTE, -1*inPast);
                        cal.set(Calendar.SECOND, 0);
                        cal.set(Calendar.MILLISECOND, 0);                                            
                    }else if(forPastUnits.compareTo("HO")==0){
                        cal.add(Calendar.HOUR, -1*inPast);
                        cal.set(Calendar.MINUTE, 0);
                        cal.set(Calendar.SECOND, 0);
                        cal.set(Calendar.MILLISECOND, 0);                                            
                    }else if(forPastUnits.compareTo("DY")==0){
                        cal.add(Calendar.DATE, -1*inPast);
                        cal.set(Calendar.HOUR_OF_DAY, 0);
                        cal.set(Calendar.MINUTE, 0);
                        cal.set(Calendar.SECOND, 0);
                        cal.set(Calendar.MILLISECOND, 0);                                            
                    }else if(forPastUnits.compareTo("MO")==0){
                        cal.add(Calendar.MONTH, -1*inPast);
                        cal.set(Calendar.HOUR_OF_DAY, 0);
                        cal.set(Calendar.MINUTE, 0);
                        cal.set(Calendar.SECOND, 0);
                        cal.set(Calendar.MILLISECOND, 0);                                            
                    }else if(forPastUnits.compareTo("YR")==0){
                        cal.add(Calendar.YEAR, -1*inPast);
                        cal.set(Calendar.HOUR_OF_DAY, 0);
                        cal.set(Calendar.MINUTE, 0);
                        cal.set(Calendar.SECOND, 0);
                        cal.set(Calendar.MILLISECOND, 0);                                            
                    }else{
                        cal.add(Calendar.DATE, -1*inPast);
                    }
                    date = cal.getTime();
                }                
            }catch(Exception e){
                logger.severe("Failed to calculate inPast "+inPast);
            }
        }
        return date;
    }
    
    private List<Object[]> modOperator(List<String> values){
        if(values !=null && !values.isEmpty()){
            ArrayList<Object[]> ret = new ArrayList<Object[]>();
            for(String val : values){
                ret.add(new Object[]{val,"matches"});
            }
            return ret;
        }else{
            return null;
        }
    }
    
    @GET
    @Path("/{kdScopeLevel}/{kdScopeName}")
    public Response query(@PathParam("kdScopeLevel") String kdLevel,
                        @PathParam("kdScopeName") String kdScope,
                        @QueryParam("kdAssetType") List<String> kdAssetType,
                        @QueryParam("kdAssetSubType") List<String> kdAssetSubType,
                        @QueryParam("kdAssetCategory") List<String> kdAssetCategory,
                        @QueryParam("kdAssetSubCategory") List<String> kdAssetSubCategory,
                        @QueryParam("sortBy") List<String> sortBy,
                        @QueryParam("forPast") Integer forPast,
                        @DefaultValue("DY") @QueryParam("forPastUnits") String forPastUnits,                                   
                        @DefaultValue("true") @QueryParam("lc") boolean processLikesComemnt,                                   
                        @DefaultValue("0") @QueryParam("startIndex") StartIndexParam startIndex,
                        @DefaultValue("25") @QueryParam("itemsPerPage") ItemsPerPageParam itemsPerPage,                                    
                        @DefaultValue("en") @QueryParam("lang") String lang,
                        @DefaultValue("true") @QueryParam("isSSq") boolean isSsq){
        if(kdLevel != null && kdScope != null){
            List<Object[]> params = new ArrayList<Object[]>();
            params.add(new Object[]{"xKrowdScopeLevel","matches",kdLevel});
            params.add(new Object[]{"xKrowdScopeName","matches", kdScope});
            
            if(kdAssetType != null && !kdAssetType.isEmpty())
                params.add(new Object[]{"xKrowdAssetType","matches",modOperator(kdAssetType)});

            if(kdAssetSubType != null && !kdAssetSubType.isEmpty())
                params.add(new Object[]{"xKrowdAssetSubType","matches", modOperator(kdAssetSubType)});

            if(kdAssetCategory != null && !kdAssetCategory.isEmpty())
                params.add(new Object[]{"xKrowdAssetCategory","matches",modOperator(kdAssetCategory)});

            if(kdAssetSubCategory != null && !kdAssetSubCategory.isEmpty())
                params.add(new Object[]{"xKrowdAssetSubCategory","matches",modOperator(kdAssetSubCategory)});
            
            if(isSsq){
                params.add(new Object[]{"xWebsiteObjectType","matches", "Data File"});
                //params.add(new Object[]{"dDocType","matches", "Document"});
                params.add(new Object[]{"dWebExtension","matches", "xml"});            
            }
            
            Date pastDate = calculatePastDate(forPast,forPastUnits);
            if(pastDate !=null){
                params.add(new Object[]{"dInDate",">=",pastDate});
            }
            
            if(sortBy == null || sortBy.isEmpty()){
                sortBy = new ArrayList<String>();
                sortBy.add("dInDate:DESC");
            }
            
            try {
                SecurityContext secContext = ADFContext.getCurrent().getSecurityContext();
                String userGuid = secContext.getUserProfile().getGUID();
                UCMUtil ucmUtil = UCMUtil.getInstance();  
                PaginationParams pagination = new PaginationParams(startIndex, itemsPerPage);
                int startRow = pagination.getStartIndexValue()+1;
                List<SearchDataObject> objs = ucmUtil.search(params,getSortParams(sortBy),startRow,pagination.getItemsPerPageValue(),new Locale(lang)); 
                List<ContentItem> result = processSearchDataObjects(userGuid, processLikesComemnt, objs);
                ContentItemList contentItemList = new ContentItemList(result,pagination.getStartIndexValue(),-1);
                return Response.ok(contentItemList).build();
            } catch (Exception e) {
                throw new BadRequestException(e);
            }             
        }else{
            throw new BadRequestException("Level & Scope are mandatory"); 
        }
    }
    
    public List<ContentItem> processSearchDataObjects(String userGuid,boolean processLikesComemnt,List<SearchDataObject> searchDataObjects) throws Exception {
        List<ContentItem> list = new ArrayList<ContentItem>();

        if(searchDataObjects != null && !searchDataObjects.isEmpty()){
            String xWebsiteObjectType = null;
            String dDocType = null;
            String dWebExtension = null;            
            UCMNode cachedNode;
            String dDocName=null;
            Node node;
            HashMap<String,Object> cacheObject =null;
            ContentItem contentItem = null;
            UCMUtil ucmUtil = UCMUtil.getInstance(); 
            boolean isContributor = ucmUtil.isContributor();
            String likeId;
                        
            logger.info("--- Starting processing results from UCM ---");
            for(SearchDataObject sdo : searchDataObjects){
                if(ucmUtil.isCacheEnabled())
                    cacheObject = (HashMap<String, Object>)getCache().get(sdo.getId());
                if(cacheObject == null){
                    logger.info("No Cached Object found dID "+sdo.getId());
                    xWebsiteObjectType = sdo.getWebsiteObjectType();
                    dDocType = sdo.getDocType();
                    dWebExtension = sdo.getWebExtension();                
                    xWebsiteObjectType = xWebsiteObjectType==null?"":xWebsiteObjectType;
                    dDocType = dDocType==null?"":dDocType;
                    dWebExtension = dWebExtension==null?"":dWebExtension;                
                    if(xWebsiteObjectType.compareToIgnoreCase("Data File")==0 && dWebExtension.compareToIgnoreCase("xml")==0){
                        logger.info("Found a Data File. Processing.");
                        dDocName = sdo.getName();
                        cachedNode=UCMCacheHelper.getCachedNode(ucmUtil.getPrimaryConnection(),new ID(dDocName));
                        if(cachedNode !=null){                            
                            logger.info("Older Cache Node found");
                            UCMCacheHelper.invalidateNodeEntry(new ID(dDocName), ucmUtil.getPrimaryConnection());
                            logger.info("Invalidated Older Cache Node.");
                        }
                        node = ucmUtil.getWCContentNode(dDocName);
                        if(node !=null)
                            contentItem = new ContentItem(node,processLikesComemnt);                
                    }else{
                        logger.info("Found a Non-Data File. Processing.");
                        contentItem = new ContentItem(sdo.getDataObject(),processLikesComemnt);                
                    }
                    if(ucmUtil.isCacheEnabled())
                        getCache().put(sdo.getId(), contentItem.getAttributes());
                }else{
                    logger.info("Found Cached Content Item. Should processs Likes & Comments? "+processLikesComemnt);
                    contentItem = new ContentItem(cacheObject,processLikesComemnt );
                }
                
                if(contentItem!=null){
                    if(processLikesComemnt){
                        likeId = getLikeId(contentItem.getLikes(), userGuid);
                        contentItem.setLikeId(likeId);
                        if(likeId ==null){
                            contentItem.setILikeIt(false);                                        
                        }else{
                            contentItem.setILikeIt(true);    
                        }                                
                    }else{
                        contentItem.setILikeIt(false);
                    }                    
                    contentItem.setEditable(isContributor);
                    list.add(contentItem);                                                                        
                }                
            }
            logger.info("--- Done processing results from UCM ---");
        }
        return list;
    }

    private boolean checkLikes1(List<LikeItem> likes,String userGuid){
        boolean iLikeIt = false;
        if(likes != null && userGuid != null){
            for(LikeItem like : likes){
                if(like.getAuthorId().compareTo(userGuid)==0){
                    iLikeIt = true;
                    break;
                }
            }
            return iLikeIt;
        }
        
        return iLikeIt;
    }

    private String getLikeId(List<LikeItem> likes,String userGuid){
        boolean iLikeIt = false;
        String likeId=null;
        if(likes != null && userGuid != null){
            for(LikeItem like : likes){
                if(like.getAuthorId().compareTo(userGuid)==0){
                    iLikeIt = true;
                    likeId = like.getId();
                    break;
                }
            }
            return likeId;
        }
        
        return likeId;
    }
    
    public static <T> boolean contains(final T[] array, final T v) {
        if (v == null) {
            for (final T e : array)
                if (e == null)
                    return true;
        } else {
            for (final T e : array)
                if (e == v || v.equals(e))
                    return true;
        }

        return false;
    }    
    
    private ActivityObject createActivityObject(String serviceId, String objectType, String objectId)
    {
      ActivityObject obj = null;
      try {
        ActivityStreamingService as = ActivityStreamingServiceFactory.getInstance().getActivityStreamingService();
        ServiceObjectType serviceObjType = as.findObjectType(serviceId, objectType);
        obj = as.createObject(objectId, serviceObjType, objectId);
        obj.setServiceID(serviceId);
      } catch (ActivityException e) {
          logger.severe(e);
      }
      return obj;
    }   
    
    @GET
    @Path("/photos")
    public Response getPhotos(@QueryParam("userId") String userId) {          
        if (userId == null || StringUtils.isBlank(userId)) {
            userId = ADFContext.getCurrent().getSecurityContext().getUserName();
        }                
        try {
            String query = ProfileConstants.QUERYTEXT.concat("`").concat(userId).concat("`");
            UCMUtil ucmUtil = UCMUtil.getInstance();
            List<SearchDataObject> searchDataObjects = ucmUtil.search(query,new IdcContext(ProfileConstants.PHOTOALBUM_ADMIN));            
            SecurityContext secContext = ADFContext.getCurrent().getSecurityContext();
            String userGuid = secContext.getUserProfile().getGUID();            
            List<ContentItem> contentItems = processSearchDataObjects(userGuid,false,searchDataObjects);
            ContentItemList contentItemList = new ContentItemList(contentItems,0,-1);
            return Response.ok(contentItemList).build();        
        } catch (Exception e) {
            throw new BadRequestException(e);
        }
    }    
    
    @POST
    @Path("/photos")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    public Response uploadPhoto(@FormDataParam("file") InputStream uploadedInputStream,@FormDataParam("file") FormDataContentDisposition fileDetail) {          
        try {
            UCMUtil ucmUtil = UCMUtil.getInstance();      
            String fileName = fileDetail.getFileName();   
            byte[] bytes = IOUtils.toByteArray(uploadedInputStream);
            
            FileNameMap fileNameMap = URLConnection.getFileNameMap();
            String mimeType = fileNameMap.getContentTypeFor(fileDetail.getFileName());            
            
            Map<String,String> attrs = new HashMap<String,String>();
            attrs.put(ProfileConstants.DARDEN_LITERAL_DDOCTYPE,ProfileConstants.DARDEN_PHOTO_DOCTYPE);
            attrs.put(ProfileConstants.DARDEN_LITERAL_DSECURITYGROUP,ProfileConstants.KROWD);            
            String dDocName = ucmUtil.createUCMDocument(new IdcContext(ProfileConstants.PHOTOALBUM_ADMIN), bytes, fileName, mimeType, attrs);
            return Response.ok(dDocName).build();        
        } catch (Exception e) {
            throw new BadRequestException(e);
        }
    }     
    
    @GET
    @Path("/photos/{dDocName}/{name}")
    public Response getPhoto(@PathParam("dDocName") String dDocName,@PathParam("name") String name) {          
        if (dDocName == null || StringUtils.isBlank(dDocName)) {
            throw new BadRequestException("dDocName path parameter is mandatory");
        }                
        try {
            UCMUtil ucmUtil = UCMUtil.getInstance();              
            dDocName = ucmUtil.getUCMDocName(dDocName);
            DataObject dataObject = ucmUtil.getDocumentInfo(dDocName,new IdcContext(ProfileConstants.PHOTOALBUM_ADMIN));                        
            String type = dataObject.get("xWebsiteObjectType");

            if(type != null && type.compareToIgnoreCase("Data File")==0){
                String xml = ucmUtil.getContentAsString(dDocName,new IdcContext(ProfileConstants.PHOTOALBUM_ADMIN));
                JAXBContext jaxbContext = JAXBContext.newInstance("com.darden.krowd.content.xml.wcm.data");
                Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
                Object  object = unmarshaller.unmarshal( new ByteArrayInputStream(xml.getBytes()) );
                return Response.status(Response.Status.OK).entity(object).type("application/json").build();  
            }else{
                SearchDataObject sdo = new SearchDataObject(dataObject);
                String originalName = sdo.getOriginalName();
                byte[] bytes = ucmUtil.getContentAsBytes(dDocName,new IdcContext(ProfileConstants.PHOTOALBUM_ADMIN));            
                String mimeType = URLConnection.guessContentTypeFromName(originalName);
                return Response.ok(new ByteArrayInputStream(bytes)).type(mimeType).build();                    
            }
            
        } catch (Exception e) {
            throw new BadRequestException(e);
        }
    }     
    
    @DELETE
    @Path("/photos/{dDocName}/{name}")
    public Response deletePhoto(@PathParam("dDocName") String dDocName,@PathParam("name") String name) {          
        if (dDocName == null || StringUtils.isBlank(dDocName)) {
            throw new BadRequestException("dDocName path parameter is mandatory");
        }                
        try {
            UCMUtil ucmUtil = UCMUtil.getInstance();
            ucmUtil.deleteDocument(dDocName,new IdcContext(ProfileConstants.PHOTOALBUM_ADMIN));
            
            return Response.ok("Document Deleted").build();        
        } catch (Exception e) {
            throw new BadRequestException(e);
        }
    }      
    
    public static void main(String[] args) throws LoginException,
                                                  RepositoryException,
                                                  NamingException, Exception {
//        JAASAuthenticationService jas = new JAASAuthenticationService();
//        jas.login("990008937","Darden37");
//        UCMUtil ucmUtil = UCMUtil.getInstance("UCM");
//        List<SearchDataObject> listResult = ucmUtil.search("xWebsiteObjectType <matches> `Data File` <AND> dExtension <matches> `xml`  <and> xRegionDefinition <matches> `RD_ANNOUNCEMENT`",new Locale("en"));
//        ContentItem contIt = new ContentItem(ucmUtil.getWCContentNode(listResult.get(0).getName()),false);
        //System.out.println(contIt);
        //Node node = ucmUtil.getWCContentNode(listResult.get(0).getName());
        //ContentItem contentItem = new ContentItem(node,false);
        //ContentResource cResource = new ContentResource();
        //Date date = cResource.calculatePastDate(30,"DY");
        //System.out.println(date);
        //StartIndexParam startIndex = new StartIndexParam("0");
        //cResource.query("xWebsiteObjectType <matches> `Data File` <AND> dExtension <matches> `xml`  <and> xRegionDefinition <matches> `RD_LOADBADGE`", null,"en",null,300,"DY",startIndex,new ItemsPerPageParam("20"),true, true);
        //DataObject dao = UCMUtil.getInstance().getDataObject("NEWSOGHAZELTHOMPSON_EN");
        //System.out.println(dao);
//        IdcContext idcContext = UCMUtil.getInstance().getIdcContext();
//        IdcClient idcClient = UCMUtil.getInstance().getIdcClient();
//        Map obj = cResource.resolveSSObject("NEWSFORTUNE2013AMERIDREAM_EN");
//        System.out.println(obj);
        //Object obj = UCMUtil.getInstance().getNodeByID("TESSSTGS_EN");
        //System.out.println(obj);
//        Map<String,Object> params = new HashMap<String,Object>();
//        params.put("dDocName","TESSSTGS_EN");
//        List<SearchDataObject> result = UCMUtil.getInstance().search(params);
//        System.out.println(result);
//        String pg_tpl = "<div class=\"galleria\" ng-repeat=\"m in media\" on-finish-render=\"init()\">\n" + 
//        "	<a ng-href=\"{{m.src}}\"><img ng-src=\"{{m.thumb}}\" data-title=\"{{m.title}}\" data-description=\"{{m.description}}\"></a>\n" + 
//        "</div>";
        //SearchDataObject sdao = new SearchDataObject(dao);
        //System.out.println(sdao.getWebURL());
        //jas.logout();        
    }    
}
