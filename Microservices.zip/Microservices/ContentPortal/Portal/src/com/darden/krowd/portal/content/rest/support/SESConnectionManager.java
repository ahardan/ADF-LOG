package com.darden.krowd.portal.content.rest.support;



import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;

import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;

import oracle.search.query.webservice.client.OracleSearchService;

public class SESConnectionManager implements HttpSessionBindingListener {
    private static final ADFLogger LOGGER = ADFLogger.createADFLogger(SESConnectionManager.class);

    private OracleSearchService searchService;
    
    public SESConnectionManager(OracleSearchService searchService) {
        super();
        this.searchService = searchService;
    }
    
    public OracleSearchService getSearchService(){
        return this.searchService;
    }
    
    public void valueBound(HttpSessionBindingEvent httpSessionBindingEvent) {
        LOGGER.info("Search Service bound to session under attribute name "+httpSessionBindingEvent.getName());
        
        Object attrVal = httpSessionBindingEvent.getValue();
        if(attrVal != null){
            if(attrVal instanceof SESConnectionManager){
                this.searchService = ((SESConnectionManager)attrVal).getSearchService();
            }else{
                LOGGER.info("Attribute Object class "+attrVal.getClass());
            }
        }else{
            LOGGER.info("Empty search service value cannot be store ");
        }
    }

    public void valueUnbound(HttpSessionBindingEvent httpSessionBindingEvent) {
        LOGGER.info("Search Service un-bound from session under attribute name "+httpSessionBindingEvent.getName());
        LOGGER.info("Current user = "+ ADFContext.getCurrent().getSecurityContext().getUserName());
        Object attrVal = httpSessionBindingEvent.getValue();
        if(attrVal != null){
            System.out.println(attrVal);
            if(attrVal instanceof SESConnectionManager){
                this.searchService = ((SESConnectionManager)attrVal).getSearchService();
                try {                    
                    this.searchService.logout();
                } catch (Exception e) {
                    LOGGER.severe(e);
                }
            }else{
                LOGGER.info("Attribute Object class "+attrVal.getClass());
            }
        }else{
            System.out.println("NULL unbound");
        }
    }

}
