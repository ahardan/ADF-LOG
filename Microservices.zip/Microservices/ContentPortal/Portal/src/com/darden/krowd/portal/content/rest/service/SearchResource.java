package com.darden.krowd.portal.content.rest.service;


import com.darden.krowd.RIDCCommon.util.UCMUtil;
import com.darden.krowd.common.KrowdUtility;
import com.darden.krowd.common.PortalConstants;
import com.darden.krowd.common.ridc.SearchDataObject;
import com.darden.krowd.portal.content.rest.exception.BadRequestException;
import com.darden.krowd.rest.model.ContentItem;
import com.darden.krowd.rest.search.model.SesSearchResult;

import com.darden.krowd.rest.search.model.SesSearchResultItem;
import com.darden.krowd.portal.content.rest.support.SESConnectionManager;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import java.util.Properties;

import javax.naming.NamingException;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpSession;

import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import oracle.adf.mbean.share.config.AdfConfig;
import oracle.adf.mbean.share.connection.webcenter.search.SesConnectionReferenceable;
import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.share.security.authentication.JAASAuthenticationService;

import oracle.search.query.webservice.client.Attribute;
import oracle.search.query.webservice.client.AttributeLOVElement;
import oracle.search.query.webservice.client.CustomAttribute;
import oracle.search.query.webservice.client.DataGroup;
import oracle.search.query.webservice.client.Filter;
import oracle.search.query.webservice.client.OracleSearchResult;
import oracle.search.query.webservice.client.OracleSearchService;
import oracle.search.query.webservice.client.ResultElement;
import oracle.search.query.webservice.client.SCElement;
import oracle.search.query.webservice.client.Status;

import oracle.webcenter.framework.application.context.WebCenterApplicationContext;
import oracle.webcenter.framework.service.WebCenterConfig;
import oracle.webcenter.jaxrs.framework.param.ItemsPerPageParam;
import oracle.webcenter.jaxrs.framework.param.PaginationParams;
import oracle.webcenter.jaxrs.framework.param.StartIndexParam;
import oracle.webcenter.search.internal.config.SearchAdfConfig;
import oracle.webcenter.search.internal.config.SearchAdfConfigParser;


@Path("/ses")
@Produces("application/json")
public class SearchResource {
    @Context private HttpServletRequest httpRequest;
    private static final ADFLogger LOGGER = ADFLogger.createADFLogger(SearchResource.class);
    public SearchResource() {
        
    }
    
    private static int getTimeout(){
        int timeoutInMs = 30000;
        try{
            SearchAdfConfig config = SearchAdfConfig.getInstance();
             timeoutInMs= (int)config.getExecutionProperties().getTimeoutMs();    
            LOGGER.info("Got Timeout from SES Settings : "+ timeoutInMs);
        }catch(Exception e){
            LOGGER.severe(e.getMessage());
        }
        return timeoutInMs;
    }
    
    
    public static void main(String[] args) {
        Date t = new Date();
        JAASAuthenticationService jas = new JAASAuthenticationService();
        jas.logout();
    }
    
    
    
    @GET
    @Path("/search/simple")
    public Response doSimpleSearch(@QueryParam("q") String query,
                                   @DefaultValue("1") @QueryParam("startIndex") StartIndexParam startIndex,
                                   @DefaultValue("25") @QueryParam("itemsPerPage") ItemsPerPageParam itemsPerPage,  
                                   @DefaultValue("true") @QueryParam("dupRemoved") boolean dupRemoved,
                                   @DefaultValue("false") @QueryParam("dupMarked") boolean dupMarked){
        if(query==null || query.trim().compareTo("")==0){
            throw new BadRequestException("query is mandatory");  
        }
        
        try{
            OracleSearchService searchService = getOracleSearchService();
            PaginationParams pagination = new PaginationParams(startIndex, itemsPerPage);
            
            Boolean duplicateRemoved = Boolean.valueOf(dupRemoved);
            Boolean duplicateMarked = Boolean.valueOf(dupMarked);
            
            if(duplicateRemoved){
                duplicateMarked=null;
            }
            
            OracleSearchResult searchResult = searchService.doOracleSimpleSearch(query,
                                                                                 pagination.getStartIndexValue(),
                                                                                 pagination.getItemsPerPageValue(),duplicateRemoved,duplicateMarked,true);            
            SesSearchResult respSearchResult =new SesSearchResult(searchResult);
            respSearchResult.processSearchResult(null);
            
            return Response.ok(respSearchResult).type(MediaType.APPLICATION_JSON).build();  
        }catch(Exception e){
            LOGGER.severe(e);
            throw new BadRequestException(e);  
        }
    }
    
    @GET
    @Path("/search/advanced")
    public Response doAdvancedSearch(@QueryParam("q") String query,
                                   @DefaultValue("1") @QueryParam("startIndex") StartIndexParam startIndex,
                                   @DefaultValue("25") @QueryParam("itemsPerPage") ItemsPerPageParam itemsPerPage,  
                                   @DefaultValue("true") @QueryParam("dupRemoved") boolean dupRemoved,
                                   @DefaultValue("true") @QueryParam("dupMarked") boolean dupMarked,
                                   @QueryParam("dataGroupName") List<String> dataGroupNames,
                                   @DefaultValue("en") @QueryParam("locale") String locale,
                                   @DefaultValue("and") @QueryParam("filterConnector") String filterConnector,
                                   @QueryParam("filter") List<String> filters,  
                                   @QueryParam("attributeId") List<Integer> attributeIds,
                                   @DefaultValue("false") @QueryParam("processDataFile") boolean processDataFile){
        if(query==null || query.trim().compareTo("")==0){
            throw new BadRequestException("query is mandatory");  
        }
        
        OracleSearchService searchService = getOracleSearchService();
                
        try{
            //Determine Datagroups
            DataGroup[] dataGroups = null;
            if(dataGroupNames!=null && dataGroupNames.size()>0){
                DataGroup[] allDataGroups = searchService.getDataGroups(locale);                
                if(allDataGroups.length>0){
                    List<DataGroup> tdataGroups = new ArrayList<DataGroup>();                                        
                    for(DataGroup tdatagroup : allDataGroups){
                        if(dataGroupNames.contains(tdatagroup.getGroupName())){
                            tdataGroups.add(tdatagroup);
                        }
                    }
                    
                    if(tdataGroups.size() ==0){
                        throw new BadRequestException("Specified data groups not found.");    
                    }else{
                        dataGroups = new DataGroup[tdataGroups.size()];
                        tdataGroups.toArray(dataGroups);
                    }
                }else{
                    dataGroups = allDataGroups;
                }
            }
            
            //Attributes
            if(processDataFile){
                    Attribute[] allAttributes = null;
                    if(dataGroups != null && dataGroups.length>0){
                        allAttributes = searchService.getAttributes(locale,dataGroups,"or");
                    }else{
                        allAttributes = searchService.getAllAttributes(locale);
                    }
                    
                    if(allAttributes != null && allAttributes.length>0){
                        Attribute dIDAttirbute = null;
                        String attribName = null;
                        for(Attribute attrib : allAttributes){
                            attribName = attrib.getName();
                            if(attribName != null && attribName.compareToIgnoreCase("dID")==0){
                                dIDAttirbute = attrib;
                                break;
                            }
                        }
                        
                        if(dIDAttirbute == null){
                            throw new BadRequestException("dID Attribute not found");
                        }else{
                            if(attributeIds == null || attributeIds.size()==0){
                                attributeIds = new ArrayList<Integer>();
                                attributeIds.add(dIDAttirbute.getId());
                            }else{
                                attributeIds.add(dIDAttirbute.getId());
                            }
                        }
                    }else{
                        throw new BadRequestException("No attributes found when processDataFile is set");
                    }
            }
            
            Integer[] attributes = null;
            if(attributeIds != null && attributeIds.size()>0){
                attributes = new Integer[attributeIds.size()];
                attributeIds.toArray(attributes);
            }
            
            
            //Filters
            Filter[] queryFilters = null;
            if(filters != null && filters.size()>0){
                
                Attribute[] allAttributes = null;
                if(dataGroups != null && dataGroups.length>0){
                    allAttributes = searchService.getAttributes(locale,dataGroups,"or");
                }else{
                    allAttributes = searchService.getAllAttributes(locale);
                }
                
                String[] filterParts;
                String attributeIdStr = null;
                String attributeVal = null;
                String operator = null;
                List<Filter> queryFiltersList = new ArrayList<Filter>();
                Filter queryFilter;
                for(String filter : filters){
                    filterParts = filter.split(":");
                    if(filterParts.length == 2){
                        attributeIdStr = filterParts[0];
                        attributeVal = filterParts[1];
                        /*
                         * If the attributeType is "string", then operator should be either "equals" or "contains". If the attributeType is "number" or "date", then operator should be "greaterthan", "greaterthanequals" , "lessthan", "lessthanequals" or "equals".
                         */
                        operator = "equals";
                    }
                    
                    if(filterParts.length == 3){
                        attributeIdStr = filterParts[0];
                        operator = filterParts[1];
                        attributeVal = filterParts[2];                                        
                    }
                    
                    queryFilter = getFilter(attributeIdStr, operator, attributeVal, allAttributes);
                    if(queryFilter != null){
                        queryFiltersList.add(queryFilter);
                    }
                }
                
                if(queryFiltersList.size() >0){
                    queryFilters = new Filter[queryFiltersList.size()];
                    queryFiltersList.toArray(queryFilters);
                }
            }
            
            PaginationParams pagination = new PaginationParams(startIndex, itemsPerPage);
            Date d = new Date();
            OracleSearchResult searchResult = searchService.doOracleAdvancedSearch(query,
                                                                                    pagination.getStartIndexValue(),
                                                                                    pagination.getItemsPerPageValue(),
                                                                                    dupRemoved,
                                                                                    dupMarked,
                                                                                   dataGroups,
                                                                                   locale,
                                                                                   null,
                                                                                   true,
                                                                                   filterConnector,
                                                                                   queryFilters,
                                                                                   attributes,
                                                                                   null);
            LOGGER.info("Time taken for search to return : "+ (new Date().getTime() - d.getTime())+"");
            SesSearchResult respSearchResult =new SesSearchResult(searchResult);

            if(processDataFile){
              HashMap<Integer,ContentItem> contentItems =  processDataFileSearchResults(searchResult);              
                respSearchResult.processSearchResult(contentItems);
            }else{
                respSearchResult.processSearchResult(null);
            }
            
            return Response.ok(respSearchResult).type(MediaType.APPLICATION_JSON).build();  
        }catch(Exception e){
            LOGGER.severe(e);
            throw new BadRequestException(e);  
        }
    }
    
    private HashMap<Integer,ContentItem> processDataFileSearchResults(OracleSearchResult searchResult){
        HashMap<Integer,ContentItem> contentItemsMap = null;
        
        if(searchResult.getResultElements() != null ){
            ResultElement[] resultElems = searchResult.getResultElements();
            ResultElement resultElem=null;
            HashMap<String,Object> docIdParamsMap = new HashMap<String,Object>();
            List<Integer> dIDList = new ArrayList<Integer>();
            Integer dID = null;
            String mimeType;            
            for(int i=0;i<resultElems.length;i++){
                resultElem = resultElems[i];
                mimeType = resultElem.getMimetype();
                if(mimeType != null && mimeType.compareToIgnoreCase("application/xml")==0){
                    dID = getDID(resultElem);
                    if(dID != null){
                        dIDList.add(dID);
                    }
                }
            }
            if(dIDList.size()>0){
                try {
                    docIdParamsMap.put("dID", dIDList);
                    List<SearchDataObject> content =  UCMUtil.getInstance().search(docIdParamsMap);
                    if(content != null && content.size()>0){
                        ContentResource contentResource = new ContentResource();
                        List<ContentItem> contentItems = contentResource.processSearchDataObjects(null,false,content);
                        if(contentItems != null && contentItems.size()>0){
                            contentItemsMap = new HashMap<Integer,ContentItem>();
                            Object attrVal;
                            for(ContentItem contentItem : contentItems){
                                attrVal = contentItem.getAttributes().get("did");
                                if(attrVal != null){
                                    if(attrVal instanceof java.lang.Number){
                                        contentItemsMap.put((Integer)attrVal,contentItem);
                                    }else{
                                        contentItemsMap.put(Integer.parseInt((String)attrVal),contentItem);
                                    }
                                }else{
                                    LOGGER.info("did NULL");
                                }
                            }
                        }                        
                    }
                } catch (Exception e) {
                    LOGGER.severe(e);
                } 
            }
        } 
        
        return contentItemsMap;
    }
    
    private Integer getDID(ResultElement resultElem){
        CustomAttribute[] customAttribs = resultElem.getCustomAttributes();
        if(customAttribs == null || customAttribs.length ==0){
            return null;
        }else{
            String attrName = null;
            String dIDStrVal = null;
            for(CustomAttribute tCustomAttrib : customAttribs){
                attrName = tCustomAttrib.getName();
                if(attrName.compareToIgnoreCase("dID_NUMBER")==0){
                    dIDStrVal = tCustomAttrib.getValue();
                }
            }
            
            if(dIDStrVal == null){
                return null;
            }else{
                try{
                    return Integer.parseInt(dIDStrVal);
                }catch(Exception e){
                    LOGGER.severe(e);
                }
                return null;
            }
        }
    }
    
    
    private Filter getFilter(String attributeIdStr,String operator, String attributeVal,Attribute[] allAttributes){
        if(allAttributes == null || allAttributes.length==0){
            return null;
        }else{
            Integer attributeId = null;
            
            try{
                attributeId = Integer.parseInt(attributeIdStr);    
            }catch(Exception e){
                LOGGER.severe(e);
                return null;
            }
            
            if(attributeId == null){
                return null;
            }else{
                Attribute attribute = null;
                for(Attribute attrib : allAttributes){
                    if(attributeId.compareTo(attrib.getId())==0){
                        attribute = attrib;
                        break;
                    }
                }
                
                if(attribute == null){
                    return null;
                }else{
                    String attrType = attribute.getType();
                    attrType = attrType.toLowerCase(); 
                    boolean operatorValid=false;
                    if(attrType.compareTo("string")==0){
                        if(operator.compareTo("contains")==0 || operator.compareTo("equals")==0){
                            operatorValid=true;
                        }
                    }else if(attrType.compareTo("number")==0 || attrType.compareTo("date")==0){
                        if(operator.compareTo("greaterthan")==0 || operator.compareTo("equals")==0 || operator.compareTo("greaterthanequals")==0 || operator.compareTo("lessthan")==0 || operator.compareTo("lessthanequals")==0){
                            operatorValid=true;
                        }                        
                    }else{
                        LOGGER.severe("Invalid attribute type "+ attrType);
                        return null;
                    }
                    
                    if(!operatorValid){
                        LOGGER.severe("Invalid operator for type "+ attrType);
                        return null;
                    }else{
                        Filter filter = new Filter(attributeId,attribute.getType(),operator,attributeVal);
                        return filter;                        
                    }                    
                }
            }            
        }
    }
    

    @GET
    @Path("/attribute/{id}/lov")
    public Response getAttributeLOV(@PathParam("id") int attributeId,@DefaultValue("en") @QueryParam("locale") String locale){
        try{
            OracleSearchService searchService = getOracleSearchService();
            Attribute[] attributes = searchService.getAllAttributes(locale);
            Attribute attribute = null;
            
            if(attributes.length<=0){
                throw new BadRequestException("No Attributes detected");    
            }else{
                for(Attribute attrib : attributes){
                    if(attrib.getId() == attributeId){
                        attribute = attrib;
                        break;
                    }
                }
                
                if(attribute == null){
                    throw new BadRequestException("Attribute with Id "+attributeId + " not found.");        
                }else{
                    AttributeLOVElement[] attributeLOV = searchService.getAttributeLOV(attribute,locale);
                    return Response.ok(attributeLOV).type(MediaType.APPLICATION_JSON).build();  
                }
            }                        
        }catch(Exception e){
            LOGGER.severe(e);
            throw new BadRequestException("Failed to get Attribute LOV");    
        }
        
    }
    
    @GET
    @Path("/attributes")
    public Response getAttributes(@DefaultValue("en") @QueryParam("locale") String locale,
                                  @QueryParam("dataGroupId") List<Integer> dataGroupsIds,
                                  @DefaultValue("or")  @QueryParam("groupConnector") String groupConnector){
        try{
            if(dataGroupsIds == null || dataGroupsIds.size()<=0){
                OracleSearchService searchService = getOracleSearchService();
                Attribute[] attributes = searchService.getAllAttributes(locale);
                return Response.ok(attributes).type(MediaType.APPLICATION_JSON).build();  
            }else{
                OracleSearchService searchService = getOracleSearchService();
                DataGroup[] allDataGroups = searchService.getDataGroups(locale);
                
                if(allDataGroups.length<=0){
                    Attribute[] attributes = searchService.getAllAttributes(locale);
                    return Response.ok(attributes).type(MediaType.APPLICATION_JSON).build();  
                }else{
                    List<DataGroup> tdataGroups = new ArrayList<DataGroup>();                                        
                    for(DataGroup tdatagroup : allDataGroups){
                        if(dataGroupsIds.contains(tdatagroup.getGroupID())){
                            tdataGroups.add(tdatagroup);
                        }
                    }
                    
                    if(tdataGroups.size() ==0){
                        throw new BadRequestException("Failed to get Attributes as no data groups found.");    
                    }else{
                        DataGroup[] intendedDataGroups = new DataGroup[tdataGroups.size()];
                        tdataGroups.toArray(intendedDataGroups);
                        Attribute[] attributes =
                            searchService.getAttributes(locale,intendedDataGroups, groupConnector);
                        return Response.ok(attributes).type(MediaType.APPLICATION_JSON).build();  
                    }
                }                                
            }
        }catch(Exception e){
            LOGGER.severe(e);
            throw new BadRequestException("Failed to get Attributes");    
        }        
    }
    
    @GET
    @Path("/datagroups")
    public Response getDataGroups(@DefaultValue("en") @QueryParam("locale") String locale){
        try{
            OracleSearchService searchService = getOracleSearchService();
            DataGroup[] dataGroups = searchService.getDataGroups(locale);
            return Response.ok(dataGroups).type(MediaType.APPLICATION_JSON).build();  
        }catch(Exception e){
            LOGGER.severe(e);
            throw new BadRequestException("Failed to get data groups");    
        }        
    }
    
    
    @GET
    @Path("/suggestions")
    public Response getDataGroups(@QueryParam("q") String query,@DefaultValue("html") @QueryParam("returnType") String returnType){
        try{
            OracleSearchService searchService = getOracleSearchService();
            SCElement[] suggestions = searchService.getSuggestedContent(query,returnType);
            return Response.ok(suggestions).type(MediaType.APPLICATION_JSON).build();  
        }catch(Exception e){
            LOGGER.severe(e);
            throw new BadRequestException("Failed to get suggestions");    
        }        
    }    
        
    
    private OracleSearchService getOracleSearchService(){
        OracleSearchService service = null;
        HttpSession httpSession = httpRequest.getSession();
        SESConnectionManager sesConnectionManager = (SESConnectionManager)httpSession.getAttribute("SES_CONNECTION");
        service = sesConnectionManager==null?null:sesConnectionManager.getSearchService();
        
        
        if(service != null){
            return service;
        }
        
        String connectionName = SearchAdfConfig.getInstance().getSesProperties().getConnectionName();
        LOGGER.info("----------------------connectionName "+ connectionName);
        ADFContext adfCtx = ADFContext.getCurrent();
        String searchUser = oracle.adf.share.ADFContext.getCurrent().getSecurityContext().getUserName();
        javax.naming.Context context;
        try {            
            context = adfCtx.getConnectionsContext();
            SesConnectionReferenceable connectionRef = (SesConnectionReferenceable)context.lookup(connectionName);
            String appPw = connectionRef.getAppPw();
            String appUser = connectionRef.getAppUser();
            String soapUrl = connectionRef.getSoapURL();
            service = new OracleSearchService();
            service.setSoapURL(soapUrl);
            int timeoutToConfigure = getTimeout();
            //@gsdsmm2 As per documentation this should be sec but works only when sending milliseconds
            service.getSearchPort()._setProperty("weblogic.wsee.transport.connection.timeout", timeoutToConfigure);
            service.getSearchPort()._setProperty("weblogic.wsee.transport.read.timeout", timeoutToConfigure);
            Status loginStatus = service.proxyLogin(appUser, appPw, searchUser);
            LOGGER.info("SES Login status:"+loginStatus.getStatus());
            LOGGER.info("SES Login message:"+loginStatus.getMessage());
            
            LOGGER.info("Caching search service in session");
            httpSession.setAttribute("SES_CONNECTION",new SESConnectionManager(service));
        } catch (NamingException e) {
            LOGGER.severe(e);
        } catch (Exception e) {
            LOGGER.severe(e);
        }
        return service;
//                String sesServiceURL;
//        String federationEntityUserName;
//        String federationEntityPassd;
//        OracleSearchService service = null;
//        
//       // Login to ses1
//        sesServiceURL = "http://seswebd1.darden.com:8888/search/query/OracleSearch";//"http://seswebd1.darden.com:8888/search/query/OracleSearch";//properties.getProperty("KROWD_MOBILE_SES1_URL");
//        federationEntityUserName = "wcsearch";//properties.getProperty("KROWD_MOBILE_SES1_FEDERATION_ENTITY_USERNAME");
//        federationEntityPassd = "Mak3its0";//properties.getProperty("KROWD_MOBILE_SES1_FEDERATION_ENTITY_PASSWORD");
//        String searchUser = oracle.adf.share.ADFContext.getCurrent().getSecurityContext().getUserName();
//        try{
//            service = new OracleSearchService();
//            service.setSoapURL(sesServiceURL);
//            Status loginStatus = service.proxyLogin(federationEntityUserName, federationEntityPassd, searchUser);
//            LOGGER.info("Login status:"+loginStatus.getStatus());
//            //If login to ses1 fails , login to ses2
//            if(loginStatus.getStatus().equalsIgnoreCase("failed")) {
//                LOGGER.info("Reaching the second url");
//            //            sesServiceURL = properties.getProperty("KROWD_MOBILE_SES2_URL");
//            //            federationEntityUserName = properties.getProperty("KROWD_MOBILE_SES2_FEDERATION_ENTITY_USERNAME");
//            //            federationEntityPassd = properties.getProperty("KROWD_MOBILE_SES2_FEDERATION_ENTITY_PASSWORD");
//                service = new OracleSearchService();
//                service.setSoapURL(sesServiceURL);
//                loginStatus = service.proxyLogin(federationEntityUserName, federationEntityPassd, searchUser);
//                LOGGER.info("Login status in second server:"+loginStatus.getStatus());
//            }
//        }catch(Exception e){
//            e.printStackTrace();
//        }
//       
//        
//        return service;

    }    
}
