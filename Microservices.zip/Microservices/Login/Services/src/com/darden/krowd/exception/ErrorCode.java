package com.darden.krowd.exception;

public enum ErrorCode {
    AGENT_UNINIT_NO_CONNECTION("SERVER",100, "Agent Un-Initialization failed. No Connection."),
    AGENT_UNINIT_FAILURE("SERVER",101, "Agent Un-Initialization failed. General Failure."),
    AGENT_INIT_NO_CONNECTION("SERVER",102, "Agent Initialization failed. No Connection."),
    AGENT_INIT_INVALID_RESCTXDEF("SERVER",103, "Agent Initialized. Invalid Resource."),
    AGENT_INIT_INVALID_REALMDEF("SERVER",104, "Agent Initialized. Invalid Realm"),
    AGENT_INIT_TIMEOUT("SERVER",105, "Agent Initialization failed. Timeout."),
    AGENT_INIT_FAILURE("SERVER",106, "Agent Initialization failed. General Failure."),
    AGENT_INIT_INVALID_CONF("SERVER",107, "Failed to Initialize agent. Connection to the Policy Server is established, but the shared secret and/or agent name are incorrect."),
    LOGIN_FAIL_NO("USER",108, "Login Failed. Return code is NO."),
    LOGIN_FAIL_CHALLENGE("USER",109, "Additional Challenge required for Login."),
    LOGIN_FAIL_NOCONNECTION("SERVER",110, "Login Failed. No Connection."),
    LOGIN_FAIL_TIMEOUT("SERVER",111, "Login Failed. Connection Timeout"),
    LOGIN_FAIL_INVALID_RESCTXDEF("SERVER",112, "Login Failed. Invalid Resource Context."),
    LOGIN_FAIL_INVALID_REALMDEF("SERVER",113, "Login Failed. Invalid Realm Context."),
    LOGIN_FAIL_INVALID_USERCREDS("SERVER",114, "Login Failed. Invalid Credentials."),
    LOGIN_FAIL_INVALID_SESSIONDEF("SERVER",115, "Login Failed. Invalid Session Def."),
    LOGIN_FAIL_INVALID_ATTRLIST("SERVER",116, "Login Failed. Invalid Attributes List."),
    LOGIN_FAIL_FAILURE("SERVER",117, "Login Failed. General Failure."),
    SSO_TOKEN_FAILURE("SERVER",118, "Failed to Generate SSO Token."),
    SSO_TOKEN_NOCONNECTION("SERVER",119, "Failed to Generate SSO Token. No Connection."),
    SSO_TOKEN_INVALID_SESSIONDEF("SERVER",120, "Failed to Generate SSO Token. Invalid Session Def."),
    SSO_TOKEN_INVALID_ATTRSLIST("SERVER",121, "Failed to Generate SSO Token. Invalid Attrs List."),

    LOGOUT_NO("SERVER",122, "Failed to Logout."),
    LOGOUT_NOCONNECTION("SERVER",123, "Failed to Logout.No Connection."),
    LOGOUT_TIMEOUT("SERVER",124, "Failed to Logout. Timeout."),
    LOGOUT_FAILURE("SERVER",124, "Failed to Logout. General Failure."),
    LOGOUT_INVALID_SESSIONDEF("SERVER",124, "Failed to Logout. Invalid Session Def."),

    AD_INIT_FAILED("SERVER",125, "Failed to Initialize AD Context."),
    AD_UNINIT_FAILED("SERVER",125, "Failed to Close AD Context."),

    AD_USER_SEARCH_FAILED("USER",126, "Failed to search for user."),
    AD_NO_SUCH_USER("USER",127, "No such user found."),
    AD_INVALID_RESET_PASS_DET("USER",128, "Invalid values Provided."),
    AD_INVALID_PASSWORD("USER",129, "Invalid password provided."),
    AD_PASSWORD_RESET_FAILED("USER",130, "Password Reset Failed."),
    AD_PASSWORD_OLD_NEW_SAME("USER",131, "Password change failed. Old and New passwords cannot be same."),
    AD_NO_USERS_BY_LOGIN_ID("USER",132, "Failed to search for user by either AKA or SAM."),
    AD_SAM_NOT_UNIQUE("USER",133, "More than one user found for SAM."),
    AD_AKA_NOT_UNIQUE("USER",134, "More than one user found for AKA."),
    AD_USER_FOUND_FOR_AKA_SAM("USER",135, "Multiple users found by both AKA and SAM for same Login ID."),
    AD_LOGIN_FAILED("USER",136, "Failed to authenticate user with AD."),

    AD_DOB_MISMATCH("USER",137, "User DOB mismatch in AD"),
    AD_MORE_THAN_ONE_USER("USER",138, "More than one user found for Combination."),
    AD_NO_USERS_FOUND("USER",139, "No matching users found."),

    SM_ADMIN_LOGIN_ERROR("USER",140, "Exception performing admin login."),
    ERROR_RESOLVING_HOST("SERVER",141, "Could not resolve local IP."),

    SMAPI_AGENT_FAILURE("SERVER",142,"Agent API failure."),
    SMAPI_AGENT_INITIALIZATION_FAILURE("SERVER",143,"Agent initialization failed."),
    SMAPI_BUFFER_CREATION_FAILURE("SERVER",144,"Buffer creation failure."),
    SMAPI_CLIENT_EXPORT_CONFIG_F("SERVER",145,"config file for policy data export already exists."),
    SMAPI_CLIENT_EXPORT_FILE_WRITE_ERROR("SERVER",146,"Error writing data to file during policy data export."),
    SMAPI_CLIENT_EXPORT_FILENAME_F("SERVER",147,"Policy data export file name not supplied."),
    SMAPI_CLIENT_EXPORT_SMDIFFILE_F("SERVER",148,".smdif file for policy data export already exists"),
    SMAPI_CLIENT_IMPORT_FILE_READ_ERROR("SERVER",149,"Error reading data from file during policy data import."),
    SMAPI_CLIENT_IMPORT_NO_INPUTFILE_I("SERVER",150,"Input file name for policy data import not set."),
    SMAPI_CLIENT_IMPORT_OPEN_ERROR("SERVER",151,"Error opening input .smdif file for policy data import."),
    SMAPI_CLIENT_INVALID_AGENTTYPE("SERVER",152,"Invalid Agent Type."),
    SMAPI_CLIENT_INVALID_AGENTTYPE_ACTION("SERVER",153,"Invalid action supplied for RADIUS agent"),
    SMAPI_CLIENT_INVALID_AGENTTYPE_RESOURCE("SERVER",154,"Invalid Resource type set for agent"),
    SMAPI_CLIENT_INVALID_AGENTTYPE_SPECIFIC("SERVER",155,"Invalid Agent type Specific set for agent"),
    SMAPI_CLIENT_INVALID_AGENTTYPEATTR_DATATYPE("SERVER",156,"Invalid AgentTypeAttr DataType"),
    SMAPI_CLIENT_INVALID_AGENTTYPEATTR_DATATYPE_VALUE("SERVER",157,"Invalid Data type values"),
    SMAPI_CLIENT_INVALID_AGENTTYPEATTR_ID("SERVER",158,"Invalid AgentTypeAttr Identifier"),
    SMAPI_CLIENT_INVALID_AGENTTYPEATTR_NUMERICVALUE("SERVER",159,"Invalid Numeric Value"),
    SMAPI_CLIENT_INVALID_AGENTTYPEATTR_RADIUSBEHAVIOR("SERVER",160,"Invalid AgentTypeAttr RADIUS Behavior"),
    SMAPI_CLIENT_INVALID_AGENTTYPEATTR_RADIUSTYPE("SERVER",161,"Invalid AgentTypeAttr RADIUS Type"),
    SMAPI_CLIENT_INVALID_AUTHDIRNAME("SERVER",162,"Invalid Authentication Directory Name."),
    SMAPI_CLIENT_INVALID_AUTHVALIDATEMAP_MAPPING_TYPE("SERVER",163,"Invalid authentication and validation mapping type."),
    SMAPI_CLIENT_INVALID_OID("SERVER",164,"INVALID OID is passed."),
    SMAPI_CLIENT_MISSING_AUTHVALIDATEMAP_PROPERTY("SERVER",165,"Missing required property for AuthValidateMap."),
    SMAPI_CLIENT_NO_AGENTTYPE("SERVER",166,"No AgentType set for AgentTypeAttr"),
    SMAPI_CLIENT_NOT_IMPLEMENTED("SERVER",167,"SiteMinder Java API method is not implemented."),
    SMAPI_CLIENT_NULL_PARAM_ERROR("SERVER",168,"Parameter can not be null."),
    SMAPI_CLIENT_SUCCESS("SERVER",169,"Indicates the result is a success."),
    SMAPI_CONNECTION_TIMEOUT("SERVER",170,"Connection timeout."),
    SMAPI_CORRUPT_BUFFER("SERVER",171,"Tunnel buffer corrupt."),
    SMAPI_DMS_MISMATCH_ARGUMENTS("SERVER",172,"Mismatched arguments in the search filter."),
    SMAPI_INCORRECT_BUFFER_LENGTH("SERVER",173,"Incorrect buffer length."),
    SMAPI_INVALID_AGENT_CONNECTION("SERVER",174,"Invalid agent API connection."),
    SMAPI_INVALID_PARAMETERS("SERVER",175,"Incorrect parameters passed to the API call."),
    SMAPI_NO_SERVER_CONNECTION("SERVER",176,"No server connection."),
    SMAPI_POLICY_INVALID_ADDRESS("SERVER",177,"Invalid IP address."),
    SMAPI_POLICY_INVALID_ADDRESS_MODE("SERVER",178,"Invalid IP address mode."),
    SMAPI_POLICY_INVALID_AUTHAZ_MAP_TYPE("SERVER",179,"Invalid authentication and authorization map type."),
    SMAPI_POLICY_INVALID_GROUP_TYPE("SERVER",180,"Invalid group type."),
    SMAPI_SERVER_ADD_MEMBER("SERVER",181,"Failed to add the member to a group."),
    SMAPI_SERVER_AUTH_CHALLENGE("SERVER",182,"Authentication challenge."),
    SMAPI_SERVER_AUTH_REJECT("SERVER",183,"User authentication was rejected due to invalid credentials."),
    SMAPI_SERVER_BAD_ATTR_FORMAT("SERVER",184,"Attribute value not formatted properly"),
    SMAPI_SERVER_BAD_FORMAT("SERVER",185,"Badly formatted command."),
    SMAPI_SERVER_CHANGE_PASSWORD("SERVER",186,"Failed to change the user password."),
    SMAPI_SERVER_CONFIGURATION_FAILURE("SERVER",187,"Unable to get server configuration."),
    SMAPI_SERVER_CREATE("SERVER",188,"Failed to create directory object."),
    SMAPI_SERVER_DELETE("SERVER",189,"Failed to delete the object."),
    SMAPI_SERVER_DIRECTORY_OBJECT("SERVER",190,"Directory connection failed or object does not exist."),
    SMAPI_SERVER_EXCEPTION("SERVER",191,"Server Exception while processing the API request."),
    SMAPI_SERVER_EXPIRED_SESSION("SERVER",192,"The session in the API request has expired."),
    SMAPI_SERVER_FAILURE("SERVER",193,"API request has failed."),
    SMAPI_SERVER_FETCH_DOMAIN("SERVER",194,"Failed to fetch the SiteMinder domain."),
    SMAPI_SERVER_FETCH_REALM("SERVER",195,"Failed to fetch the SiteMinder realm."),
    SMAPI_SERVER_FETCH_REG_SCHEME("SERVER",196,"Failed to fetch the SiteMinder registration scheme."),
    SMAPI_SERVER_FETCH_USER_DIR("SERVER",197,"Failed to fetch the SiteMinder user directory."),
    SMAPI_SERVER_GET_GROUPS("SERVER",198,"Failed to get groups."),
    SMAPI_SERVER_GET_PROPS("SERVER",199,"Failed to get object properties."),
    SMAPI_SERVER_GET_ROLES("SERVER",200,"Failed to get roles."),
    SMAPI_SERVER_GET_TEMP_PASSWORD("SERVER",201,"Could not generate a temporary password."),
    SMAPI_SERVER_IMEXPORT_CRYPTO_ERROR1("SERVER",202,"Policy Server-side crypto configuration error during policy data import/export."),
    SMAPI_SERVER_IMEXPORT_CRYPTO_ERROR2("SERVER",203,"Policy Server-side crypto configuration error during policy data import/export."),
    SMAPI_SERVER_IMEXPORT_CRYPTO_ERROR3("SERVER",204,"Crypto configuration error during policy data import/export."),
    SMAPI_SERVER_IMEXPORT_CRYPTO_INITIALIZE_ERROR("SERVER",205,"Crypto initialization error during policy data import/export."),
    SMAPI_SERVER_IMEXPORT_FILE_ERROR("SERVER",206,"File error during policy data import/export,"),
    SMAPI_SERVER_IMEXPORT_INITIALIZATION_ERROR("SERVER",207,"Initialization error during policy data import/export."),
    SMAPI_SERVER_IMEXPORT_INVALID_MATCH("SERVER",208,"Invalid match during policy data import/export."),
    SMAPI_SERVER_IMEXPORT_INVALID_OBJECT("SERVER",209,"Invalid object during policy data import/export."),
    SMAPI_SERVER_IMEXPORT_INVALID_OID("SERVER",210,"Invalid OID during policy data import/export."),
    SMAPI_SERVER_IMEXPORT_INVALID_PARENT("SERVER",211,"Invalid parent object during policy data import/export."),
    SMAPI_SERVER_IMEXPORT_INVALID_PROPERTY("SERVER",212,"Invalid property during policy data import/export."),
    SMAPI_SERVER_IMEXPORT_MIGRATION_CREATE_ERROR("SERVER",213,"Migration object creation error during policy data import/export."),
    SMAPI_SERVER_IMEXPORT_NO_DOMAIN("SERVER",214,"Wrong domain name supplied for policy data export."),
    SMAPI_SERVER_IMEXPORT_NO_IMS_DIRECTORY("SERVER",215,"Wrong IMS directory name supplied for policy data export."),
    SMAPI_SERVER_IMEXPORT_NO_IMS_ENV("SERVER",216,"Wrong IMS environment name supplied for policy data export."),
    SMAPI_SERVER_IMEXPORT_OBJECT_FETCH_ERROR("SERVER",217,"Unable to fetch object during policy data import/export."),
    SMAPI_SERVER_IMEXPORT_OBJECT_NOTFOUND("SERVER",218,"Object not found during policy data import/export."),
    SMAPI_SERVER_IMEXPORT_ODBS_ERROR("SERVER",219,"ODBC error during policy data import/export."),
    SMAPI_SERVER_IMEXPORT_OVERWRITE_ERROR("SERVER",220,"Overwrite error during policy data import/export."),
    SMAPI_SERVER_IMEXPORT_POLICY_STORE_ERROR("SERVER",221,"Error opening policy store during policy data import/export."),
    SMAPI_SERVER_IMEXPORT_PROPERTY_ACCESS_ERROR("SERVER",222,"Unable to access property during policy data import/export."),
    SMAPI_SERVER_IMEXPORT_PROPERTY_NOTFOUND("SERVER",223,"Property not found during policy data import/export."),
    SMAPI_SERVER_IMEXPORT_READ_ERROR("SERVER",224,"Error reading from file during policy data export."),
    SMAPI_SERVER_IMEXPORT_SITEMINDER_CREDENTIALS_ERROR("SERVER",225,"Error authenticating Siteminder aadminstrator credentials during policy data import/export."),
    SMAPI_SERVER_IMEXPORT_UNKNOWN_ERROR("SERVER",226,"Unknown error during policy data import."),
    SMAPI_SERVER_IMEXPORT_WRITE_ERROR("SERVER",227,"Error reading from file during policy data import."),
    SMAPI_SERVER_INVALID_DIRECTORY("SERVER",228,"Invalid user directory configuration."),
    SMAPI_SERVER_INVALID_OBJECTCLASS("SERVER",229,"Invalid object class."),
    SMAPI_SERVER_INVALID_PASSWORD("SERVER",230,"Password is invalid."),
    SMAPI_SERVER_INVALID_SESSION("SERVER",231,"The session in the API request is invalid."),
    SMAPI_SERVER_MISMATCH("SERVER",232,"Mismatch"),
    SMAPI_SERVER_NO_COMMAND("SERVER",233,"The API request cannot be recognized."),
    SMAPI_SERVER_NO_ITEMS_FOUND("SERVER",234,"No items found."),
    SMAPI_SERVER_NO_SESSION("SERVER",235,"The API request did not contain any session information."),
    SMAPI_SERVER_NOT_AUTHORIZED("SERVER",236,"The user is not authorized to perform the API request."),
    SMAPI_SERVER_NOT_IMPLEMENTED("SERVER",237,"The API request is not implemented."),
    SMAPI_SERVER_PASSWORDSTATE("SERVER",238,"The SmDmsUserPWState object cannot be accessed correctly."),
    SMAPI_SERVER_POLICY_API("SERVER",239,"Policy API error occurred during the request."),
    SMAPI_SERVER_REMOVE_MEMBER("SERVER",240,"Failed to remove the member from a group."),
    SMAPI_SERVER_RESPONSE_TOO_BIG("SERVER",241,"The response is too big."),
    SMAPI_SERVER_SEARCH("SERVER",242,"Failed to search."),
    SMAPI_SERVER_SET_PROPS("SERVER",243,"Failed to set object properties."),
    SMAPI_SERVER_TOO_MANY_ITEMS_FOUND("SERVER",244,"Too many items found."),
    SMAPI_SERVER_USER_DIR_NOT_CONFIGURED("SERVER",245,"User directory not configured properly."),
    SMAPI_SERVER_USER_POLICY_IN_CONSISTENT_AND_BIT_MASK("SERVER",246,"Mismatched setting of AND bit between user policies of same user directory"),
    SMAPI_SERVER_WORKFLOW_EXCEPTION("SERVER",247,"Exception caught in the workflow library."),
    SMAPI_SERVER_WORKFLOW_INIT("SERVER",248,"Could not load or initialize the workflow library."),
    SMAPI_SERVER_WORKFLOW_POSTPROCESS("SERVER",249,"Error occurred during workflow post-process."),
    SMAPI_SERVER_WORKFLOW_PREPROCESS("SERVER",250,"Error occurred during workflow pre-process."),
    SMAPI_OPERATION_FAILED("SERVER",251,"SmApiPolicy Operation Failed."),    
    AD_CONNECTION_POOL_BORROW_FAILED("SERVER",252,"Unable to get AD Connection Object."),
    SM_CONNECTION_POOL_BORROW_FAILED("SERVER",253,"Unable to get SM Agent Connection Object."),
    
    AD_USER_LOCKOUT("USER",254,"User has been locked out."),
    SM_AD_MISMATCH("SERVER",255,"SM Login failed but AD successful.")

    ;

    private final String type;
    private final int code;
    private final String description;

    private ErrorCode(String type,int code, String description) {
        this.type = type;
        this.code = code;
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public int getCode() {
        return code;
    }


    public String getType() {
        return type;
    }

    @Override
    public String toString() {
        return code + ": " + description;
    }
}
