/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.darden.krowd.login.siteminder;

import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 *
 * @author gsdrxg1
 */
public class SMAgentConfig {
    private String policyServerIpAddress;
    private int minConnection;
    private int maxConnection;
    private int connectionStep;
    private int connectionTimeout;
    private int authorizationPort;
    private int authenticationPort;
    private int accountingPort;
    private String defaultProtectedContextRoot;
    private String smAgentName;
    private String hostName = SMAgentConfig._getHostName();
    private String hostIp = SMAgentConfig._getLocalIP();
    private String sharedSecret;
    private boolean failOver;
    private int poolMaxIdle;
    private int poolMaxTotal;


    public String getPolicyServerIpAddress() {
        return policyServerIpAddress;
    }

    public void setPolicyServerIpAddress(String policyServerIpAddress) {
        this.policyServerIpAddress = policyServerIpAddress;
    }

    public int getMinConnection() {
        return minConnection;
    }

    public void setMinConnection(int minConnection) {
        this.minConnection = minConnection;
    }

    public int getMaxConnection() {
        return maxConnection;
    }

    public void setMaxConnection(int maxConnection) {
        this.maxConnection = maxConnection;
    }

    public int getConnectionStep() {
        return connectionStep;
    }

    public void setConnectionStep(int connectionStep) {
        this.connectionStep = connectionStep;
    }

    public int getConnectionTimeout() {
        return connectionTimeout;
    }

    public void setConnectionTimeout(int connectionTimeout) {
        this.connectionTimeout = connectionTimeout;
    }

    public int getAuthorizationPort() {
        return authorizationPort;
    }

    public void setAuthorizationPort(int authorizationPort) {
        this.authorizationPort = authorizationPort;
    }

    public int getAuthenticationPort() {
        return authenticationPort;
    }

    public void setAuthenticationPort(int authenticationPort) {
        this.authenticationPort = authenticationPort;
    }

    public int getAccountingPort() {
        return accountingPort;
    }

    public void setAccountingPort(int accountingPort) {
        this.accountingPort = accountingPort;
    }

    public String getDefaultProtectedContextRoot() {
        return defaultProtectedContextRoot;
    }

    public void setDefaultProtectedContextRoot(String defaultProtectedContextRoot) {
        this.defaultProtectedContextRoot = defaultProtectedContextRoot;
    }

    public String getSmAgentName() {
        return smAgentName;
    }

    public void setSmAgentName(String smAgentName) {
        this.smAgentName = smAgentName;
    }

    public String getHostName() {
        return hostName;
    }

    public void setHostName(String hostName) {
        this.hostName = hostName;
    }

    public String getHostIp() {
        return hostIp;
    }

    public void setHostIp(String hostIp) {
        this.hostIp = hostIp;
    }

    public String getSharedSecret() {
        return sharedSecret;
    }

    public void setSharedSecret(String sharedSecret) {
        this.sharedSecret = sharedSecret;
    }

    public boolean isFailOver() {
        return failOver;
    }

    public void setFailOver(boolean failOver) {
        this.failOver = failOver;
    }

    public int getPoolMaxIdle() {
        return poolMaxIdle;
    }

    public void setPoolMaxIdle(int poolMaxIdle) {
        this.poolMaxIdle = poolMaxIdle;
    }

    public int getPoolMaxTotal() {
        return poolMaxTotal;
    }

    public void setPoolMaxTotal(int poolMaxTotal) {
        this.poolMaxTotal = poolMaxTotal;
    }


    private static String _getHostName() {
        try {
            InetAddress localhost = InetAddress.getLocalHost();
            return localhost.getHostName();
        } catch (UnknownHostException ex) {
            ex.printStackTrace();
            return "localhost";
        }
    }

    private static String _getLocalIP() {
        try {
            InetAddress localhost = InetAddress.getLocalHost();
            return localhost.getHostAddress();
        } catch (UnknownHostException ex) {
            ex.printStackTrace();
            return "127.0.0.1";
        }
    }

}
