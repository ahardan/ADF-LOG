/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.darden.krowd.login.siteminder;

import java.io.IOException;

import java.net.HttpCookie;
import java.net.InetAddress;
import java.net.UnknownHostException;

import java.nio.charset.StandardCharsets;

import java.util.Base64;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ws.rs.core.HttpHeaders;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;


/**
 *
 * @author gsdrxg1
 */
public class SMAgentFactoryTest {
    private static final String SERVER_IP_ADRESS = "146.217.100.150";
    private static final int MIN_CONNECTION = 1;
    private static final int MAX_CONNECTION = 3;
    private static final int CONNECTION_STEP = 1;
    private static final int CONNECTION_TIMEOUT = 5;
    private static final int AUTHORIZATION_PORT = 44443;
    private static final int AUTHENTICATION_PORT = 44442;
    private static final int ACCOUNTING_PORT = 44441;
    private static final String SM_DEFAULT_PROTECTED_CONTEXT_ROOT = "/krowd/";
    private static final String SM_BASIC_AUTH_PROTECTED_CONTEXT_ROOT = "/login/auth.json";
    /*private static final String SM_AGENT_NAME = "kwdwebt2a";
    private static final String SHARED_SECRET = "{RC2}87ZR+UllIcpqI0SlhANCRRf6MyjGzoaBen/LkEZm69SegZOylImE/rjHUx4bzROIPEPXSvbxdSFXJA24H9oJ0INzFjgE7QubGefZy0ALhJknIemFSkxUA79pJuEWGA9j158OJEbDkW6rX/A/BI+uAVOf2BTZ4FWGiveCWcqwtWS4I56wyLDXU/4eRr0aqc51";
    */
    
    //kwdpxyd2a
    private static final String SM_AGENT_NAME = "kwdappd2a";
    private static final String SHARED_SECRET = "{RC2}uXUygH3LS1MxquS9t/+cgiBvch1Y84vPYZQlMArfNQSimbWE3pt7QW2nY9t4WjAz/7JjqmZwv1jV02Sh++5aYAyUhuX2ojXHSezbdrJQBMt613ovN+LpVuWpFX4ZdOEjQVJbLql9cK1AdoBZHMMa7dHKrh5wZ1ltgzNAkd9J23VsT5TRzmj7GIesRAUQlfBO";

    //kwdpxyd2b
    //private static final String SM_AGENT_NAME = "kwdpxyd2b";
    //private static final String SHARED_SECRET = "{RC2}1y3X4b2FpnZA/RuoiV6NHenj9Bpq35AXvXuMpKTT6q0pkS7QHnjOuUW01hOsDC7lq6/5DQHG0L5/KX6ll6jxe2RKCcsftNZIf/AXa4oSkz+8k7A6rOqkJW0nvmfdoo2KYIRGLnmvi5invi4KQ97RUkvbevPZRrBpXS4md/P2EpUxK0Fk8qH2csbv7jTZh3Fo";

    //kwdpxyd2a
    //private static final String SM_AGENT_NAME = "kwdpxyd2a";
    //private static final String SHARED_SECRET = "{RC2}8lHpfGCa5/psl5KkFoB7LlsUk7vG6GwL/T77pMkK7l3Fl7ONrEMH7D310RcdHV7SHREY7MVTjxOisuNr/gkLOHx6cjpJX9N5F/docBqEN2smb3WeuHkWGZ+4RPFtNPYJcNk1xIumVMfmugqOL90Mb5g81HDwRE5kGUH7IKVOYcxbQ3L7xRiYDgUIc2R1VZS7";

    //private static final String SM_AGENT_NAME = "kwdapid2a";
    //private static final String SHARED_SECRET = "api";

    private static final boolean FAIL_OVER = false;
        
    private static SMAgentConnectionPool smAgentConnectionPool;
    

/*
 * hostname="kwdpxyd2a"
sharedsecret="{RC2}8lHpfGCa5/psl5KkFoB7LlsUk7vG6GwL/T77pMkK7l3Fl7ONrEMH7D310RcdHV7SHREY7MVTjxOisuNr/gkLOHx6cjpJX9N5F/docBqEN2smb3WeuHkWGZ+4RPFtNPYJcNk1xIumVMfmugqOL90Mb5g81HDwRE5kGUH7IKVOYcxbQ3L7xRiYDgUIc2R1VZS7"
 */
    
    private static String getHostName() {
        try {
            InetAddress localhost = InetAddress.getLocalHost();
            return localhost.getHostName();
        } catch (UnknownHostException ex) {
            ex.printStackTrace();
            return "localhost";
        }
    }

    private static String getLocalIP() {
        try {
            InetAddress localhost = InetAddress.getLocalHost();
            return localhost.getHostAddress();
        } catch (UnknownHostException ex) {
            ex.printStackTrace();
            return "localhost";
        }
    }
    
    private static void performBasicAuth(){
        String username = "gsdrxg1";
        String password = "who4:eva";
        
        CredentialsProvider provider = new BasicCredentialsProvider();
        UsernamePasswordCredentials creds = new UsernamePasswordCredentials(username, password);
        provider.setCredentials(AuthScope.ANY,creds);
        
        CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultCredentialsProvider(provider).build();                
        HttpUriRequest request = RequestBuilder.get().setUri("https://krowddev2.darden.com/login/auth.json").addHeader("Cookie", "SMCHALLENGE=YES").build();
        try {
            CloseableHttpResponse response = httpClient.execute(request);
            System.out.println(response.getStatusLine().getStatusCode());   
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                // return it as a String
                String result = EntityUtils.toString(entity);
                System.out.println(result);
            } 
            Header[] allHeaders = response.getAllHeaders();
            for(Header header : allHeaders){
                System.out.println(header.getName());
            }
            Header[] headers = response.getHeaders("Set-Cookie");

            for(Header header : headers){
                List<HttpCookie> cookies = HttpCookie.parse(header.getValue());
                System.out.println(cookies);
            }

            System.out.println("--");

        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    
    public static void main(String[] args){
        SMAgentFactoryTest.performBasicAuth();
    }
    
    public static void main1(String[] args){
        GenericObjectPoolConfig config = new GenericObjectPoolConfig();
        config.setMaxIdle(1);
        config.setMaxTotal(5);
        config.setTestOnBorrow(true);
        config.setTestOnReturn(true);       
        
        SMAgentConfig smAgentConfig = new SMAgentConfig();
        smAgentConfig.setAccountingPort(ACCOUNTING_PORT);
        smAgentConfig.setAuthenticationPort(AUTHENTICATION_PORT);
        smAgentConfig.setAuthorizationPort(AUTHORIZATION_PORT);
        smAgentConfig.setConnectionStep(CONNECTION_STEP);
        smAgentConfig.setConnectionTimeout(CONNECTION_TIMEOUT);
        smAgentConfig.setFailOver(FAIL_OVER);
        smAgentConfig.setHostName(SMAgentFactoryTest.getHostName());
        smAgentConfig.setHostIp(SMAgentFactoryTest.getLocalIP());
        smAgentConfig.setMaxConnection(MAX_CONNECTION);
        smAgentConfig.setMinConnection(MIN_CONNECTION);
        smAgentConfig.setSharedSecret(SHARED_SECRET);
        smAgentConfig.setSmAgentName(SM_AGENT_NAME);
        smAgentConfig.setDefaultProtectedContextRoot(SM_DEFAULT_PROTECTED_CONTEXT_ROOT);
        smAgentConfig.setPolicyServerIpAddress(SERVER_IP_ADRESS);
        
        smAgentConnectionPool = new SMAgentConnectionPool(new SMAgentConnectionFactory(smAgentConfig),config);
        
        SMAgentConnection conn = null;
        try {
            conn = smAgentConnectionPool.borrowObject();
            SessionInfo sessionInfo = conn.login("gsdrxg1", "who4:eva");
            System.out.println(sessionInfo);
            conn.logout(sessionInfo);
            System.out.println(sessionInfo.getSSOToken());
        } catch (Exception ex) {
            Logger.getLogger(SMAgentFactoryTest.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            smAgentConnectionPool.returnObject(conn);
            smAgentConnectionPool.clear();
            smAgentConnectionPool.close();                        
        }
    }
}
