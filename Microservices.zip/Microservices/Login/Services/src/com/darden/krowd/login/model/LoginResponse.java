package com.darden.krowd.login.model;

public class LoginResponse {
    String smsession;
    
    
    public LoginResponse() {
        super();
    }
}
