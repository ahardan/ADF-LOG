package com.darden.krowd.exception;

import com.netegrity.sdk.apiutil.SmApiResult;

import java.io.PrintWriter;
import java.io.StringWriter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;


public class AppException extends Exception {

    private static final long serialVersionUID = 7718828512143293558L;

    private final ErrorCode code;

    public AppException(ErrorCode code) {
        super();
        this.code = code;
    }

    public AppException(String message, Throwable cause, ErrorCode code) {
        super(message, cause);
        this.code = code;
    }

    public AppException(String message, ErrorCode code) {
        super(message);
        this.code = code;
    }

    public AppException(Throwable cause, ErrorCode code) {
        super(cause);
        this.code = code;
    }

    public ErrorCode getCode() {
        return this.code;
    }

    public static AppException getAppException(SmApiResult smApiResult){
        /*int errorCode = smApiResult.getError();
        int facilityCode = smApiResult.getFacility();
        int reasonCode = smApiResult.getReason();
        int severityCode = smApiResult.getSeverity();
        int statusCode = smApiResult.getStatus();*/

        AppException appException = null;

        if(smApiResult.equals(SmApiResult.AGENT_FAILURE)) { appException = new AppException(ErrorCode.SMAPI_AGENT_FAILURE);}
        else if(smApiResult.equals(SmApiResult.AGENT_INITIALIZATION_FAILURE)) { appException = new AppException(ErrorCode.SMAPI_AGENT_INITIALIZATION_FAILURE);}
        else if(smApiResult.equals(SmApiResult.BUFFER_CREATION_FAILURE)) { appException = new AppException(ErrorCode.SMAPI_BUFFER_CREATION_FAILURE);}
        else if(smApiResult.equals(SmApiResult.CLIENT_EXPORT_CONFIG_F)) { appException = new AppException(ErrorCode.SMAPI_CLIENT_EXPORT_CONFIG_F);}
        else if(smApiResult.equals(SmApiResult.CLIENT_EXPORT_FILE_WRITE_ERROR)) { appException = new AppException(ErrorCode.SMAPI_CLIENT_EXPORT_FILE_WRITE_ERROR);}
        else if(smApiResult.equals(SmApiResult.CLIENT_EXPORT_FILENAME_F)) { appException = new AppException(ErrorCode.SMAPI_CLIENT_EXPORT_FILENAME_F);}
        else if(smApiResult.equals(SmApiResult.CLIENT_EXPORT_SMDIFFILE_F)) { appException = new AppException(ErrorCode.SMAPI_CLIENT_EXPORT_SMDIFFILE_F);}
        else if(smApiResult.equals(SmApiResult.CLIENT_IMPORT_FILE_READ_ERROR)) { appException = new AppException(ErrorCode.SMAPI_CLIENT_IMPORT_FILE_READ_ERROR);}
        else if(smApiResult.equals(SmApiResult.CLIENT_IMPORT_NO_INPUTFILE_I)) { appException = new AppException(ErrorCode.SMAPI_CLIENT_IMPORT_NO_INPUTFILE_I);}
        else if(smApiResult.equals(SmApiResult.CLIENT_IMPORT_OPEN_ERROR)) { appException = new AppException(ErrorCode.SMAPI_CLIENT_IMPORT_OPEN_ERROR);}
        else if(smApiResult.equals(SmApiResult.CLIENT_INVALID_AGENTTYPE)) { appException = new AppException(ErrorCode.SMAPI_CLIENT_INVALID_AGENTTYPE);}
        else if(smApiResult.equals(SmApiResult.CLIENT_INVALID_AGENTTYPE_ACTION)) { appException = new AppException(ErrorCode.SMAPI_CLIENT_INVALID_AGENTTYPE_ACTION);}
        else if(smApiResult.equals(SmApiResult.CLIENT_INVALID_AGENTTYPE_RESOURCE)) { appException = new AppException(ErrorCode.SMAPI_CLIENT_INVALID_AGENTTYPE_RESOURCE);}
        else if(smApiResult.equals(SmApiResult.CLIENT_INVALID_AGENTTYPE_SPECIFIC)) { appException = new AppException(ErrorCode.SMAPI_CLIENT_INVALID_AGENTTYPE_SPECIFIC);}
        else if(smApiResult.equals(SmApiResult.CLIENT_INVALID_AGENTTYPEATTR_DATATYPE)) { appException = new AppException(ErrorCode.SMAPI_CLIENT_INVALID_AGENTTYPEATTR_DATATYPE);}
        else if(smApiResult.equals(SmApiResult.CLIENT_INVALID_AGENTTYPEATTR_DATATYPE_VALUE)) { appException = new AppException(ErrorCode.SMAPI_CLIENT_INVALID_AGENTTYPEATTR_DATATYPE_VALUE);}
        else if(smApiResult.equals(SmApiResult.CLIENT_INVALID_AGENTTYPEATTR_ID)) { appException = new AppException(ErrorCode.SMAPI_CLIENT_INVALID_AGENTTYPEATTR_ID);}
        else if(smApiResult.equals(SmApiResult.CLIENT_INVALID_AGENTTYPEATTR_NUMERICVALUE)) { appException = new AppException(ErrorCode.SMAPI_CLIENT_INVALID_AGENTTYPEATTR_NUMERICVALUE);}
        else if(smApiResult.equals(SmApiResult.CLIENT_INVALID_AGENTTYPEATTR_RADIUSBEHAVIOR)) { appException = new AppException(ErrorCode.SMAPI_CLIENT_INVALID_AGENTTYPEATTR_RADIUSBEHAVIOR);}
        else if(smApiResult.equals(SmApiResult.CLIENT_INVALID_AGENTTYPEATTR_RADIUSTYPE)) { appException = new AppException(ErrorCode.SMAPI_CLIENT_INVALID_AGENTTYPEATTR_RADIUSTYPE);}
        else if(smApiResult.equals(SmApiResult.CLIENT_INVALID_AUTHDIRNAME)) { appException = new AppException(ErrorCode.SMAPI_CLIENT_INVALID_AUTHDIRNAME);}
        else if(smApiResult.equals(SmApiResult.CLIENT_INVALID_AUTHVALIDATEMAP_MAPPING_TYPE)) { appException = new AppException(ErrorCode.SMAPI_CLIENT_INVALID_AUTHVALIDATEMAP_MAPPING_TYPE);}
        else if(smApiResult.equals(SmApiResult.CLIENT_INVALID_OID)) { appException = new AppException(ErrorCode.SMAPI_CLIENT_INVALID_OID);}
        else if(smApiResult.equals(SmApiResult.CLIENT_MISSING_AUTHVALIDATEMAP_PROPERTY)) { appException = new AppException(ErrorCode.SMAPI_CLIENT_MISSING_AUTHVALIDATEMAP_PROPERTY);}
        else if(smApiResult.equals(SmApiResult.CLIENT_NO_AGENTTYPE)) { appException = new AppException(ErrorCode.SMAPI_CLIENT_NO_AGENTTYPE);}
        else if(smApiResult.equals(SmApiResult.CLIENT_NOT_IMPLEMENTED)) { appException = new AppException(ErrorCode.SMAPI_CLIENT_NOT_IMPLEMENTED);}
        else if(smApiResult.equals(SmApiResult.CLIENT_NULL_PARAM_ERROR)) { appException = new AppException(ErrorCode.SMAPI_CLIENT_NULL_PARAM_ERROR);}
        else if(smApiResult.equals(SmApiResult.CLIENT_SUCCESS)) { appException = new AppException(ErrorCode.SMAPI_CLIENT_SUCCESS);}
        else if(smApiResult.equals(SmApiResult.CONNECTION_TIMEOUT)) { appException = new AppException(ErrorCode.SMAPI_CONNECTION_TIMEOUT);}
        else if(smApiResult.equals(SmApiResult.CORRUPT_BUFFER)) { appException = new AppException(ErrorCode.SMAPI_CORRUPT_BUFFER);}
        else if(smApiResult.equals(SmApiResult.DMS_MISMATCH_ARGUMENTS)) { appException = new AppException(ErrorCode.SMAPI_DMS_MISMATCH_ARGUMENTS);}
        else if(smApiResult.equals(SmApiResult.INCORRECT_BUFFER_LENGTH)) { appException = new AppException(ErrorCode.SMAPI_INCORRECT_BUFFER_LENGTH);}
        else if(smApiResult.equals(SmApiResult.INVALID_AGENT_CONNECTION)) { appException = new AppException(ErrorCode.SMAPI_INVALID_AGENT_CONNECTION);}
        else if(smApiResult.equals(SmApiResult.INVALID_PARAMETERS)) { appException = new AppException(ErrorCode.SMAPI_INVALID_PARAMETERS);}
        else if(smApiResult.equals(SmApiResult.NO_SERVER_CONNECTION)) { appException = new AppException(ErrorCode.SMAPI_NO_SERVER_CONNECTION);}
        else if(smApiResult.equals(SmApiResult.POLICY_INVALID_ADDRESS)) { appException = new AppException(ErrorCode.SMAPI_POLICY_INVALID_ADDRESS);}
        else if(smApiResult.equals(SmApiResult.POLICY_INVALID_ADDRESS_MODE)) { appException = new AppException(ErrorCode.SMAPI_POLICY_INVALID_ADDRESS_MODE);}
        else if(smApiResult.equals(SmApiResult.POLICY_INVALID_AUTHAZ_MAP_TYPE)) { appException = new AppException(ErrorCode.SMAPI_POLICY_INVALID_AUTHAZ_MAP_TYPE);}
        else if(smApiResult.equals(SmApiResult.POLICY_INVALID_GROUP_TYPE)) { appException = new AppException(ErrorCode.SMAPI_POLICY_INVALID_GROUP_TYPE);}
        else if(smApiResult.equals(SmApiResult.SERVER_ADD_MEMBER)) { appException = new AppException(ErrorCode.SMAPI_SERVER_ADD_MEMBER);}
        else if(smApiResult.equals(SmApiResult.SERVER_AUTH_CHALLENGE)) { appException = new AppException(ErrorCode.SMAPI_SERVER_AUTH_CHALLENGE);}
        else if(smApiResult.equals(SmApiResult.SERVER_AUTH_REJECT)) { appException = new AppException(ErrorCode.SMAPI_SERVER_AUTH_REJECT);}
        else if(smApiResult.equals(SmApiResult.SERVER_BAD_ATTR_FORMAT)) { appException = new AppException(ErrorCode.SMAPI_SERVER_BAD_ATTR_FORMAT);}
        else if(smApiResult.equals(SmApiResult.SERVER_BAD_FORMAT)) { appException = new AppException(ErrorCode.SMAPI_SERVER_BAD_FORMAT);}
        else if(smApiResult.equals(SmApiResult.SERVER_CHANGE_PASSWORD)) { appException = new AppException(ErrorCode.SMAPI_SERVER_CHANGE_PASSWORD);}
        else if(smApiResult.equals(SmApiResult.SERVER_CONFIGURATION_FAILURE)) { appException = new AppException(ErrorCode.SMAPI_SERVER_CONFIGURATION_FAILURE);}
        else if(smApiResult.equals(SmApiResult.SERVER_CREATE)) { appException = new AppException(ErrorCode.SMAPI_SERVER_CREATE);}
        else if(smApiResult.equals(SmApiResult.SERVER_DELETE)) { appException = new AppException(ErrorCode.SMAPI_SERVER_DELETE);}
        else if(smApiResult.equals(SmApiResult.SERVER_DIRECTORY_OBJECT)) { appException = new AppException(ErrorCode.SMAPI_SERVER_DIRECTORY_OBJECT);}
        else if(smApiResult.equals(SmApiResult.SERVER_EXCEPTION)) { appException = new AppException(ErrorCode.SMAPI_SERVER_EXCEPTION);}
        else if(smApiResult.equals(SmApiResult.SERVER_EXPIRED_SESSION)) { appException = new AppException(ErrorCode.SMAPI_SERVER_EXPIRED_SESSION);}
        else if(smApiResult.equals(SmApiResult.SERVER_FAILURE)) { appException = new AppException(ErrorCode.SMAPI_SERVER_FAILURE);}
        else if(smApiResult.equals(SmApiResult.SERVER_FETCH_DOMAIN)) { appException = new AppException(ErrorCode.SMAPI_SERVER_FETCH_DOMAIN);}
        else if(smApiResult.equals(SmApiResult.SERVER_FETCH_REALM)) { appException = new AppException(ErrorCode.SMAPI_SERVER_FETCH_REALM);}
        else if(smApiResult.equals(SmApiResult.SERVER_FETCH_REG_SCHEME)) { appException = new AppException(ErrorCode.SMAPI_SERVER_FETCH_REG_SCHEME);}
        else if(smApiResult.equals(SmApiResult.SERVER_FETCH_USER_DIR)) { appException = new AppException(ErrorCode.SMAPI_SERVER_FETCH_USER_DIR);}
        else if(smApiResult.equals(SmApiResult.SERVER_GET_GROUPS)) { appException = new AppException(ErrorCode.SMAPI_SERVER_GET_GROUPS);}
        else if(smApiResult.equals(SmApiResult.SERVER_GET_PROPS)) { appException = new AppException(ErrorCode.SMAPI_SERVER_GET_PROPS);}
        else if(smApiResult.equals(SmApiResult.SERVER_GET_ROLES)) { appException = new AppException(ErrorCode.SMAPI_SERVER_GET_ROLES);}
        else if(smApiResult.equals(SmApiResult.SERVER_GET_TEMP_PASSWORD)) { appException = new AppException(ErrorCode.SMAPI_SERVER_GET_TEMP_PASSWORD);}
        else if(smApiResult.equals(SmApiResult.SERVER_IMEXPORT_CRYPTO_ERROR1)) { appException = new AppException(ErrorCode.SMAPI_SERVER_IMEXPORT_CRYPTO_ERROR1);}
        else if(smApiResult.equals(SmApiResult.SERVER_IMEXPORT_CRYPTO_ERROR2)) { appException = new AppException(ErrorCode.SMAPI_SERVER_IMEXPORT_CRYPTO_ERROR2);}
        else if(smApiResult.equals(SmApiResult.SERVER_IMEXPORT_CRYPTO_ERROR3)) { appException = new AppException(ErrorCode.SMAPI_SERVER_IMEXPORT_CRYPTO_ERROR3);}
        else if(smApiResult.equals(SmApiResult.SERVER_IMEXPORT_CRYPTO_INITIALIZE_ERROR)) { appException = new AppException(ErrorCode.SMAPI_SERVER_IMEXPORT_CRYPTO_INITIALIZE_ERROR);}
        else if(smApiResult.equals(SmApiResult.SERVER_IMEXPORT_FILE_ERROR)) { appException = new AppException(ErrorCode.SMAPI_SERVER_IMEXPORT_FILE_ERROR);}
        else if(smApiResult.equals(SmApiResult.SERVER_IMEXPORT_INITIALIZATION_ERROR)) { appException = new AppException(ErrorCode.SMAPI_SERVER_IMEXPORT_INITIALIZATION_ERROR);}
        else if(smApiResult.equals(SmApiResult.SERVER_IMEXPORT_INVALID_MATCH)) { appException = new AppException(ErrorCode.SMAPI_SERVER_IMEXPORT_INVALID_MATCH);}
        else if(smApiResult.equals(SmApiResult.SERVER_IMEXPORT_INVALID_OBJECT)) { appException = new AppException(ErrorCode.SMAPI_SERVER_IMEXPORT_INVALID_OBJECT);}
        else if(smApiResult.equals(SmApiResult.SERVER_IMEXPORT_INVALID_OID)) { appException = new AppException(ErrorCode.SMAPI_SERVER_IMEXPORT_INVALID_OID);}
        else if(smApiResult.equals(SmApiResult.SERVER_IMEXPORT_INVALID_PARENT)) { appException = new AppException(ErrorCode.SMAPI_SERVER_IMEXPORT_INVALID_PARENT);}
        else if(smApiResult.equals(SmApiResult.SERVER_IMEXPORT_INVALID_PROPERTY)) { appException = new AppException(ErrorCode.SMAPI_SERVER_IMEXPORT_INVALID_PROPERTY);}
        else if(smApiResult.equals(SmApiResult.SERVER_IMEXPORT_MIGRATION_CREATE_ERROR)) { appException = new AppException(ErrorCode.SMAPI_SERVER_IMEXPORT_MIGRATION_CREATE_ERROR);}
        else if(smApiResult.equals(SmApiResult.SERVER_IMEXPORT_NO_DOMAIN)) { appException = new AppException(ErrorCode.SMAPI_SERVER_IMEXPORT_NO_DOMAIN);}
        else if(smApiResult.equals(SmApiResult.SERVER_IMEXPORT_NO_IMS_DIRECTORY)) { appException = new AppException(ErrorCode.SMAPI_SERVER_IMEXPORT_NO_IMS_DIRECTORY);}
        else if(smApiResult.equals(SmApiResult.SERVER_IMEXPORT_NO_IMS_ENV)) { appException = new AppException(ErrorCode.SMAPI_SERVER_IMEXPORT_NO_IMS_ENV);}
        else if(smApiResult.equals(SmApiResult.SERVER_IMEXPORT_OBJECT_FETCH_ERROR)) { appException = new AppException(ErrorCode.SMAPI_SERVER_IMEXPORT_OBJECT_FETCH_ERROR);}
        else if(smApiResult.equals(SmApiResult.SERVER_IMEXPORT_OBJECT_NOTFOUND)) { appException = new AppException(ErrorCode.SMAPI_SERVER_IMEXPORT_OBJECT_NOTFOUND);}
        else if(smApiResult.equals(SmApiResult.SERVER_IMEXPORT_ODBS_ERROR)) { appException = new AppException(ErrorCode.SMAPI_SERVER_IMEXPORT_ODBS_ERROR);}
        else if(smApiResult.equals(SmApiResult.SERVER_IMEXPORT_OVERWRITE_ERROR)) { appException = new AppException(ErrorCode.SMAPI_SERVER_IMEXPORT_OVERWRITE_ERROR);}
        else if(smApiResult.equals(SmApiResult.SERVER_IMEXPORT_POLICY_STORE_ERROR)) { appException = new AppException(ErrorCode.SMAPI_SERVER_IMEXPORT_POLICY_STORE_ERROR);}
        else if(smApiResult.equals(SmApiResult.SERVER_IMEXPORT_PROPERTY_ACCESS_ERROR)) { appException = new AppException(ErrorCode.SMAPI_SERVER_IMEXPORT_PROPERTY_ACCESS_ERROR);}
        else if(smApiResult.equals(SmApiResult.SERVER_IMEXPORT_PROPERTY_NOTFOUND)) { appException = new AppException(ErrorCode.SMAPI_SERVER_IMEXPORT_PROPERTY_NOTFOUND);}
        else if(smApiResult.equals(SmApiResult.SERVER_IMEXPORT_READ_ERROR)) { appException = new AppException(ErrorCode.SMAPI_SERVER_IMEXPORT_READ_ERROR);}
        else if(smApiResult.equals(SmApiResult.SERVER_IMEXPORT_SITEMINDER_CREDENTIALS_ERROR)) { appException = new AppException(ErrorCode.SMAPI_SERVER_IMEXPORT_SITEMINDER_CREDENTIALS_ERROR);}
        else if(smApiResult.equals(SmApiResult.SERVER_IMEXPORT_UNKNOWN_ERROR)) { appException = new AppException(ErrorCode.SMAPI_SERVER_IMEXPORT_UNKNOWN_ERROR);}
        else if(smApiResult.equals(SmApiResult.SERVER_IMEXPORT_WRITE_ERROR)) { appException = new AppException(ErrorCode.SMAPI_SERVER_IMEXPORT_WRITE_ERROR);}
        else if(smApiResult.equals(SmApiResult.SERVER_INVALID_DIRECTORY)) { appException = new AppException(ErrorCode.SMAPI_SERVER_INVALID_DIRECTORY);}
        else if(smApiResult.equals(SmApiResult.SERVER_INVALID_OBJECTCLASS)) { appException = new AppException(ErrorCode.SMAPI_SERVER_INVALID_OBJECTCLASS);}
        else if(smApiResult.equals(SmApiResult.SERVER_INVALID_PASSWORD)) { appException = new AppException(ErrorCode.SMAPI_SERVER_INVALID_PASSWORD);}
        else if(smApiResult.equals(SmApiResult.SERVER_INVALID_SESSION)) { appException = new AppException(ErrorCode.SMAPI_SERVER_INVALID_SESSION);}
        else if(smApiResult.equals(SmApiResult.SERVER_MISMATCH)) { appException = new AppException(ErrorCode.SMAPI_SERVER_MISMATCH);}
        else if(smApiResult.equals(SmApiResult.SERVER_NO_COMMAND)) { appException = new AppException(ErrorCode.SMAPI_SERVER_NO_COMMAND);}
        else if(smApiResult.equals(SmApiResult.SERVER_NO_ITEMS_FOUND)) { appException = new AppException(ErrorCode.SMAPI_SERVER_NO_ITEMS_FOUND);}
        else if(smApiResult.equals(SmApiResult.SERVER_NO_SESSION)) { appException = new AppException(ErrorCode.SMAPI_SERVER_NO_SESSION);}
        else if(smApiResult.equals(SmApiResult.SERVER_NOT_AUTHORIZED)) { appException = new AppException(ErrorCode.SMAPI_SERVER_NOT_AUTHORIZED);}
        else if(smApiResult.equals(SmApiResult.SERVER_NOT_IMPLEMENTED)) { appException = new AppException(ErrorCode.SMAPI_SERVER_NOT_IMPLEMENTED);}
        else if(smApiResult.equals(SmApiResult.SERVER_PASSWORDSTATE)) { appException = new AppException(ErrorCode.SMAPI_SERVER_PASSWORDSTATE);}
        else if(smApiResult.equals(SmApiResult.SERVER_POLICY_API)) { appException = new AppException(ErrorCode.SMAPI_SERVER_POLICY_API);}
        else if(smApiResult.equals(SmApiResult.SERVER_REMOVE_MEMBER)) { appException = new AppException(ErrorCode.SMAPI_SERVER_REMOVE_MEMBER);}
        else if(smApiResult.equals(SmApiResult.SERVER_RESPONSE_TOO_BIG)) { appException = new AppException(ErrorCode.SMAPI_SERVER_RESPONSE_TOO_BIG);}
        else if(smApiResult.equals(SmApiResult.SERVER_SEARCH)) { appException = new AppException(ErrorCode.SMAPI_SERVER_SEARCH);}
        else if(smApiResult.equals(SmApiResult.SERVER_SET_PROPS)) { appException = new AppException(ErrorCode.SMAPI_SERVER_SET_PROPS);}
        else if(smApiResult.equals(SmApiResult.SERVER_TOO_MANY_ITEMS_FOUND)) { appException = new AppException(ErrorCode.SMAPI_SERVER_TOO_MANY_ITEMS_FOUND);}
        else if(smApiResult.equals(SmApiResult.SERVER_USER_DIR_NOT_CONFIGURED)) { appException = new AppException(ErrorCode.SMAPI_SERVER_USER_DIR_NOT_CONFIGURED);}
        else if(smApiResult.equals(SmApiResult.SERVER_USER_POLICY_IN_CONSISTENT_AND_BIT_MASK)) { appException = new AppException(ErrorCode.SMAPI_SERVER_USER_POLICY_IN_CONSISTENT_AND_BIT_MASK);}
        else if(smApiResult.equals(SmApiResult.SERVER_WORKFLOW_EXCEPTION)) { appException = new AppException(ErrorCode.SMAPI_SERVER_WORKFLOW_EXCEPTION);}
        else if(smApiResult.equals(SmApiResult.SERVER_WORKFLOW_INIT)) { appException = new AppException(ErrorCode.SMAPI_SERVER_WORKFLOW_INIT);}
        else if(smApiResult.equals(SmApiResult.SERVER_WORKFLOW_POSTPROCESS)) { appException = new AppException(ErrorCode.SMAPI_SERVER_WORKFLOW_POSTPROCESS);}
        else if(smApiResult.equals(SmApiResult.SERVER_WORKFLOW_PREPROCESS)) { appException = new AppException(ErrorCode.SMAPI_SERVER_WORKFLOW_PREPROCESS);}
        else {
            appException = null;
        }
        return appException;
    }

    public String getStackAsString(){
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        this.printStackTrace(pw);        
        return sw.toString();
    }
    
    private Map<String, Object> getMap(){
        Throwable cause = this.getCause();
        String message =  this.getMessage();
        ErrorCode errCode  = this.getCode();
        String causeStr = null;
        String stack = this.getStackAsString();
        
        if(cause != null){
            StringWriter causeStringWriter = new StringWriter();
            PrintWriter causePrintWriter = new PrintWriter(causeStringWriter);
            cause.printStackTrace(causePrintWriter);            
            causeStr = causeStringWriter.toString();            
        }
        
        Map<String, Object> ret = new HashMap<String, Object>();
        ret.put("errorCode",errCode.getCode());
        ret.put("errorCodeDesc",errCode.getDescription());
        ret.put("message",message);
        ret.put("cause",causeStr);
        ret.put("stack",stack);        
        return ret;
    }
    
    public WebApplicationException getWebAppException(){
        return this.getWebAppException(null);
    }
    
    public WebApplicationException getWebAppException(Map<String, Object> addInfo){
        return this.getWebAppException(addInfo, null);
    }
    
    public WebApplicationException getWebAppException(Map<String, Object> addInfo, List<NewCookie> cookies){
        Throwable cause = this.getCause();        
        ErrorCode errorCode = this.getCode();
        String message = this.getMessage();
        String stackStr = this.getStackAsString();
        Map obj = this.getMap();
        
        if(addInfo != null && addInfo.size() >0){
            obj.putAll(addInfo);    
        }
        
        return new WebApplicationException(){

            @Override
            public Response getResponse() {
                Response.Status status = Response.Status.INTERNAL_SERVER_ERROR;
                if(errorCode.getType().compareTo("USER")==0){
                    status = Response.Status.BAD_REQUEST;
                }
                if(cookies == null){
                    return Response.status(status).entity(obj).build();    
                }else{
                    return Response.status(status).cookie(cookies.toArray(new NewCookie[0])).entity(obj).build();    
                }
            }

            @Override
            public String getMessage() {
                return message;
            }

            @Override
            public synchronized Throwable getCause() {
                return cause;
            }

            @Override
            public String toString() {
                return stackStr;
            }
        };
    }
}
