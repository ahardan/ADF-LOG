/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.darden.krowd.login.ldap;

import java.util.logging.Logger;

import org.apache.commons.pool2.PooledObjectFactory;
import org.apache.commons.pool2.impl.GenericObjectPool;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;

/**
 *
 * @author gsdrxg1
 */
public class ADConnectionPool extends GenericObjectPool<ADConnection> {    
    public ADConnectionPool(PooledObjectFactory factory) {
        super(factory);
    }

    @Override
    public void addObject() throws Exception {
        super.addObject(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void close() {
        super.close(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void clear() {
        super.clear(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void invalidateObject(ADConnection obj) throws Exception {
        super.invalidateObject(obj); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void returnObject(ADConnection obj) {
        super.returnObject(obj); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ADConnection borrowObject() throws Exception {
        return super.borrowObject(); //To change body of generated methods, choose Tools | Templates.
    }

    public ADConnectionPool(ADConnectionFactory factory, GenericObjectPoolConfig config) {
        super(factory, config);
    }

}
