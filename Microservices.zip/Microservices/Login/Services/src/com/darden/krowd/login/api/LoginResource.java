package com.darden.krowd.login.api;

import com.darden.krowd.exception.AppException;
import com.darden.krowd.exception.ErrorCode;
import com.darden.krowd.login.ldap.ADConnection;
import com.darden.krowd.login.ldap.ADConnectionPool;

import com.darden.krowd.login.ldap.ADUser;
import com.darden.krowd.login.model.LoginRequest;
import com.darden.krowd.login.siteminder.SMAgentConnection;
import com.darden.krowd.login.siteminder.SMAgentConnectionPool;

import com.darden.krowd.login.siteminder.SessionInfo;

import java.io.IOException;

import java.net.HttpCookie;

import java.net.URI;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;

import javax.servlet.http.HttpServletRequest;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Cookie;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;

@Path("authenticate")
public class LoginResource {
    private static String SM_AGENT_CONNECTION_POOL = "SM_AGENT_CONNECTION_POOL";
    private static String AD_CONNECTION_POOL = "AD_CONNECTION_POOL";
    private static SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyyy hh:mm:ss");
    private static final String SM_BASIC_AUTH_PROTECTED_CONTEXT_ROOT = "/login/auth.json";

    private static String[] VISITING_COOKIES = new String[] {
        "co2", "Div2", "Area2", "Reg2", "Rest2", "Security2", "UserType2" };
    private static HashMap<String, String> COOKIE_AD_ATTR_MAPPING = new HashMap<String, String>() {
        {
            put("Name", ADUser.DISPLAYNAME);
            put("UserID", ADUser.SAMACCOUNTNAME);
            put("EmpID", ADUser.DARDEN_PS_OPRID);
            put("Co", ADUser.CO);
            put("Rest", ADUser.PHYSICALDELIVERYOFFICENAME);
            put("Div", ADUser.DIVISION);
            put("Area", ADUser.DARDEN_AREA);
            put("Reg", ADUser.DARDEN_REGION);
            put("Security", ADUser.DARDEN_SECURITY_CODE); //left most digit
            put("UserType", "");
            put("SignOnDefault", ADUser.DARDEN_PS_OPRID);
            put("co", ADUser.CO);

        }
    };

    private String[] PEOPLESOFT_COOKIES = new String[] {
        "ATH_TOKEN", "PS_TOKEN", "PS_LOGINLIST", "PS_TOKENEXPIRE", "pa-web-p1.darden.com-8080-PORTAL-PSJSESSIONID",
        "pa-web-p2.darden.com-8080-PORTAL-PSJSESSIONID", "pa-web-p3.darden.com-8080-PORTAL-PSJSESSIONID",
        "pa-web-p4.darden.com-8080-PORTAL-PSJSESSIONID", "pa-web-p1-8080-PORTAL-PSJSESSIONID",
        "pa-web-p2-8080-PORTAL-PSJSESSIONID", "pa-web-p3-8080-PORTAL-PSJSESSIONID",
        "pa-web-p4-8080-PORTAL-PSJSESSIONID", "psuwebp3-8080-PORTAL-PSJSESSIONID", "psuwebp4-8080-PORTAL-PSJSESSIONID",
        "psuwebp5-8080-PORTAL-PSJSESSIONID", "psuwebp6-8080-PORTAL-PSJSESSIONID", "psuwebp7-8080-PORTAL-PSJSESSIONID",
        "psuwebp3.darden.com-8080-PORTAL-PSJSESSIONID", "psuwebp4.darden.com-8080-PORTAL-PSJSESSIONID",
        "psuwebp5.darden.com-8080-PORTAL-PSJSESSIONID", "psuwebp6.darden.com-8080-PORTAL-PSJSESSIONID",
        "psuwebp7.darden.com-8080-PORTAL-PSJSESSIONID"
    };


    @Context
    private ServletContext context;

    public LoginResource() {
    }

    private ADConnectionPool getADConnectionPool() {
        ADConnectionPool adConnectionPool = (ADConnectionPool) context.getAttribute(AD_CONNECTION_POOL);
        return adConnectionPool;
    }

    private SMAgentConnectionPool getSMAgentConnectionPool() {
        SMAgentConnectionPool smAgentConnectionPool =
            (SMAgentConnectionPool) context.getAttribute(SM_AGENT_CONNECTION_POOL);
        return smAgentConnectionPool;
    }

    private void returnToPool(ADConnection adConn, SMAgentConnection smAgentConnection) {
        if (adConn != null) {
            getADConnectionPool().returnObject(adConn);
        }

        if (smAgentConnection != null) {
            getSMAgentConnectionPool().returnObject(smAgentConnection);
        }
    }

    /*
     * SMAUTHREASON
     *
     * Sm_Api_Reason_None = 0
      Sm_Api_Reason_PwMustChange = 1
      Sm_Api_Reason_InvalidSession = 2
      Sm_Api_Reason_RevokedSession = 3
      Sm_Api_Reason_ExpiredSession = 4
      Sm_Api_Reason_AuthLevelTooLow = 5
      Sm_Api_Reason_UnknownUser = 6
      Sm_Api_Reason_UserDisabled = 7
      Sm_Api_Reason_InvalidSessionId = 8
      Sm_Api_Reason_InvalidSessionIp = 9
      Sm_Api_Reason_CertificateRevoked = 10
      Sm_Api_Reason_CRLOutOfDate = 11
      Sm_Api_Reason_CertRevokedKeyCompromised = 12
      Sm_Api_Reason_CertRevokedAffiliationChange = 13
      Sm_Api_Reason_CertOnHold = 14
      Sm_Api_Reason_TokenCardChallenge = 15
      Sm_Api_Reason_ImpersonatedUserNotInDir = 16
      Sm_Api_Reason_Anonymous = 17
      Sm_Api_Reason_PwWillExpire = 18
      Sm_Api_Reason_PwExpired = 19
      Sm_Api_Reason_ImmedPWChangeRequired = 20
      Sm_Api_Reason_PWChangeFailed = 21
      Sm_Api_Reason_BadPWChange = 22
      Sm_Api_Reason_PWChangeAccepted = 23
      Sm_Api_Reason_ExcessiveFailedLoginAttempts = 24
      Sm_Api_Reason_AccountInactivity = 25
      Sm_Api_Reason_NoRedirectConfigured = 26
      Sm_Api_Reason_ErrorMessageIsRedirect = 27
      Sm_Api_Reason_Next_Tokencode = 28
      Sm_Api_Reason_New_PIN_Select = 29
      Sm_Api_Reason_New_PIN_Sys_Tokencode = 30
      Sm_Api_Reason_New_User_PIN_Tokencode = 31
      Sm_Api_Reason_New_PIN_Accepted = 32
      Sm_Api_Reason_Guest = 33
      Sm_Api_Reason_PWSelfChange = 34
      Sm_Api_Reason_ServerException = 35
      Sm_Api_Reason_UnknownScheme = 36
      Sm_Api_Reason_UnsupportedScheme = 37
      Sm_Api_Reason_Misconfigured = 38
      Sm_Api_Reason_BufferOverflow = 39
      Sm_Api_Reason_SetPersistentSessionFailed = 40
      Sm_Api_Reason_UserLogout = 41
      Sm_Api_Reason_IdleSession = 42
      Sm_Api_Reason_PolicyServerEnforcedTimeout = 43
      Sm_Api_Reason_PolicyServerEnforcedIdle = 44
      Sm_Api_Reason_ImpersonationNotAllowed = 45
      Sm_Api_Reason_ImpersonationNotAllowedUser = 46
      Sm_Api_Reason_FederationNoLoginID = 47
      Sm_Api_Reason_FederationUserNotInDir = 48
      Sm_Api_Reason_FederationInvalidMessage = 49
      Sm_Api_Reason_FederationUnacceptedMessage  = 50
      Sm_Api_Reason_ADnativeUserDisabled  = 51

        Note: This reason code is a duplicate of Sm_Api_Reason_UserDisabled.
        It is used only in the case where the registry key "IgnoreDefaultRedirectOnADnativeDisabled" is set, and an AD native disabled reason is found.
        Since this value duplicates Sm_Api_Reason_UserDisabled, whenever that value is checked, this should probably be checked as well.
        This value is only returned by SnDsLdapProvider::AuthenticateUser.
     */

    /*
     * Smenc - contains information that tells the browser what language encoding to use.
        smlocale - is the language used in the HTML forms that collect user information or display status messages.
        Username - is the name to use as the login user name.
        password - is the password to use to perform the login.
        target - is the resource to access after login.
        smauthreason - is the reason code associated with a login failure.
        smusrmsg - contains the text that describes why the user was challenged or failed to login.
        Smagentname - is the agent name used for logging the user in.
        postpreservationdata - is the data that a user submits through a post request.
        smerrorpage - is the page to which the user's browser will be redirected if there is an error on a post to the custom form.
        smretries - defines the maximum number of allowed failures when attempting to login.
     */

    /*
     *
     *
        Dim strOprID, strMemberOf, bContinue, strSecurityLevel
        strOprID = GetAttribute("OPRID") //Darden-PS-OPRID
        strMemberOf = GetAttribute("MemberOf")
        strSecurityLevel = GetAttribute("SECURITYLEVEL") //Darden-Security-Code

        ' California manager check from home
        if (Request.Cookies("CA_HOME") = "1" or GetAttribute("CA_HOME") = "1") then
                if(instr(strMemberOf, "zzSGCAManagers") and strSecurityLevel <> "69999") then
                        Response.cookies("Name") = GetAttribute("FirstName") & " " & GetAttribute("LastName")
                        Response.cookies("Name").Path = "/"
                Response.cookies("Name").Domain = "darden.com"
                // JMF: 10/8/18: corrected the redirect URL for Krowd Lite
                //Response.redirect "applications/CaMgrHomeLinks/default.htm"
                Response.redirect "/krowd/applications/CaMgrHomeLinks/default.asp"
                end if
        end if
     */

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response authenticate(@Context HttpServletRequest re, LoginRequest loginReq) {        
        String serverName = re.getServerName();
        String scheme = re.getScheme();
        int port = re.getServerPort();
        String serverRoot = scheme +"://"+serverName + ":" + port;
        
        String username = loginReq.getUsername();
        String password = loginReq.getPassword();
        
        
        
        
        // Redirection to https://krowdweb.darden.com/krowd/prd/siteminder/login.asp?TYPE=33554433&REALMOID=06-0170fdd6-20c9-4f47-b6b2-05d60541a5cf&GUID=&SMAUTHREASON=0&METHOD=GET&SMAGENTNAME=-SM-EEoY3i%2bgtzJCmZO6dNK7447aNZupFaub3x1r%2fqs7gftOa%2fO52czqjZti0B%2bwb0Tq&TARGET=-SM-https%3a%2f%2fkrowd%2edarden%2ecom%2fkrowd%2f
        ADConnectionPool adConnPool = getADConnectionPool();
        ADConnection adConn = null;
        try {
            adConn = adConnPool.borrowObject();
        } catch (Exception e) {
            returnToPool(adConn, null);
            throw new AppException(ErrorCode.AD_CONNECTION_POOL_BORROW_FAILED.getDescription(),
                                                               e, ErrorCode.AD_CONNECTION_POOL_BORROW_FAILED).getWebAppException(null, clearApplicationCookies());
        }

        ADUser adUser = null;
        try {
            adUser = adConn.getUserForLoginID(username);
        } catch (AppException e) {
            returnToPool(adConn, null);
            throw e.getWebAppException(null, clearApplicationCookies());
        }

        Date lockoutTime = adUser.getLockoutTime();

        if (lockoutTime != null) {
            returnToPool(adConn, null);
            HashMap<String, Object> addInfo = new HashMap<String, Object>();
            addInfo.put(ADUser.LOCKOUTTIME, adUser.getLockoutTime());
            addInfo.put(ADUser.BADPASSWORDTIME, adUser.getBadPasswordTime());
            addInfo.put(ADUser.BADPWDCOUNT, adUser.getBadPwdCount());
            throw new AppException(ErrorCode.AD_USER_LOCKOUT.getDescription(), ErrorCode.AD_USER_LOCKOUT)
                  .getWebAppException(addInfo, clearApplicationCookies());
        }

        String sam = adUser.getSAMAccountName();
        try {
            //set cookies
            //TODO: Test UCM Url redirect login
            
            //TODO: Check if previous successful auth attempts have the same credential hash. Store all previous successful attempts in DB or Redis
            List<HttpCookie> smLoginCookies = performSMLogin(sam, password,serverRoot);              
            List<NewCookie> cookies = getCookies(adUser);
            cookies.addAll(toNewCookies(smLoginCookies));
            
            
            /*
            strOprID = GetAttribute("OPRID")
            strMemberOf = GetAttribute("MemberOf")
            strSecurityLevel = GetAttribute("SECURITYLEVEL")

            ' California manager check from home
            if (Request.Cookies("CA_HOME") = "1" or GetAttribute("CA_HOME") = "1") then
                    if(instr(strMemberOf, "zzSGCAManagers") and strSecurityLevel <> "69999") then
                            Response.cookies("Name") = GetAttribute("FirstName") & " " & GetAttribute("LastName")
                            Response.cookies("Name").Path = "/"
                    Response.cookies("Name").Domain = "darden.com"        
                    // JMF: 10/8/18: corrected the redirect URL for Krowd Lite
                    //Response.redirect "applications/CaMgrHomeLinks/default.htm"
                    Response.redirect "/krowd/applications/CaMgrHomeLinks/default.asp"
                    end if
            end if
             */
            
            return Response.ok().cookie(cookies.toArray(new NewCookie[0])).build();                           
        } catch (AppException e) {
            //unable to login via SM. Check for MFA ?
            try {
                //TODO: Do not simply retry. Check user password pattern with previous attempts. Store successful patterns in Redis or Database.
                adConn.login(adUser, password); //TODO: This will count towards invalid login attempt. How to prevent?
                //User able to authenticate against AD but SM. Log this. Retry SM Login.
                //TODO: Perform retry
                throw new AppException(ErrorCode.SM_AD_MISMATCH.getDescription(), ErrorCode.SM_AD_MISMATCH)
                      .getWebAppException(null, clearApplicationCookies());
            } catch (AppException f) {
                //unable to login to AD as well.

                //TODO: get latest user details from AD
                HashMap<String, Object> addInfo = new HashMap<String, Object>();
                addInfo.put(ADUser.LOCKOUTTIME, adUser.getLockoutTime());
                addInfo.put(ADUser.BADPASSWORDTIME, adUser.getBadPasswordTime());
                addInfo.put(ADUser.BADPWDCOUNT, adUser.getBadPwdCount() + 2);

                throw e.getWebAppException(addInfo, clearApplicationCookies());
            }
        }finally{
            returnToPool(adConn, null);            
        }
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.APPLICATION_JSON)
    public Response authenticate(@Context HttpServletRequest re, @FormParam("username") String username,
                                 @FormParam("password") String password, @FormParam("TYPE") String smType,
                                 @FormParam("REALMOID") String smRealmOid, @FormParam("GUID") String smGUID,
                                 @FormParam("smauthreason") String smAuthReason,@FormParam("smquerydata") String smquerydata,
                                 @FormParam("smagentname") String smAgentName, @FormParam("target") String smTarget) {
        // Redirection to https://krowdweb.darden.com/krowd/prd/siteminder/login.asp?TYPE=33554433&REALMOID=06-0170fdd6-20c9-4f47-b6b2-05d60541a5cf&GUID=&SMAUTHREASON=0&METHOD=GET&SMAGENTNAME=-SM-EEoY3i%2bgtzJCmZO6dNK7447aNZupFaub3x1r%2fqs7gftOa%2fO52czqjZti0B%2bwb0Tq&TARGET=-SM-https%3a%2f%2fkrowd%2edarden%2ecom%2fkrowd%2f
        String serverName = re.getServerName();
        String scheme = re.getScheme();
        int port = re.getServerPort();
        String serverRoot = scheme +"://"+serverName + ":" + port;

        ADConnectionPool adConnPool = getADConnectionPool();
        ADConnection adConn = null;
        
        try {
            adConn = adConnPool.borrowObject();
        } catch (Exception e) {
            returnToPool(adConn, null);
            throw new WebApplicationException(new AppException(ErrorCode.AD_CONNECTION_POOL_BORROW_FAILED.getDescription(),
                                                               e, ErrorCode.AD_CONNECTION_POOL_BORROW_FAILED),
                                              Response.Status.INTERNAL_SERVER_ERROR);
        }

        ADUser adUser = null;
        try {
            adUser = adConn.getUserForLoginID(username);
        } catch (AppException e) {
            returnToPool(adConn, null);
            throw e.getWebAppException();
        }

        Date lockoutTime = adUser.getLockoutTime();

        if (lockoutTime != null) {
            returnToPool(adConn, null);
            HashMap<String, Object> addInfo = new HashMap<String, Object>();
            addInfo.put(ADUser.LOCKOUTTIME, adUser.getLockoutTime());
            addInfo.put(ADUser.BADPASSWORDTIME, adUser.getBadPasswordTime());
            addInfo.put(ADUser.BADPWDCOUNT, adUser.getBadPwdCount());
            throw new AppException(ErrorCode.AD_USER_LOCKOUT.getDescription(), ErrorCode.AD_USER_LOCKOUT)
                  .getWebAppException(addInfo);
        }

        String sam = adUser.getSAMAccountName();
        try {
            //set cookies
            //TODO: Test UCM Url redirect login
                        
            //TODO: Check if previous successful auth attempts have the same credential hash. Store all previous successful attempts in DB or Redis
            List<HttpCookie> smLoginCookies = performSMLogin(sam, password,serverRoot);         
            returnToPool(adConn, null);
            List<NewCookie> cookies = getCookies(adUser);
            cookies.addAll(toNewCookies(smLoginCookies));
            String destination = serverRoot + "/krowd";
            if(smTarget != null){                
                try{
                    URI uri = new URI(smTarget);
                    String host = uri.getHost();
                    if(host.toUpperCase().endsWith(".DARDEN.COM")){
                        return Response.seeOther(uri).cookie(cookies.toArray(new NewCookie[0])).build();
                    }else{
                        return Response.status(Response.Status.FOUND).header("Location", destination).cookie(cookies.toArray(new NewCookie[0])).build();
                    }
                }catch(Exception e){
                    return Response.status(Response.Status.FOUND).header("Location", destination).cookie(cookies.toArray(new NewCookie[0])).build();    
                }                                
            }else{
                return Response.status(Response.Status.FOUND).header("Location", destination).cookie(cookies.toArray(new NewCookie[0])).build();    
            }
        } catch (AppException e) {
            //unable to login via SM. Check for MFA ?
            try {
                //TODO: Do not simply retry. Check user password pattern with previous attempts. Store successful patterns in Redis or Database.
                adConn.login(adUser, password); //TODO: This will count towards invalid login attempt. How to prevent?
                //User able to authenticate against AD but SM. Log this. Retry SM Login.
                //TODO: Perform retry
                returnToPool(adConn, null);
                throw new AppException(ErrorCode.SM_AD_MISMATCH.getDescription(), ErrorCode.SM_AD_MISMATCH)
                      .getWebAppException();
            } catch (AppException f) {
                //unable to login to AD as well.

                returnToPool(adConn, null);

                //TODO: get latest user details from AD
                HashMap<String, Object> addInfo = new HashMap<String, Object>();
                addInfo.put(ADUser.LOCKOUTTIME, adUser.getLockoutTime());
                addInfo.put(ADUser.BADPASSWORDTIME, adUser.getBadPasswordTime());
                addInfo.put(ADUser.BADPWDCOUNT, adUser.getBadPwdCount() + 2);

                throw e.getWebAppException(addInfo);
            }
        }
    }
   
    
    private List<NewCookie> toNewCookies(List<HttpCookie> httpCookies){
        if(httpCookies == null){
            return null;
        }
        
        List<NewCookie> newCookies = new ArrayList<NewCookie>();
        NewCookie newCookie = null;
        for(HttpCookie httpCookie : httpCookies){
            //NewCookie(String name, String value, String path, String domain, int version, String comment, int maxAge, boolean secure
            newCookie = new NewCookie(httpCookie.getName(), httpCookie.getValue(), httpCookie.getPath(), httpCookie.getDomain(), httpCookie.getVersion(), httpCookie.getComment(), new Long(httpCookie.getMaxAge()).intValue() ,httpCookie.getSecure());
            newCookies.add(newCookie);
        }
        return newCookies;
    }

/*
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response authenticate(@Context HttpServletRequest re, LoginRequest loginReq) {
        String username = loginReq.getUsername();
        String password = loginReq.getPassword();
        // Redirection to https://krowdweb.darden.com/krowd/prd/siteminder/login.asp?TYPE=33554433&REALMOID=06-0170fdd6-20c9-4f47-b6b2-05d60541a5cf&GUID=&SMAUTHREASON=0&METHOD=GET&SMAGENTNAME=-SM-EEoY3i%2bgtzJCmZO6dNK7447aNZupFaub3x1r%2fqs7gftOa%2fO52czqjZti0B%2bwb0Tq&TARGET=-SM-https%3a%2f%2fkrowd%2edarden%2ecom%2fkrowd%2f
        ADConnectionPool adConnPool = getADConnectionPool();
        SMAgentConnectionPool smAgentConnectionPool = getSMAgentConnectionPool();

        ADConnection adConn = null;
        SMAgentConnection agentConn = null;
        try {
            adConn = adConnPool.borrowObject();
        } catch (Exception e) {
            returnToPool(adConn, agentConn);
            List<NewCookie> cookies = clearApplicationCookies();
            throw new AppException(ErrorCode.AD_CONNECTION_POOL_BORROW_FAILED.getDescription(),
                                                               e, ErrorCode.AD_CONNECTION_POOL_BORROW_FAILED).getWebAppException(null, clearApplicationCookies());
        }

        try {
            agentConn = smAgentConnectionPool.borrowObject();
        } catch (Exception e) {
            returnToPool(adConn, agentConn);
            throw new AppException(ErrorCode.AD_CONNECTION_POOL_BORROW_FAILED.getDescription(),
                                                               e, ErrorCode.AD_CONNECTION_POOL_BORROW_FAILED).getWebAppException(null, clearApplicationCookies());
        }

        ADUser adUser = null;
        try {
            adUser = adConn.getUserForLoginID(username);
        } catch (AppException e) {
            returnToPool(adConn, agentConn);
            throw e.getWebAppException(null, clearApplicationCookies());
        }

        Date lockoutTime = adUser.getLockoutTime();

        if (lockoutTime != null) {
            returnToPool(adConn, agentConn);
            HashMap<String, Object> addInfo = new HashMap<String, Object>();
            addInfo.put(ADUser.LOCKOUTTIME, adUser.getLockoutTime());
            addInfo.put(ADUser.BADPASSWORDTIME, adUser.getBadPasswordTime());
            addInfo.put(ADUser.BADPWDCOUNT, adUser.getBadPwdCount());
            throw new AppException(ErrorCode.AD_USER_LOCKOUT.getDescription(), ErrorCode.AD_USER_LOCKOUT)
                  .getWebAppException(addInfo, clearApplicationCookies());
        }

        String sam = adUser.getSAMAccountName();
        try {
            //TODO: Check if previous successful auth attempts have the same credential hash. Store all previous successful attempts in DB or Redis
            SessionInfo sessionInfo = agentConn.login(sam, password, re.getRemoteAddr());
            sessionInfo.setUser(adUser);
            //set cookies
            //TODO: Test UCM Url redirect login
            returnToPool(adConn, agentConn);
            List<NewCookie> cookies = getCookies(adUser);
            cookies.add(new NewCookie("SMSESSION",sessionInfo.getSSOToken(),"/",".darden.com",0,null,-1, false));
            return Response.ok().cookie(cookies.toArray(new NewCookie[0])).build();
                           
        } catch (AppException e) {
            //unable to login via SM. Check for MFA ?
            try {
                //TODO: Do not simply retry. Check user password pattern with previous attempts. Store successful patterns in Redis or Database.
                adConn.login(adUser, password); //TODO: This will count towards invalid login attempt. How to prevent?
                //User able to authenticate against AD but SM. Log this. Retry SM Login.
                //TODO: Perform retry
                returnToPool(adConn, agentConn);
                throw new AppException(ErrorCode.SM_AD_MISMATCH.getDescription(), ErrorCode.SM_AD_MISMATCH)
                      .getWebAppException(null, clearApplicationCookies());
            } catch (AppException f) {
                //unable to login to AD as well.

                returnToPool(adConn, agentConn);

                //TODO: get latest user details from AD
                HashMap<String, Object> addInfo = new HashMap<String, Object>();
                addInfo.put(ADUser.LOCKOUTTIME, adUser.getLockoutTime());
                addInfo.put(ADUser.BADPASSWORDTIME, adUser.getBadPasswordTime());
                addInfo.put(ADUser.BADPWDCOUNT, adUser.getBadPwdCount() + 2);

                throw e.getWebAppException(addInfo, clearApplicationCookies());
            }
        }
    }

 */
    private List<HttpCookie> performSMLogin(String username, String password, String loginApiPrefix) throws AppException {
        CredentialsProvider provider = new BasicCredentialsProvider();
        UsernamePasswordCredentials creds = new UsernamePasswordCredentials(username, password);
        provider.setCredentials(AuthScope.ANY,creds);
        
        CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultCredentialsProvider(provider).build();                
        HttpUriRequest request = RequestBuilder.get().setUri(loginApiPrefix + SM_BASIC_AUTH_PROTECTED_CONTEXT_ROOT).addHeader("Cookie", "SMCHALLENGE=YES").build();
        
        
        try {
            CloseableHttpResponse response = httpClient.execute(request);
            int statusCode =  response.getStatusLine().getStatusCode();
            
            if(statusCode == 200){
                List<HttpCookie> retCookies = new ArrayList<HttpCookie>();
                Header[] headers = response.getHeaders("Set-Cookie");
                for(Header header : headers){
                     retCookies.addAll(HttpCookie.parse(header.getValue()));
                }
                return retCookies;
            }else{
                if(statusCode == 401){
                    throw new AppException(ErrorCode.LOGIN_FAIL_NO.getDescription(), ErrorCode.LOGIN_FAIL_NO);
                }else{
                    throw new AppException(statusCode+"", ErrorCode.LOGIN_FAIL_FAILURE);
                }
            }
        } catch (ClientProtocolException e) {
            throw new AppException(ErrorCode.LOGIN_FAIL_NOCONNECTION.getDescription(),e, ErrorCode.LOGIN_FAIL_FAILURE);
        } catch (IOException e) {
            throw new AppException(ErrorCode.LOGIN_FAIL_NOCONNECTION.getDescription(),e, ErrorCode.LOGIN_FAIL_FAILURE);
        }  
    }
    
    private List<NewCookie> clearApplicationCookies() {
        String dateInString = "01-01-2000 00:00:06";
        Date dt = null;
        try {
            dt = sdf.parse(dateInString);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        
        ArrayList<NewCookie> cookies = new ArrayList<NewCookie>();
        //Clear Visiting cookies
        for (String cookieName : VISITING_COOKIES) {
            cookies.add(new NewCookie(cookieName,null, "/",".darden.com",0,null,-1,dt, false, false));
        }
        
        //Clean PeopleSoft Cookies
        for (String cookieName : PEOPLESOFT_COOKIES) {
            cookies.add(new NewCookie(cookieName,null, "/",".darden.com",0,null,-1,dt, false, false));
        }
        
        for (Map.Entry<String, String> entry : COOKIE_AD_ATTR_MAPPING.entrySet()) {
            String cookieName = entry.getKey();
            cookies.add(new NewCookie(cookieName,null, "/",".darden.com",0,null,-1,dt, false, false));
        }
        
        cookies.add(new NewCookie("SMSESSION","LOGGEDOFF","/",".darden.com",0,null,-1, false));        
        return cookies;
    }
    private List<NewCookie> getCookies(ADUser user) {
        ArrayList<NewCookie> cookies = new ArrayList<NewCookie>();

        //Clear Visiting cookies
        for (String visitingCookieName : VISITING_COOKIES) {
            cookies.add(new NewCookie(new Cookie(visitingCookieName, "", "/", ".darden.com",0)));
        }

        //Set Legacy Cookies
        Cookie cookie = null;
        for (Map.Entry<String, String> entry : COOKIE_AD_ATTR_MAPPING.entrySet()) {
            String cookieName = entry.getKey();
            String adAttrName = entry.getValue();
            Object adVal = user.getAttrVal(adAttrName);

            if (adVal != null) {
                String adValStr = adVal.toString();
                if (cookieName.compareTo("Security") == 0) {
                    if (adValStr.compareTo("00000") == 0) {
                        cookie = new Cookie(cookieName, "9", "/", ".darden.com",0);
                    } else {
                        cookie = new Cookie(cookieName, adValStr.substring(0, 1), "/", ".darden.com",0);
                    }
                }

                if (cookieName.compareTo("UserType") == 0) {
                    String dn = user.getDistinguishedName();
                    if (dn.indexOf("DC=mydish,DC=darden,DC=com") > 0) {
                        cookie = new Cookie(cookieName, "HOUR", "/", ".darden.com",0);
                    }

                    if (dn.indexOf("OU=RSC") > 0) {
                        cookie = new Cookie(cookieName, "DRI", "/", ".darden.com",0);
                    }
                    cookie = new Cookie(cookieName, "MGR", "/", ".darden.com",0);
                }


                cookie = new Cookie(cookieName, adVal.toString(), "/", ".darden.com",0);
            } else {
                if (cookieName.compareToIgnoreCase("co") == 0 || cookieName.compareToIgnoreCase("Div") == 0 ||
                    cookieName.compareToIgnoreCase("Reg") == 0 || cookieName.compareToIgnoreCase("Rest") == 0 ||
                    cookieName.compareToIgnoreCase("Area") == 0) {
                    cookie = new Cookie(cookieName, "0", "/", ".darden.com",0);
                }
            }

            if (cookie != null) {
                cookies.add(new NewCookie(cookie, null, -1,null,false, false));
            }
        }

        //Clean PeopleSoft Cookies
        String dateInString = "01-01-2000 00:00:06";
        Date dt = null;
        try {
            dt = sdf.parse(dateInString);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        for (String cookieName : PEOPLESOFT_COOKIES) {
            cookies.add(new NewCookie(cookieName,null, "/",".darden.com",0,null,-1,dt, false, false));
        }


        return cookies;
    }
    
    



}
