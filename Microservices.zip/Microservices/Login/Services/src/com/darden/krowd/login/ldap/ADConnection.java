/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.darden.krowd.login.ldap;

import com.darden.krowd.exception.AppException;
import com.darden.krowd.exception.ErrorCode;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.DirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.Control;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import org.apache.commons.collections4.MultiValuedMap;
import org.apache.commons.collections4.multimap.ArrayListValuedHashMap;

/**
 *
 * @author gsdrxg1
 */
public class ADConnection {

    private static final Logger LOGGER = Logger.getLogger(ADConnection.class.getName());
    
    private static final Integer THREE_SECONDS = 3000;
        private static final String[] AD_USER_ATTRIBS = new String[]{
                "cn",
                "objectCategory",
                "objectClass",
                "objectClass",
                "objectClass",
                "objectClass",
                "accountExpires",
                "co",
                "company",
                "Darden-Business-Unit",
                "Darden-Company-Number",
                "Darden-Date-Of-Birth",
                "Darden-Empl-ID",
                "Darden-Functional-Area",
                "Darden-Giftcard-Number",
                "Darden-Job-Function",
                "Darden-Job-Sub-Function",
                "Darden-Manager-Level",
                "Darden-PS-OPRID",
                "Darden-Region",
                "Darden-Security-Code",
                "department",
                "displayName",
                "distinguishedName",
                "division",
                "gecos",
                "gidNumber",
                "givenName",
                "lastLogonTimestamp",
                "lockoutTime",
                "mail",
                "mailNickname",
                "manager",
                "memberOf",
                "mobile",
                "name",
                "objectGUID",
                "physicalDeliveryOfficeName",
                "pwdLastSet",
                "sAMAccountName",
                "sAMAccountType",
                "sn",
                "title",
                "uidNumber",
                "userAccountControl",
                "userPrincipalName",
                "whenChanged",
                "whenCreated",
                "Darden-AKA",
                "Darden-Approver",
                "Darden-Area",
                "Darden-Badge-Number",
                "Darden-Building-Floor",
                "Darden-Continuous-Service-Date",
                "Darden-E-C-G-Sign-Date",
                "Darden-Job-Code",
                "Darden-Nickname",
                "Darden-Phone-Number",
                "Darden-Photo-Name",
                "Darden-POS-ID",
                "Darden-Work-State",
                "badPasswordTime",
                "badPwdCount",
                "countryCode",
                "departmentNumber",
                "description",
                "directReports",
                "employeeID",
                "employeeNumber",
                "employeeType",
                "initials",
                "middleName",
                "modifyTimeStamp",
                "photo",
                "thumbnailLogo",
                "thumbnailPhoto",
                "uid",
                "unicodePwd",
                "url",
                "userParameters",
                "userPassword",
                "jpegPhoto",
                "logonCount"
        };    
    
    private Hashtable ldapEnv;
    private ADConnectionConfig adConnectionConfig;
    private LdapContext ldapContext;

    public ADConnection(Hashtable ldapEnv, ADConnectionConfig adConnectionConfig) {
        this.ldapEnv = ldapEnv;
        this.adConnectionConfig = adConnectionConfig;
    }
    
    private SearchControls getDefaultSearchControls(){
            SearchControls sc = new SearchControls();
            sc.setSearchScope(SearchControls.SUBTREE_SCOPE);
            sc.setTimeLimit(THREE_SECONDS);
            sc.setCountLimit(50);
            sc.setReturningAttributes(AD_USER_ATTRIBS);
            return sc;
        }    

    public void init() throws AppException {
        try {
            if(this.ldapContext == null){
                this.ldapContext = new InitialLdapContext(this.ldapEnv, null);
                LOGGER.log(Level.INFO, "==> LDAP Context Initialized");                
            }else{
                LOGGER.log(Level.INFO, "==> LDAP Context already Initialized. Do nothing.");                
            }
        } catch (NamingException ex) {
            LOGGER.log(Level.SEVERE, null, ex);
            throw new AppException(ex, ErrorCode.AD_INIT_FAILED);
        }
    }

    public void unInit() {
        ADConnection.closeContext(this.ldapContext);
        this.ldapContext = null;
        LOGGER.log(Level.INFO, "==> LDAP Context UnInitialized");
    }

    private static void closeContext(LdapContext ldapContext){
        if (ldapContext != null) {
            try {
                ldapContext.close();
            } catch (NamingException e) {
                LOGGER.log(Level.SEVERE, "Unable to close Context");
            }
            ldapContext = null;
        }
    }

    public boolean isInitialized() {
        return this.ldapContext != null;
    }

    public List<ADUser> findUsersBySAM(String sAMAccountName) throws AppException {
        return this.findUsersByAttribute("sAMAccountName", sAMAccountName);
    }

    public List<ADUser> findUsersByAKA(String aka) throws AppException {
        return this.findUsersByAttribute("Darden-AKA", aka);
    }

    public List<ADUser> findUsersByAttributes(Map<String, String> attrs) throws AppException {
        MultiValuedMap<String, String> qMap = new ArrayListValuedHashMap<String, String>();
        qMap.putAll(attrs);
        return this.queryUsers(ADConnection.getQuery(qMap));
    }

    private List<ADUser> findUsersByAttribute(String attrName, String attrVal) throws AppException {
        MultiValuedMap<String, String> qMap = new ArrayListValuedHashMap<String, String>();
        qMap.put(attrName, attrVal);
        return this.queryUsers(ADConnection.getQuery(qMap));
    }

    private List<ADUser> queryUsers(String queryStr) throws AppException {

        try {
            NamingEnumeration answer = ldapContext.search(this.adConnectionConfig.getUserDN(), "(&(objectClass=User)(objectCategory=Person)" + queryStr + ")", getDefaultSearchControls());
            if (answer != null) {
                SearchResult ldapResult;
                List<ADUser> users = new ArrayList<ADUser>();
                while (answer.hasMore()) {
                    ldapResult = (SearchResult) answer.next();
                    Attributes attrs = ldapResult.getAttributes();
                    users.add(new ADUser(attrs));
                }

                if (users.size() == 0) {
                    LOGGER.log(Level.SEVERE, "No Matching users found.");
                    throw new AppException(ErrorCode.AD_NO_USERS_FOUND.getDescription(), ErrorCode.AD_NO_USERS_FOUND);
                }

                return users;
            } else {
                LOGGER.log(Level.SEVERE, "No Matching users found.");
                throw new AppException(ErrorCode.AD_NO_USERS_FOUND.getDescription(), ErrorCode.AD_NO_USERS_FOUND);
            }
        } catch (NamingException ex) {
            LOGGER.log(Level.SEVERE, "Search Failed", ex);
            throw new AppException(ex, ErrorCode.AD_USER_SEARCH_FAILED);
        }

    }

    private static String getQuery(MultiValuedMap<String, String> attributesMap) {
        if (attributesMap == null || attributesMap.size() == 0) {
            return null;
        }
        Set<String> keySet = attributesMap.keySet();
        String query = "";
        String subQuery = "";
        for (String key : keySet) {
            subQuery = "";
            Collection<String> vals = attributesMap.get(key);
            for (String val : vals) {
                subQuery = subQuery.concat("(" + key + "=" + val + ")");
            }
            if (vals.size() > 1) {
                subQuery = "(|" + subQuery + ")";
            }

            query = query.concat(subQuery);
        }
        query = "(&" + query + ")";
        LOGGER.info("======> QUERY : " + query);
        return query;
    }

    public void resetPassword(ADUser user, String password) throws AppException {
        if (user == null || password == null) {
            throw new AppException(ErrorCode.AD_INVALID_RESET_PASS_DET.getDescription(), ErrorCode.AD_INVALID_RESET_PASS_DET);
        }
        String dn = user.getDistinguishedName();
        ModificationItem[] mods = new ModificationItem[1];
        // Replace the "unicdodePwd" attribute with a new value
        // Password must be both Unicode and a quoted string
        String newQuotedPassword = "\"" + password + "\"";

        try {
            byte[] newUnicodePassword = newQuotedPassword.getBytes("UTF-16LE");
            mods[0] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE, new BasicAttribute("unicodePwd", newUnicodePassword));
            ldapContext.modifyAttributes(dn, mods);
        } catch (UnsupportedEncodingException ex) {
            LOGGER.log(Level.SEVERE, null, ex);
            throw new AppException(ex, ErrorCode.AD_INVALID_PASSWORD);
        } catch (NamingException ex) {
            LOGGER.log(Level.SEVERE, null, ex);
            throw new AppException(ex, ErrorCode.AD_PASSWORD_RESET_FAILED);
        }
    }
    
    /**
     * Simplifies the process of unlocking users.
     * <p>
     * The AD attribute "userAccountControl" may be any of the following
     * - 512 Enabled Account (normally this..)
     * - 514 Disabled Account
     * - 544 Enabled, Password Not Required
     * - 546 Disabled, Password Not Required
     * - 66048 Enabled, Password Doesn't Expire
     * - 66050 Disabled, Password Doesn't Expire
     * - 66080 Enabled, Password Doesn't Expire & Not Required
     * - 66082 Disabled, Password Doesn't Expire & Not Required
     * <p>
     * The AD attribute "lockoutTime" must be set to "0" in order to successfully unlock the user itself
     *
     */

//TODO: Not working. Check with Jim / Daryl
    public void unlock(ADUser user) throws AppException {
        if (user == null ) {
            throw new AppException(ErrorCode.AD_INVALID_RESET_PASS_DET.getDescription(), ErrorCode.AD_INVALID_RESET_PASS_DET);
        }
        String dn = user.getDistinguishedName();
        ModificationItem[] modItems = new ModificationItem[2];
        modItems[0] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE, new BasicAttribute("userAccountControl","512"));
        modItems[1] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE, new BasicAttribute("lockoutTime","0"));
        try {
            /*ldapContext.setRequestControls(new Control[]{new Control(){
                @Override
                public String getID() {
                    return "1.3.18.0.2.10.15";
                }

                @Override
                public boolean isCritical() {
                    return true;
                }

                @Override
                public byte[] getEncodedValue() {
                    return null;
                }
            }});*/
            ldapContext.modifyAttributes(dn, modItems);
        } catch (NamingException ex) {
            LOGGER.log(Level.SEVERE, null, ex);
            throw new AppException(ex, ErrorCode.AD_PASSWORD_RESET_FAILED);
        }
    }

    private Hashtable getLdapEnvForUser(ADUser user, String userPass) {
        Hashtable userLdapEnv = new Hashtable<Object, Object>();
        userLdapEnv.put(Context.INITIAL_CONTEXT_FACTORY, this.ldapEnv.get(Context.INITIAL_CONTEXT_FACTORY));
        userLdapEnv.put(Context.REFERRAL, this.ldapEnv.get(Context.REFERRAL));
        userLdapEnv.put(Context.PROVIDER_URL, this.ldapEnv.get(Context.PROVIDER_URL));
        userLdapEnv.put(Context.SECURITY_AUTHENTICATION, this.ldapEnv.get(Context.SECURITY_AUTHENTICATION));
        userLdapEnv.put(Context.SECURITY_PRINCIPAL, user.getDistinguishedName());
        userLdapEnv.put(Context.SECURITY_CREDENTIALS, userPass);
        userLdapEnv.put(Context.SECURITY_PROTOCOL, this.ldapEnv.get(Context.SECURITY_PROTOCOL));
        userLdapEnv.put("java.naming.ldap.attributes.binary", "objectSid objectGUID");
        return userLdapEnv;
    }

    /*
    This does not seem to be working. Check with Jim / Daryl
     */
    public void changePassword(ADUser user, String oldPassword, String newPassword) throws AppException {
        LdapContext userLdapContext = null;

        if (user == null || oldPassword == null || newPassword == null) {
            throw new AppException(ErrorCode.AD_INVALID_RESET_PASS_DET.getDescription(), ErrorCode.AD_INVALID_RESET_PASS_DET);
        }

        if (oldPassword.compareTo(newPassword) == 0) {
            throw new AppException(ErrorCode.AD_PASSWORD_OLD_NEW_SAME.getDescription(), ErrorCode.AD_PASSWORD_OLD_NEW_SAME);
        }

        String dn = user.getDistinguishedName();
        ModificationItem[] mods = new ModificationItem[1];
        // Replace the "unicdodePwd" attribute with a new value
        // Password must be both Unicode and a quoted string
        //String oldQuotedPassword = "\"" + oldPassword + "\"";
        String newQuotedPassword = "\"" + newPassword + "\"";

        try {
            //byte[] oldUnicodePassword = oldQuotedPassword.getBytes("UTF-16LE");
            byte[] newUnicodePassword = newQuotedPassword.getBytes("UTF-16LE");

            //mods[0] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE, new BasicAttribute("unicodePwd", oldUnicodePassword));
            mods[0] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE, new BasicAttribute("unicodePwd", newUnicodePassword));

            /*Hashtable userLdapEnv = this.getLdapEnvForUser(user, oldPassword);
            userLdapContext = new InitialLdapContext(userLdapEnv, null);*/
            ldapContext.modifyAttributes(dn, mods);
        } catch (UnsupportedEncodingException ex) {
            LOGGER.log(Level.SEVERE, "Invalid Password Provided", ex);
            throw new AppException(ex, ErrorCode.AD_INVALID_PASSWORD);
        } catch (NamingException ex) {
            LOGGER.log(Level.SEVERE, "Password reset failed.", ex);
            throw new AppException(ex, ErrorCode.AD_PASSWORD_RESET_FAILED);
        } finally {
            ADConnection.closeContext(userLdapContext);

        }
    }

    public ADUser lookupUser(String birthDate, String restaurantNumber, String last4EmpId) throws AppException {
            HashMap<String, String> attributesMap = new HashMap<String, String>();

            attributesMap.put("physicalDeliveryOfficeName", restaurantNumber);
            attributesMap.put("Darden-Empl-ID", "*" + last4EmpId);

            List<ADUser> users = findUsersByAttributes(attributesMap);

            if (users == null || users.size() == 0) {
                throw new AppException(ErrorCode.AD_NO_USERS_FOUND.getDescription(), ErrorCode.AD_NO_USERS_FOUND);
            }

            ADUser ret = null;
            for (int count = 0; count < users.size(); count++) {
                ADUser user = users.get(count);
                String dateOfBirth = user.getDardenDateOfBirth();
                String adFinalDate = (null != dateOfBirth && !dateOfBirth.isEmpty()) ? (dateOfBirth.substring(6).concat(dateOfBirth.substring(4, 6))) : null;
                if (adFinalDate != null && adFinalDate.equalsIgnoreCase(birthDate)) {
                    String userName = user.getSAMAccountName();
                    LOGGER.info(" Username of the Team Member is : " + userName);
                    ret = user;
                }
            }

            if (ret == null) {
                throw new AppException(ErrorCode.AD_NO_USERS_FOUND.getDescription(), ErrorCode.AD_NO_USERS_FOUND);
            }else{
                return ret;
            }
        }

        public ADUser lookupUser(String initials, String birthDate, String restaurantNumber, String posId) throws AppException {
            HashMap<String, String> attributesMap = new HashMap<String, String>();

            if (null != initials && !initials.isEmpty()) {
                attributesMap.put("givenName", initials.substring(0, 1) + "*");
            }
            attributesMap.put("physicalDeliveryOfficeName", restaurantNumber);
            attributesMap.put("Darden-POS-ID", posId);

            List<ADUser> users = findUsersByAttributes(attributesMap);

            String sn;
            String userId;
            String[] snParts;
            String snInitial = initials.substring(1, 2);
            String snPartInitial;
            Map<String, ADUser> usersMap = new HashMap<String, ADUser>();
            ADUser entry;

            for (ADUser user : users) {
                sn = user.getSn();
                userId = user.getSAMAccountName();
                if (sn != null) {
                    sn = sn.trim();
                    snParts = sn.split("\\s+");

                    if (snParts.length > 0) {
                        for (String snPart : snParts) {
                            snPartInitial = snPart.trim().substring(0, 1);
                            if (snPartInitial.equalsIgnoreCase(snInitial)) {
                                entry = usersMap.get(userId);
                                if (entry == null) {
                                    usersMap.put(userId, (ADUser) user);
                                }
                            }
                        }
                    }
                }
            }

            if (usersMap.size() > 0) {
                if (usersMap.size() > 1) {
                    LOGGER.info("--- Following users match the criteria -- " + initials + "--" + birthDate + " -- " + restaurantNumber + " -- " + posId);
                    for (Map.Entry<String, ADUser> mapEntry : usersMap.entrySet()) {
                        LOGGER.info(mapEntry.getKey());
                    }
                    throw new AppException("More than one users found.", ErrorCode.AD_MORE_THAN_ONE_USER);
                } else {
                    Map.Entry<String, ADUser> userEntry = usersMap.entrySet().iterator().next();
                    ADUser user = userEntry.getValue();

                    // Getting Date of Birth for the user, based on the Restaurant number filter and employee id filter
                    String dateOfBirth = user.getDardenDateOfBirth();
                    LOGGER.info("Date of Birth from LDAP is : " + dateOfBirth);

                    // formatting the DOB in format DDMM - Changed the format from DDYYYY to DDMM as per the new requirements
                    String adFinalDate = (null != dateOfBirth && !dateOfBirth.isEmpty()) ? (dateOfBirth.substring(6).concat(dateOfBirth.substring(4, 6))) : null;
                    LOGGER.info("Final Birth Date after restructure is : " + adFinalDate);

                    if (adFinalDate != null && adFinalDate.equalsIgnoreCase(birthDate)) {
                        String userName = user.getSAMAccountName();
                        LOGGER.info(" Username of the Team Member is : " + userName);
                        return user;
                    } else {
                        // DOB provided by Team Member does not match AD entry
                        throw new AppException(ErrorCode.AD_DOB_MISMATCH.getDescription(), ErrorCode.AD_DOB_MISMATCH);
                    }
                }

            } else {
                throw new AppException(ErrorCode.AD_NO_USERS_FOUND.getDescription(), ErrorCode.AD_NO_USERS_FOUND);
            }
        }


        public ADUser getUserForLoginID(String loginId) throws AppException { // Should we return null or throw exception
            List<ADUser> adUsersByAka = null;
            List<ADUser> adUsersBySam = null;

            try {
                adUsersByAka = this.findUsersByAKA(loginId);
            } catch (AppException e) {
                if (e.getCode().compareTo(ErrorCode.AD_NO_USERS_FOUND) != 0) {
                    throw e;
                }
            }

            try {
                adUsersBySam = this.findUsersBySAM(loginId);
            } catch (AppException e) {
                if (e.getCode().compareTo(ErrorCode.AD_NO_USERS_FOUND) != 0) {
                    throw e;
                }
            }

            ADUser user = null;

            if (adUsersByAka == null || adUsersByAka.size() == 0) {
                //No users found by AKA
                if (adUsersBySam == null || adUsersBySam.size() == 0) {
                    //No users found by Sam
                    throw new AppException(ErrorCode.AD_NO_USERS_BY_LOGIN_ID.getDescription(), ErrorCode.AD_NO_USERS_BY_LOGIN_ID);
                } else {
                    //Users found by Sam.
                    if (adUsersBySam.size() > 1) {
                        throw new AppException(ErrorCode.AD_SAM_NOT_UNIQUE.getDescription(), ErrorCode.AD_SAM_NOT_UNIQUE);
                    } else {
                        user = adUsersBySam.get(0);
                    }
                }
            } else {
                //Users found by AKA
                if (adUsersBySam == null || adUsersBySam.size() == 0) {
                    //No users found by Sam
                    if (adUsersByAka.size() > 1) {
                        throw new AppException(ErrorCode.AD_AKA_NOT_UNIQUE.getDescription(), ErrorCode.AD_AKA_NOT_UNIQUE);
                    } else {
                        user = adUsersByAka.get(0);
                    }
                } else {
                    //Users found by Sam and aka
                    //user can have both aka and sam identical
                    if (adUsersBySam.size() == 1 && adUsersByAka.size() == 1) {
                        //THe only valid case
                        ADUser akaUser = adUsersByAka.get(0);
                        ADUser samUser = adUsersBySam.get(0);
                        if (akaUser.equals(samUser)) {
                            user = samUser;
                        } else {
                            throw new AppException(ErrorCode.AD_USER_FOUND_FOR_AKA_SAM.getDescription(), ErrorCode.AD_USER_FOUND_FOR_AKA_SAM);
                        }
                    } else {
                        if (adUsersBySam.size() > 1) {
                            throw new AppException(ErrorCode.AD_SAM_NOT_UNIQUE.getDescription(), ErrorCode.AD_SAM_NOT_UNIQUE);
                        }

                        if (adUsersByAka.size() > 1) {
                            throw new AppException(ErrorCode.AD_AKA_NOT_UNIQUE.getDescription(), ErrorCode.AD_AKA_NOT_UNIQUE);
                        }
                    }
                }

            }

            if (user == null) {
                throw new AppException(ErrorCode.AD_NO_USERS_BY_LOGIN_ID.getDescription(), ErrorCode.AD_NO_USERS_BY_LOGIN_ID);
            }

            return user;
        }
        
    public ADUser login(String loginId, String userPass) throws AppException {
        LdapContext userLdapContext = null;
        ADUser user = null;
        try {
            user = this.getUserForLoginID(loginId);
            Hashtable userLdapEnv = getLdapEnvForUser(user, userPass);
            userLdapContext = new InitialLdapContext(userLdapEnv, null);
        } catch (AppException ex) {
            LOGGER.log(Level.SEVERE, "Failed to get user by Login ID " + loginId, ex);
            throw ex;
        } catch (NamingException ex) {
            LOGGER.log(Level.SEVERE, "Failed to authenticate user : " + loginId, ex);
            throw new AppException(ex, ErrorCode.AD_LOGIN_FAILED);
        } finally {
            ADConnection.closeContext(userLdapContext);
        }

        return user;
    }        
    
    public ADUser login(ADUser user, String userPass) throws AppException {
        LdapContext userLdapContext = null;
        try {
            Hashtable userLdapEnv = getLdapEnvForUser(user, userPass);
            userLdapContext = new InitialLdapContext(userLdapEnv, null);
        } catch (NamingException ex) {
            LOGGER.log(Level.SEVERE, "Failed to authenticate user : " + user.getSAMAccountName(), ex);
            throw new AppException(ex, ErrorCode.AD_LOGIN_FAILED);
        } finally {
            ADConnection.closeContext(userLdapContext);
        }

        return user;
    }        
    
}
