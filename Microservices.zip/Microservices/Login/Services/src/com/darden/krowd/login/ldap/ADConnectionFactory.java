/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.darden.krowd.login.ldap;

import java.security.Security;
import java.util.Base64;
import java.util.Hashtable;
import java.util.logging.Logger;

import javax.naming.Context;
import org.apache.commons.pool2.BasePooledObjectFactory;
import org.apache.commons.pool2.PooledObject;
import org.apache.commons.pool2.impl.DefaultPooledObject;

/**
 *
 * @author gsdrxg1
 */
public class ADConnectionFactory extends BasePooledObjectFactory<ADConnection> {
    private static final Logger LOGGER = Logger.getLogger(ADConnectionFactory.class.getName());
    private Hashtable<Object, Object> ldapEnv;
    private ADConnectionConfig adConnectionConfig;

    public ADConnectionFactory(ADConnectionConfig adConnectionConfig) {
        Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
        
        this.adConnectionConfig = adConnectionConfig;
        
        ldapEnv = new Hashtable<Object, Object>();       
        
        ldapEnv.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        ldapEnv.put(Context.REFERRAL, "follow");
        ldapEnv.put(Context.PROVIDER_URL, adConnectionConfig.getProviderURL());
        ldapEnv.put(Context.SECURITY_AUTHENTICATION, adConnectionConfig.getAuthenticationType());
        ldapEnv.put(Context.SECURITY_PRINCIPAL, adConnectionConfig.getSecurityPrincipal());
        ldapEnv.put(Context.SECURITY_CREDENTIALS,new String(Base64.getDecoder().decode(adConnectionConfig.getSecurityCredentials())));
        
        String protocol = adConnectionConfig.getProtocol();
        if(protocol != null){
            ldapEnv.put(Context.SECURITY_PROTOCOL, adConnectionConfig.getProtocol());    
        }
        
        
        ldapEnv.put("java.naming.ldap.attributes.binary", "objectSid objectGUID");
        //ldapEnv.put("com.sun.jndi.ldap.trace.ber", System.err);
        
        System.setProperty("javax.net.ssl.keyStore",adConnectionConfig.getKeyStoreLocation());
        System.setProperty("javax.net.ssl.keyStorePassword", new String(Base64.getDecoder().decode(adConnectionConfig.getKeyStorePassword())));
        System.setProperty("javax.net.ssl.trustStore", adConnectionConfig.getTrustStoreLocation());
        
        
        
        System.setProperty("javax.net.debug", adConnectionConfig.getDebug());        
    }

    @Override
    public ADConnection create() throws Exception {
        LOGGER.fine("==> Creating new ADConnection Object.");
        return new ADConnection(this.ldapEnv, this.adConnectionConfig);
    }

    @Override
    public PooledObject<ADConnection> wrap(ADConnection t) {
        LOGGER.fine("==> Creating wrapped new ADConnection Object.");
        return new DefaultPooledObject<ADConnection>(t);
    }

    @Override
    public void passivateObject(PooledObject<ADConnection> p) throws Exception {
        LOGGER.fine("==> Calling passivate on ADConnection.");
        p.getObject().unInit(); // Do i need to unInit ?
    }

    @Override
    public void activateObject(PooledObject<ADConnection> p) throws Exception {
        LOGGER.fine("==> Activating on ADConnection.");
        p.getObject().init();
    }

    @Override
    public boolean validateObject(PooledObject<ADConnection> p) {
        LOGGER.fine("==> Validation phase ADConnection.");
        return p.getObject().isInitialized();
    }

    @Override
    public void destroyObject(PooledObject<ADConnection> p) throws Exception {
        LOGGER.fine("==> Destroying ADConnection Object.");
        p.getObject().unInit();
    }

}
