package com.darden.krowd.login.test;

import com.darden.krowd.exception.AppException;
import com.darden.krowd.login.ldap.ADConnection;
import com.darden.krowd.login.ldap.ADConnectionConfig;
import com.darden.krowd.login.ldap.ADConnectionFactory;
import com.darden.krowd.login.ldap.ADConnectionFactoryTest;
import com.darden.krowd.login.ldap.ADConnectionPool;
import com.darden.krowd.login.ldap.ADUser;
import com.darden.krowd.login.siteminder.SMAgentConfig;
import com.darden.krowd.login.siteminder.SMAgentConnection;
import com.darden.krowd.login.siteminder.SMAgentConnectionFactory;
import com.darden.krowd.login.siteminder.SMAgentConnectionPool;

import com.darden.krowd.login.siteminder.SMAgentFactoryTest;

import com.darden.krowd.login.siteminder.SessionInfo;

import java.net.InetAddress;
import java.net.UnknownHostException;

import java.security.SecureRandom;

import java.util.List;


import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;

public class AppTest {
    private static final String SERVER_IP_ADRESS = "146.217.100.122";
    private static final int MIN_CONNECTION = 1;
    private static final int MAX_CONNECTION = 3;
    private static final int CONNECTION_STEP = 1;
    private static final int CONNECTION_TIMEOUT = 5;
    private static final int AUTHORIZATION_PORT = 44443;
    private static final int AUTHENTICATION_PORT = 44442;
    private static final int ACCOUNTING_PORT = 44441;
    private static final String SM_DEFAULT_PROTECTED_CONTEXT_ROOT = "/krowd/";
    private static final String SM_AGENT_NAME = "kwdwebt2a";

    private static final String SHARED_SECRET = "{RC2}87ZR+UllIcpqI0SlhANCRRf6MyjGzoaBen/LkEZm69SegZOylImE/rjHUx4bzROIPEPXSvbxdSFXJA24H9oJ0INzFjgE7QubGefZy0ALhJknIemFSkxUA79pJuEWGA9j158OJEbDkW6rX/A/BI+uAVOf2BTZ4FWGiveCWcqwtWS4I56wyLDXU/4eRr0aqc51";
    private static final boolean FAIL_OVER = false;

    private static final String PROVIDER_URL = "ldaps://secureldap.darden.com:636";
    //private static final String PROVIDER_URL = "ldap://146.217.100.225:389";
    private static final String AUTHENTICATION_TYPE = "simple";
    private static final String SECURITY_PRINCIPAL = "CN=PortalLDAPdev,OU=Service Accounts,DC=darden,DC=com";
    private static final String SECURITY_CREDENTIALS_BASE64 = "T3JhY2xlMTIz";
    private static final String PROTOCOL = "ssl";
    //private static final String PROTOCOL = null;
    private static final String KEYSTORE_LOCATION = "/usr/local/apache-tomcat-9.0.30/conf/appTrustKeyStore.jks";
    private static final String KEYSTORE_PASSWORD_BASE64 = "UzNjdXIxdHkk";
    private static final String TRUSTSTORE_LOCATION = "/usr/local/apache-tomcat-9.0.30/conf/appTrustKeyStore.jks";
    private static final String DEBUG = "none"; //ssl, 
    
    private static final String BASE_DN = "DC=darden,DC=com";
    private static final String USER_DN = "DC=darden,DC=com";
    
    /*
    all            turn on all debugging
    ssl            turn on ssl debugging

    The following can be used with ssl:

        record       enable per-record tracing
        handshake    print each handshake message
        keygen       print key generation data
        session      print session activity
        defaultctx   print default SSL initialization
        sslctx       print SSLContext tracing
        sessioncache print session cache tracing
        keymanager   print key manager tracing
        trustmanager print trust manager tracing
        pluggability print pluggability tracing

        handshake debugging can be widened with:
        data         hex dump of each handshake message
        verbose      verbose handshake message printing

        record debugging can be widened with:
        plaintext    hex dump of record plaintext
        packet       print raw SSL/TLS packets    
    */
    
    private static ADConnectionPool adConnectionPool ;
    private static SMAgentConnectionPool smAgentConnectionPool;
    
    private static String getHostName() {
        try {
            InetAddress localhost = InetAddress.getLocalHost();
            return localhost.getHostName();
        } catch (UnknownHostException ex) {
            ex.printStackTrace();
            return "localhost";
        }
    }

    private static String getLocalIP() {
        try {
            InetAddress localhost = InetAddress.getLocalHost();
            return localhost.getHostAddress();
        } catch (UnknownHostException ex) {
            ex.printStackTrace();
            return "localhost";
        }
    }
        
    public static void main(String[] args) {
        GenericObjectPoolConfig config = new GenericObjectPoolConfig();
        config.setMaxIdle(1);
        config.setMaxTotal(5);
        config.setTestOnBorrow(true);
        config.setTestOnReturn(true);       
        
        ADConnectionConfig adConnectionConfig = new ADConnectionConfig();
        adConnectionConfig.setAuthenticationType(AUTHENTICATION_TYPE);
        adConnectionConfig.setDebug(DEBUG);
        adConnectionConfig.setKeyStoreLocation(KEYSTORE_LOCATION);
        adConnectionConfig.setKeyStorePassword(KEYSTORE_PASSWORD_BASE64);
        adConnectionConfig.setProviderURL(PROVIDER_URL);
        adConnectionConfig.setSecurityCredentials(SECURITY_CREDENTIALS_BASE64);
        adConnectionConfig.setSecurityPrincipal(SECURITY_PRINCIPAL);
        adConnectionConfig.setTrustStoreLocation(TRUSTSTORE_LOCATION);
        adConnectionConfig.setProtocol(PROTOCOL);
        adConnectionConfig.setBaseDN(BASE_DN);
        adConnectionConfig.setUserDN(USER_DN);
        
        SMAgentConfig smAgentConfig = new SMAgentConfig();
        smAgentConfig.setAccountingPort(ACCOUNTING_PORT);
        smAgentConfig.setAuthenticationPort(AUTHENTICATION_PORT);
        smAgentConfig.setAuthorizationPort(AUTHORIZATION_PORT);
        smAgentConfig.setConnectionStep(CONNECTION_STEP);
        smAgentConfig.setConnectionTimeout(CONNECTION_TIMEOUT);
        smAgentConfig.setFailOver(FAIL_OVER);
        smAgentConfig.setHostName(AppTest.getHostName());
        smAgentConfig.setHostIp(AppTest.getLocalIP());
        smAgentConfig.setMaxConnection(MAX_CONNECTION);
        smAgentConfig.setMinConnection(MIN_CONNECTION);
        smAgentConfig.setSharedSecret(SHARED_SECRET);
        smAgentConfig.setSmAgentName(SM_AGENT_NAME);
        smAgentConfig.setDefaultProtectedContextRoot(SM_DEFAULT_PROTECTED_CONTEXT_ROOT);
        smAgentConfig.setPolicyServerIpAddress(SERVER_IP_ADRESS);
        
        smAgentConnectionPool = new SMAgentConnectionPool(new SMAgentConnectionFactory(smAgentConfig),config);
        adConnectionPool = new ADConnectionPool(new ADConnectionFactory(adConnectionConfig),config);
        
        ADConnection adConn = null;
        SMAgentConnection smConn = null;
        
        try {
            adConn = adConnectionPool.borrowObject();
            smConn = smAgentConnectionPool.borrowObject();
            List<ADUser> users = adConn.findUsersBySAM("881761042t");
            
            SecureRandom random = new SecureRandom();            
            ADUser user = users.get(0);      
            String newPass;
            boolean cont = true;
            boolean adLoginFailed = true;
            int i=0;
            while(cont && i<10){
                i++;
                newPass = "Darden"+ (random.nextInt(900) + 100);
                adConn.changePassword(user, "Darden345", newPass);
                Thread.sleep(3000);
                adLoginFailed = true;
                try{
                    adConn.login(user, newPass);        
                    System.out.println("-------- AD Login Successful-----------");
                    adLoginFailed = false;
                }catch(AppException ade){
                    cont = false;
                    System.out.println("------Error :" + ade.getCode().getDescription() +"--- Code: "+ ade.getCode().getCode());
                }
                
                if(!adLoginFailed){                    
                    //Valid attempt
                    try{
                        SessionInfo sessionInfo = smConn.login(user.getSAMAccountName(), newPass);
                        System.out.println(sessionInfo.getSSOToken());
                    }catch(AppException ae){
                        cont = false;
                        System.out.println("------Error :" + ae.getCode().getDescription() +"--- Code: "+ ae.getCode().getCode());
                    }                    
                }
            }
        } catch (AppException e) {
            Logger.getLogger(ADConnectionFactoryTest.class.getName()).log(Level.SEVERE, null, e);
        } catch (Exception e) {
            Logger.getLogger(ADConnectionFactoryTest.class.getName()).log(Level.SEVERE, null, e);
        } finally{
            adConnectionPool.returnObject(adConn);
            adConnectionPool.clear();
            adConnectionPool.close();  
            
            smAgentConnectionPool.returnObject(smConn);
            smAgentConnectionPool.clear();            
            smAgentConnectionPool.close();            
        }
        
    }
}
