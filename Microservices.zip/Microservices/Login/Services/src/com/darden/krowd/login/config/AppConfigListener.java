package com.darden.krowd.login.config;

import com.darden.krowd.login.ldap.ADConnectionConfig;
import com.darden.krowd.login.ldap.ADConnectionFactory;
import com.darden.krowd.login.ldap.ADConnectionPool;

import com.darden.krowd.login.siteminder.SMAgentConfig;
import com.darden.krowd.login.siteminder.SMAgentConnection;
import com.darden.krowd.login.siteminder.SMAgentConnectionFactory;
import com.darden.krowd.login.siteminder.SMAgentConnectionPool;
import com.darden.krowd.login.siteminder.SMAgentFactoryTest;

import java.net.InetAddress;
import java.net.UnknownHostException;

import java.util.logging.Logger;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;

public class AppConfigListener implements ServletContextListener {
    private static final Logger LOGGER = Logger.getLogger(SMAgentConnection.class.getName());
    private static final String PROVIDER_URL = "ldaps://secureldap.darden.com:636";
    private static final String AUTHENTICATION_TYPE = "simple";
    private static final String SECURITY_PRINCIPAL = "CN=PortalLDAPdev,OU=Service Accounts,DC=darden,DC=com";
    private static final String SECURITY_CREDENTIALS_BASE64 = "T3JhY2xlMTIz";
    private static final String PROTOCOL = "ssl";
    //private static final String KEYSTORE_LOCATION = "/usr/local/apache-tomcat-9.0.30/conf/appTrustKeyStore.jks";
    private static final String KEYSTORE_LOCATION = "/u01/app/oracle/admin/portal-domain/cert/appTrustKeyStore.jks";
    private static final String KEYSTORE_PASSWORD_BASE64 = "UzNjdXIxdHkk";
    //private static final String TRUSTSTORE_LOCATION = "/usr/local/apache-tomcat-9.0.30/conf/appTrustKeyStore.jks";
    private static final String TRUSTSTORE_LOCATION = "/u01/app/oracle/admin/portal-domain/cert/appTrustKeyStore.jks";
    private static final String DEBUG = "ssl,keymanager"; //ssl, 
    
    /*
    all            turn on all debugging
    ssl            turn on ssl debugging

    The following can be used with ssl:

        record       enable per-record tracing
        handshake    print each handshake message
        keygen       print key generation data
        session      print session activity
        defaultctx   print default SSL initialization
        sslctx       print SSLContext tracing
        sessioncache print session cache tracing
        keymanager   print key manager tracing
        trustmanager print trust manager tracing
        pluggability print pluggability tracing

        handshake debugging can be widened with:
        data         hex dump of each handshake message
        verbose      verbose handshake message printing

        record debugging can be widened with:
        plaintext    hex dump of record plaintext
        packet       print raw SSL/TLS packets    
    */
    
    
    private static final String BASE_DN = "DC=darden,DC=com";
    private static final String USER_DN = "DC=darden,DC=com";

    private static final String SERVER_IP_ADRESS = "146.217.100.122";
    private static final int MIN_CONNECTION = 1;
    private static final int MAX_CONNECTION = 3;
    private static final int CONNECTION_STEP = 1;
    private static final int CONNECTION_TIMEOUT = 5;
    private static final int AUTHORIZATION_PORT = 44443;
    private static final int AUTHENTICATION_PORT = 44442;
    private static final int ACCOUNTING_PORT = 44441;
    private static final String SM_DEFAULT_PROTECTED_CONTEXT_ROOT = "/krowd/";
    private static final String SM_AGENT_NAME = "kwdwebt2a";

    private static final String SHARED_SECRET = "{RC2}87ZR+UllIcpqI0SlhANCRRf6MyjGzoaBen/LkEZm69SegZOylImE/rjHUx4bzROIPEPXSvbxdSFXJA24H9oJ0INzFjgE7QubGefZy0ALhJknIemFSkxUA79pJuEWGA9j158OJEbDkW6rX/A/BI+uAVOf2BTZ4FWGiveCWcqwtWS4I56wyLDXU/4eRr0aqc51";
    private static final boolean FAIL_OVER = false;
    
    private static String SM_AGENT_CONNECTION_POOL = "SM_AGENT_CONNECTION_POOL";
    private static String AD_CONNECTION_POOL = "AD_CONNECTION_POOL";
    
    public AppConfigListener() {
        super();
    }

    @Override
    public void contextInitialized(ServletContextEvent servletContextEvent) {
        LOGGER.info("--- Initializing App Context ----");
        ServletContext context = servletContextEvent.getServletContext();
        context.setAttribute(SM_AGENT_CONNECTION_POOL,createSMAgentConnectionPool());
        context.setAttribute(AD_CONNECTION_POOL,createADConnectionPool());
        // set attributes
    }

    @Override
    public void contextDestroyed(ServletContextEvent servletContextEvent) {
        LOGGER.info("--- Destroying App Context ----");
        ServletContext context = servletContextEvent.getServletContext();
        SMAgentConnectionPool smAgentConnectionPool =
            (SMAgentConnectionPool) context.getAttribute(SM_AGENT_CONNECTION_POOL);
        
        ADConnectionPool adConnectionPool = (ADConnectionPool) context.getAttribute(AD_CONNECTION_POOL);
        
        if(smAgentConnectionPool != null){
            smAgentConnectionPool.clear();
            smAgentConnectionPool.close();
        }

        if(adConnectionPool != null){
            adConnectionPool.clear();
            adConnectionPool.close();
        }
        
        context.setAttribute(SM_AGENT_CONNECTION_POOL,null);
        context.setAttribute(AD_CONNECTION_POOL,null);
        
    }
    
    private SMAgentConnectionPool createSMAgentConnectionPool(){
        LOGGER.info("--- Creating SM Agent Connection Pool ----");
        GenericObjectPoolConfig config = new GenericObjectPoolConfig();
        config.setMaxIdle(5);
        config.setMaxTotal(15);
        config.setTestOnBorrow(true);
        config.setTestOnReturn(true);       
        
        SMAgentConfig smAgentConfig = new SMAgentConfig();
        smAgentConfig.setAccountingPort(ACCOUNTING_PORT);
        smAgentConfig.setAuthenticationPort(AUTHENTICATION_PORT);
        smAgentConfig.setAuthorizationPort(AUTHORIZATION_PORT);
        smAgentConfig.setConnectionStep(CONNECTION_STEP);
        smAgentConfig.setConnectionTimeout(CONNECTION_TIMEOUT);
        smAgentConfig.setFailOver(FAIL_OVER);
        smAgentConfig.setHostName(getHostName());
        smAgentConfig.setHostIp(getLocalIP());
        smAgentConfig.setMaxConnection(MAX_CONNECTION);
        smAgentConfig.setMinConnection(MIN_CONNECTION);
        smAgentConfig.setSharedSecret(SHARED_SECRET);
        smAgentConfig.setSmAgentName(SM_AGENT_NAME);
        smAgentConfig.setDefaultProtectedContextRoot(SM_DEFAULT_PROTECTED_CONTEXT_ROOT);
        smAgentConfig.setPolicyServerIpAddress(SERVER_IP_ADRESS);
        
        SMAgentConnectionPool smAgentConnectionPool = new SMAgentConnectionPool(new SMAgentConnectionFactory(smAgentConfig),config);        
        return smAgentConnectionPool;
    }
    
    private ADConnectionPool createADConnectionPool(){
        LOGGER.info("--- Creating AD Connection Pool ----");
        GenericObjectPoolConfig config = new GenericObjectPoolConfig();
        config.setMaxIdle(5);
        config.setMaxTotal(15);
        config.setTestOnBorrow(true);
        config.setTestOnReturn(true);       
        
        ADConnectionConfig adConnectionConfig = new ADConnectionConfig();
        adConnectionConfig.setAuthenticationType(AUTHENTICATION_TYPE);
        adConnectionConfig.setDebug(DEBUG);
        adConnectionConfig.setKeyStoreLocation(KEYSTORE_LOCATION);
        adConnectionConfig.setKeyStorePassword(KEYSTORE_PASSWORD_BASE64);
        adConnectionConfig.setProviderURL(PROVIDER_URL);
        adConnectionConfig.setSecurityCredentials(SECURITY_CREDENTIALS_BASE64);
        adConnectionConfig.setSecurityPrincipal(SECURITY_PRINCIPAL);
        adConnectionConfig.setTrustStoreLocation(TRUSTSTORE_LOCATION);
        adConnectionConfig.setProtocol(PROTOCOL);
        adConnectionConfig.setBaseDN(BASE_DN);
        adConnectionConfig.setUserDN(USER_DN);
        
        ADConnectionPool adConnectionPool = new ADConnectionPool(new ADConnectionFactory(adConnectionConfig),config);        
        return adConnectionPool;
    }
    
    private static String getHostName() {
        try {
            InetAddress localhost = InetAddress.getLocalHost();
            return localhost.getHostName();
        } catch (UnknownHostException ex) {
            ex.printStackTrace();
            return "localhost";
        }
    }

    private static String getLocalIP() {
        try {
            InetAddress localhost = InetAddress.getLocalHost();
            return localhost.getHostAddress();
        } catch (UnknownHostException ex) {
            ex.printStackTrace();
            return "localhost";
        }
    }
    
        
}
