/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.darden.krowd.login.siteminder;


import java.util.logging.Logger;

import org.apache.commons.pool2.BasePooledObjectFactory;
import org.apache.commons.pool2.PooledObject;
import org.apache.commons.pool2.impl.DefaultPooledObject;


/**
 *
 * @author gsdrxg1
 */
public class SMAgentConnectionFactory extends BasePooledObjectFactory<SMAgentConnection> {
    private static final Logger LOGGER = Logger.getLogger(SMAgentConnectionFactory.class.getName());
    private SMAgentConfig smAgentConfig;
    
    public SMAgentConnectionFactory(SMAgentConfig smAgentConfig){
        this.smAgentConfig = smAgentConfig;
    }
    
    @Override
    public SMAgentConnection create() throws Exception {
        LOGGER.fine("==> Creating new SMAgentConnection Object.");
        return new SMAgentConnection(this.smAgentConfig);
    }

    @Override
    public PooledObject<SMAgentConnection> wrap(SMAgentConnection t) {
        LOGGER.fine("==> Wrapping SMAgentConnection Object.");
        return new DefaultPooledObject<SMAgentConnection>(t);
    }

    @Override
    public void passivateObject(PooledObject<SMAgentConnection> p) throws Exception {
        LOGGER.fine("==> Passivate SMAgentConnection Object.");
        //p.getObject().unInit();
    }

    @Override
    public void activateObject(PooledObject<SMAgentConnection> p) throws Exception {
        LOGGER.fine("==> Activate SMAgentConnection Object.");
        p.getObject().init();
    }

    @Override
    public boolean validateObject(PooledObject<SMAgentConnection> p) {
        LOGGER.fine("==> Validation Phase SMAgentConnection Object.");
        return p.getObject().isInitialized();
    }

    @Override
    public void destroyObject(PooledObject<SMAgentConnection> p) throws Exception {
        LOGGER.fine("==> Destroying SMAgentConnection Object.");
        p.getObject().unInit();
    }
}
