/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.darden.krowd.login.siteminder;



import com.darden.krowd.exception.AppException;
import com.darden.krowd.exception.ErrorCode;
import com.darden.krowd.login.siteminder.SMAgentConfig;
import com.netegrity.sdk.apiutil.SmApiConnection;
import com.netegrity.sdk.apiutil.SmApiException;
import com.netegrity.sdk.apiutil.SmApiResult;
import com.netegrity.sdk.apiutil.SmApiSession;
import com.netegrity.sdk.policyapi.SmPolicyApi;
import com.netegrity.sdk.policyapi.SmPolicyApiImpl;
import netegrity.siteminder.javaagent.AgentAPI;
import netegrity.siteminder.javaagent.ServerDef;
import netegrity.siteminder.javaagent.InitDef;
import netegrity.siteminder.javaagent.ResourceContextDef;
import netegrity.siteminder.javaagent.RealmDef;
import netegrity.siteminder.javaagent.UserCredentials;
import netegrity.siteminder.javaagent.SessionDef;
import netegrity.siteminder.javaagent.AttributeList;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Iterator;
import java.util.Vector;
import java.util.logging.Logger;
import java.util.logging.Level;

/**
 *
 * @author gsdrxg1
 */
public class SMAgentConnection {
        private static final Logger LOGGER = Logger.getLogger(SMAgentConnection.class.getName());
        public enum GLOBAL_OBJECT_TYPE {AGENT_CONFIGS,
                AGENT_GROUPS,
                AGENTS,
                AGENT_TYPES,
                ADMINS,
                AUTH_AZ_MAPS,
                CERT_MAPS,
                DOMAINS,
                HOST_CONFIGS,
                KEY_MANAGEMENT,
                PASSWORD_POLICIES,
                SCHEMES,
                SELF_REGS,
                SHARED_SECRET_POLICY,
                TRUSTED_HOSTS,
                USER_DIRECTORIES
        };


        public static final String AGENT_CONFIGS = "AgentConfigs";
        public static final String AGENT_GROUPS = "AgentGroups";
        public static final String AGENTS = "Agents";
        public static final String AGENT_TYPES = "AgentTypes";
        public static final String ADMINS = "Admins";
        public static final String AUTH_AZ_MAPS = "AuthAzMaps";
        public static final String CERT_MAPS = "CertMaps";
        public static final String DOMAINS = "Domains";
        public static final String HOST_CONFIGS = "HostConfigs";
        public static final String KEY_MANAGEMENT = "KeyManagement";
        public static final String PASSWORD_POLICIES = "PasswordPolicies";
        public static final String SCHEMES = "Schemes";
        public static final String SELF_REGS = "SelfRegs";
        public static final String SHARED_SECRET_POLICY = "SharedSecretPolicy";
        public static final String TRUSTED_HOSTS = "TrustedHosts";
        public static final String USER_DIRECTORIES = "UserDirectories";


        private SMAgentConfig smAgentConfig;

        private AgentAPI agent;
        private final ServerDef sd;
        private final InitDef init;
        private RealmDef realmDef;

        private boolean agentInitialized = false;
        private int initReturnCode = -1;
        private int unInitReturnCode = -1;
        private int checkProtectedReturnCode = -1;

        private SmApiSession smApiSession;

        SMAgentConnection(SMAgentConfig smAgentConfig) {
            this.smAgentConfig = smAgentConfig;
            this.sd = new ServerDef();
            this.agent = new AgentAPI();
            this.sd.accountingPort = smAgentConfig.getAccountingPort();
            this.sd.authenticationPort = smAgentConfig.getAuthenticationPort();
            this.sd.authorizationPort = smAgentConfig.getAuthorizationPort();
            this.sd.connectionMax = smAgentConfig.getMaxConnection();
            this.sd.connectionMin = smAgentConfig.getMinConnection();
            this.sd.connectionStep = smAgentConfig.getConnectionStep();
            this.sd.timeout = smAgentConfig.getConnectionTimeout();
            this.sd.serverIpAddress = smAgentConfig.getPolicyServerIpAddress();
            this.init = new InitDef(smAgentConfig.getSmAgentName(), smAgentConfig.getSharedSecret(),smAgentConfig.isFailOver(), sd); // TODO: hostname can be got from environment. Change this
            
            //TODO: Implement clustered serverdef configuration
        }

        public AgentAPI getAgent() {
            return agent;
        }

        public void setAgent(AgentAPI agent) {
            this.agent = agent;
        }

        public int getInitReturnCode() {
            return initReturnCode;
        }

        public void setInitReturnCode(int initReturnCode) {
            this.initReturnCode = initReturnCode;
        }

        public int getUnInitReturnCode() {
            return unInitReturnCode;
        }

        public void setUnInitReturnCode(int unInitReturnCode) {
            this.unInitReturnCode = unInitReturnCode;
        }

        public void unInit() throws AppException {
            this.unInitReturnCode = this.agent.unInit();
            switch(this.unInitReturnCode){
                case AgentAPI.SUCCESS : LOGGER.log(Level.INFO, "==> Agent Un-Initialized"); break;
                case AgentAPI.NOCONNECTION : LOGGER.log(Level.INFO, "==> Agent Un-Initialization failed. No Connection."); throw new AppException(ErrorCode.AGENT_UNINIT_NO_CONNECTION);
                case AgentAPI.FAILURE : LOGGER.log(Level.INFO, "==> Agent Un-Initialization failed. General Failure."); throw new AppException(ErrorCode.AGENT_UNINIT_FAILURE);
                default: LOGGER.log(Level.INFO, "==> Unknown. Return Code: {0}", this.unInitReturnCode); throw new AppException(ErrorCode.AGENT_UNINIT_FAILURE);
            }
            this.initReturnCode = -1;
            this.checkProtectedReturnCode = -1;
            this.unInitReturnCode = -1;
            this.agentInitialized = false;
        }

        public void init() throws Exception {
            if(!this.agentInitialized){
                this.initReturnCode = agent.init(this.init);
                if (this.initReturnCode == AgentAPI.SUCCESS) {
                    /*
                     Just because the return code is SUCCESS does not mean the initialization was successful.
                     Following could happen and the init will still succeed

                     1. An incorrect Policy Server IP address and/or port number are provided during the initialization operation
                     2. A correct Policy Server IP address and port number are provided, but the Policy Server is down
                     */

                    ResourceContextDef resctxdef = new ResourceContextDef(this.smAgentConfig.getSmAgentName(), this.smAgentConfig.getHostName(), this.smAgentConfig.getDefaultProtectedContextRoot(), "GET");
                    this.realmDef = new RealmDef();
                    this.checkProtectedReturnCode = agent.isProtected(this.smAgentConfig.getHostIp(), resctxdef, this.realmDef); //use local ip for validating SMAgent Connection

                    switch(this.checkProtectedReturnCode){
                        case AgentAPI.YES : LOGGER.log(Level.INFO, "==> Agent Initialized"); break;
                        case AgentAPI.NO : LOGGER.log(Level.INFO, "==> Agent Initialized. Not a Problem."); break;
                        case AgentAPI.NOCONNECTION : LOGGER.log(Level.INFO, "==> Agent Initialization failed. No Connection."); throw new AppException(ErrorCode.AGENT_INIT_NO_CONNECTION);
                        case AgentAPI.INVALID_RESCTXDEF : LOGGER.log(Level.INFO, "==> Agent Initialized. Invalid Resource."); throw new AppException(ErrorCode.AGENT_INIT_INVALID_RESCTXDEF);
                        case AgentAPI.INVALID_REALMDEF : LOGGER.log(Level.INFO, "==> Agent Initialized. Invalid Realm"); throw new AppException(ErrorCode.AGENT_INIT_INVALID_REALMDEF);
                        case AgentAPI.TIMEOUT : LOGGER.log(Level.INFO, "==> Agent Initialization failed. Timeout."); throw new AppException(ErrorCode.AGENT_INIT_TIMEOUT);
                        case AgentAPI.FAILURE : LOGGER.log(Level.INFO, "==> Agent Initialization failed. General Failure."); throw new AppException(ErrorCode.AGENT_INIT_FAILURE);
                        default: LOGGER.log(Level.INFO, "==> Unknown. Return Code: {0}", this.checkProtectedReturnCode); throw new AppException(ErrorCode.AGENT_INIT_FAILURE);
                    }

                    SMAgentConnection.logRealmInfo(this.realmDef);
                    this.agentInitialized = true;

                } else {
                    //Refer to https://ftpdocs.broadcom.com/cadocs/0/CA%20SiteMinder%20r12%20SP3-ENU/Bookshelf_Files//programming-reference/javadoc-sm/netegrity/siteminder/javaagent/AgentAPI.html#init(netegrity.siteminder.javaagent.InitDef)
                    throw new AppException(ErrorCode.AGENT_INIT_INVALID_CONF);
                }                
            }else{
                LOGGER.log(Level.INFO, "==> Agent already Initialized. Do Nothing.");
            }
        }

        private static void logRealmInfo(RealmDef realmdef){
            LOGGER.info("---------- Realm Info -----------");
            LOGGER.log(Level.INFO, " ==> Domain Object ID : {0}", realmdef.domOid);
            LOGGER.log(Level.INFO, " ==> Form Location : {0}", realmdef.formLocation);
            LOGGER.log(Level.INFO, " ==> Realm Name : {0}", realmdef.name);
            LOGGER.log(Level.INFO, " ==> Object ID : {0}", realmdef.oid);
        }

        public boolean isInitialized(){
            if (this.initReturnCode == AgentAPI.SUCCESS) {
                if(this.checkProtectedReturnCode == AgentAPI.NOCONNECTION || this.checkProtectedReturnCode == AgentAPI.TIMEOUT || this.checkProtectedReturnCode ==AgentAPI.FAILURE){
                    return false;
                }else{
                    return true;
                }
            }else{
                return false;
            }
        }

        private SmApiSession getSMApiSession(){
            if(this.smApiSession == null){
                AgentAPI adminAgent = new AgentAPI();
                adminAgent.init(this.init);
                SmApiConnection smApiConnection = new SmApiConnection(adminAgent);

                this.smApiSession = new SmApiSession(smApiConnection);
            }
            return this.smApiSession;
        }

        public void logoutAdmin(){
            if(this.smApiSession != null){
                try {
                    this.smApiSession.logout();
                } catch (SmApiException e) {
                    e.printStackTrace();
                }
                this.smApiSession = null;
            }
        }

        public String[] getGlobalObjectNames(SmPolicyApi smPolicyApi, GLOBAL_OBJECT_TYPE objectType) throws AppException {
            String type = null;
            if(objectType == GLOBAL_OBJECT_TYPE.AGENT_CONFIGS){ type = "AgentConfigs";}
            else if(objectType == GLOBAL_OBJECT_TYPE.AGENT_GROUPS){ type = "AgentGroups";}
            else if(objectType == GLOBAL_OBJECT_TYPE.AGENTS){ type = "Agents";}
            else if(objectType == GLOBAL_OBJECT_TYPE.AGENT_TYPES){ type = "AgentTypes";}
            else if(objectType == GLOBAL_OBJECT_TYPE.ADMINS){ type = "Admins";}
            else if(objectType == GLOBAL_OBJECT_TYPE.AUTH_AZ_MAPS){ type = "AuthAzMaps";}
            else if(objectType == GLOBAL_OBJECT_TYPE.CERT_MAPS){ type = "CertMaps";}
            else if(objectType == GLOBAL_OBJECT_TYPE.DOMAINS){ type = "Domains";}
            else if(objectType == GLOBAL_OBJECT_TYPE.HOST_CONFIGS){ type = "HostConfigs";}
            else if(objectType == GLOBAL_OBJECT_TYPE.KEY_MANAGEMENT){ type = "KeyManagement";}
            else if(objectType == GLOBAL_OBJECT_TYPE.PASSWORD_POLICIES){ type = "PasswordPolicies";}
            else if(objectType == GLOBAL_OBJECT_TYPE.SCHEMES){ type = "Schemes";}
            else if(objectType == GLOBAL_OBJECT_TYPE.SELF_REGS){ type = "SelfRegs";}
            else if(objectType == GLOBAL_OBJECT_TYPE.SHARED_SECRET_POLICY){ type = "SharedSecretPolicy";}
            else if(objectType == GLOBAL_OBJECT_TYPE.TRUSTED_HOSTS){ type = "TrustedHosts";}
            else if(objectType == GLOBAL_OBJECT_TYPE.USER_DIRECTORIES){ type = "UserDirectories";}
            else {
                type = null;
            }

            if(type == null){
                return null;
            }

            Vector<String> vector = new Vector(20);
            try {
                SmApiResult smApiResult = smPolicyApi.getGlobalObjectNames(type,vector);
                if(smApiResult.isSuccess()){
                    return vector.toArray(new String[vector.size()]);
                }else{
                    throw AppException.getAppException(smApiResult);
                }
            } catch (SmApiException e) {
                throw new AppException(e, ErrorCode.SMAPI_OPERATION_FAILED);
            }
        }

        public SmPolicyApi adminLogin(String adminUser, String adminPassword) throws AppException {
            SmApiSession smApiSession = this.getSMApiSession();
            int initialChallengeReason = 0;
            try {
                InetAddress localhost = InetAddress.getLocalHost();
                SmApiResult result = smApiSession.login(adminUser, adminPassword, localhost, initialChallengeReason);
                if(result.isSuccess()){
                    SmPolicyApi smPolicyApi = new SmPolicyApiImpl(smApiSession);
                    return smPolicyApi;
                }else{
                    throw AppException.getAppException(result);
                }
            } catch (SmApiException e) {
                throw new AppException(e,ErrorCode.SM_ADMIN_LOGIN_ERROR);
            } catch (UnknownHostException e) {
                throw new AppException(e,ErrorCode.ERROR_RESOLVING_HOST);
            }
        }


        public SessionInfo login(String userName, String password, String clientIp) throws AppException{
            SessionDef sessionDef = new SessionDef();
            AttributeList attrList = new AttributeList();
            //RealmDef realmdef = new RealmDef();

            UserCredentials userCredentials = new UserCredentials(userName, password);
            ResourceContextDef resctxdef = new ResourceContextDef(this.smAgentConfig.getSmAgentName(), this.smAgentConfig.getHostName(), this.smAgentConfig.getDefaultProtectedContextRoot(), "GET");            


            int loginRetCode = agent.login(clientIp,resctxdef,this.realmDef,userCredentials,sessionDef,attrList);
            
            switch(loginRetCode){
                case AgentAPI.YES : LOGGER.log(Level.INFO, "==> Login Successful."); break;
                case AgentAPI.NO : LOGGER.log(Level.INFO, "==> Login Failed. Return code is NO."); throw new AppException(ErrorCode.LOGIN_FAIL_NO);
                case AgentAPI.CHALLENGE : LOGGER.log(Level.INFO, "==> Additional Challenge required for Login."); throw new AppException(ErrorCode.LOGIN_FAIL_CHALLENGE);
                case AgentAPI.NOCONNECTION : LOGGER.log(Level.INFO, "==> Login Failed. No Connection."); throw new AppException(ErrorCode.LOGIN_FAIL_NOCONNECTION);
                case AgentAPI.TIMEOUT : LOGGER.log(Level.INFO, "==> Login Failed. Connection Timeout"); throw new AppException(ErrorCode.LOGIN_FAIL_TIMEOUT);
                case AgentAPI.INVALID_RESCTXDEF : LOGGER.log(Level.INFO, "==> Login Failed. Invalid Resource Context."); throw new AppException(ErrorCode.LOGIN_FAIL_INVALID_RESCTXDEF);
                case AgentAPI.INVALID_REALMDEF : LOGGER.log(Level.INFO, "==> Login Failed. Invalid Realm Context."); throw new AppException(ErrorCode.LOGIN_FAIL_INVALID_REALMDEF);
                case AgentAPI.INVALID_USERCREDS : LOGGER.log(Level.INFO, "==> Login Failed. Invalid Credentials."); throw new AppException(ErrorCode.LOGIN_FAIL_INVALID_USERCREDS);
                case AgentAPI.INVALID_SESSIONDEF : LOGGER.log(Level.INFO, "==> Login Failed. Invalid Session Def."); throw new AppException(ErrorCode.LOGIN_FAIL_INVALID_SESSIONDEF);
                case AgentAPI.INVALID_ATTRLIST : LOGGER.log(Level.INFO, "==> Login Failed. Invalid Attributes List."); throw new AppException(ErrorCode.LOGIN_FAIL_INVALID_ATTRLIST);
                case AgentAPI.FAILURE : LOGGER.log(Level.INFO, "==> Login Failed. General Failure."); throw new AppException(ErrorCode.LOGIN_FAIL_FAILURE);
                default: LOGGER.log(Level.INFO, "==> Unknown. Return Code: {0}", loginRetCode); throw new AppException(ErrorCode.LOGIN_FAIL_FAILURE);
            }
            SMAgentConnection.logRealmInfo(this.realmDef);

            byte[] ipBytes = clientIp.getBytes();
            attrList.addAttribute(AgentAPI.ATTR_CLIENTIP, 0, 0, "" , ipBytes);

            StringBuffer ssoToken = new StringBuffer();
            int ssoTokenRetCode = agent.createSSOToken(sessionDef, attrList, ssoToken);
            
            switch(ssoTokenRetCode){
                case AgentAPI.SUCCESS : LOGGER.log(Level.INFO, "==> SSO Token Generation Successful."); break;
                case AgentAPI.FAILURE : LOGGER.log(Level.INFO, "==> SSO TOken Generation Failed."); throw new AppException(ErrorCode.SSO_TOKEN_FAILURE);
                case AgentAPI.NOCONNECTION : LOGGER.log(Level.INFO, "==> SSO TOken Generation Failed. No Connection."); throw new AppException(ErrorCode.SSO_TOKEN_NOCONNECTION);
                case AgentAPI.INVALID_SESSIONDEF : LOGGER.log(Level.INFO, "==> SSO TOken Generation Failed. Invalid Session Def."); throw new AppException(ErrorCode.SSO_TOKEN_INVALID_SESSIONDEF);
                case AgentAPI.INVALID_ATTRLIST : LOGGER.log(Level.INFO, "==> SSO TOken Generation Failed. Invalid Attributes List."); throw new AppException(ErrorCode.SSO_TOKEN_INVALID_ATTRSLIST);
                default: LOGGER.log(Level.INFO, "==> Unknown. Return Code: {0}", loginRetCode); throw new AppException(ErrorCode.SSO_TOKEN_FAILURE);
            }
            
            SessionInfo sessInfo = new SessionInfo(sessionDef,attrList, ssoToken.toString());
            
            LOGGER.info("-- Spec --" + sessionDef.spec);

            ResourceContextDef testResctxdef = new ResourceContextDef(this.smAgentConfig.getSmAgentName(), this.smAgentConfig.getHostName(), this.smAgentConfig.getDefaultProtectedContextRoot(), "GET");
            
            AttributeList testAttrList = new AttributeList();
            testAttrList.addAttribute(AgentAPI.ATTR_CLIENTIP, 0, 0, "" , ipBytes);
            int testRet = agent.authorize(clientIp, null, testResctxdef, this.realmDef,sessionDef, testAttrList);
            
            LOGGER.info("--- Return TEST --" + testRet);

            
            return sessInfo;
        }

        public SessionInfo login(String userName, String password) throws AppException{
            return this.login(userName, password, this.smAgentConfig.getHostIp());
        }

        public SessionInfo logout(SessionInfo sessInfo) throws AppException{
            int logoutRetCode = this.agent.logout(new String(sessInfo.getAttribute(AgentAPI.ATTR_CLIENTIP).value),sessInfo.getSessionDef());
            switch(logoutRetCode){
                case AgentAPI.YES : LOGGER.log(Level.INFO, "==> Logout Successful."); break;
                case AgentAPI.NO : LOGGER.log(Level.INFO, "==> Logout Failed."); throw new AppException(ErrorCode.LOGOUT_FAILURE);
                case AgentAPI.FAILURE : LOGGER.log(Level.INFO, "==> Logout Failed. Genera Failure"); throw new AppException(ErrorCode.LOGOUT_FAILURE);
                case AgentAPI.NOCONNECTION : LOGGER.log(Level.INFO, "==> Logout Failed. No Connection."); throw new AppException(ErrorCode.LOGOUT_NOCONNECTION);
                case AgentAPI.TIMEOUT : LOGGER.log(Level.INFO, "==> Logout Failed. Timeout."); throw new AppException(ErrorCode.LOGOUT_TIMEOUT);
                case AgentAPI.INVALID_SESSIONDEF : LOGGER.log(Level.INFO, "==> Logout Failed. Invalid Session Def."); throw new AppException(ErrorCode.LOGOUT_INVALID_SESSIONDEF);
                default: LOGGER.log(Level.INFO, "==> Unknown. Return Code: {0}", logoutRetCode); throw new AppException(ErrorCode.SSO_TOKEN_FAILURE);
            }
            return sessInfo;
        }

    
}
