/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.darden.krowd.login.ldap;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;


/**
 *
 * @author gsdrxg1
 */
public class ADUser {

    private static final Logger LOGGER = Logger.getLogger(ADUser.class.getName());
    private final static long DIFF_NET_JAVA_FOR_DATES = 11644473600000L + 24 * 60 * 60 * 1000;

    public static final String WHENCREATED = "whenCreated";
    public static final String OBJECTCATEGORY = "objectCategory";
    public static final String DARDEN_APPROVER = "Darden-Approver";
    public static final String BADPWDCOUNT = "badPwdCount";
    public static final String DARDEN_MANAGER_LEVEL = "Darden-Manager-Level";
    public static final String DARDEN_EMPL_ID = "Darden-Empl-ID";
    public static final String OBJECTGUID = "objectGUID";
    public static final String MAIL = "mail";
    public static final String MODIFYTIMESTAMP = "modifyTimeStamp";
    public static final String DARDEN_PS_OPRID = "Darden-PS-OPRID";
    public static final String MEMBEROF = "memberOf";
    public static final String DARDEN_DATE_OF_BIRTH = "Darden-Date-Of-Birth";
    public static final String DARDEN_PHOTO_NAME = "Darden-Photo-Name";
    public static final String BADPASSWORDTIME = "badPasswordTime";
    public static final String OBJECTCLASS = "objectClass";
    public static final String COMPANY = "company";
    public static final String NAME = "name";
    public static final String UIDNUMBER = "uidNumber";
    public static final String SN = "sn";
    public static final String EMPLOYEENUMBER = "employeeNumber";
    public static final String GIDNUMBER = "gidNumber";
    public static final String GECOS = "gecos";
    public static final String DARDEN_PHONE_NUMBER = "Darden-Phone-Number";
    public static final String USERACCOUNTCONTROL = "userAccountControl";
    public static final String DARDEN_BUSINESS_UNIT = "Darden-Business-Unit";
    public static final String ACCOUNTEXPIRES = "accountExpires";
    public static final String DARDEN_CONTINUOUS_SERVICE_DATE = "Darden-Continuous-Service-Date";
    public static final String JPEGPHOTO = "jpegPhoto";
    public static final String DARDEN_BADGE_NUMBER = "Darden-Badge-Number";
    public static final String LOCKOUTTIME = "lockoutTime";
    public static final String PHYSICALDELIVERYOFFICENAME = "physicalDeliveryOfficeName";
    public static final String CO = "co";
    public static final String DARDEN_GIFTCARD_NUMBER = "Darden-Giftcard-Number";
    public static final String CN = "cn";
    public static final String DARDEN_REGION = "Darden-Region";
    public static final String DARDEN_AREA = "Darden-Area";
    public static final String TITLE = "title";
    public static final String DARDEN_SECURITY_CODE = "Darden-Security-Code";
    public static final String LOGONCOUNT = "logonCount";
    public static final String MOBILE = "mobile";
    public static final String DARDEN_BUILDING_FLOOR = "Darden-Building-Floor";
    public static final String SAMACCOUNTTYPE = "sAMAccountType";
    public static final String GIVENNAME = "givenName";
    public static final String DISPLAYNAME = "displayName";
    public static final String DARDEN_JOB_CODE = "Darden-Job-Code";
    public static final String PWDLASTSET = "pwdLastSet";
    public static final String USERPRINCIPALNAME = "userPrincipalName";
    public static final String DARDEN_NICKNAME = "Darden-Nickname";
    public static final String WHENCHANGED = "whenChanged";
    public static final String LASTLOGONTIMESTAMP = "lastLogonTimestamp";
    public static final String DARDEN_WORK_STATE = "Darden-Work-State";
    public static final String DARDEN_JOB_FUNCTION = "Darden-Job-Function";
    public static final String DEPARTMENT = "department";
    public static final String COUNTRYCODE = "countryCode";
    public static final String MAILNICKNAME = "mailNickname";
    public static final String DISTINGUISHEDNAME = "distinguishedName";
    public static final String DARDEN_COMPANY_NUMBER = "Darden-Company-Number";
    public static final String DARDEN_FUNCTIONAL_AREA = "Darden-Functional-Area";
    public static final String DIVISION = "division";
    public static final String MANAGER = "manager";
    public static final String DARDEN_JOB_SUB_FUNCTION = "Darden-Job-Sub-Function";
    public static final String SAMACCOUNTNAME = "sAMAccountName";
    public static final String UNICODEPASSWORD = "unicodePwd";

    private Date whenCreated;
    private String objectCategory;
    private String dardenApprover;
    private Integer badPwdCount;
    private String dardenManagerLevel;
    private String dardenEmplID;
    private byte[] objectGUID;
    private String mail;
    private Date modifyTimeStamp;
    private String dardenPSOPRID;
    private List<String> memberOf;
    private String dardenDateOfBirth; // custom date yyyymmdd
    private String dardenPhotoName;
    private Date badPasswordTime;
    private List<String> objectClass;
    private String company;
    private String name;
    private Long uidNumber;
    private String sn;
    private String employeeNumber;
    private Long gidNumber;
    private String gecos;
    private String dardenPhoneNumber;
    private String userAccountControl;
    private String dardenBusinessUnit;
    private Date accountExpires;
    private String dardenContinuousServiceDate; // custom date yyyymmdd
    private byte[] jpegPhoto;
    private String dardenBadgeNumber;
    private Date lockoutTime;
    private String physicalDeliveryOfficeName;
    private String co;
    private String dardenGiftcardNumber;
    private String cn;
    private String dardenRegion;
    private String title;
    private String dardenSecurityCode;
    private Integer logonCount;
    private String mobile;
    private String dardenBuildingFloor;
    private String sAMAccountType;
    private String givenName;
    private String displayName;
    private String dardenJobCode;
    private Date pwdLastSet;
    private String userPrincipalName;
    private String dardenNickname;
    private Date whenChanged;
    private Date lastLogonTimestamp;
    private String dardenWorkState;
    private String dardenJobFunction;
    private String department;
    private String countryCode;
    private String mailNickname;
    private String distinguishedName;
    private String dardenCompanyNumber;
    private String dardenFunctionalArea;
    private String division;
    private String manager;
    private String dardenJobSubFunction;
    private String sAMAccountName;
    private String unicodePwd;
    private String dardenArea;

    private Map<String, Object> attrsMap;

    public ADUser(Attributes attrs) {
        whenCreated = getDate((String) getAttrVal(attrs, WHENCREATED));
        objectCategory = (String) getAttrVal(attrs, OBJECTCATEGORY);
        dardenApprover = (String) getAttrVal(attrs, DARDEN_APPROVER);
        badPwdCount = getIntVal((String) getAttrVal(attrs, BADPWDCOUNT));
        dardenManagerLevel = (String) getAttrVal(attrs, DARDEN_MANAGER_LEVEL);
        dardenEmplID = (String) getAttrVal(attrs, DARDEN_EMPL_ID);
        objectGUID = (byte[]) getAttrVal(attrs, OBJECTGUID);
        mail = (String) getAttrVal(attrs, MAIL);
        modifyTimeStamp = getDate((String) getAttrVal(attrs, MODIFYTIMESTAMP));
        dardenPSOPRID = (String) getAttrVal(attrs, DARDEN_PS_OPRID);
        memberOf = (List<String>) getAttrVal(attrs, MEMBEROF);
        dardenDateOfBirth = (String) getAttrVal(attrs, DARDEN_DATE_OF_BIRTH);
        dardenPhotoName = (String) getAttrVal(attrs, DARDEN_PHOTO_NAME);
        badPasswordTime = getDate((String) getAttrVal(attrs, BADPASSWORDTIME));
        objectClass = (List<String>) getAttrVal(attrs, OBJECTCLASS);
        company = (String) getAttrVal(attrs, COMPANY);
        name = (String) getAttrVal(attrs, NAME);
        uidNumber = getLongVal((String) getAttrVal(attrs, UIDNUMBER));
        sn = (String) getAttrVal(attrs, SN);
        employeeNumber = (String) getAttrVal(attrs, EMPLOYEENUMBER);
        gidNumber = getLongVal((String) getAttrVal(attrs, GIDNUMBER));
        gecos = (String) getAttrVal(attrs, GECOS);
        dardenPhoneNumber = (String) getAttrVal(attrs, DARDEN_PHONE_NUMBER);
        userAccountControl = (String) getAttrVal(attrs, USERACCOUNTCONTROL);
        dardenBusinessUnit = (String) getAttrVal(attrs, DARDEN_BUSINESS_UNIT);
        accountExpires = getDate((String) getAttrVal(attrs, ACCOUNTEXPIRES));
        dardenContinuousServiceDate = (String) getAttrVal(attrs, DARDEN_CONTINUOUS_SERVICE_DATE);
        jpegPhoto = (byte[]) getAttrVal(attrs, JPEGPHOTO);
        dardenBadgeNumber = (String) getAttrVal(attrs, DARDEN_BADGE_NUMBER);
        lockoutTime = getDate((String) getAttrVal(attrs, LOCKOUTTIME));
        physicalDeliveryOfficeName = (String) getAttrVal(attrs, PHYSICALDELIVERYOFFICENAME);
        co = (String) getAttrVal(attrs, CO);
        dardenGiftcardNumber = (String) getAttrVal(attrs, DARDEN_GIFTCARD_NUMBER);
        cn = (String) getAttrVal(attrs, CN);
        dardenRegion = (String) getAttrVal(attrs, DARDEN_REGION);
        dardenArea = (String) getAttrVal(attrs, DARDEN_AREA);
        title = (String) getAttrVal(attrs, TITLE);
        dardenSecurityCode = (String) getAttrVal(attrs, DARDEN_SECURITY_CODE);
        logonCount = getIntVal((String) getAttrVal(attrs, LOGONCOUNT));
        mobile = (String) getAttrVal(attrs, MOBILE);
        dardenBuildingFloor = (String) getAttrVal(attrs, DARDEN_BUILDING_FLOOR);
        sAMAccountType = (String) getAttrVal(attrs, SAMACCOUNTTYPE);
        givenName = (String) getAttrVal(attrs, GIVENNAME);
        displayName = (String) getAttrVal(attrs, DISPLAYNAME);
        dardenJobCode = (String) getAttrVal(attrs, DARDEN_JOB_CODE);
        pwdLastSet = getDate((String) getAttrVal(attrs, PWDLASTSET));
        userPrincipalName = (String) getAttrVal(attrs, USERPRINCIPALNAME);
        dardenNickname = (String) getAttrVal(attrs, DARDEN_NICKNAME);
        whenChanged = getDate((String) getAttrVal(attrs, WHENCHANGED));
        lastLogonTimestamp = getDate((String) getAttrVal(attrs, LASTLOGONTIMESTAMP));
        dardenWorkState = (String) getAttrVal(attrs, DARDEN_WORK_STATE);
        dardenJobFunction = (String) getAttrVal(attrs, DARDEN_JOB_FUNCTION);
        department = (String) getAttrVal(attrs, DEPARTMENT);
        countryCode = (String) getAttrVal(attrs, COUNTRYCODE);
        mailNickname = (String) getAttrVal(attrs, MAILNICKNAME);
        distinguishedName = (String) getAttrVal(attrs, DISTINGUISHEDNAME);
        dardenCompanyNumber = (String) getAttrVal(attrs, DARDEN_COMPANY_NUMBER);
        dardenFunctionalArea = (String) getAttrVal(attrs, DARDEN_FUNCTIONAL_AREA);
        division = (String) getAttrVal(attrs, DIVISION);
        manager = (String) getAttrVal(attrs, MANAGER);
        dardenJobSubFunction = (String) getAttrVal(attrs, DARDEN_JOB_SUB_FUNCTION);
        sAMAccountName = (String) getAttrVal(attrs, SAMACCOUNTNAME);
        unicodePwd = (String) getAttrVal(attrs, UNICODEPASSWORD);

        attrsMap = new HashMap<String,Object>();
        attrsMap.put(WHENCREATED, whenCreated);
        attrsMap.put(OBJECTCATEGORY, objectCategory);
        attrsMap.put(DARDEN_APPROVER, dardenApprover);
        attrsMap.put(BADPWDCOUNT, badPwdCount);
        attrsMap.put(DARDEN_MANAGER_LEVEL, dardenManagerLevel);
        attrsMap.put(DARDEN_EMPL_ID, dardenEmplID);
        attrsMap.put(OBJECTGUID, objectGUID);
        attrsMap.put(MAIL, mail);
        attrsMap.put(MODIFYTIMESTAMP, modifyTimeStamp);
        attrsMap.put(DARDEN_PS_OPRID, dardenPSOPRID);
        attrsMap.put(MEMBEROF, memberOf);
        attrsMap.put(DARDEN_DATE_OF_BIRTH, dardenDateOfBirth);
        attrsMap.put(DARDEN_PHOTO_NAME, dardenPhotoName);
        attrsMap.put(BADPASSWORDTIME, badPasswordTime);
        attrsMap.put(OBJECTCLASS, objectClass);
        attrsMap.put(COMPANY, company);
        attrsMap.put(NAME, name);
        attrsMap.put(UIDNUMBER, uidNumber);
        attrsMap.put(SN, sn);
        attrsMap.put(EMPLOYEENUMBER, employeeNumber);
        attrsMap.put(GIDNUMBER, gidNumber);
        attrsMap.put(GECOS, gecos);
        attrsMap.put(DARDEN_PHONE_NUMBER, dardenPhoneNumber);
        attrsMap.put(USERACCOUNTCONTROL, userAccountControl);
        attrsMap.put(DARDEN_BUSINESS_UNIT, dardenBusinessUnit);
        attrsMap.put(ACCOUNTEXPIRES, accountExpires);
        attrsMap.put(DARDEN_CONTINUOUS_SERVICE_DATE, dardenContinuousServiceDate);
        attrsMap.put(JPEGPHOTO, jpegPhoto);
        attrsMap.put(DARDEN_BADGE_NUMBER, dardenBadgeNumber);
        attrsMap.put(LOCKOUTTIME, lockoutTime);
        attrsMap.put(PHYSICALDELIVERYOFFICENAME, physicalDeliveryOfficeName);
        attrsMap.put(CO, co);
        attrsMap.put(DARDEN_GIFTCARD_NUMBER, dardenGiftcardNumber);
        attrsMap.put(CN, cn);
        attrsMap.put(DARDEN_REGION, dardenRegion);
        attrsMap.put(DARDEN_AREA, dardenArea);
        attrsMap.put(TITLE, title);
        attrsMap.put(DARDEN_SECURITY_CODE, dardenSecurityCode);
        attrsMap.put(LOGONCOUNT, logonCount);
        attrsMap.put(MOBILE, mobile);
        attrsMap.put(DARDEN_BUILDING_FLOOR, dardenBuildingFloor);
        attrsMap.put(SAMACCOUNTTYPE, sAMAccountType);
        attrsMap.put(GIVENNAME, givenName);
        attrsMap.put(DISPLAYNAME, displayName);
        attrsMap.put(DARDEN_JOB_CODE, dardenJobCode);
        attrsMap.put(PWDLASTSET, pwdLastSet);
        attrsMap.put(USERPRINCIPALNAME, userPrincipalName);
        attrsMap.put(DARDEN_NICKNAME, dardenNickname);
        attrsMap.put(WHENCHANGED, whenChanged);
        attrsMap.put(LASTLOGONTIMESTAMP, lastLogonTimestamp);
        attrsMap.put(DARDEN_WORK_STATE, dardenWorkState);
        attrsMap.put(DARDEN_JOB_FUNCTION, dardenJobFunction);
        attrsMap.put(DEPARTMENT, department);
        attrsMap.put(COUNTRYCODE, countryCode);
        attrsMap.put(MAILNICKNAME, mailNickname);
        attrsMap.put(DISTINGUISHEDNAME, distinguishedName);
        attrsMap.put(DARDEN_COMPANY_NUMBER, dardenCompanyNumber);
        attrsMap.put(DARDEN_FUNCTIONAL_AREA, dardenFunctionalArea);
        attrsMap.put(DIVISION, division);
        attrsMap.put(MANAGER, manager);
        attrsMap.put(DARDEN_JOB_SUB_FUNCTION, dardenJobSubFunction);
        attrsMap.put(SAMACCOUNTNAME, sAMAccountName);
        attrsMap.put(UNICODEPASSWORD, unicodePwd);
    }
    
    public Object getAttrVal(String attrName){
        return this.attrsMap.get(attrName);
    }

    public Object getAttrVal(Attributes attrs, String attrName) {
        Attribute attr = attrs.get(attrName);
        if (attr != null) {
            int size = attr.size();
            if (size > 0) {
                if (size > 1) {
                    List vals = new ArrayList();
                    for (int i = 0; i < size; i++) {
                        try {
                            vals.add(attr.get(i));
                        } catch (NamingException ex) {
                            LOGGER.log(Level.SEVERE, null, ex);
                        }
                    }
                    return vals;
                } else {
                    try {
                        if (attrName.compareToIgnoreCase(MEMBEROF) == 0) {
                            List groups = new ArrayList<String>();
                            groups.add(attr.get(0));
                            return groups;
                        } else {
                            return attr.get(0);
                        }
                    } catch (NamingException ex) {
                        LOGGER.log(Level.SEVERE, null, ex);
                        return null;
                    }
                }
            } else {
                return null;
            }
        } else {
            return null;
        }
    }

    private Date getDate(String adStrVal) {
        if (adStrVal == null || adStrVal.trim().compareTo("") == 0 || adStrVal.trim().compareTo("0") == 0) {
            return null;
        }
        try {
            Long adLongValue = Long.parseLong(adStrVal);
            long milliseconds = (adLongValue / 10000) - DIFF_NET_JAVA_FOR_DATES;
            Date date = new Date(milliseconds);
            return date;
        } catch (Exception e) {
            return null;
        }
    }

    private Long getLongVal(String adStrVal) {
        if (adStrVal == null || adStrVal.trim().compareTo("") == 0) {
            return null;
        }
        try {
            Long adLongVal = Long.parseLong(adStrVal);
            return adLongVal;
        } catch (Exception e) {
            return null;
        }
    }

    private Integer getIntVal(String adStrVal) {
        if (adStrVal == null || adStrVal.trim().compareTo("") == 0) {
            return null;
        }
        try {
            Integer adVal = Integer.parseInt(adStrVal);
            return adVal;
        } catch (Exception e) {
            return null;
        }
    }

    public static String convertObjectGUIDToByteString(byte[] objectGUID) {
        StringBuilder result = new StringBuilder();

        for (int i = 0; i < objectGUID.length; i++) {
            String transformed = prefixZeros((int) objectGUID[i] & 0xFF);
            result.append("\\");
            result.append(transformed);
        }

        return result.toString();
    }

    public static String decodeObjectGUID(byte[] objectGUID) {
        StringBuilder displayStr = new StringBuilder();

        displayStr.append(convertToDashedString(objectGUID));

        return displayStr.toString();
    }

    public static String decodeGuid(byte[] guid) {
        byte[] withBigEndian = new byte[] {
            guid[3], guid[2], guid[1], guid[0], guid[5], guid[4], guid[7], guid[6], guid[8], guid[9], guid[10],
            guid[11], guid[12], guid[13], guid[14], guid[15]
        };
        return convertToDashedString(withBigEndian);
    }

    private static String convertToDashedString(byte[] objectGUID) {
        StringBuilder displayStr = new StringBuilder();

        displayStr.append(prefixZeros((int) objectGUID[3] & 0xFF));
        displayStr.append(prefixZeros((int) objectGUID[2] & 0xFF));
        displayStr.append(prefixZeros((int) objectGUID[1] & 0xFF));
        displayStr.append(prefixZeros((int) objectGUID[0] & 0xFF));
        displayStr.append("-");
        displayStr.append(prefixZeros((int) objectGUID[5] & 0xFF));
        displayStr.append(prefixZeros((int) objectGUID[4] & 0xFF));
        displayStr.append("-");
        displayStr.append(prefixZeros((int) objectGUID[7] & 0xFF));
        displayStr.append(prefixZeros((int) objectGUID[6] & 0xFF));
        displayStr.append("-");
        displayStr.append(prefixZeros((int) objectGUID[8] & 0xFF));
        displayStr.append(prefixZeros((int) objectGUID[9] & 0xFF));
        displayStr.append("-");
        displayStr.append(prefixZeros((int) objectGUID[10] & 0xFF));
        displayStr.append(prefixZeros((int) objectGUID[11] & 0xFF));
        displayStr.append(prefixZeros((int) objectGUID[12] & 0xFF));
        displayStr.append(prefixZeros((int) objectGUID[13] & 0xFF));
        displayStr.append(prefixZeros((int) objectGUID[14] & 0xFF));
        displayStr.append(prefixZeros((int) objectGUID[15] & 0xFF));

        return displayStr.toString();
    }

    private static String prefixZeros(int value) {
        if (value <= 0xF) {
            StringBuilder sb = new StringBuilder("0");
            sb.append(Integer.toHexString(value));
            return sb.toString();
        } else {
            return Integer.toHexString(value);
        }
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 89 * hash + Objects.hashCode(this.sn);
        hash = 89 * hash + Objects.hashCode(this.cn);
        hash = 89 * hash + Objects.hashCode(this.distinguishedName);
        hash = 89 * hash + Objects.hashCode(this.sAMAccountName);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ADUser other = (ADUser) obj;
        if (!Objects.equals(this.sn, other.sn)) {
            return false;
        }
        if (!Objects.equals(this.cn, other.cn)) {
            return false;
        }
        if (!Objects.equals(this.distinguishedName, other.distinguishedName)) {
            return false;
        }
        if (!Objects.equals(this.sAMAccountName, other.sAMAccountName)) {
            return false;
        }
        return true;
    }


    public Date getWhenCreated() {
        return whenCreated;
    }

    public String getObjectCategory() {
        return objectCategory;
    }

    public String getDardenApprover() {
        return dardenApprover;
    }

    public Integer getBadPwdCount() {
        return badPwdCount;
    }

    public String getDardenManagerLevel() {
        return dardenManagerLevel;
    }

    public String getDardenEmplID() {
        return dardenEmplID;
    }

    public byte[] getObjectGUID() {
        return objectGUID;
    }

    public String getMail() {
        return mail;
    }

    public Date getModifyTimeStamp() {
        return modifyTimeStamp;
    }

    public String getDardenPSOPRID() {
        return dardenPSOPRID;
    }

    public List<String> getMemberOf() {
        return memberOf;
    }

    public String getDardenDateOfBirth() {
        return dardenDateOfBirth;
    }

    public String getDardenPhotoName() {
        return dardenPhotoName;
    }

    public Date getBadPasswordTime() {
        return badPasswordTime;
    }

    public List<String> getObjectClass() {
        return objectClass;
    }

    public String getCompany() {
        return company;
    }

    public String getName() {
        return name;
    }

    public Long getUidNumber() {
        return uidNumber;
    }

    public String getSn() {
        return sn;
    }

    public String getEmployeeNumber() {
        return employeeNumber;
    }

    public Long getGidNumber() {
        return gidNumber;
    }

    public String getGecos() {
        return gecos;
    }

    public String getDardenPhoneNumber() {
        return dardenPhoneNumber;
    }

    public String getUserAccountControl() {
        return userAccountControl;
    }

    public String getDardenBusinessUnit() {
        return dardenBusinessUnit;
    }

    public Date getAccountExpires() {
        return accountExpires;
    }

    public String getDardenContinuousServiceDate() {
        return dardenContinuousServiceDate;
    }

    public byte[] getJpegPhoto() {
        return jpegPhoto;
    }

    public String getDardenBadgeNumber() {
        return dardenBadgeNumber;
    }

    public Date getLockoutTime() {
        return lockoutTime;
    }

    public String getPhysicalDeliveryOfficeName() {
        return physicalDeliveryOfficeName;
    }

    public String getCo() {
        return co;
    }

    public String getDardenGiftcardNumber() {
        return dardenGiftcardNumber;
    }

    public String getCn() {
        return cn;
    }

    public String getDardenRegion() {
        return dardenRegion;
    }

    public String getTitle() {
        return title;
    }

    public String getDardenSecurityCode() {
        return dardenSecurityCode;
    }

    public Integer getLogonCount() {
        return logonCount;
    }

    public String getMobile() {
        return mobile;
    }

    public String getDardenBuildingFloor() {
        return dardenBuildingFloor;
    }

    public String getSAMAccountType() {
        return sAMAccountType;
    }

    public String getGivenName() {
        return givenName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getDardenJobCode() {
        return dardenJobCode;
    }

    public Date getPwdLastSet() {
        return pwdLastSet;
    }

    public String getUserPrincipalName() {
        return userPrincipalName;
    }

    public String getDardenNickname() {
        return dardenNickname;
    }

    public Date getWhenChanged() {
        return whenChanged;
    }

    public Date getLastLogonTimestamp() {
        return lastLogonTimestamp;
    }

    public String getDardenWorkState() {
        return dardenWorkState;
    }

    public String getDardenJobFunction() {
        return dardenJobFunction;
    }

    public String getDepartment() {
        return department;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public String getMailNickname() {
        return mailNickname;
    }

    public String getDistinguishedName() {
        return distinguishedName;
    }

    public String getDardenCompanyNumber() {
        return dardenCompanyNumber;
    }

    public String getDardenFunctionalArea() {
        return dardenFunctionalArea;
    }

    public String getDivision() {
        return division;
    }

    public String getManager() {
        return manager;
    }

    public String getDardenJobSubFunction() {
        return dardenJobSubFunction;
    }

    public String getSAMAccountName() {
        return sAMAccountName;
    }

    public String getUnicodePwd() {
        return unicodePwd;
    }


    public String getDardenArea() {
        return dardenArea;
    }
}
