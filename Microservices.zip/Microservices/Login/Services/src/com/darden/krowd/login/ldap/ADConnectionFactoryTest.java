/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.darden.krowd.login.ldap;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;

/**
 *
 * @author gsdrxg1
 */
public class ADConnectionFactoryTest {
    private static final String PROVIDER_URL = "ldaps://secureldap.darden.com:636";
    //private static final String PROVIDER_URL = "ldap://146.217.100.225:389";
    private static final String AUTHENTICATION_TYPE = "simple";
    //private static final String SECURITY_PRINCIPAL = "CN=PortalLDAPdev,OU=Service Accounts,DC=darden,DC=com";
    private static final String SECURITY_PRINCIPAL = "cn=PortalLDAPprod,OU=Service Accounts,DC=darden,DC=com";
    //private static final String SECURITY_CREDENTIALS_BASE64 = "T3JhY2xlMTIz";
    private static final String SECURITY_CREDENTIALS_BASE64 = "UHJkbGQ0cFAwcnQ0bA==";
    private static final String PROTOCOL = "ssl";
    //private static final String PROTOCOL = null;
    private static final String KEYSTORE_LOCATION = "/usr/local/apache-tomcat-9.0.30/conf/appTrustKeyStore.jks";
    private static final String KEYSTORE_PASSWORD_BASE64 = "UzNjdXIxdHkk";
    private static final String TRUSTSTORE_LOCATION = "/usr/local/apache-tomcat-9.0.30/conf/appTrustKeyStore.jks";
    private static final String DEBUG = "none"; //ssl, 
    
    private static final String BASE_DN = "DC=darden,DC=com";
    private static final String USER_DN = "DC=darden,DC=com";
    
    /*
    all            turn on all debugging
    ssl            turn on ssl debugging

    The following can be used with ssl:

        record       enable per-record tracing
        handshake    print each handshake message
        keygen       print key generation data
        session      print session activity
        defaultctx   print default SSL initialization
        sslctx       print SSLContext tracing
        sessioncache print session cache tracing
        keymanager   print key manager tracing
        trustmanager print trust manager tracing
        pluggability print pluggability tracing

        handshake debugging can be widened with:
        data         hex dump of each handshake message
        verbose      verbose handshake message printing

        record debugging can be widened with:
        plaintext    hex dump of record plaintext
        packet       print raw SSL/TLS packets    
    */
    
    private static ADConnectionPool adConnectionPool ;
    
    public static void main(String[] args){
        GenericObjectPoolConfig config = new GenericObjectPoolConfig();
        config.setMaxIdle(1);
        config.setMaxTotal(5);
        config.setTestOnBorrow(true);
        config.setTestOnReturn(true);       
        
        ADConnectionConfig adConnectionConfig = new ADConnectionConfig();
        adConnectionConfig.setAuthenticationType(AUTHENTICATION_TYPE);
        adConnectionConfig.setDebug(DEBUG);
        adConnectionConfig.setKeyStoreLocation(KEYSTORE_LOCATION);
        adConnectionConfig.setKeyStorePassword(KEYSTORE_PASSWORD_BASE64);
        adConnectionConfig.setProviderURL(PROVIDER_URL);
        adConnectionConfig.setSecurityCredentials(SECURITY_CREDENTIALS_BASE64);
        adConnectionConfig.setSecurityPrincipal(SECURITY_PRINCIPAL);
        adConnectionConfig.setTrustStoreLocation(TRUSTSTORE_LOCATION);
        adConnectionConfig.setProtocol(PROTOCOL);
        adConnectionConfig.setBaseDN(BASE_DN);
        adConnectionConfig.setUserDN(USER_DN);
        
        adConnectionPool = new ADConnectionPool(new ADConnectionFactory(adConnectionConfig),config);
        ADConnection conn = null;
        try {
            conn = adConnectionPool.borrowObject();
            List<ADUser> users = conn.findUsersBySAM("AMA12112150");
            
            /*Map<String,String> attrs = new HashMap<String,String>();
            attrs.put(ADUser.DEPARTMENT, "KROWD");
            attrs.put(ADUser.DARDEN_EMPL_ID, "101512788");
            List<ADUser> users = conn.findUsersByAttributes(attrs);            
            */            
            ADUser user = users.get(0);      
            conn.resetPassword(user,"Darden2019");
            //conn.changePassword(user, "Darden1234", "Darden88");
            
            //user = conn.login(user,"Darden1234");
            
            //ADUser user= conn.lookupUser("TV","2902", "1547", "540");
            
            //user = conn.login("881976556t","Darden88");
            //conn.unlock(user);
            
            System.out.println(user.getCn());
            //adConnectionPool.returnObject(conn);
            //adConnectionPool.close();
        } catch (Exception ex) {
            Logger.getLogger(ADConnectionFactoryTest.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            adConnectionPool.returnObject(conn);
            adConnectionPool.clear();
            adConnectionPool.close();                        
        }
    }
}
