package com.darden.krowd.exception;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

@Provider
public class AppExceptionMapper implements ExceptionMapper<AppException> {
    public AppExceptionMapper() {
        super();
    }

    @Override
    public Response toResponse(AppException appException) {
        return Response.status(Response.Status.BAD_REQUEST).entity(appException.toString()).build();        
    }
}
