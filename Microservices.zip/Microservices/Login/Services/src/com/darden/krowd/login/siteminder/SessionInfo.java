/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.darden.krowd.login.siteminder;

import com.darden.krowd.login.ldap.ADUser;

import java.util.Date;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import netegrity.siteminder.javaagent.SessionDef;
import netegrity.siteminder.javaagent.AttributeList;
import netegrity.siteminder.javaagent.AgentAPI;
import netegrity.siteminder.javaagent.Attribute;

/**
 *
 * @author gsdrxg1
 */
public class SessionInfo {

    private static final Logger LOGGER = Logger.getLogger(SessionInfo.class.getName());
    private SessionDef sessionDef;
    private HashMap<String, Attribute> sessionAttrs;    
    private String ssoToken;
    private AttributeList attrsList;
    private ADUser user;


    public SessionInfo(SessionDef sessionDef, AttributeList attrsList, String ssoToken) {
        this.ssoToken = ssoToken;
        this.sessionDef = sessionDef;
        this.attrsList = attrsList;
        this.extractSessionAttrs();
    }

    public SessionInfo(SessionDef sessionDef, AttributeList attrsList, String ssoToken, ADUser user) {
        this.ssoToken = ssoToken;
        this.sessionDef = sessionDef;
        this.attrsList = attrsList;
        this.user = user;
        this.extractSessionAttrs();
    }

    public String getSSOToken() {
        return ssoToken;
    }
    
    public SessionDef getSessionDef(){
        return this.sessionDef;
    }
    
    public HashMap<String, Attribute> getSessionAttributes(){
        return this.sessionAttrs;
    }
    
    public Attribute getAttribute(int attrCode){
        Attribute attr =null;
        for(int i=0;i<attrsList.getAttributeCount();i++){
            Attribute tAttr = attrsList.getAttributeAt(i);
            if(tAttr.id == attrCode){
                attr = tAttr;
                break;
            }
        }
        return attr;
    }


    public void setUser(ADUser user) {
        this.user = user;
    }

    public ADUser getUser() {
        return user;
    }

    private void extractSessionAttrs() {        
        this.sessionAttrs = new HashMap<String, Attribute>();
        for (int i = 0; i < attrsList.getAttributeCount(); i++) {
            Attribute attr = attrsList.getAttributeAt(i);
            switch (attr.id) {
                case AgentAPI.ATTR_DEVICENAME: {
                    this.sessionAttrs.put("ATTR_DEVICENAME", attr);
                    LOGGER.log(Level.INFO, "--- ATTR_DEVICENAME ---- {0} --- {1}", new Object[]{attr.ttl, new String(attr.value)});
                    break;
                }
                case AgentAPI.ATTR_LASTSESSIONTIME: {
                    Date lastSession = new Date(Long.parseLong(new String(attr.value)) * 1000);
                    this.sessionAttrs.put("ATTR_LASTSESSIONTIME", attr);
                    LOGGER.log(Level.INFO, "--- ATTR_LASTSESSIONTIME ---- {0} --- {1}", new Object[]{attr.ttl, lastSession.toString()});
                    break;
                }
                case AgentAPI.ATTR_STARTSESSIONTIME: {
                    Date startSession = new Date(Long.parseLong(new String(attr.value)) * 1000);
                    this.sessionAttrs.put("ATTR_STARTSESSIONTIME", attr);
                    LOGGER.log(Level.INFO, "--- ATTR_STARTSESSIONTIME ---- {0} --- {1}", new Object[]{attr.ttl, startSession.toString()});
                    break;
                }
                case AgentAPI.ATTR_AUTH_DIR_NAME: {
                    this.sessionAttrs.put("ATTR_AUTH_DIR_NAME", attr);
                    LOGGER.log(Level.INFO, "--- ATTR_AUTH_DIR_NAME ---- {0} --- {1}", new Object[]{attr.ttl, new String(attr.value)});
                    break;
                }
                case AgentAPI.ATTR_AUTH_DIR_NAMESPACE: {
                    this.sessionAttrs.put("ATTR_AUTH_DIR_NAMESPACE", attr);
                    LOGGER.log(Level.INFO, "--- ATTR_AUTH_DIR_NAMESPACE ---- {0} --- {1}", new Object[]{attr.ttl, new String(attr.value)});
                    break;
                }
                case AgentAPI.ATTR_AUTH_DIR_OID: {
                    this.sessionAttrs.put("ATTR_AUTH_DIR_OID", attr);
                    LOGGER.log(Level.INFO, "--- ATTR_AUTH_DIR_OID ---- {0} --- {1}", new Object[]{attr.ttl, new String(attr.value)});
                    break;
                }
                case AgentAPI.ATTR_AUTH_DIR_SERVER: {
                    this.sessionAttrs.put("ATTR_AUTH_DIR_SERVER", attr);
                    LOGGER.log(Level.INFO, "--- ATTR_AUTH_DIR_SERVER ---- {0} --- {1}", new Object[]{attr.ttl, new String(attr.value)});
                    break;
                }
                case AgentAPI.ATTR_CLIENTIP: {
                    this.sessionAttrs.put("ATTR_CLIENTIP", attr);
                    LOGGER.log(Level.INFO, "--- ATTR_CLIENTIP ---- {0} --- {1}", new Object[]{attr.ttl, new String(attr.value)});
                    break;
                }
                case AgentAPI.ATTR_IDENTITYSPEC: {
                    this.sessionAttrs.put("ATTR_IDENTITYSPEC", attr);
                    LOGGER.log(Level.INFO, "--- ATTR_IDENTITYSPEC ---- {0} --- {1}", new Object[]{attr.ttl, new String(attr.value)});
                    break;
                }
                case AgentAPI.ATTR_IDLESESSIONTIMEOUT: {
                    this.sessionAttrs.put("ATTR_IDLESESSIONTIMEOUT", attr);
                    LOGGER.log(Level.INFO, "--- ATTR_IDLESESSIONTIMEOUT ---- {0} --- {1}", new Object[]{attr.ttl, new String(attr.value)});
                    break;
                }
                case AgentAPI.ATTR_MAXSESSIONTIMEOUT: {
                    this.sessionAttrs.put("ATTR_MAXSESSIONTIMEOUT", attr);
                    LOGGER.log(Level.INFO, "--- ATTR_MAXSESSIONTIMEOUT ---- {0} --- {1}", new Object[]{attr.ttl, new String(attr.value)});
                    break;
                }
                case AgentAPI.ATTR_SERVICE_DATA: {
                    this.sessionAttrs.put("ATTR_SERVICE_DATA", attr);
                    LOGGER.log(Level.INFO, "--- ATTR_SERVICE_DATA ---- {0} --- {1}", new Object[]{attr.ttl, new String(attr.value)});
                    break;
                }
                case AgentAPI.ATTR_SESSIONDOMAIN: {
                    this.sessionAttrs.put("ATTR_SESSIONDOMAIN", attr);
                    LOGGER.log(Level.INFO, "--- ATTR_SESSIONDOMAIN ---- {0} --- {1}", new Object[]{attr.ttl, new String(attr.value)});
                    break;
                }
                case AgentAPI.ATTR_SESSIONID: {
                    this.sessionAttrs.put("ATTR_SESSIONID", attr);
                    LOGGER.log(Level.INFO, "--- ATTR_SESSIONID ---- {0} --- {1}", new Object[]{attr.ttl, new String(attr.value)});
                    break;
                }
                case AgentAPI.ATTR_USERDN: {
                    this.sessionAttrs.put("ATTR_USERDN", attr);
                    LOGGER.log(Level.INFO, "--- ATTR_USERDN ---- {0} --- {1}", new Object[]{attr.ttl, new String(attr.value)});
                    break;
                }
                case AgentAPI.ATTR_SESSIONSPEC: {
                    this.sessionAttrs.put("ATTR_SESSIONSPEC", attr);
                    LOGGER.log(Level.INFO, "--- ATTR_SESSIONSPEC ---- {0} --- {1}", new Object[]{attr.ttl, new String(attr.value)});
                    break;
                }
                case AgentAPI.ATTR_SSOZONE: {
                    this.sessionAttrs.put("ATTR_SSOZONE", attr);
                    LOGGER.log(Level.INFO, "--- ATTR_SSOZONE ---- {0} --- {1}", new Object[]{attr.ttl, new String(attr.value)});
                    break;
                }
                case AgentAPI.ATTR_STATUS_MESSAGE: {
                    this.sessionAttrs.put("ATTR_STATUS_MESSAGE", attr);
                    LOGGER.log(Level.INFO, "--- ATTR_STATUS_MESSAGE ---- {0} --- {1}", new Object[]{attr.ttl, new String(attr.value)});
                    break;
                }
                case AgentAPI.ATTR_USERMSG: {
                    this.sessionAttrs.put("ATTR_USERMSG", attr);
                    LOGGER.log(Level.INFO, "--- ATTR_USERMSG ---- {0} --- {1}", new Object[]{attr.ttl, new String(attr.value)});
                    break;
                }
                case AgentAPI.ATTR_USERNAME: {
                    this.sessionAttrs.put("ATTR_USERNAME", attr);
                    LOGGER.log(Level.INFO, "--- ATTR_USERNAME ---- {0} --- {1}", new Object[]{attr.ttl, new String(attr.value)});
                    break;
                }
                case AgentAPI.ATTR_USERUNIVERSALID: {
                    this.sessionAttrs.put("ATTR_USERUNIVERSALID", attr);
                    LOGGER.log(Level.INFO, "--- ATTR_USERUNIVERSALID ---- {0} --- {1}", new Object[]{attr.ttl, new String(attr.value)});
                    break;
                }

            }
        }
    }
}
