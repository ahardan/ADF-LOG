package com.darden.krowd.notification.connections;

import com.darden.krowd.common.KrowdUtility;
import com.darden.krowd.notification.servlet.JMSConnector;
import com.darden.krowd.notification.servlet.NotificationMessageListener;

import javax.jms.ExceptionListener;
import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.QueueSession;
import javax.jms.Session;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import oracle.adf.share.logging.ADFLogger;

public class SplashMessageQueue {
    public final static String JNDI_FACTORY = "weblogic.jndi.WLInitialContextFactory";
    ADFLogger logger = ADFLogger.createADFLogger(SplashMessageQueue.class);
    private static final String SMQ_INTERNAL_QUEUE_FACTORY = "jms/splash/smqInternalQueueConnectionFactory";
    private static final String SMQ_INTERNAL_QUEUE = "jms/splash/smqInternalQueue";

    private QueueConnectionFactory qconFactory;
    private QueueConnection qcon;
    private QueueSession qsession;
    private QueueReceiver qreceiver;
    private Queue queue;
    private static SplashMessageQueue SMQueue;
    public SplashMessageQueue() throws NamingException, JMSException {
        InitialContext ctx;
        ctx = new InitialContext();
        qconFactory = (QueueConnectionFactory)ctx.lookup(SMQ_INTERNAL_QUEUE_FACTORY);
        qcon = qconFactory.createQueueConnection();
        qsession = qcon.createQueueSession(true, Session.SESSION_TRANSACTED);
        queue = (Queue)ctx.lookup(SMQ_INTERNAL_QUEUE);
        qreceiver = qsession.createReceiver(queue);
        
        qreceiver.setMessageListener(new NotificationMessageListener(qsession));
        qcon.setExceptionListener(new ExceptionListener() {
                public void onException(JMSException jmsException) {
                    logger.severe("----Capture Impression Queue Connection Exception "+ jmsException.getMessage());jmsException.printStackTrace();
                }
            });
        qcon.start();
        logger.severe("--------------------Capture Impression Queue MessageListener Connection Initialized-------------------------------------");
    }
    
//    public static ExternalCEFQueue ensureConnection() throws NamingException,
//                                                     JMSException {
//        if(CEFQueue == null){
//            CEFQueue = new ExternalCEFQueue();
//        }
//        return CEFQueue;
//    }
    
    public void closeConnections() throws JMSException{
        qreceiver.close();
        qsession.close();
        qcon.close();
        logger.severe("--------------------Capture Impression Queue MessageListener Connections Closed-----------------------------------------");
    }
}