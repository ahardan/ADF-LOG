package com.darden.krowd.notification.test;

import com.darden.krowd.messages.splash.model.converter.KrowdCampaignToSOAXMLConverter;

import java.text.ParseException;

import java.util.Hashtable;

import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import javax.xml.bind.JAXBException;
import javax.xml.datatype.DatatypeConfigurationException;

public class TestCampaignPublisher {
    public final static String JNDI_FACTORY ="weblogic.jndi.WLInitialContextFactory";

    private static final String SMC_QUEUE_FACTORY = "jms.cf.KrowdEmployeeCampaignEventV1Publisher";
    private static final String SMC_QUEUE = "jms.queue.KrowdEmployeeCampaignEventV1";
    

    private QueueConnectionFactory qconFactory;
    private QueueConnection qcon;
    private QueueSession qsession;
    private QueueSender qsender;
    private Queue queue;
    private TextMessage msg;
    String messageStr = null;
    public TestCampaignPublisher() throws JAXBException, DatatypeConfigurationException, ParseException {
        KrowdCampaignToSOAXMLConverter converter = new KrowdCampaignToSOAXMLConverter();
        messageStr = converter.convert(converter._getDummyCampaign());
        System.out.println("....sending message size="+ messageStr.length());
    }
    
    public void send() throws NamingException,
                                                           JMSException {
        Hashtable env = new Hashtable();
        env.put(Context.INITIAL_CONTEXT_FACTORY, JNDI_FACTORY);
        env.put(Context.PROVIDER_URL, "t3://ejmsappd1.darden.com:1801");
        InitialContext ctx = new InitialContext(env);
        qconFactory = (QueueConnectionFactory)ctx.lookup(SMC_QUEUE_FACTORY);
        qcon = qconFactory.createQueueConnection();
        qsession = qcon.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
        queue = (Queue)ctx.lookup(SMC_QUEUE);
        qsender = qsession.createSender(queue);
        msg = qsession.createTextMessage();
        qcon.start();
        
        msg.setText(messageStr);
        System.out.println(messageStr);
        qsender.send(msg);
        
        qsender.close();
        qsession.close();
        qcon.close();
    }

    public static void main(String[] args) throws NamingException, JMSException, JAXBException,
                                                  DatatypeConfigurationException, ParseException {
        TestCampaignPublisher publisher = new TestCampaignPublisher();
        publisher.send();
        System.out.println("Message sent");
    }

}
