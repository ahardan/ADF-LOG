package com.darden.krowd.notification.mdb;

import com.darden.krowd.common.notification.GenericEventObject;
import com.darden.krowd.common.util.KrowdQueueSender;
import com.darden.krowd.messages.splash.model.converter.CampaignErrorConverter;
import com.darden.krowd.messages.splash.model.converter.CampaignImpressionConverter;
import com.darden.krowd.messages.splash.model.dto.SplashImpressionDTO;

import java.io.IOException;

import java.util.List;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import javax.naming.NamingException;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;

import oracle.adf.share.logging.ADFLogger;

import org.xml.sax.SAXException;

@MessageDriven(name = "KrowdSplashMessageErrorConsumer", activationConfig = { 
@ActivationConfigProperty(propertyName = "destinationJndiName", propertyValue = "jms.ErrorQueue.KrowdEmployeeCampaignEventV1"), 
@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"), 
@ActivationConfigProperty(propertyName = "connectionFactoryJndiName", propertyValue = "jms.cf.KrowdEmployeeCampaignErrorEventV1Subscriber"), 
@ActivationConfigProperty(propertyName = "initialContextFactory", propertyValue = "weblogic.jndi.WLInitialContextFactory"), 
//@ActivationConfigProperty(propertyName = "topicMessagesDistributionMode", propertyValue = "One-Copy-Per-Application"), 
@ActivationConfigProperty(propertyName = "subscriptionDurability", propertyValue = "Durable") 
})
public class CampaignErrorQueueConsumer implements MessageListener{
    ADFLogger logger = ADFLogger.createADFLogger(CampaignErrorQueueConsumer.class);
    public CampaignErrorQueueConsumer() {
        super();
    }
    
    public void onMessage(Message msg) {
        logger.info("-- Message recieved in CampaignErrorQueueConsumer");
        if (msg instanceof TextMessage) {
            TextMessage message = (TextMessage)msg;
            String exceptionMsg = null;
            GenericEventObject errorObject = null;
            try {
                errorObject = new CampaignErrorConverter().convert(message.getText());
                logger.info("Xml to ErrorConverter: "+ errorObject);
                if(errorObject != null){
                    KrowdQueueSender sender = null;
                    sender = new KrowdQueueSender();
                    sender.sendInternalSplashMessageEvent(errorObject);
                    sender.close();
                    logger.info("Error Event sent to Internal Splash Message Queue and connection closed");   
                }
            } catch (JAXBException e) {
                e.printStackTrace();
                exceptionMsg = e.getMessage();
                logger.severe(e.getMessage());
            } catch (ParserConfigurationException e) {
                e.printStackTrace();
                exceptionMsg = e.getMessage();
                logger.severe(e.getMessage());
            } catch (SAXException e) {
                e.printStackTrace();
                exceptionMsg = e.getMessage();
                logger.severe(e.getMessage());
            } catch (IOException e) {
                e.printStackTrace();
                exceptionMsg = e.getMessage();
                logger.severe(e.getMessage());
            } catch (JMSException e) {
                e.printStackTrace();
                exceptionMsg = e.getMessage();
                logger.severe(e.getMessage());
            } catch (NamingException e) {
                e.printStackTrace();
                exceptionMsg = e.getMessage();
                logger.severe(e.getMessage());
            }
            if(exceptionMsg != null){
                logger.severe(exceptionMsg);       
                logger.severe("-------Error Consuming Messsage. Will not retry. Logging into error log----");
            }
        }
    }
}
