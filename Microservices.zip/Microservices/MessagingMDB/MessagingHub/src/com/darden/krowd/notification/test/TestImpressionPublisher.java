package com.darden.krowd.notification.test;

import java.util.Hashtable;

import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class TestImpressionPublisher {
    public final static String JNDI_FACTORY ="weblogic.jndi.WLInitialContextFactory";

    private static final String SMI_QUEUE_FACTORY = "jms.cf.KrowdPublisherTemp";
    private static final String SMI_QUEUE = "jms.queue.KrowdEmployeeCampaignImpressionEventV1";
    

    private QueueConnectionFactory qconFactory;
    private QueueConnection qcon;
    private QueueSession qsession;
    private QueueSender qsender;
    private Queue queue;
    private TextMessage msg;
    String messageStr = "<?xml version = \"1.0\" encoding = \"UTF-8\"?>\n" + 
    "<PublishEmployeeCampaignImpressionEventRequest>\n" + 
    "    <EmployeeCampaignImpressionEvent>\n" + 
    "        <EventHeader>\n" + 
    "            <ID>123456789</ID>\n" + 
    "            <!--type: UTCDateTimeType-->\n" + 
    "            <Timestamp>2019-12-31T09:44:07.Z</Timestamp>\n" + 
    "            <Name>DASHEmployeeCampaignImpressionEventV1</Name>\n" + 
    "            <EventSources>\n" + 
    "                <EventSource>\n" + 
    "                    <System>DASH</System>\n" + 
    "                </EventSource>\n" + 
    "            </EventSources>\n" + 
    "        </EventHeader>\n" + 
    "        <Body>\n" + 
    "            <CampaignImpressions>\n" + 
    "                <!--1 or more repetitions:-->\n" + 
    "                <CampaignImpression>\n" + 
    "                    <CampaignID>90</CampaignID>\n" + 
    "                    <CampaignVersion>5</CampaignVersion>\n" + 
    "                    <EmployeeID>\n" + 
    "                        <ID>11223344</ID>\n" + 
    "                    </EmployeeID>\n" + 
    "                    <LocationID>\n" + 
    "                        <CorporationID>TOG</CorporationID>\n" + 
    "                        <Number>1005</Number>\n" + 
    "                    </LocationID>\n" + 
    "                    <TriggerName>CLOCK_IN</TriggerName>\n" + 
    "                    <JobCode>\n" + 
    "                        <Code>2003</Code>\n" + 
    "                    </JobCode>\n" + 
    "                    <ControlsAction>\n" + 
    "                        <!--1 or more repetitions:-->\n" + 
    "                        <Object>\n" + 
    "                            <Name>VIEW</Name>\n" + 
    "                            <Value>Y</Value>\n" + 
    "                            <!--type: UTCDateTimeType-->\n" + 
    "                            <ActionDateTime>2019-12-31T09:07:34.Z</ActionDateTime>\n" + 
    "                            <Properties>\n" + 
    "                                <!--1 or more repetitions:-->\n" + 
    "                                <Property>\n" + 
    "                                    <Name>ANY</Name>\n" + 
    "                                    <Value>ANY</Value>\n" + 
    "                                </Property>\n" + 
    "                            </Properties>\n" + 
    "                        </Object>\n" + 
    "                        <Object>\n" + 
    "                            <Name>ACK</Name>\n" + 
    "                            <Value>Y</Value>\n" + 
    "                            <!--type: UTCDateTimeType-->\n" + 
    "                            <ActionDateTime>2019-12-31T09:08:34.Z</ActionDateTime>\n" + 
    "                            <Properties>\n" + 
    "                                <!--1 or more repetitions:-->\n" + 
    "                                <Property>\n" + 
    "                                    <Name>SEND_KROWD_MESSAGE_ON_ACK</Name>\n" + 
    "                                    <Value>true</Value>\n" + 
    "                                </Property>\n" + 
    "                            </Properties>\n" + 
    "                        </Object>\n" + 
    "                    </ControlsAction>\n" + 
    "                </CampaignImpression>\n" + 
    "                <CampaignImpression>\n" + 
    "                    <CampaignID>91</CampaignID>\n" + 
    "                    <CampaignVersion>3</CampaignVersion>\n" + 
    "                    <EmployeeID>\n" + 
    "                        <ID>11223344</ID>\n" + 
    "                    </EmployeeID>\n" + 
    "                    <LocationID>\n" + 
    "                        <CorporationID>TOG</CorporationID>\n" + 
    "                        <Number>1005</Number>\n" + 
    "                    </LocationID>\n" + 
    "                    <TriggerName>CLOCK_IN</TriggerName>\n" + 
    "                    <JobCode>\n" + 
    "                        <Code>2003</Code>\n" + 
    "                    </JobCode>\n" + 
    "                    <ControlsAction>\n" + 
    "                        <!--1 or more repetitions:-->\n" + 
    "                        <Object>\n" + 
    "                            <Name>VIEW</Name>\n" + 
    "                            <Value>Y</Value>\n" + 
    "                            <!--type: UTCDateTimeType-->\n" + 
    "                            <ActionDateTime>2019-12-31T09:08:34.Z</ActionDateTime>\n" + 
    "                            <Properties>\n" + 
    "                                <!--1 or more repetitions:-->\n" + 
    "                                <Property>\n" + 
    "                                    <Name>ANY</Name>\n" + 
    "                                    <Value>ANY</Value>\n" + 
    "                                </Property>\n" + 
    "                            </Properties>\n" + 
    "                        </Object>\n" + 
    "                        <Object>\n" + 
    "                            <Name>ACK</Name>\n" + 
    "                            <Value>Y</Value>\n" + 
    "                            <!--type: UTCDateTimeType-->\n" + 
    "                            <ActionDateTime>2019-12-31T09:09:34.Z</ActionDateTime>\n" + 
    "                            <Properties>\n" + 
    "                                <!--1 or more repetitions:-->\n" + 
    "                                <Property>\n" + 
    "                                    <Name>SEND_KROWD_MESSAGE_ON_ACK</Name>\n" + 
    "                                    <Value>true</Value>\n" + 
    "                                </Property>\n" + 
    "                            </Properties>\n" + 
    "                        </Object>\n" + 
    "                    </ControlsAction>\n" + 
    "                </CampaignImpression>\n" + 
    "            </CampaignImpressions>\n" + 
    "        </Body>\n" + 
    "    </EmployeeCampaignImpressionEvent>\n" + 
    "</PublishEmployeeCampaignImpressionEventRequest>";
    public TestImpressionPublisher() {
        super();
    }
    
    public void send() throws NamingException,
                                                           JMSException {
        Hashtable env = new Hashtable();
        env.put(Context.INITIAL_CONTEXT_FACTORY, JNDI_FACTORY);
        env.put(Context.PROVIDER_URL, "t3://ejmsappd1.darden.com:1801");
        InitialContext ctx = new InitialContext(env);
        qconFactory = (QueueConnectionFactory)ctx.lookup(SMI_QUEUE_FACTORY);
        qcon = qconFactory.createQueueConnection();
        qsession = qcon.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
        queue = (Queue)ctx.lookup(SMI_QUEUE);
        qsender = qsession.createSender(queue);
        msg = qsession.createTextMessage();
        qcon.start();
        
        msg.setText(messageStr);
        qsender.send(msg);
        
        qsender.close();
        qsession.close();
        qcon.close();
    }

    public static void main(String[] args) throws NamingException, JMSException {
        TestImpressionPublisher publisher = new TestImpressionPublisher();
        publisher.send();
    }

}
