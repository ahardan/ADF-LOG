package com.darden.krowd.notification.mdb;

import com.darden.commonwsdl.common.xsd.notificationservicev2.SendNotificationEventRequestType;
import com.darden.krowd.common.notification.KrowdBusinessObjectEvent;
import com.darden.krowd.common.util.KrowdQueueSender;

import com.darden.krowd.messages.splash.model.converter.CampaignImpressionConverter;

import com.darden.krowd.messages.splash.model.dto.SplashImpressionDTO;

import java.io.IOException;

import java.util.List;
import java.util.UUID;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import javax.jms.TextMessage;

import javax.naming.NamingException;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;

import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;

import oracle.jbo.client.Configuration;
import oracle.jbo.common.ampool.ApplicationPool;
import oracle.jbo.common.ampool.PoolMgr;
import oracle.jbo.common.ampool.SessionCookie;


import org.xml.sax.SAXException;

@MessageDriven(name = "KrowdSplashMessageConsumer", activationConfig = { 
@ActivationConfigProperty(propertyName = "destinationJndiName", propertyValue = "jms.queue.KrowdEmployeeCampaignImpressionEventV1"), 
@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"), 
@ActivationConfigProperty(propertyName = "connectionFactoryJndiName", propertyValue = "jms.cf.KrowdEmployeeCampaignImpressionEventV1Subscriber"), 
@ActivationConfigProperty(propertyName = "initialContextFactory", propertyValue = "weblogic.jndi.WLInitialContextFactory"), 
//@ActivationConfigProperty(propertyName = "topicMessagesDistributionMode", propertyValue = "One-Copy-Per-Application"), 
@ActivationConfigProperty(propertyName = "subscriptionDurability", propertyValue = "Durable") 
}) 
public class SplashImpressionQueueConsumer implements MessageListener{
    ADFLogger logger = ADFLogger.createADFLogger(SplashImpressionQueueConsumer.class);
    public SplashImpressionQueueConsumer() {
        super();
    }

    public void onMessage(Message msg) {
        logger.info("-- Message recieved in SOAKrowdSplashMessageConsumer");
        if (msg instanceof TextMessage) {
            TextMessage message = (TextMessage)msg;
            List<SplashImpressionDTO> impressions;
            String exceptionMsg = null;
            try {
                impressions = new CampaignImpressionConverter().convert(message.getText());
                logger.info("Xml to impressions: "+ impressions);
                if(impressions != null){
                    KrowdQueueSender sender = null;
                    for(SplashImpressionDTO dto : impressions){
                        sender = new KrowdQueueSender();
                        sender.sendInternalSplashMessageEvent(dto);
                        sender.close();
                        logger.info(" Event sent to Internal Splash Message Queue and connection closed");   
                    }
                }
            } catch (JAXBException e) {
                e.printStackTrace();
                exceptionMsg = e.getMessage();
                logger.severe("Error1 " +e.getMessage());
            } catch (ParserConfigurationException e) {
                e.printStackTrace();
                exceptionMsg = e.getMessage();
                logger.severe("Error2 " +e.getMessage());
            } catch (SAXException e) {
                e.printStackTrace();
                exceptionMsg = e.getMessage();
                logger.severe("Error3 " +e.getMessage());
            } catch (IOException e) {
                e.printStackTrace();
                exceptionMsg = e.getMessage();
                logger.severe("Error4 " +e.getMessage());
            } catch (JMSException e) {
                e.printStackTrace();
                exceptionMsg = e.getMessage();
                logger.severe("Error5 " +e.getMessage());
            } catch (NamingException e) {
                e.printStackTrace();
                exceptionMsg = e.getMessage();
                logger.severe("Error6 " +e.getMessage());
            } catch (Exception e){
                e.printStackTrace();
                exceptionMsg = e.getMessage();
                logger.severe("Error7 " +e.getMessage());
            }
            if(exceptionMsg != null){
                logger.severe(exceptionMsg);       
                logger.severe("-------Error Consuming Messsage. Will not retry. Logging into error log----");
            }
        }
    }
}
