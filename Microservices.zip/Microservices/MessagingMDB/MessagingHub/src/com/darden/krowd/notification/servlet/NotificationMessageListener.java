package com.darden.krowd.notification.servlet;

import com.darden.krowd.common.notification.GenericEventObject;
import com.darden.krowd.common.notification.KrowdBusinessObjectEvent;
import com.darden.krowd.messages.splash.model.dto.ErrorObjectDTO;
import com.darden.krowd.messages.splash.model.dto.SplashImpressionDTO;
import com.darden.krowd.messages.splash.model.publisher.MessagePublisher;
import com.darden.krowd.notification.handler.BusinessObjectEventHandler;

import com.darden.krowd.notification.mdb.SplashImpressionQueueConsumer;

import java.util.Date;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import javax.jms.TextMessage;

import javax.jms.QueueSession;

import javax.naming.NamingException;

import oracle.adf.share.logging.ADFLogger;

public class NotificationMessageListener implements MessageListener {
    ADFLogger logger = ADFLogger.createADFLogger(NotificationMessageListener.class);
    private QueueSession qSession;

    public NotificationMessageListener(QueueSession qSession) {
        super();
        this.qSession = qSession;
    }

    //Message handler to take care of both internal and external events.
    //Internal events raised by Webcenter are BusinessObjectEvents
    //Internal Events raised by krowd code are KrowdBusinessObjectEvents
    public void onMessage(Message msg) {
        ObjectMessage messageWrapper = null;
        if (msg instanceof ObjectMessage) {
            try {
                logger.severe("===================msg=" + msg);
                messageWrapper = (ObjectMessage) msg;
                logger.severe("=====================messageWrapper=" + messageWrapper);

                if (messageWrapper.getObject() instanceof GenericEventObject) {
                    String xmlPayload;
                    try {
                        logger.severe("Trying to extract text from message");
                        GenericEventObject msgObj = (GenericEventObject) messageWrapper.getObject();
                        if (msgObj.getEventName().equalsIgnoreCase("CAMPAIGN_UPDATE")) {
                            xmlPayload = msgObj.getObjectText();
                            if (xmlPayload != null) {
                                MessagePublisher publisher = new MessagePublisher();
                                publisher.sendCampaignEvent(xmlPayload);
                                //Record of the sent event is recorded in Locations Table for the splash in the publisher logic
                                logger.severe("CampaignUpdateEvent Message sent " + xmlPayload.length());
                            } else {
                                logger.severe("Error:::: empty text message");
                            }
                        } else if (msgObj.getEventName().equalsIgnoreCase("CAMPAIGN_ERROR_EVENT")){
                            logger.info("-- ErrorObjectDTO message recieved by NotificationMessageListener " +
                                        messageWrapper.getObject());
                            ErrorObjectDTO dto = (ErrorObjectDTO) messageWrapper.getObject();
                            BusinessObjectEventHandler handler = new BusinessObjectEventHandler();
                            Date messageTime = new Date(msg.getJMSTimestamp());
                            handler.handle(dto, messageTime);
                            logger.info("---------got event in NotificationMessageListener krowd dto event = " + dto);
                        }else if (msgObj.getEventName().equalsIgnoreCase("DASHEmployeeCampaignImpressionEventV1")) {
                            logger.info("-- SplashImpressionDTO message recieved by NotificationMessageListener " +
                                        messageWrapper.getObject());
                            SplashImpressionDTO dto = (SplashImpressionDTO) messageWrapper.getObject();
                            BusinessObjectEventHandler handler = new BusinessObjectEventHandler();
                            Date messageTime = new Date(msg.getJMSTimestamp());
                            handler.handle(dto, messageTime);
                            logger.info("---------got event in NotificationMessageListener krowd dto event = " + dto);
                        }

                    } catch (JMSException e) {
                        logger.severe("---------Exception while processing message on queue listener----" +
                                      e.getMessage());
                        e.printStackTrace();
                    } catch (NamingException e) {
                        logger.severe("---------Exception while processing message on queue listener----" +
                                      e.getMessage());
                        e.printStackTrace();
                    }
                }

                //////////msg.acknowledge();//CLIENT_ACKNOWLEDGE
                qSession.commit();
                logger.info("--------------------------Message Acknowledged-----------------------");
            } catch (Exception e) {
                //                try {
                //                    qSession.rollback();
                //                    logger.severe(":::BOE rolled back.");
                //                } catch (JMSException f) {
                //                    logger.severe(":::Couldnot rollback message. Message will be commited in next commit----"+ e.getMessage());
                //                }
                logger.severe("---------Exception while processing message on queue listener----" + e.getMessage());
                e.printStackTrace();
            }
        }
    }
}
