package com.darden.krowd.notification.handler;

import com.darden.krowd.common.KrowdUtility;
import com.darden.krowd.common.cache.LDAPCacheUtil;
import com.darden.krowd.common.dto.KrowdUserDTO;
import com.darden.krowd.common.notification.GenericEventObject;
import com.darden.krowd.common.notification.KrowdActor;
import com.darden.krowd.common.notification.KrowdBusinessObjectEvent;
import com.darden.krowd.common.notification.KrowdCustomProperty;

import com.darden.krowd.messages.splash.model.applicationModule.SplashMessageAMImpl;
import com.darden.krowd.messages.splash.model.dto.ErrorObjectDTO;
import com.darden.krowd.messages.splash.model.dto.SplashImpressionDTO;
import com.darden.krowd.targetedmessaging.model.applicationmodule.common.MessagesAM;

import java.io.FileInputStream;

import java.io.IOException;
import java.io.ObjectInputStream;

import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import oracle.adf.share.ADFContext;

import oracle.adf.share.logging.ADFLogger;

import oracle.jbo.client.Configuration;
import oracle.jbo.common.ampool.ApplicationPool;
import oracle.jbo.common.ampool.PoolMgr;
import oracle.jbo.common.ampool.SessionCookie;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

public class BusinessObjectEventHandler {
    private static final ADFLogger logger =
        ADFLogger.createADFLogger(BusinessObjectEventHandler.class);
    private static final String KROWD_APP_ROLLOUT_RULES_CONFIG = KrowdUtility.getInstance().getProperties().getProperty("KROWD_APP_ROLLOUT_RULES_CONFIG");
    Map<String, List<String>> rolloutExclusionRules;
    Map<String, Map<String, String>> allowedActivityTypes;

    public BusinessObjectEventHandler() {
        super();
        int totalEventsSupported = 0;
        allowedActivityTypes = new HashMap<String, Map<String, String>>();
//        String[] dashAllowedEvents = (KrowdUtility.getInstance().getProperties().getProperty("NOTIFICATION_DASH_ALLOWED_EVENTS")).split("##");
        Map<String, String> allowedEvents = new HashMap<String, String>();
//        for(String event : dashAllowedEvents){
//            allowedEvents.put(event, event);
//            totalEventsSupported++;
//        }
        allowedActivityTypes.put("DASH", allowedEvents);
        logger.info("BusinessObjectEventHandler totalEventsSupported = "+ totalEventsSupported);
    }

    public void handle(GenericEventObject bizObjEv, Date jmsTimestamp) throws Exception {
        //SessionCookie sc = null;
        SplashMessageAMImpl splashAM = null;
        try {
            Map<String, String> allowedEventsForApp = allowedActivityTypes.get(bizObjEv.getAppId());
            boolean isEventNameSupported = allowedEventsForApp != null && allowedEventsForApp.containsKey(bizObjEv.getEventName());
            logger.info(":^:^:^:>>>>> appId = " + bizObjEv.getAppId() +
                          " ,::: eventName = " + bizObjEv.getEventName() + 
                          ", isEventNameSupported= "+ isEventNameSupported);
            
            if (bizObjEv.getEventName() != null){// && isEventNameSupported) {
                logger.info(":::NotificationMDB::onMessage: Event Name : " +
                              bizObjEv.getEventName());
                    splashAM = 
                        (SplashMessageAMImpl)Configuration.createRootApplicationModule("com.darden.krowd.messages.splash.model.applicationModule.SplashMessageAMLocal",
                                                                                                                                   "SplashMessageAMLocal");
                    logger.info("______NotificationBroadcaster Queue onMessage splashAM = " +
                                  splashAM);
                    if (splashAM != null) {
                        if(bizObjEv instanceof SplashImpressionDTO){
                            SplashImpressionDTO dto = (SplashImpressionDTO)bizObjEv;
                            splashAM.registerImpression(dto);    
                        } else if(bizObjEv instanceof ErrorObjectDTO){
                            ErrorObjectDTO dto = (ErrorObjectDTO)bizObjEv;
                            splashAM.captureErrorQueueMessage(dto);    
                        }
                        
                        
                    }                
            } else {
                logger.severe(":::: appId = " + bizObjEv.getAppId() +
                              " ,::: eventName = " + bizObjEv.getEventName() +" combination not supported currently.");
            }
        } catch (Exception e) {
            logger.severe("Generic Exception ::: " + e.getMessage());
            e.printStackTrace();
            throw e;
        } finally {
            if(splashAM != null){
                Configuration.releaseRootApplicationModule(splashAM, true);    
            }
        }
    }
}
