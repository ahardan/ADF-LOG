package com.darden.krowd.notification.servlet;

import com.darden.krowd.common.KrowdUtility;
import com.darden.krowd.notification.connections.SplashMessageQueue;

import java.util.ArrayList;
import java.util.List;

import javax.jms.JMSException;
import javax.naming.NamingException;

import oracle.adf.share.logging.ADFLogger;

public class JMSConnector{
    ADFLogger logger = ADFLogger.createADFLogger(JMSConnector.class);
    private static final String noOfSplashImpressionsConsumersPerApp = KrowdUtility.getInstance().getProperties().getProperty("SPLASH_IMPRESSIONS_QUEUE_NO_OF_CONSUMERS");
    private static JMSConnector connector;
    List<SplashMessageQueue> impressionQueues = new ArrayList<SplashMessageQueue>();

    private JMSConnector() {
        try {
            
            int noOfExtConsumers = getNoOfConsumers();
            for(int i=0; i< noOfExtConsumers; i++){
                impressionQueues.add(new SplashMessageQueue());    
            }
        } catch (NamingException e) {
            e.printStackTrace();
        } catch (JMSException e){
            e.printStackTrace();        
        }
    }
    
    private int getNoOfConsumers(){
        int noOfConsumers = 1;
        if(noOfSplashImpressionsConsumersPerApp != null){
            try{
                noOfConsumers = Integer.parseInt(noOfSplashImpressionsConsumersPerApp);                
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        return noOfConsumers;
    }
    
    public static JMSConnector buildInstance(){
        if(connector != null){
            return connector;
        }else{
            return new JMSConnector();
        }
    }
    
    public void closeConnections() throws NamingException, JMSException {
        //InternalCEFQueue.ensureConnection().closeConnections();
        for(SplashMessageQueue q : impressionQueues){
            q.closeConnections();    
        }
        
        //SOANotificationTopic.ensureConnection().closeConnections();
    }
}
