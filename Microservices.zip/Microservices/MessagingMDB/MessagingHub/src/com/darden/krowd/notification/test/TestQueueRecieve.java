package com.darden.krowd.notification.test;

import java.io.IOException;

import java.util.Hashtable;

import javax.jms.*;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import java.io.*;

import oracle.security.audit.util.Base64;

import oracle.social.network.cef.BusinessObject;

public class TestQueueRecieve implements MessageListener {
    public final static String JNDI_FACTORY = "weblogic.jndi.WLInitialContextFactory";

    private static final String CEF_QUEUE_FACTORY = "jms.cf.KrowdEmployeeCampaignImpressionEventV1Subscriber";
    private static final String CEF_QUEUE = "jms.queue.KrowdEmployeeCampaignImpressionEventV1";

    private QueueConnectionFactory qconFactory;
    private QueueConnection qcon;
    private QueueSession qsession;
    private QueueReceiver qreceiver;
    private Queue queue;
    private boolean quit = false;

    public void onMessage(Message msg) {
        try {
            String msgText;
            if (msg instanceof TextMessage) {
                msgText = ((TextMessage)msg).getText();
            } else {
                msgText = msg.toString();
            }
            System.out.println("\n\t&lt;Msg_Receiver&gt; " + msgText);
            if (msgText.equalsIgnoreCase("quit")) {
                synchronized (this) {
                    quit = true;
                    this.notifyAll(); // Notify main thread to quit
                }
            }
        } catch (JMSException jmse) {
            jmse.printStackTrace();
        }
    }

    public void init(Context ctx, String queueName) throws NamingException,
                                                           JMSException {
        qconFactory = (QueueConnectionFactory)ctx.lookup(CEF_QUEUE_FACTORY);
        qcon = qconFactory.createQueueConnection();
        qsession = qcon.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
        queue = (Queue)ctx.lookup(queueName);
        qreceiver = qsession.createReceiver(queue);
        qreceiver.setMessageListener(this);
        qcon.start();
    }

    public void close() throws JMSException {
        qreceiver.close();
        qsession.close();
        qcon.close();
    }

    public static void main(String[] args) throws Exception {
        args = new String[]{"t3://ejmsappd1.darden.com:1801"};
        if (args.length != 1) {
            System.out.println("Usage: java QueueReceive WebLogicURL");
            return;
        }
        InitialContext ic = getInitialContext(args[0]);
        TestQueueRecieve qr = new TestQueueRecieve();
        qr.init(ic, CEF_QUEUE);
        System.out.println("JMS Ready To Receive Messages (To quit, send a \"quit\" message from QueueSender.class).");
        // Wait until a "quit" message has been received.
        synchronized (qr) {
            while (!qr.quit) {
                try {
                    qr.wait();
                } catch (InterruptedException ie) {
                }
            }
        }
        qr.close();
        
//        BusinessObjectEvent event = (BusinessObjectEvent)fromBase64String("rO0ABXNyAC1vcmFjbGUuc29jaWFsLm5ldHdvcmsuY2VmLkJ1c2luZXNzT2JqZWN0RXZlbnQAAAAAAAAAAgIAC0wAB21BY3RvcnN0ABBMamF2YS91dGlsL0xpc3Q7TAAGbUFwcElkdAASTGphdmEvbGFuZy9TdHJpbmc7TAAPbUN1c3RQcm9wZXJ0aWVzcQB+AAFMAAhtRXZlbnRJZHEAfgACTAAKbUV2ZW50TmFtZXEAfgACTAAIbU1lc3NhZ2VxAH4AAkwAC21NZXNzYWdlS2V5cQB+AAJMAAhtT2JqZWN0c3EAfgABTAAObVBhcmVudEV2ZW50SWRxAH4AAkwADW1QcmltYXJ5QWN0b3J0ACFMb3JhY2xlL3NvY2lhbC9uZXR3b3JrL2NlZi9BY3RvcjtMAA5tUHJpbWFyeU9iamVjdHQAKkxvcmFjbGUvc29jaWFsL25ldHdvcmsvY2VmL0J1c2luZXNzT2JqZWN0O3hwc3IAE2phdmEudXRpbC5BcnJheUxpc3R4gdIdmcdhnQMAAUkABHNpemV4cAAAAAF3BAAAAApzcgAfb3JhY2xlLnNvY2lhbC5uZXR3b3JrLmNlZi5BY3RvcgAAAAAAAAACAgAEWgAGbUdyb3VwTAAMbURpc3BsYXlOYW1lcQB+AAJMAAZtRW1haWxxAH4AAkwAA21JZHEAfgACeHAAdAANUmFrZXNoIEdhanVsYXQAElJHYWp1bGFAZGFyZGVuLmNvbXQAB2dzZHJ4ZzF4dAAJd2ViY2VudGVyc3EAfgAGAAAAAHcEAAAACnh0ACQ5ZjBiZTk0MS01YTFkLTRjNmEtOWY0NS1kYmRmMmU2Y2Q3ZGR0AAlwb3N0c2NvcGV0ABt7YWN0b3JbMF19IHBvc3RlZCBhIG1lc3NhZ2V0ABZBQ1RJVklUWV9TQ09QRVBPU1RfTVNHc3EAfgAGAAAAAncEAAAACnNyAChvcmFjbGUuc29jaWFsLm5ldHdvcmsuY2VmLkJ1c2luZXNzT2JqZWN0AAAAAAAAAAECAARMAA9tQ3VzdFByb3BlcnRpZXNxAH4AAUwADG1EaXNwbGF5TmFtZXEAfgACTAADbUlkcQB+AAJMAAVtVHlwZXEAfgACeHBzcQB+AAYAAAABdwQAAAAKc3IAKG9yYWNsZS5zb2NpYWwubmV0d29yay5jZWYuQ3VzdG9tUHJvcGVydHkAAAAAAAAAAQIAAkwABW1OYW1lcQB+AAJMAAZtVmFsdWVxAH4AAnhwdAADdXJsdADNaHR0cHM6Ly9rcm93ZGRldjIuZGFyZGVuLmNvbTo0NDMvd2ViY2VudGVyL2ZhY2VzL293UmVzb3VyY2UuanNweD96PW9yYWNsZS53ZWJjZW50ZXIucGVvcGxlY29ubmVjdGlvbnMud2FsbCUyMXMwZTZjY2E2MF9iOGE0XzQ2NjNfOWFhYl85ZDFlNWE3ZDlmMzUlMjFkZWZkZWZmYS1kNzdjLTRmZTUtYWFiNy1kM2JkOTBlYzkzZDUlMjFtZXNzYWdlJTIxbWVzc2FnZXh0AAdtZXNzYWdldAAkZGVmZGVmZmEtZDc3Yy00ZmU1LWFhYjctZDNiZDkwZWM5M2Q1dAAHbWVzc2FnZXNxAH4AFHNxAH4ABgAAAAF3BAAAAApzcQB+ABdxAH4AGXQAymh0dHBzOi8va3Jvd2RkZXYyLmRhcmRlbi5jb206NDQzL3dlYmNlbnRlci9mYWNlcy9vd1Jlc291cmNlLmpzcHg/ej1vcmFjbGUud2ViY2VudGVyLmFjdGl2aXR5c3RyZWFtaW5nJTIxczBlNmNjYTYwX2I4YTRfNDY2M185YWFiXzlkMWU1YTdkOWYzNSUyMTlmMGJlOTQxLTVhMWQtNGM2YS05ZjQ1LWRiZGYyZTZjZDdkZCUyMWFjdGl2aXR5JTIxYWN0aXZpdHl4dAAIYWN0aXZpdHlxAH4AD3QACGFjdGl2aXR5eHBxAH4ACXEAfgAV");
//        System.out.println(event);
    }

    private static InitialContext getInitialContext(String url) throws NamingException {
        Hashtable env = new Hashtable();
        env.put(Context.INITIAL_CONTEXT_FACTORY, JNDI_FACTORY);
        env.put(Context.PROVIDER_URL, url);
        return new InitialContext(env);
    }
    
    /** Read the object from Base64 string. */
    private static Object fromBase64String( String s ) throws IOException ,
                                                       ClassNotFoundException {

        byte [] data = Base64.fromBase64(s);
        ObjectInputStream ois = new ObjectInputStream( 
                                        new ByteArrayInputStream(  data ) );
        Object o  = ois.readObject();
        ois.close();
        return o;
    }

    /** Write the object to a Base64 string. */
    private static String toBase64String( Serializable o ) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream( baos );
        oos.writeObject( o );
        oos.close();
        return Base64.toBase64(baos.toByteArray(),false); 
    }    
}