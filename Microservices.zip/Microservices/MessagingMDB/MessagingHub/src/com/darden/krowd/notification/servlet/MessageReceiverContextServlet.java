package com.darden.krowd.notification.servlet;

import com.darden.krowd.common.cache.LDAPCacheUtil;

import java.io.IOException;

import java.io.PrintWriter;

import javax.jms.JMSException;

import javax.naming.NamingException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;

import oracle.adf.share.logging.ADFLogger;


public class MessageReceiverContextServlet extends HttpServlet {
    ADFLogger logger = ADFLogger.createADFLogger(MessageReceiverContextServlet.class);
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        JMSConnector.buildInstance();
    }

    @Override
    public void destroy() {
        super.destroy();
        try {
            JMSConnector.buildInstance().closeConnections();
        } catch (JMSException e) {
            logger.severe(e.getMessage());
            e.printStackTrace();
        } catch (NamingException e) {
            logger.severe(e.getMessage());
            e.printStackTrace();
        }
    }
    
    protected void doGet(HttpServletRequest httpServletRequest,
                         HttpServletResponse httpServletResponse) throws ServletException,
                                                                         IOException {
        LDAPCacheUtil aPCacheUtil = LDAPCacheUtil.getInstance();
        logger.info("----NotificationReceiverContextServlet doGet aPCacheUtil = "+ aPCacheUtil);
        String ret = aPCacheUtil.dumpMessageUserCacheStats();
        logger.info("----NotificationReceiverContextServlet doGet ret = "+ ret);
        PrintWriter pw = httpServletResponse.getWriter();
        pw.println(ret);
        pw.flush();
    }
}
