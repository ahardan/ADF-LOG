package com.darden.krowd.portal.notification.rest.service;


import com.darden.commonwsdl.common.xsd.notificationservicev2.SendNotificationEventRequestType;
import com.darden.krowd.common.KrowdUtility;
import com.darden.krowd.common.cache.LDAPCacheUtil;
import com.darden.krowd.common.dto.KrowdUserDTO;
import com.darden.krowd.common.model.dto.UserPreferenceDTO;
import com.darden.krowd.common.notification.KrowdActor;
import com.darden.krowd.common.notification.KrowdBusinessObject;
import com.darden.krowd.common.notification.KrowdBusinessObjectEvent;
import com.darden.krowd.common.notification.KrowdCustomProperty;
import com.darden.krowd.common.util.CacheUtil;
import com.darden.krowd.common.util.KrowdQueueSender;
import com.darden.krowd.model.converter.SoaEBOToBusinessObjectConverter;
import com.darden.krowd.model.pojo.AppInfo;
import com.darden.krowd.model.pojo.BadgeCount;
import com.darden.krowd.model.pojo.Device;
import com.darden.krowd.model.pojo.DeviceDTO;
import com.darden.krowd.model.pojo.NotificationDTO;
import com.darden.krowd.model.pojo.NotificationPreferenceDTO;
import com.darden.krowd.model.pojo.PushInfo;
import com.darden.krowd.model.pojo.UserInfo;
import com.darden.krowd.model.serialize.ActivityNotification;
import com.darden.krowd.model.serialize.NotificationSetting;
import com.darden.krowd.model.storeMds.MdsStoreObject;
import com.darden.krowd.model.util.NotificationUtil;
import com.darden.krowd.notifications.model.jdbc.NotificationDAO;
import com.darden.krowd.notifications.model.applicationModule.NotificationsAMImpl;
import com.darden.krowd.notifications.model.applicationModule.common.NotificationsAM;
import com.darden.krowd.portal.notification.rest.exceptions.BadRequestException;
import com.darden.krowd.portal.notification.rest.schema.SOARegistrationSchema;
import com.darden.krowd.portal.notification.rest.schema.SignupChannel;
import com.darden.krowd.portal.notification.rest.schema.Source;
import com.darden.krowd.portal.notification.rest.schema.SourceID;
import com.darden.krowd.portal.notification.rest.schema.SourceIDs;
import com.darden.krowd.portal.notification.rest.schema.SubscriptionChannel;

import java.io.IOException;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import java.util.Map;

import javax.jms.JMSException;

import javax.naming.NamingException;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;

import oracle.adf.model.BindingContext;
import oracle.adf.model.DataControlFrame;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;

import oracle.webcenter.content.integration.cache.Cache;

import oracle.webcenter.peopleconnections.profile.ProfileFactory;
import oracle.webcenter.peopleconnections.profile.UserProfileManager;
import oracle.webcenter.peopleconnections.profile.WCUserProfile;
import oracle.webcenter.peopleconnections.profile.internal.model.ProfileInternalUtils;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import org.xml.sax.SAXException;


@Path("/notifications")
@Produces("application/json")
public class NotificationResource {
    
    private static final ADFLogger logger = ADFLogger.createADFLogger(NotificationResource.class);
    private static String PAGE_DEF = "com_darden_krowd_portal_RestPageDef"; 
    private static String DATACONTROL = "NotificationsAMDataControl";

    public NotificationResource() {
        super();
    }
    
    private NotificationsAMImpl getNotificationsAM(){
        BindingContext bindingContext = BindingContext.getCurrent();
        NotificationsAMImpl am =null;
        DCDataControl dc = null; 
        if(bindingContext !=null){
            String dcFrameName = bindingContext.getCurrentDataControlFrame();
            DataControlFrame dcframe = dcFrameName == null? null : bindingContext.findDataControlFrame(dcFrameName);
            
            dc = dcframe == null ? null : dcframe.findDataControl(DATACONTROL);        
            dc = dc == null ? bindingContext.findDataControl(DATACONTROL) : dc;
            if(dc == null){
               DCBindingContainer amx = bindingContext.findBindingContainer(PAGE_DEF);
                dc = amx.findDataControl(DATACONTROL); 
                am = (NotificationsAMImpl)dc.getDataProvider();
            }else{
                am = (NotificationsAMImpl)dc.getDataProvider();
            }
        }
        return am;
    }     
    
    @GET
    @Path(value="/activity/{activityId}")
    public Response getActivity(@PathParam("activityId")String activityId){
        NotificationsAM am = getNotificationsAM();
        System.out.println("----------------------am = "+ am);
        NotificationDTO dto = new NotificationDTO();
        dto.setActivityId(activityId);
//        am.retrieveActivity(activityId, dto);
        return Response.ok(dto).type(MediaType.APPLICATION_JSON).build();
    }
    
       
    @GET
      @Path("/inbox")
      public Response getNotifications(){
          List<ActivityNotification> notifications = new ArrayList<ActivityNotification>();
          NotificationsAM am = getNotificationsAM();
          LDAPCacheUtil util = LDAPCacheUtil.getInstance();
          List<NotificationDTO> dtos = am.getNotifications(0,10);
          for(NotificationDTO dto : dtos){
              ActivityNotification noti = new ActivityNotification();
              noti.setNotificationId(dto.getNotificationId());
              noti.setActivityId(dto.getActivityId());
              noti.setActivityCreator(dto.getPrimaryActorId());
              noti.setActivityType(dto.getActivityType());
              noti.setPostType(dto.getActivitySubType());
              noti.setActivityDescription(dto.getActivityDescription());
              noti.setPostReadStatus(dto.isIsRead());
              
              noti.setActDocId(dto.getActivityDocumentDDocName());
              try{
                  noti.setActDId(dto.getActivityDocumentDID() == null ? 0 : Integer.parseInt(dto.getActivityDocumentDID()));    
              }catch(NumberFormatException e){
                  e.printStackTrace();
                  noti.setActDId(0);
              }
              noti.setActDetailUrl(dto.getActivityDetailUrl());
              
              noti.setPostName(dto.getActivitySubType());
              noti.setComActorId(dto.getPrimaryActorId());
              KrowdUserDTO user = util.getKrowdUser(dto.getPrimaryActorId());
              noti.setComActorName(user.getDisplayName());
              noti.setComActorPhotoURI("/webcenter/profilephoto/"+user.getImageUrl());
              noti.setComDescription(dto.getActivityDescription());
              noti.setComTimeStamp(dto.getActivityTime());
              
              noti.setLikeActorId(dto.getPrimaryActorId());
              noti.setLikeActorName(user.getDisplayName());
              noti.setLikeActorPhotoURI("/webcenter/profilephoto/"+user.getImageUrl());
              noti.setLikeTimeStamp(dto.getActivityTime());
              noti.setFormCommunityUrl(dto.getCommunityUrl());
              noti.setCommunityName(dto.getCommunityName());
              notifications.add(noti);
          }
          ActivityNotification[] notiArray = new ActivityNotification[0];
          if(notifications != null)
              notiArray = notifications.toArray(notiArray);
          
          return Response.ok(notiArray).build();
      }
    
    @GET
      @Path("/ishiftNotifications")
      public Response getIshiftNotifications(@DefaultValue("10") @QueryParam("itemsPerPage") long _itemsPerPage,
            @DefaultValue("-1") @QueryParam("notificationId") long _notificationId,
            @DefaultValue("DOWN") @QueryParam("fetchDir") String _fetchDir,
            @QueryParam("userName") String _userName){
          NotificationsAM am = getNotificationsAM();

          List<NotificationDTO> dtos = am.getIshiftNotifications(_userName, _notificationId, _itemsPerPage, _fetchDir);
          NotificationDTO[] dtoArr = new NotificationDTO[0];
          if(dtos != null){
              dtoArr = dtos.toArray(dtoArr);
          }
          return Response.ok(dtoArr).build();
      }
    
    @PUT
    @Path("/read/{notificationId}")
    public Response readNotification(@PathParam("notificationId") Long notificationId){
        MdsStoreObject ret = new MdsStoreObject();
        NotificationsAM am = getNotificationsAM();
        Long retNotificationId = am.readNotification(notificationId);
//        StoreMDS mds = StoreMDS.getInstance();
//        MdsStoreObject ret = null;
//        try {
//            ret = mds.updateNotification(index, ADFContext.getCurrent().getSecurityContext().getUserName());
//            ArrayList<ActivityNotification> notifications = null;
//            notifications = ret.getActivityNotification();
//            for(ActivityNotification activityNotification:notifications){
//                if("Comment".equalsIgnoreCase(activityNotification.getActivityType())){
//                    try{
//                        UserProfileManager profileManager = ProfileFactory.getProfileManager();
//                        WCUserProfile userProfile = profileManager.getProfile(activityNotification.getComActorId());
//                        if(userProfile != null){
//                            String guid = WallServiceUtils.userNameToGuid(userProfile.getUserName());
//                            activityNotification.setComActorName(userProfile.getDisplayName());
//                            activityNotification.setComActorPhotoURI(generatePhotoURI(guid,"SMALL"));
//                        }
//                    }
//                    catch (ProfileException e) {
//                               logger.severe(e);
//                    }
//                }
//                if("Like".equalsIgnoreCase(activityNotification.getActivityType())){
//                    try {
//                        UserProfileManager profileManager = ProfileFactory.getProfileManager();
//                        WCUserProfile userProfile =
//                            profileManager.getProfile(activityNotification.getLikeActorId());
//                        if (userProfile != null) {
//                            String guid =WallServiceUtils.userNameToGuid(userProfile.getUserName());
//                            activityNotification.setLikeActorName(userProfile.getDisplayName());
//                            activityNotification.setLikeActorPhotoURI(generatePhotoURI(guid,"SMALL"));
//                        }
//                    } catch (ProfileException e) {
//                        logger.severe(e);
//                    }
//                }
//            }
//            
//        } catch (IOException e) {
//            logger.severe(e);
//            throw new BadRequestException(e);
//        } catch (ParserConfigurationException e) {
//            logger.severe(e);
//            throw new BadRequestException(e);
//        } catch (SAXException e) {
//            logger.severe(e);
//            throw new BadRequestException(e);
//        }
        return Response.ok(retNotificationId).build();
    }
    
    @DELETE
    @Path("/delete/{notificationId}")
    public Response deleteNotification(@PathParam("notificationId") Long notificationId){
        NotificationsAM am = getNotificationsAM();
        Long retNotificationId = am.deleteNotification(notificationId);
//        StoreMDS mds = StoreMDS.getInstance();
//        MdsStoreObject ret = null;
//        try {
//            ret = mds.removeNotification(index, ADFContext.getCurrent().getSecurityContext().getUserName());
//        } catch (IOException e) {
//            logger.severe(e);
//            throw new BadRequestException(e);
//        } catch (ParserConfigurationException e) {
//            logger.severe(e);
//            throw new BadRequestException(e);
//        } catch (SAXException e) {
//            logger.severe(e);
//            throw new BadRequestException(e);            
//        }
        return Response.ok(retNotificationId).build();
    }
    
    @DELETE
    @Path("/delete/ishiftAll")
    public Response deleteAllIShiftNotifications(){
        NotificationsAM am = getNotificationsAM();
        int noOfRowsDeleted = am.deleteAllIshiftNotifications();
        return Response.ok(noOfRowsDeleted).build();
    }
    
    @GET
    @Path("/prefs")
    public Response getNotificationsPreferences(){
        List<String> userPreferences = new ArrayList<String>();
//        StoreMDS mds = StoreMDS.getInstance();
        ArrayList<String> preferences = null;
        List<NotificationSetting> notificationSettings = new ArrayList<NotificationSetting>();
        
        NotificationsAM am = getNotificationsAM();
        NotificationPreferenceDTO dto = am.getNotificationPreferences();
        
        
        
//        try {
//            preferences = mds.getNotificationsPreferences(ADFContext.getCurrent().getSecurityContext().getUserName());
//        } catch (IOException e) {
//            logger.severe(e);
//            throw new BadRequestException(e);
//        }
//        if(preferences != null){
//        for(String preference:preferences){
//            if(preference != null && preference.contains("userPreferences")){
//              userPreferences.add(preference.substring((preference.lastIndexOf("\"")+1),preference.length()));
//            }else if (preference != null && preference.contains("\"}")){
//                userPreferences.add(preference.substring(0,(preference.lastIndexOf("\""))));
//            }else{
//                userPreferences.add(preference);
//            }
//        }
//        }
//        if(userPreferences != null){
//            for(int i=0;i<7;i++){
//                String index=Integer.toString(i+1);
//                NotificationSetting notificationSetting = new  NotificationSetting();
//                if(userPreferences.contains(index)){
//                  
//                    notificationSetting.setName(index);
//                    notificationSetting.setValue(true);
//                }else{
//                  
//                    notificationSetting.setName("0");
//                    notificationSetting.setValue(false);
//                }
//                notificationSettings.add(notificationSetting);
//            }
//        }
        //NotificationSetting[] ret=notificationSettings.toArray(new NotificationSetting[notificationSettings.size()]);
        //return Response.ok(ret).build();
        return Response.ok(dto).build();
        
    }
    
    @POST
    @Path("/saveprefs")
    public Response saveNotificationPreferences(NotificationPreferenceDTO dto){
//        StoreMDS mds = StoreMDS.getInstance();
//        ArrayList<String> userPreferenceList=new ArrayList<String>();
//        List<String> userPreferencesTemp = new ArrayList<String>();
//        if(userPreferences != null && !userPreferences.isEmpty()){
//            String[] userNotiPreferences = userPreferences.split(",");
//            for(String preference:userNotiPreferences){
//                if(preference != null && preference.contains("userPreferences")){
//                  userPreferencesTemp.add(preference.substring((preference.lastIndexOf("\"")+1),preference.length()));
//                }else if (preference != null && preference.contains("\"}")){
//                    userPreferencesTemp.add(preference.substring(0,(preference.lastIndexOf("\""))));
//                }else{
//                    userPreferencesTemp.add(preference);
//                }
//            }
//            for(String userNotiPrefence:userPreferencesTemp){
//                if(userNotiPrefence != null && !userNotiPrefence.isEmpty() && !userNotiPrefence.equalsIgnoreCase("0")){
//                    userPreferenceList.add(userNotiPrefence);
//                }
//                
//            }
//        }
//        MdsStoreObject ret = null;
//        try {
//            ret = mds.storeInMDS(ADFContext.getCurrent().getSecurityContext().getUserName(), 0, userPreferenceList, null);
//        } catch (IOException e) {
//            logger.severe(e);
//            throw new BadRequestException(e);
//        } catch (ParserConfigurationException e) {
//            logger.severe(e);
//            throw new BadRequestException(e);
//        } catch (SAXException e) {
//            logger.severe(e);
//            throw new BadRequestException(e);            
//        } catch (ClassNotFoundException e) {
//            logger.severe(e);
//            throw new BadRequestException(e);    
//        }
        //return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
        NotificationsAM am = getNotificationsAM();
        Long prefId = am.saveNotificationPreference(dto);
        return Response.ok(prefId).build();
    }
    
    @GET
    @Path("/count")
    public Response getNotificationsCount(){
        NotificationsAM am = getNotificationsAM();
        Long count = am.getNotificationsCount();
        return Response.ok(count).build();
        
//        StoreMDS mds = StoreMDS.getInstance();
//        int count = -1;
//        try {
//            count = mds.getMessageCount(ADFContext.getCurrent().getSecurityContext().getUserName());
//        } catch (IOException e) {
//            logger.severe(e);
//            throw new BadRequestException(e);
//        }
//        return Response.ok(count).type(MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("/ishiftCount")
    public Response getIshiftNotificationsCount(){
        Long count = 0L;
        Response response = null;
        String isMessageCountCacheDisabled = KrowdUtility.getInstance().getProperties().getProperty("NOTIFICATION_UNREAD_COUNT_CACHE_DISABLED");
        if(isMessageCountCacheDisabled == null || isMessageCountCacheDisabled.equalsIgnoreCase("FALSE")) {
            Cache cache = CacheUtil.getInstance().getCache(CacheUtil.CacheType.NOTIFICATION_COUNT_CACHE);
            String userName = ADFContext.getCurrent().getSecurityContext().getUserName();
            Object cacheEntry = cache.get(userName);
            if(cacheEntry == null){
                count = _getiShiftNotificationCountIntern();
                cache.put(userName, count);
                response = Response.ok(count).type(MediaType.APPLICATION_JSON).build();
            } else {
                count = (Long)cacheEntry;
                response = Response.ok(count).header("Cache-COH-Entry", "true")
                    .type(MediaType.APPLICATION_JSON).build();
            }
        } else {
            count = _getiShiftNotificationCountIntern();
            response = Response.ok(count).type(MediaType.APPLICATION_JSON).build();
        }
        return response;
    }
    
    private Long _getiShiftNotificationCountIntern(){
        NotificationsAM am = getNotificationsAM();
        Long count = am.getIShiftNotificationsCount();
        return count;
    }
    
    private String generatePhotoURI(String guid, String size) {
        String encodedGuid = null;
        if (guid != null)
            encodedGuid = ProfileInternalUtils.asciiToHex(guid);

        StringBuilder uriBuilder =
            new StringBuilder(64).append("/").append("webcenter").append("/").append("profilephoto").append("/").append(encodedGuid).append('/').append(size);
        String photoUID = "xxxxxxx";
        try {
            UserProfileManager profileManager =
                ProfileFactory.getProfileManager();
            WCUserProfile profile = profileManager.getProfileByGUID(guid);
            photoUID = profile.getPhotoUID();
        } catch (Exception e) {
            logger.severe(e);
        }

        uriBuilder.append('/').append(photoUID);
        uriBuilder.append("?_xResourceMethod=wsrp");
        return uriBuilder.toString();
    }
    
    @GET
    @Path("/migrate")
    public Response migrateEvents(@DefaultValue("01-SEP-2016 00:00:00") @QueryParam("fromDate") String fromDate,@DefaultValue("02-SEP-2016 00:00:00") @QueryParam("toDate") String toDate, 
                                  @DefaultValue("false") @QueryParam("isJms") Boolean isJms){
        String[] roles =ADFContext.getCurrent().getSecurityContext().getUserRoles();
        boolean isAdmin = false;
        boolean status = false;
        Date startTime = new Date();
        Date endTime = null;
        for(String role:roles){
            if(role.equalsIgnoreCase("Administrator")){
                isAdmin = true;
                break;
            }
        }
        if(isAdmin){
            NotificationsAM am = getNotificationsAM();
            status = am.migrateBusinessEvent(fromDate, toDate, isJms);
            endTime = new Date();
            logger.severe("START AND END TIME OF MIGRATION:"+startTime.toString()+"#####"+endTime.toString());
        }
        return Response.ok(status).build();
    }
    
    
    //=========================================================================================================
    /**
     * accepts a complex object 
     * @return
     */
    @POST
    @Path("/registerDevice")
    public Response registerDevice(DeviceDTO deviceDTO){
        logger.info("------------"+ deviceDTO);
        NotificationsAM am = getNotificationsAM();
        String ret = am.registerDevice(deviceDTO);
        logger.info("--------Device Registered--");
        return Response.ok(ret).build();
    }
    
    /**
     * accepts a complex object 
     * @return
     */
    @POST
    @Path("/unRegisterDevice")
    public Response unRegisterDevice(DeviceDTO deviceDTO){
        NotificationsAM am = getNotificationsAM();
        String ret = am.unregisterDevice(deviceDTO);
        return Response.ok(ret).build();
    }
    
//    @POST
//    @Path("/optIn")
//    @Consumes({"application/json","application/xml"})
//    public Response Optin(SubscribePartyRequestType requestType)throws Exception{
//        Response response = null;       
//        if(requestType != null){
//                DeviceDTO dto;
//            try {
//                dto = OptInRequestUtil.transformSubscribePartyRequest(requestType);
//                response = registerDevice(dto);
//            } catch (Exception e) {
//                throw e;
//            }
//            
//        }
//        
//        return Response.ok(true).build();
//    }
    
    @POST
    @Path("/optIn")
    @Consumes({"application/json"})
    public Response Optin(SOARegistrationSchema requestType)throws Exception{
        Response response = null;       
        if(requestType != null){
            try {
                //construct DTO
                DeviceDTO dto = new DeviceDTO();
                
                Source source = requestType.getHeader().getSource();
                AppInfo appInfo = new AppInfo();
                appInfo.setAppName(source.getSystem());
                appInfo.setAppVersion(source.getVersion());
                appInfo.setAppSubVersion(source.getBundleID());
                
                SourceIDs sourceIDs = requestType.getSourceIDs();
                List<SourceID> sIds = sourceIDs.getSourceID();
                String userName = null;
                if(sIds == null || sIds.size() == 0){
                    throw new Exception("No User Information in SourceIDs.");
                }else{
                    userName = sIds.get(0).getId();
                }
                UserInfo userInfo = new UserInfo();
                userInfo.setUserName(userName);
                
                Device device = new Device();
                com.darden.krowd.portal.notification.rest.schema.Device sourceDevice = requestType.getHeader().getSource().getDevice();
                device.setPlatform(sourceDevice.getPlatform());
                device.setVersion(sourceDevice.getVersion());
                device.setUuId(sourceDevice.getUuid());
                device.setManufacturer(sourceDevice.getManufacturer());
                device.setModel(sourceDevice.getModel());
                
                PushInfo pushInfo = new PushInfo();
                
                SubscriptionChannel channel = requestType.getSubscriptionChannel();
                if(channel.getChannel() != null && channel.getChannel().equalsIgnoreCase("PUSH")){
                    if(channel.getToken() != null){
                        pushInfo.setToken(channel.getToken());
                    }
                }
                
                //preferences
                UserPreferenceDTO[] prefDTOs = null;
                if(requestType.getSubscriptionChannel().getSignupChannels() != null){
                    List<SignupChannel> signupChannels = requestType.getSubscriptionChannel().getSignupChannels().getSignupChannel();
                    if(signupChannels != null && signupChannels.size() > 0){
                        prefDTOs = new UserPreferenceDTO[signupChannels.size()];
                        int index = 0;
                        for(SignupChannel ch : signupChannels){
                            UserPreferenceDTO prefDto = new UserPreferenceDTO();
                            prefDto.setPrefType(ch.getTopic());
                            prefDto.setPrefSubType(ch.getSubtopic());
                            prefDto.setPrefValue(ch.getState());
                            prefDTOs[index++] = prefDto;
                        }
                        dto.setPrefs(prefDTOs);
                    }
                }
                
                
                dto.setAppInfo(appInfo);
                dto.setUserInfo(userInfo);
                dto.setDevice(device);
                dto.setPushInfo(pushInfo);

                response = registerDevice(dto);
                
            } catch (Exception e) {
                throw e;
            }
            
        }
        
        return response;
    }
        
    @POST
    @Path("/sendTestNotification")
    public Response sendTestNotification(KrowdBusinessObjectEvent boe){
        KrowdQueueSender sender;
        boolean success = false;
        if(boe == null){
            throw new BadRequestException("Invalid BusinessObjectEvent.");
        }else{
            try {
                sender = new KrowdQueueSender();
                sender.sendInternalEvent(boe);
                success = true;
            } catch (NamingException e) {
                e.printStackTrace();
                throw new BadRequestException(e.getMessage());
            } catch (JMSException e) {
                e.printStackTrace();
                throw new BadRequestException(e.getMessage());
            }    
        }
        
        return Response.ok(success).build();
    }
    
    @POST
    @Path("/sendMyShiftNotification")
    public Response sendMyShiftNotification(SendNotificationEventRequestType req){
        if(req == null){
            throw new BadRequestException("Invalid BusinessObjectEvent.");
        }else{
            NotificationUtil util = new NotificationUtil();
            KrowdBusinessObjectEvent boe = util.convertEboEventToBusinessObjectEvent(req);
            return sendTestNotification(boe);
        }
    }
    
    @POST
    @Path("/testJsonPayload")
    @Consumes("application/json")
    public Response testPayload(Object o){
        ObjectMapper mapper = new ObjectMapper();
        StringBuffer buf = new StringBuffer();
        try {
            String s= mapper.writeValueAsString(o);
            logger.severe("Test JSON Payload: "+s);
            buf.append(s);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Response.ok(buf).build();
    }
    
    @POST
    @Path("/push")
    @Consumes("application/json")
    public Response pushNotification(KrowdBusinessObjectEvent boe){
        NotificationsAM am = getNotificationsAM();
        am.pushNotifications(boe);
        return Response.ok("{}").build();
    }
    
    @POST
    @Path("/updateUserLocalePref/{locale}")
    @Consumes("application/json")
    public Response updateUserPreference(@PathParam("locale") String locale,
                                         @QueryParam("userId") String userId){
        if(userId == null){
            userId = ADFContext.getCurrent().getSecurityContext().getUserName();
        }
        KrowdBusinessObjectEvent boe = new KrowdBusinessObjectEvent();
        boe.setAppId("KROWD");
        boe.setEventName("KROWD_LOCALE_CHANGE");
        KrowdActor primaryAct = new KrowdActor();
        primaryAct.setId(userId);
        boe.setPrimaryActor(primaryAct);
        List<KrowdActor> secActors = new ArrayList<KrowdActor>();
        boe.addSecondaryActors(secActors);
        
        KrowdCustomProperty prop = new KrowdCustomProperty();
        prop.setName("locale");
        prop.setValue(locale);
        
        List<KrowdCustomProperty> props = new ArrayList<KrowdCustomProperty>();
        props.add(prop);
        
        boe.setCustomProperties(props);

        try {
            KrowdQueueSender sender = new KrowdQueueSender();
            sender.sendExternalEvent(boe);   
            sender.close();
        } catch (NamingException e) {
            e.printStackTrace();
        } catch (JMSException e) {
            e.printStackTrace();
        }
        return Response.ok("{\"message\": \"ok\"}").build();
    }
   
    
    ////////////////////////////////////////////////////////////////////////////
    
    @POST
    @Path("/testMsgNotification")
    @Consumes("text/html")
    public Response testMsgNotification(){
        NotificationsAM am = getNotificationsAM();
        KrowdBusinessObjectEvent boe = getDummyMessageNotificationBOE();
        am.pushNotifications(boe);
        return Response.ok("ok").build();
    }
    
    /**
     *Tests internal queue path
     * @param text
     * @return
     */
    @POST
    @Path("/testIShiftPayload")
    @Consumes("text/html")
    public Response saveTestIShiftXMLPayload(String text){
        KrowdBusinessObjectEvent boe;
        String exceptionMsg = null;
        try {
            boe = new SoaEBOToBusinessObjectConverter().convert(text);
            NotificationsAM am = getNotificationsAM();
            am.saveBusinessObjectEvent(boe);
        } catch (JAXBException e) {
            e.printStackTrace();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return Response.ok("ok").build();
    }
    
    /**
     *Tests external queue path 
     * after the message arrives from ishift from external SOA Topic
     * @param text
     * @return
     */
    @POST
    @Path("/testIShiftPayloadExt")
    @Consumes("text/html")
    public Response saveTestIShiftXMLPayloadExt(String text){
        KrowdBusinessObjectEvent boe;
        String exceptionMsg = null;
        try {
            boe = new SoaEBOToBusinessObjectConverter().convert(text);
            KrowdQueueSender sender = null;
            sender = new KrowdQueueSender();
            sender.sendExternalEvent(boe);   
            sender.close();
            System.out.println("------------Event successfully Sent");
        } catch (JAXBException e) {
            e.printStackTrace();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (NamingException e) {
            e.printStackTrace();
        } catch (JMSException e) {
            e.printStackTrace();
        }
        return Response.ok("ok").build();
    }    
    
    
    @POST
    @Path("/testIShiftNotification")
    @Consumes("text/html")
    public Response testDummyNotification(){
        NotificationsAM am = getNotificationsAM();
        KrowdBusinessObjectEvent boe = getDummyMessagingBOE();//getDummyNotificationBOE();
        am.saveBusinessObjectEvent(boe);
        return Response.ok("ok").build();
    }
    
    @PUT
    @Path("/badgeCount")
    public Response updateBadgeCount(BadgeCount badgeObject){
        //TODO: Validate
        String userName = ADFContext.getCurrent().getSecurityContext().getUserName();
        NotificationDAO dao = new NotificationDAO();
        Map<String, BadgeCount> bcObj = new HashMap<String, BadgeCount>();
        bcObj.put(userName, badgeObject);
        bcObj = dao.updateBadgeCount(bcObj);
        return Response.ok("{\"message\":\"ok\"}").build();
    }
    
    private KrowdBusinessObjectEvent getDummyMessageNotificationBOE() {
        KrowdBusinessObjectEvent boe = new KrowdBusinessObjectEvent();
        boe.setAppId("KROWD");
        boe.setEventName("KROWD_MESSAGING");
        boe.setMessage("Sample messaging text");
        KrowdActor sender = new KrowdActor();
        sender.setId("gsdsmm2");
        sender.setName("Shidharth Mishra");
        
        boe.setPrimaryActor(sender);
        
        KrowdActor recipient = new KrowdActor();
        recipient.setId("880111319t");
        recipient.setName("Test Angel");
        List<KrowdActor> secActors = new ArrayList<KrowdActor>();
        secActors.add(recipient);
        boe.addSecondaryActors(secActors);
        
        return boe;
        
    }
    
    private KrowdBusinessObjectEvent getDummyMessagingBOE() {
        KrowdBusinessObjectEvent boe = new KrowdBusinessObjectEvent();
        boe.addSecondaryActors(new ArrayList<KrowdActor>());
        boe.addSecondaryObjects(new ArrayList<KrowdBusinessObject>());
        boe.setAppId("KROWD");
        boe.setEventId("877erre01-ererer-97fwsefuerwe-889889");
        boe.setEventName("KROWD_MESSAGING");
        boe.setMessage("");
        
        KrowdActor primaryActor = new KrowdActor();
        primaryActor.setId("880995094t");
        primaryActor.setEmail("test@bish.com");
        boe.setPrimaryActor(primaryActor);
        
        KrowdActor secondaryActor = new KrowdActor();
        secondaryActor.setId("880111319t");
        secondaryActor.setEmail("test@guillen.com");
        boe.getSecondaryActors().add(secondaryActor);
        
        return boe;
    }
    
    private KrowdBusinessObjectEvent getDummyNotificationBOE(){
        KrowdBusinessObjectEvent boe = new KrowdBusinessObjectEvent();
        boe.addSecondaryActors(new ArrayList<KrowdActor>());
        boe.addSecondaryObjects(new ArrayList<KrowdBusinessObject>());
        boe.setAppId("KROWD");
        boe.setEventId("877erre01-ererer-97fwsefuerwe-889889");
        boe.setEventName("KROWD_MESSAGING");
        boe.setMessage("");
        
        KrowdActor primaryActor = new KrowdActor();
        primaryActor.setId("880995094t");
        primaryActor.setEmail("test@bish.com");
        boe.setPrimaryActor(primaryActor);
        
        KrowdActor secondaryActor = new KrowdActor();
        secondaryActor.setId("880111319t");
        secondaryActor.setEmail("test@guillen.com");
        boe.getSecondaryActors().add(secondaryActor);
        
        KrowdBusinessObject requestObject = getRequestObject();
        KrowdBusinessObject primaryShiftObj = getShiftObject("1213233", "880995094");
        KrowdBusinessObject shiftObject = getShiftObject("1234332", "880012319");
        
        boe.setPrimaryObject(primaryShiftObj);
        
        List<KrowdBusinessObject> secondaryObjects = new ArrayList<KrowdBusinessObject> ();
        secondaryObjects.add(requestObject);
        secondaryObjects.add(shiftObject);
        boe.addSecondaryObjects(secondaryObjects);
        
        List<KrowdActor> actors = new ArrayList<KrowdActor>();
        actors.add(secondaryActor);
        boe.addSecondaryActors(actors);
        
        return boe;
    }
    
    private KrowdBusinessObject getRequestObject(){
        KrowdBusinessObject bo = new KrowdBusinessObject();
        bo.setType("Request");
        bo.setId("73451273");
        List<KrowdCustomProperty> props = new ArrayList<KrowdCustomProperty>();
        KrowdCustomProperty prop = new KrowdCustomProperty();
        prop.setName("Type");prop.setValue("Post");
        props.add(prop);
        prop = new KrowdCustomProperty();
        prop.setName("Status");prop.setValue("In Process");
        props.add(prop);
        prop = new KrowdCustomProperty();
        prop.setName("isManagerPosted");prop.setValue("false");
        props.add(prop);
        prop = new KrowdCustomProperty();
        prop.setName("isPriority");prop.setValue("false");
        props.add(prop);
        bo.setCustomProperties(props);
        return bo;
    }
    
    private KrowdBusinessObject getShiftObject(String shiftId, String employeeID){
        KrowdBusinessObject bo = new KrowdBusinessObject();
        bo.setType("Shift");
        bo.setId(shiftId);
        List<KrowdCustomProperty> props = new ArrayList<KrowdCustomProperty>();
        KrowdCustomProperty prop = new KrowdCustomProperty();
        prop.setName("StartTime");prop.setValue("4:45 PM");
        props.add(prop);
        prop = new KrowdCustomProperty();
        prop.setName("EndTime");prop.setValue("9:15 PM");
        props.add(prop);
        prop = new KrowdCustomProperty();
        prop.setName("EndTimeDisplay");prop.setValue("9:15 PM DBD");
        props.add(prop);
        prop = new KrowdCustomProperty();
        prop.setName("EmployeeID");prop.setValue(employeeID);
        props.add(prop);
        prop = new KrowdCustomProperty();
        prop.setName("JobClass");prop.setValue("SERVER");
        props.add(prop);
        bo.setCustomProperties(props);
        return bo;
    }
    
    public static void main(String[] a) throws IOException, JsonParseException,
                                               JsonMappingException {
        NotificationResource r = new NotificationResource();
//        KrowdBusinessObjectEvent boe = r.getDummyNotificationBOE();
//        System.out.println(boe);
        ObjectMapper mapper = new ObjectMapper();
        String str = "{\n" + 
        "  \"sourceIDs\" : {\n" + 
        "    \"sourceID\" : [ {\n" + 
        "      \"id\" : \"881609747\",\n" + 
        "      \"source\" : \"AD\"\n" + 
        "    } ]\n" + 
        "  },\n" + 
        "  \"subscriptionChannel\" : {\n" + 
        "    \"state\" : \"true\",\n" + 
        "    \"channel\" : \"PUSH\",\n" + 
        "    \"token\" : \"dummyToken\",\n" + 
        "    \"signupChannels\" : {\n" + 
        "      \"signupChannel\" : [ {\n" + 
        "        \"state\" : {\n" + 
        "          \"State\" : \"true\"\n" + 
        "        },\n" + 
        "        \"topic\" : {\n" + 
        "          \"Topic\" : \"PUSH_NOTIFICATION_OPTIN\"\n" + 
        "        },\n" + 
        "        \"subtopic\" : {\n" + 
        "          \"SubTopic\" : \"ISHIFT\"\n" + 
        "        }\n" + 
        "      } ]\n" + 
        "    }\n" + 
        "  },\n" + 
        "  \"header\" : {\n" + 
        "    \"source\" : {\n" + 
        "      \"device\" : {\n" + 
        "        \"manufacturer\" : \"Manufacturer1662\",\n" + 
        "        \"model\" : \"Model1661\",\n" + 
        "        \"platform\" : \"Platform1658\",\n" + 
        "        \"uuid\" : \"Uuid1660\",\n" + 
        "        \"version\" : \"Version1659\"\n" + 
        "      },\n" + 
        "      \"version\" : \"Version1656\",\n" + 
        "      \"system\" : \"KROWD_MOBILE_APP\",\n" + 
        "      \"bundleID\" : \"BundleID1657\"\n" + 
        "    },\n" + 
        "    \"timestamp\" : \"2017-01-26T10:13:03.579\",\n" + 
        "    \"eventtype\" : \"Employee\"\n" + 
        "  },\n" + 
        "  \"utoken\" : \"FEl2kdPXQf57SbZJ_m0yaOZjEEPU_w**\"\n" + 
        "}\n" + 
        "\n";
        SOARegistrationSchema obj = mapper.readValue(str, SOARegistrationSchema.class);
        System.out.println(obj);
        String payload = "";
    }
    
    
    @GET
    @Path("/messageUserCacheStats")
    @Produces(MediaType.TEXT_HTML)
    public Response getLDapCacheUtilStats(){
        LDAPCacheUtil aPCacheUtil = LDAPCacheUtil.getInstance();
        String ret = aPCacheUtil.dumpMessageUserCacheStats();
        return Response.ok(ret).type(MediaType.TEXT_HTML).build();
    }
    
    @GET
    @Path("/notificationCountCacheStats")
    @Produces(MediaType.TEXT_HTML)
    public Response getNotificationCacheCountStats(){
        Cache notiCountCache = CacheUtil.getInstance().getCache(CacheUtil.CacheType.NOTIFICATION_COUNT_CACHE);
        logger.severe("---------notiCountCache ="+ notiCountCache);
        int ret = notiCountCache.size();
        logger.severe("---------getNotificationCacheCountStats count ="+ ret);
        return Response.ok(ret).type(MediaType.TEXT_HTML).build();
    }  
    
    @GET
    @Path("/notificationCountCacheInvalidate/{userId}")
    @Produces(MediaType.TEXT_HTML)
    public Response clearNotificationCountCache(@PathParam("userId") String userId){
        Long cacheCount = -1L;
        boolean cacheCleared = false;
        if(userId != null){
            try{
                Cache notiCountCache = CacheUtil.getInstance().getCache(CacheUtil.CacheType.NOTIFICATION_COUNT_CACHE);
                cacheCount = (Long)notiCountCache.get(userId);
                notiCountCache.put(userId, null);    
                logger.severe("--------------Msg Count Cache Cleared for user :"+ userId);
                cacheCleared = true;
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        return Response.ok(cacheCount+", cache Cleared="+cacheCleared).type(MediaType.TEXT_HTML).build();
    }
    
    @GET
    @Path("/invalidateNotificationCountCache")
    @Produces(MediaType.TEXT_HTML)
    public Response invalidateNotificationCountCache(){
        int entryCount = -1;
        boolean cacheCleared = false;
        try{
            Cache notiCountCache = CacheUtil.getInstance().getCache(CacheUtil.CacheType.NOTIFICATION_COUNT_CACHE);
            entryCount = notiCountCache.size();
            notiCountCache.clear();
            logger.severe("--------------Msg Count Cache Cleared--------------");
            cacheCleared = true;
        }catch(Exception e){
            e.printStackTrace();
        }
        return Response.ok("cache Cleared="+cacheCleared+", Number of entries cleared="+ entryCount).type(MediaType.TEXT_HTML).build();
    }
}

