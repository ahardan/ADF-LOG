
package com.darden.krowd.portal.notification.rest.schema;

import java.util.HashMap;
import java.util.Map;

public class SOARegistrationSchema {

    private SourceIDs sourceIDs;
    private SubscriptionChannel subscriptionChannel;
    private Header header;
    private String utoken;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public SourceIDs getSourceIDs() {
        return sourceIDs;
    }

    public void setSourceIDs(SourceIDs sourceIDs) {
        this.sourceIDs = sourceIDs;
    }

    public SubscriptionChannel getSubscriptionChannel() {
        return subscriptionChannel;
    }

    public void setSubscriptionChannel(SubscriptionChannel subscriptionChannel) {
        this.subscriptionChannel = subscriptionChannel;
    }

    public Header getHeader() {
        return header;
    }

    public void setHeader(Header header) {
        this.header = header;
    }

    public String getUtoken() {
        return utoken;
    }

    public void setUtoken(String utoken) {
        this.utoken = utoken;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
