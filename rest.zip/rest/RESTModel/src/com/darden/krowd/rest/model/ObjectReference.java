package com.darden.krowd.rest.model;

import java.util.ArrayList;
import java.util.Date;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import oracle.adf.share.logging.ADFLogger;

import oracle.webcenter.activitystreaming.ActivityException;
import oracle.webcenter.activitystreaming.ActivityObject;
import oracle.webcenter.comments.Comment;
import oracle.webcenter.comments.CommentsSummary;
import oracle.webcenter.framework.service.ServiceObjectType;
import oracle.webcenter.jaxrs.framework.model.Linked;
import oracle.webcenter.likes.Like;
import oracle.webcenter.likes.LikesSummary;

@XmlRootElement(name="object")
@XmlType(name="object")
public class ObjectReference extends Linked {
    private static final ADFLogger logger = ADFLogger.createADFLogger(ObjectReference.class);
    private String id;
    private String serviceId;
    private String displayName;
    private String typeDisplayName;
    private String type;
    private String iconUrl;
    private String status;
    private String displayKey;
    private String description;
    private Date createdDate;
    private Date modifiedDate;
    private String createdBy;
    private String modifiedBy;
    private boolean commentingAllowed;
    private boolean likingAllowed;
    private String activityId;
    private String scopeId;
    
    private int commentsCount;
    private int likesCount;
    private List<CommentItem> recentComments;
    private LikeItem myLike;
    
    public ObjectReference() {

    }
    
    public ObjectReference(ActivityObject activityObject){
        this.id=activityObject.getId();
        this.serviceId=activityObject.getServiceID();
        this.displayName=activityObject.getDisplayName();
        this.typeDisplayName = activityObject.getTypeDisplayName();
        this.iconUrl = activityObject.getIconURL();
        this.status=activityObject.getStatus();
        this.displayKey=activityObject.getDisplayKey();
        this.description = activityObject.getDescription();
        this.createdDate = activityObject.getCreateDate();
        this.modifiedDate = activityObject.getModifiedDate();
        this.createdBy = activityObject.getCreatedBy();
        this.modifiedBy = activityObject.getModifiedBy();
        this.commentingAllowed=activityObject.isCommentingAllowed();
        this.likingAllowed=activityObject.isLikingAllowed();
        this.activityId=activityObject.getActivityId();
        this.scopeId=activityObject.getScope()==null?null:activityObject.getScope().getGUID();
        
        ServiceObjectType servObjType;
        try {
            servObjType = activityObject.getType();
            this.type = servObjType==null?null:servObjType.getName();
        } catch (ActivityException e) {
            logger.severe(e);
        }
        
        CommentsSummary commentsSummary = activityObject.getCommentsSummary();
        LikesSummary likesSummary = activityObject.getLikesSummary();        
        
        if(commentsSummary !=null){
            this.commentsCount=commentsSummary.getCount();
            this.recentComments = new ArrayList<CommentItem>();
            for(Comment comment : commentsSummary.getRecentComments()){
                this.recentComments.add(new CommentItem(comment));
            }
        }
        
        if(likesSummary !=null){
            this.likesCount = likesSummary.getCount();
            Like like = likesSummary.getMyLike();
            this.myLike = like==null?null:new LikeItem(like);
        }        
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    public String getServiceId() {
        return serviceId;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setTypeDisplayName(String typeDisplayName) {
        this.typeDisplayName = typeDisplayName;
    }

    public String getTypeDisplayName() {
        return typeDisplayName;
    }

    public void setIconUrl(String iconUrl) {
        this.iconUrl = iconUrl;
    }

    public String getIconUrl() {
        return iconUrl;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setDisplayKey(String displayKey) {
        this.displayKey = displayKey;
    }

    public String getDisplayKey() {
        return displayKey;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setCommentingAllowed(boolean commentingAllowed) {
        this.commentingAllowed = commentingAllowed;
    }

    public boolean isCommentingAllowed() {
        return commentingAllowed;
    }

    public void setLikingAllowed(boolean likingAllowed) {
        this.likingAllowed = likingAllowed;
    }

    public boolean isLikingAllowed() {
        return likingAllowed;
    }

    public void setActivityId(String activityId) {
        this.activityId = activityId;
    }

    public String getActivityId() {
        return activityId;
    }

    public void setScopeId(String scopeId) {
        this.scopeId = scopeId;
    }

    public String getScopeId() {
        return scopeId;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }
}
