package com.darden.krowd.rest.model;

import java.io.Serializable;

import java.util.HashMap;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import oracle.jbo.domain.Number;

@XmlRootElement(name="bookmark")
@XmlType(name="bookmark")
public class Bookmark implements Serializable {
    @SuppressWarnings("compatibility:-8087058093628859104")
    private static final long serialVersionUID = 517188392864871226L;
    private int id;
    private String displayName;
    private String target;
    private boolean mandatory;
    private String url;
    private boolean dfault;
    private boolean favorite;
    private String lang;
    
    //for create
    private String displayNameEn;
    private String displayNameEs;
    private String urlEn;
    private String urlEs;
    private String keywords;
    
    public Bookmark() {
        super();
    }
    
    public Bookmark(HashMap quickLink,String lang) {
        super();
        oracle.jbo.domain.Number qlId = (Number)quickLink.get("QlId");
        oracle.jbo.domain.Number targt = (Number)quickLink.get("Target");
        String mandaT = (String)quickLink.get("IsMandatory");
        String defT = (String)quickLink.get("IsDefault");
        
        this.id=qlId.intValue();        
        this.target=targt==null?"_blank":(targt.intValue()==0?"_blank":"_self");
        this.displayName = (String)quickLink.get("DisplayName");
        
        if(mandaT!=null && mandaT.compareTo("Y")==0)
            this.mandatory=true;

        if(defT!=null && defT.compareTo("Y")==0)
            this.dfault=true;
        
        this.url = (String)quickLink.get("Url");
        this.favorite = this.mandatory;
        this.lang=lang;
    }
    

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }


    public void setUrl(String url) {
        this.url = url;
    }

    public String getUrl() {
        return url;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public String getTarget() {
        return target;
    }

    public void setMandatory(boolean mandatory) {
        this.mandatory = mandatory;
    }

    public boolean isMandatory() {
        return mandatory;
    }

    public void setFavorite(boolean favorite) {
        this.favorite = favorite;
    }

    public boolean isFavorite() {
        return favorite;
    }

    public void setDfault(boolean dfault) {
        this.dfault = dfault;
    }

    public boolean isDfault() {
        return dfault;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }

    public String getLang() {
        return lang;
    }

    public void setDisplayNameEn(String displayNameEn) {
        this.displayNameEn = displayNameEn;
    }

    public String getDisplayNameEn() {
        return displayNameEn;
    }

    public void setDisplayNameEs(String displayNameEs) {
        this.displayNameEs = displayNameEs;
    }

    public String getDisplayNameEs() {
        return displayNameEs;
    }

    public void setUrlEn(String urlEn) {
        this.urlEn = urlEn;
    }

    public String getUrlEn() {
        return urlEn;
    }

    public void setUrlEs(String urlEs) {
        this.urlEs = urlEs;
    }

    public String getUrlEs() {
        return urlEs;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    public String getKeywords() {
        return keywords;
    }
}
