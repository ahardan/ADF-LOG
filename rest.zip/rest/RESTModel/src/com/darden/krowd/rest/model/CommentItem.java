package com.darden.krowd.rest.model;

import com.darden.krowd.framework.PersonReference;

import java.io.Serializable;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import javax.xml.bind.annotation.XmlType;

import oracle.webcenter.comments.Comment;
import oracle.webcenter.jaxrs.framework.model.Linked;


@XmlRootElement(name="comment")
@XmlType(name="comment")
public class CommentItem extends Linked implements Serializable {
    private static final long serialVersionUID = 1764386271921628605L;
    protected String id;
    protected String text;
    protected Date created;
    protected boolean deletable;
    protected String authorId;
    protected transient  PersonReference author;

    public CommentItem(){
    }

    public CommentItem(Comment comment){
      setId(comment.getId());
      setText(comment.getCommentText());
      setCreated(comment.getCreationDate());
      setAuthorId(comment.getAuthorId());
      setAuthor(PersonReference.GetPersonByGuid(comment.getAuthorId()));
      this.deletable = comment.isDeleteable();
    }
    
    public String resourceType() {
      return "urn:oracle:webcenter:comment";
    }        

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setText(String commentText) {
        this.text = commentText;
    }

    public String getText() {
        return text;
    }

    public void setCreated(Date creationDate) {
        this.created = creationDate;
    }

    public Date getCreated() {
        return created;
    }

    public void setDeletable(boolean isDeletable) {
        this.deletable = isDeletable;
    }
    
    @XmlTransient
    public boolean isDeletable() {
        return deletable;
    }

    public void setAuthorId(String authorId) {
        this.authorId = authorId;
    }

    public String getAuthorId() {
        return authorId;
    }

    public void setAuthor(PersonReference author) {
        this.author = author;
    }

    public PersonReference getAuthor() {
        return author;
    }
}
