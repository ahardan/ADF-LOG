package com.darden.krowd.rest.model;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="address")
@XmlType(name="address")
public class Address {
    String line1;
    String line2;
    String city;
    String state;
    String postalCode;
    String country;
    
    public Address() {
        super();
    }
}
