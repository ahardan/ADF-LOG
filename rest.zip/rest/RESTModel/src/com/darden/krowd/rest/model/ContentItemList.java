package com.darden.krowd.rest.model;

import java.io.Serializable;

import java.util.LinkedList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import oracle.webcenter.jaxrs.framework.model.PaginatedLinked;
import oracle.webcenter.jaxrs.framework.param.StartIndexParam;


@XmlRootElement(name="contents")
@XmlType(name="contents")
public class ContentItemList  extends PaginatedLinked implements Serializable{
    private static final long serialVersionUID = -1712988651190312326L;
    protected List<ContentItem> items;
    
    public ContentItemList() {
    }
    
    public ContentItemList(List<ContentItem> pItems, int startIndex, int totalResults)
    {
      this.items = pItems;
      super.updatePaginationIndices(this.items, new StartIndexParam(String.valueOf(startIndex)));
      if (totalResults >= 0){
        super.setTotalResults(Integer.valueOf(totalResults));
      }
    }    
    
    public ContentItemList(ContentItem pItem){
      this.items = new LinkedList<ContentItem>();
      this.items.add(pItem);
      super.updatePaginationIndices(this.items, new StartIndexParam(String.valueOf(0)));
      super.setTotalResults(Integer.valueOf(1));
    } 
    
    public String resourceType() {
      return "urn:com:darden:krowd.rest.content";
    }    
    
    @XmlElementWrapper(name="items")
    @XmlElement(name="content")
    public List<ContentItem> getItems() {
      return this.items;
    }

    public void setItems(List<ContentItem> pItems)
    {
      this.items = pItems;
    }    
}
