package com.darden.krowd.rest.model;

import com.darden.krowd.framework.PersonReference;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import oracle.webcenter.activitystreaming.ActivityActor;
import oracle.webcenter.activitystreaming.ActivityDisplayElement;
import oracle.webcenter.activitystreaming.ActivityObject;
import oracle.webcenter.activitystreaming.ActivityPermission;
import oracle.webcenter.framework.service.ActivityType;

@XmlRootElement(name="activity")
@XmlType(name="activity")
public class Activity implements Serializable {
    private static final long serialVersionUID = -7388657117420339965L;
    private String id;
    private String message;
    private String displayMessage;
    private String description;
    private String displayDescription;
    private String serviceId;
    private String activityType;
    private String scope;
    private Date createdDate;    
    private String detail;
    private String detailUrl;
    private String activityTypeIconURL;
    
    private Date activityTime;
    private String iconFile;
    private transient  List<PersonReference> actors;
    private transient  List<ObjectReference> objects;
    
    private String permission;

    
    public Activity() {
        super();
    }
    
    public Activity(ActivityDisplayElement _element){
        this.id = _element.getActivityID();
        this.message = _element.getTemplateMessage();
        this.displayMessage = _element.getDisplayMessage();
        this.description = _element.getTemplateDescription();
        this.displayDescription = _element.getDisplayDescription();
        this.serviceId = _element.getServiceId();
        this.scope = _element.getScope().getGUID();        
        
        this.createdDate = _element.getCreateDate();
        this.detail = _element.getDetail();
        this.detailUrl = _element.getDetailURL();
        
        try{
            ActivityType type = _element.getActivityType();
            this.activityType=type.getName();
            this.activityTypeIconURL=type.getIconURL();
        }catch(Exception e){
            this.activityType=null;
            this.activityTypeIconURL=null;
        }
        this.activityTime=_element.getActivityTime();
        
        List<ActivityActor> activityActors = _element.getActors();
        if(activityActors !=null && activityActors.size()>0){
            actors = new ArrayList<PersonReference>();
            for(ActivityActor act : activityActors){
                actors.add(PersonReference.GetPersonByGuid(act.getId()));
            }
        }
        
        List<ActivityObject> activityObjects = _element.getObjects();
        if(activityObjects !=null && activityObjects.size()>0){
            objects=new ArrayList<ObjectReference>();
            for(ActivityObject obj : activityObjects){
                objects.add(new ObjectReference(obj));
            }
        }        
        this.permission = _element.getPermission()==null?ActivityPermission.SHARED.getDisplayName():_element.getPermission().getDisplayName();
        this.iconFile = _element.getIconFile();        
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setDisplayMessage(String displayMessage) {
        this.displayMessage = displayMessage;
    }

    public String getDisplayMessage() {
        return displayMessage;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public void setDisplayDescription(String displayDescription) {
        this.displayDescription = displayDescription;
    }

    public String getDisplayDescription() {
        return displayDescription;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    public String getServiceId() {
        return serviceId;
    }

    public void setActivityType(String activityType) {
        this.activityType = activityType;
    }

    public String getActivityType() {
        return activityType;
    }

    public void setScope(String scope) {
        this.scope = scope;
    }

    public String getScope() {
        return scope;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetailUrl(String detailUrl) {
        this.detailUrl = detailUrl;
    }

    public String getDetailUrl() {
        return detailUrl;
    }

    public void setActivityTypeIconURL(String activityTypeIconURL) {
        this.activityTypeIconURL = activityTypeIconURL;
    }

    public String getActivityTypeIconURL() {
        return activityTypeIconURL;
    }

    public void setActivityTime(Date activityTime) {
        this.activityTime = activityTime;
    }

    public Date getActivityTime() {
        return activityTime;
    }

    public void setIconFile(String iconFile) {
        this.iconFile = iconFile;
    }

    public String getIconFile() {
        return iconFile;
    }

    public void setActors(List<PersonReference> actors) {
        this.actors = actors;
    }

    public List<PersonReference> getActors() {
        return actors;
    }

    public void setObjects(List<ObjectReference> objects) {
        this.objects = objects;
    }

    public List<ObjectReference> getObjects() {
        return objects;
    }

    public void setPermission(String permission) {
        this.permission = permission;
    }

    public String getPermission() {
        return permission;
    }
}
