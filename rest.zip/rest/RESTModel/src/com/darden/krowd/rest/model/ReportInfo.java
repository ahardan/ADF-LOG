package com.darden.krowd.rest.model;

import com.darden.global.enterpriseobjects.core.ebo.worker.v1.ShowEmployeeProfileDataAreaType;
import com.darden.krowd.common.identity.LdapHelper;

import com.darden.krowd.services.employeeprofile.EmployeeProfileFaultMsg;
import com.darden.krowd.services.helper.ServicesHelper;

import java.io.Serializable;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;

import oracle.security.idm.IMException;
import oracle.security.idm.User;
import oracle.security.idm.UserProfile;

import oracle.webcenter.activitystreaming.ActivityActor;
import oracle.webcenter.activitystreaming.ActivityDisplayElement;
import oracle.webcenter.activitystreaming.ActivityException;
import oracle.webcenter.activitystreaming.ActivityObject;
import oracle.webcenter.activitystreaming.ActivityStreamingService;
import oracle.webcenter.activitystreaming.ActivityStreamingServiceFactory;
import oracle.webcenter.comments.Comment;
import oracle.webcenter.comments.CommentsManager;
import oracle.webcenter.comments.CommentsServiceFactory;
import oracle.webcenter.framework.application.FactoryFinder;
import oracle.webcenter.framework.service.Scope;
import oracle.webcenter.framework.service.ServiceObjectType;
import oracle.webcenter.peopleconnections.wall.internal.model.WallServiceUtils;
import oracle.webcenter.spaces.Space;
import oracle.webcenter.spaces.SpacesException;
import oracle.webcenter.spaces.SpacesManager;
import oracle.webcenter.spaces.SpacesManagerFactory;
import oracle.webcenter.spaces.metadata.GSMetadata;

@XmlRootElement(name="reportInfo")
@XmlType(name="reportInfo")
public class ReportInfo implements Serializable{
    private static final ADFLogger logger = ADFLogger.createADFLogger(ReportInfo.class);
    private static final long serialVersionUID = -2338828828763213693L;
    private String activityId;    
    private String message;
    private String myId;
    private String authorId;
    
    private String commentId;
    private String serviceId;
    private String objectType;
    private String objectId;

    @XmlTransient     
    transient private UserProfile authorProfile;
    @XmlTransient 
    transient private UserProfile myProfile;
    
    private String myBrand;
    private String myTitle;
    private String myLocation;
    private String myName;
    private String myEmployeeId;
    private String myDisplayName;
    private String myJobFunction;
    private String mySubFunction;
    
    private String authorBrand;
    private String authorTitle;
    private String authorLocation;
    private String authorName;
    private String authorEmployeeId;
    private String authorDisplayName;
    private String authorJobFunction;
    private String authorSubFunction;
    private String reportURL;
    
    @XmlTransient 
    transient private UserProfile authorManagerProfile;
    
    @XmlTransient 
    transient private ActivityDisplayElement activityElement;

    @XmlTransient 
    transient private Comment comment;
    
    private String type;
    
    public ReportInfo() {
        super();
    }
    
    private ActivityObject createActivityObject(String serviceId, String objectType, String objectId)
    {
      ActivityObject obj = null;
      try {
        ActivityStreamingService as = ActivityStreamingServiceFactory.getInstance().getActivityStreamingService();
        ServiceObjectType serviceObjType = as.findObjectType(serviceId, objectType);
        obj = as.createObject(objectId, serviceObjType, objectId);
        obj.setServiceID(serviceId);
      } catch (ActivityException e) {
        logger.warning(e);
        e.printStackTrace();
      }
      return obj;
    }     
    
    public void process() throws Exception {
        if(this.activityId !=null){
            this.type="ACTIVITY";
            processActivity();
        }
        
        if(this.commentId !=null && this.serviceId !=null && this.objectType !=null && this.objectId !=null){
            this.type="COMMENT";
            processComment();
        }
    }
    
    private void processComment()  throws Exception{
        CommentsManager commentsManager = CommentsServiceFactory.getInstance().getCommentsManager();
        ActivityObject activityObject = createActivityObject(serviceId, objectType, objectId);
        List<Comment> comments = commentsManager.getComments(activityObject,null);        
        if(comments != null){
            for(Comment commItm : comments){
                if(commItm.getId().compareTo(this.commentId)==0){
                    comment = commItm;
                    break;
                }
            }
        }
        
        if(comment != null){
            //Comment Identified
            logger.info("Comment Found "+comment.toString());
            authorId = comment.getAuthorId();                        
            myId = ADFContext.getCurrent().getSecurityContext().getUserName();                        
            myProfile = LdapHelper.getInstance().getUser(myId).getUserProfile();
            authorId =WallServiceUtils.userGuidToName(authorId);
            authorProfile = LdapHelper.getInstance().getUser(authorId).getUserProfile();            
        }
        
    }
    
    private void processActivity() throws Exception{
        ActivityStreamingServiceFactory factory = ActivityStreamingServiceFactory.getInstance();
        ActivityStreamingService activityService = factory.getActivityStreamingService();
        if(this.activityId != null){
            try{
                activityElement = activityService.findActivity(null,activityId);
                if(activityElement != null){
                    List<ActivityActor> actors = activityElement.getActors();
                    if(actors == null || actors.isEmpty()){
                        throw new Exception("Cannot find any actors for activity with ID "+activityId);
                    }else{
                        ActivityActor primaryActor = actors.get(0);//primaryActor
                        authorId = primaryActor.getId();                        
                        myId = ADFContext.getCurrent().getSecurityContext().getUserName();                        
                        myProfile = LdapHelper.getInstance().getUser(myId).getUserProfile();
                        authorId =WallServiceUtils.userGuidToName(authorId);
                        authorProfile = LdapHelper.getInstance().getUser(authorId).getUserProfile();
                    }
                }else{
                    logger.info("Cannot find activity with ID : "+activityId);
                    throw new Exception("Cannot find activity with ID : "+activityId);                    
                }
            }catch(Exception e){
               logger.severe(e);
               throw e;
            }            
        }        
    }

    public void setActivityId(String activityId) {
        this.activityId = activityId;
    }

    public String getActivityId() {
        return activityId;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public UserProfile getAuthorProfile() {
        return this.authorProfile;
    }

    public String getAuthorId() {
        return authorId;
    }

    public String getMyId() {
        return myId;
    }

    public UserProfile getMyProfile() {
        return myProfile;
    }

    public UserProfile getAuthorManagerProfile() {
        return authorManagerProfile;
    }

    public String getMyBrand() {
        this.myBrand = getProfileAttributeVal(myProfile,"company","Darden-Business-Unit");
        return myBrand;
    }

    public String getMyTitle() {
        this.myTitle =getProfileAttributeVal(myProfile,"Title");
        return myTitle;
    }

    public String getMyLocation() {
        this.myLocation = getProfileAttributeVal(myProfile,"physicalDeliveryOfficeName");
        return myLocation;
    }

    public String getMyName() {
        try {
            myName = myProfile==null?null:myProfile.getName();
        } catch (IMException e) {
            logger.severe(e);
        }
        return myName;
    }

    public String getMyEmployeeId() {
        myEmployeeId = getProfileAttributeVal(myProfile,"Darden-Empl-ID");
        return myEmployeeId;
    }

    public String getMyDisplayName() {
        try {
            myDisplayName = myProfile==null?null:myProfile.getDisplayName();
        } catch (IMException e) {
        }
        return myDisplayName;
    }

    public String getMyJobFunction() {
        myJobFunction = getProfileAttributeVal(myProfile,"Darden-Job-Function");
        return myJobFunction;
    }

    public String getMySubFunction() {
        mySubFunction = getProfileAttributeVal(myProfile,"Darden-Sub-Function");
        return mySubFunction;
    }

    public String getAuthorBrand() {
        this.authorBrand = getProfileAttributeVal(authorProfile,"company","Darden-Business-Unit");
        return authorBrand;
    }

    public String getAuthorTitle() {
        this.authorTitle = getProfileAttributeVal(authorProfile,"Title");
        return authorTitle;
    }

    public String getAuthorLocation() {
        this.authorLocation = getProfileAttributeVal(authorProfile,"physicalDeliveryOfficeName");
        return authorLocation;
    }

    public String getAuthorName() {
        try {
            authorName = authorProfile==null?null:authorProfile.getName();
        } catch (IMException e) {
            logger.severe(e);
        }
        return authorName;
    }

    public String getAuthorEmployeeId() {
        authorEmployeeId = getProfileAttributeVal(authorProfile,"Darden-Empl-ID");
        return authorEmployeeId;
    }

    public String getAuthorDisplayName() {
        try {
            authorDisplayName = authorProfile==null?null:authorProfile.getDisplayName();
        } catch (IMException e) {
            logger.severe(e);
        }
        return authorDisplayName;
    }

    public String getAuthorJobFunction() {
        authorJobFunction = getProfileAttributeVal(authorProfile,"Darden-Job-Function");
        return authorJobFunction;
    }

    public String getAuthorSubFunction() {
        authorSubFunction = getProfileAttributeVal(authorProfile,"Darden-Sub-Function");
        return authorSubFunction;
    }
    
    private String getProfileAttributeVal(UserProfile profile,String... attributes){
        Object obj;
        String returnVal = null;
        
        if(profile == null)
            return null;
        
        for(String attribute:attributes){
            try {
                obj = profile.getPropertyVal(attribute);
                if(obj != null){
                    returnVal = obj.toString();
                    break;
                }
            } catch (IMException e) {
                logger.severe(e);
            }
        }
        return returnVal;
    } 
    
    public String getAuthorManagerEmail(){
        if(this.authorManagerProfile !=null){
            return getProfileAttributeVal(authorManagerProfile,"mail");
        }else{
            if(this.authorId !=null){
                ServicesHelper sevHelper = new ServicesHelper();
                try {
                    ShowEmployeeProfileDataAreaType authorProfInfo = sevHelper.getUserProfile(this.authorId);
                    String managerId = null;
                    managerId = authorProfInfo.getShowEmployeeProfileResponse().getEmployeeProfileDetails().getWorkerEmployment().get(0).getEmploymentTerm().get(0).getEmploymentAssignment().get(0).getEmploymentAssignmentSupervision().get(0).getReportsToID().getValue();
                    String managerSamName = LdapHelper.getInstance().getSAMAccountName(managerId);
                    User manager = LdapHelper.getInstance().getUser(managerSamName);
                    this.authorManagerProfile = manager.getUserProfile();
                    return getProfileAttributeVal(authorManagerProfile,"mail");
                } catch (Exception e) {
                    logger.severe(e);
                    return null;
                }                
            }else{
                return null;
            }
        }
    }

    public ActivityDisplayElement getActivityElement() {
        return activityElement;
    }
    
    public GSMetadata getGroupSpace(){
        Scope scope = getActivityElement().getScope();        
        if(scope != null && !scope.isDefault()){
            SpacesManager spacesManager  = ((SpacesManagerFactory)FactoryFinder.getFactory(SpacesManagerFactory.class.getName())).getSpacesManager();
            Space space;
            try {
                space = spacesManager.getSpaceByScopeGUID(scope.getGUID());
                return space==null?null:space.getGSMetadata();
            } catch (SpacesException e) {
                logger.severe(e);
                return null;
            }
        }else{
            return null;
        }
    }

    public void setCommentId(String commentId) {
        this.commentId = commentId;
    }

    public String getCommentId() {
        return commentId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    public String getServiceId() {
        return serviceId;
    }

    public void setObjectType(String objectType) {
        this.objectType = objectType;
    }

    public String getObjectType() {
        return objectType;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }

    public String getObjectId() {
        return objectId;
    }

    public Comment getComment() {
        return comment;
    }

    public String getType() {
        return type;
    }

    public void setReportURL(String reportURL) {
        this.reportURL = reportURL;
    }

    public String getReportURL() {
        return reportURL;
    }
}
