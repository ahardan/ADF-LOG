package com.darden.krowd.rest.model;

// Copyright 2009-2013 Oracle Corporation.
// All Rights Reserved.
//
// Provided on an 'as is' basis, without warranties or conditions of any kind,
// either express or implied, including, without limitation, any warranties or
// conditions of title, non-infringement, merchantability, or fitness for a
// particular purpose. You are solely responsible for determining the
// appropriateness of using and assume any risks. You may not redistribute.
//
// Please refer to http://redstack.wordpress.com/worklist for details.

import java.io.Serializable;
import java.io.StringWriter;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import oracle.adf.share.logging.ADFLogger;

import oracle.bpel.services.workflow.task.model.ActionType;
import oracle.bpel.services.workflow.task.model.AttachmentType;
import oracle.bpel.services.workflow.task.model.CommentType;
import oracle.bpel.services.workflow.task.model.Task;

import org.codehaus.jackson.annotate.JsonIgnore;

import org.w3c.dom.Element;
import org.w3c.dom.NodeList;


/**
    A wrapper around <code>oracle.bpel.services.workflow.task.model.Task</code> that provides
    convenience methods to simplify view development.
    This class provides convenience methods to simplify the development of, and reduce code
    clutter in, the JSP/JSTL views in this application.
 */
@XmlRootElement(name = "task")
@XmlType(name = "task")
public class MTask implements Serializable {
    private static final ADFLogger logger = ADFLogger.createADFLogger(MTask.class);
    private static final long serialVersionUID = 8428087490977499444L;

    private int number;
    private String id;
    private String title;
    private String state;
    private String outcome;
    private int priority;

    private List<MTaskComment> comments;
    private List<MTaskAttachment> attachments;
    private List<MTaskAction> systemActions;
    private List<MTaskAction> customActions;
    private List payload;

    private String creator;
    private String acquirer;
    private Date createDate;
    private Date expiryDate;
    private Date updateDate;

    private List<String> htmlPayload;

    public MTask() {
    }

    /**
      This constructor is used to create a simple representation of a <code>Task</code>.
      The simple representation does not have all data populated and is intended to be used
      to build task lists, where we do not want the overhead of populating all of the data.
      @param number The task number.
      @param id The task ID.
      @param title The title of the task.
      @param state The status of the task.
      @param outcome The outcome of the task.
      @param priority The task's priority.
     */
    public MTask(int number, String id, String title, String outcome,
                 int priority, String state) {
        this.number = number;
        this.id = id;
        this.title = title;
        this.state = state;
        this.outcome = outcome;
        this.priority = priority;
    }

    /**
       This constructor is used to create a fully populated representation of a <code>Task</code>.
       The fully populated representation is intended to be used to build task detail pages, where
       all of the data for a task is wanted.  You should not use this constructor if you are not
       planning to use all of the data.  Use a simpler constructor instead.
       @param task The <code>Task</code> that you want to wrap.
     */
    public MTask(Task task) {
        this.number = task.getSystemAttributes().getTaskNumber();
        this.id = task.getSystemAttributes().getTaskId();
        this.title = task.getTitle();
        this.state = task.getSystemAttributes().getState();
        this.outcome = task.getSystemAttributes().getOutcome();
        this.priority = task.getPriority();
        
        List comms = task.getUserComment();
        if(comms !=null){            
            this.comments = new ArrayList<MTaskComment>();
            for(int i=0 ; i<=comms.size();i++){
                if(comms.get(i) !=null && comms.get(i) instanceof CommentType){
                    this.comments.add(new MTaskComment((CommentType)comms.get(i)));
                }
            }
        }
        
        List attcs = task.getAttachment();
        if(attcs !=null){            
            this.attachments = new ArrayList<MTaskAttachment>();
            for(int i=0 ; i<=attcs.size();i++){
                if(attcs.get(i) !=null && attcs.get(i) instanceof AttachmentType){
                    this.attachments.add(new MTaskAttachment((AttachmentType)attcs.get(i)));
                }
            }
        }        
        
        
        List sacts = task.getSystemAttributes().getSystemActions();
        if(sacts !=null){
            this.systemActions= new ArrayList<MTaskAction>();
            for(int i=0;i<=sacts.size();i++){
                if(sacts.get(i) !=null && sacts.get(i) instanceof ActionType){
                    this.systemActions.add(new MTaskAction((ActionType)sacts.get(i)));
                }                
            }
        }
        
        List cacts = task.getSystemAttributes().getCustomActions();
        if(cacts !=null){
            this.customActions= new ArrayList<MTaskAction>();
            for(int i=0;i<=cacts.size();i++){
                if(cacts.get(i) !=null && cacts.get(i) instanceof ActionType){
                    this.customActions.add(new MTaskAction((ActionType)cacts.get(i)));
                }                
            }
        }
        

        Element xPayload = task.getPayloadAsElement();
        if (xPayload == null) {
            logger.info("Task", "payload is null");
            this.payload = null;
        } else if (xPayload.hasChildNodes()) {
            this.payload = new ArrayList();
            NodeList children = xPayload.getChildNodes();
            if (children != null) {
                for (int i = 0; i < children.getLength(); i++) {
                    if (children.item(i) instanceof
                        oracle.xml.parser.v2.XMLElement) {
                        try {
                            Source source = new DOMSource(children.item(i));
                            StringWriter sw = new StringWriter();
                            Result result = new StreamResult(sw);
                            TransformerFactory.newInstance().newTransformer().transform(source,
                                                                                        result);
                            payload.add(sw.getBuffer().toString());
                        } catch (TransformerConfigurationException e) {
                            e.printStackTrace();
                        } catch (TransformerException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }

        this.htmlPayload = getPayloadAsHtml();
        
        this.creator = task.getCreatorDisplayName();
        this.acquirer =
                ((task.getSystemAttributes().getAcquiredBy() == null) ? null :
                 task.getSystemAttributes().getAcquiredBy());
        this.createDate =
                task.getSystemAttributes().getCreatedDate().getTime();
        this.expiryDate =
                ((task.getSystemAttributes().getExpirationDate() == null) ?
                 null :
                 task.getSystemAttributes().getExpirationDate().getTime());
        this.updateDate =
                ((task.getSystemAttributes().getUpdatedDate() == null) ? null :
                 task.getSystemAttributes().getUpdatedDate().getTime());
    }

    public int getNumber() {
        return number;
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getState() {
        return state;
    }

    public String getOutcome() {
        return outcome;
    }

    public int getPriority() {
        return priority;
    }

    public List<MTaskComment> getComments() {
        return comments;
    }

    public List<MTaskAttachment> getAttachments() {
        return attachments;
    }

    public List<MTaskAction> getSystemActions() {
        return systemActions;
    }

    public List<MTaskAction> getCustomActions() {
        return customActions;
    }

    @JsonIgnore
    public List getPayload() {
        return payload;
    }

    public String getCreator() {
        return creator;
    }

    public String getAcquirer() {
        return acquirer;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public Date getExpiryDate() {
        return expiryDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    /**
      Retrieve the payload for the task in HTML encoded Strings.
      This method is used to retrieve the payload in a format that can be directly
      displayed in the view (as HTML).
      @return The payload(s) of the task as HTML-safe Strings.
     */
    private List<String> getPayloadAsHtml() {
        if ((this.payload == null) || (this.payload.size() < 1))
            return null;
        List result = new ArrayList();
        for (Object p : this.payload) {
            result.add(((String)p).replaceAll("<", "&lt;").replaceAll(">","&gt;"));
        }
        return result;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setState(String state) {
        this.state = state;
    }

    public void setOutcome(String outcome) {
        this.outcome = outcome;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public void setComments(List<MTaskComment> comments) {
        this.comments = comments;
    }

    public void setAttachments(List<MTaskAttachment> attachments) {
        this.attachments = attachments;
    }

    @JsonIgnore
    public void setSystemActions(List systemActions) {
        this.systemActions = systemActions;
    }

    @JsonIgnore
    public void setCustomActions(List customActions) {
        this.customActions = customActions;
    }

    @JsonIgnore
    public void setPayload(List payload) {
        this.payload = payload;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public void setAcquirer(String acquirer) {
        this.acquirer = acquirer;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public List<String> getHtmlPayload() {
        return htmlPayload;
    }
}
