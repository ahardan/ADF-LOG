package com.darden.krowd.rest.model;

import java.util.ArrayList;
import java.util.List;

public class QuickLinkListDTO {
    public QuickLinkListDTO() {
        personalizedQuickLinks = new ArrayList<QuickLinkDTO>();
        availableQuickLinks  = new ArrayList<QuickLinkDTO>();
        mandatoryQuickLinks = new ArrayList<QuickLinkDTO>();
    }
    
    private List<QuickLinkDTO> personalizedQuickLinks;
    private List<QuickLinkDTO> availableQuickLinks;
    private List<QuickLinkDTO> mandatoryQuickLinks;


    public void setPersonalizedQuickLinks(List<QuickLinkDTO> personalizedQuickLinks) {
        this.personalizedQuickLinks = personalizedQuickLinks;
    }

    public List<QuickLinkDTO> getPersonalizedQuickLinks() {
        return personalizedQuickLinks;
    }

    public void setAvailableQuickLinks(List<QuickLinkDTO> availableQuickLinks) {
        this.availableQuickLinks = availableQuickLinks;
    }

    public List<QuickLinkDTO> getAvailableQuickLinks() {
        return availableQuickLinks;
    }

    public void setMandatoryQuickLinks(List<QuickLinkDTO> mandatoryQuickLinks) {
        this.mandatoryQuickLinks = mandatoryQuickLinks;
    }

    public List<QuickLinkDTO> getMandatoryQuickLinks() {
        return mandatoryQuickLinks;
    }
}
