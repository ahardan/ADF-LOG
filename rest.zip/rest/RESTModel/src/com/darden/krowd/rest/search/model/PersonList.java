package com.darden.krowd.rest.search.model;


import java.io.Serializable;

import java.util.LinkedList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

import oracle.webcenter.jaxrs.framework.model.PaginatedLinked;
import oracle.webcenter.jaxrs.framework.param.StartIndexParam;


public class PersonList extends PaginatedLinked implements Serializable{
    private static final long serialVersionUID = 4528052195602863339L;
    protected List<PersonRow> items;
    
    public PersonList() {
        super();
    }
    
    public PersonList(List<PersonRow> pItems, int startIndex, int totalResults)
    {
      this.items = pItems;
      super.updatePaginationIndices(this.items, new StartIndexParam(String.valueOf(startIndex)));
      if (totalResults >= 0){
        super.setTotalResults(Integer.valueOf(totalResults));
      }
    }    
    
    public PersonList(PersonRow pItem){
      this.items = new LinkedList<PersonRow>();
      this.items.add(pItem);
      super.updatePaginationIndices(this.items, new StartIndexParam(String.valueOf(0)));
      super.setTotalResults(Integer.valueOf(1));
    } 
    
    public String resourceType() {
      return "urn:com:darden:krowd.rest.search";
    }    
    
    public List<PersonRow> getItems() {
      return this.items;
    }

    public void setItems(List<PersonRow> pItems)
    {
      this.items = pItems;
    }    
    

}
