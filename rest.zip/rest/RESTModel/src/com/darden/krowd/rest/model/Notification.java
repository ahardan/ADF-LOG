package com.darden.krowd.rest.model;


import com.darden.krowd.framework.PersonReference;
import com.darden.krowd.model.serialize.ActivityNotification;

import java.io.Serializable;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import oracle.webcenter.activitystreaming.ActivityDisplayElement;

@XmlRootElement(name="notification")
@XmlType(name="notification")
public class Notification implements Serializable {
    private static final long serialVersionUID = -2142277077048996510L;    
    
    private boolean postReadStatus;
    private String url;
    private Activity activity;
    private boolean asObject;    
    
    private transient PersonReference actor;
    private transient PersonReference creator;
    
    private Date activityTime;
    private String activityDescription;
    private String description;
    private String detailUrl;
    private String activityType;
    
    private String postName;
    private String postType;
    private String communityName;
    private String actorId;
    private String creatorId;
    
    private String dDocName;
    private int dId;    
    
    public Notification() {
        super();
    }
    
    public boolean compare(ActivityNotification activityNoti){
        String comActId = activityNoti.getComActorId();
        String likeActId = activityNoti.getLikeActorId();        
        String creator = activityNoti.getActivityCreator();  
        
        String actor=null;
        if(comActId!=null){
            actor=comActId;
        }
        
        if(likeActId!=null){
            actor=likeActId;
        }
        String activityType = activityNoti.getActivityType();
        String postName = activityNoti.getPostName();
        
        if((this.creatorId ==null && creator ==null) || (this.creatorId !=null && creator !=null && this.creatorId.compareTo(creator)==0)){
            if((this.actorId ==null && actor ==null) || (this.actorId !=null && actor !=null && this.actorId.compareTo(actor)==0)){
                if((this.activityType ==null && activityType ==null) || (this.activityType !=null && activityType !=null && this.activityType.compareTo(activityType)==0)){
                    if((this.postName ==null && postName ==null) || (this.postName !=null && postName !=null && this.postName.compareTo(postName)==0)){
                        return true;
                    }else{
                        return false;
                    }
                }else{
                    return false;
                }
            }else{
                return false;
            }
        }else{
            return false;
        }        
    }
    
    @Override
    public String toString(){
        StringBuilder builder = new StringBuilder();
        builder.append("{");
        builder.append("activityCreator:"+this.creatorId+",");
        builder.append("activityTime:"+this.activityTime+",");
        builder.append("activityType:"+this.activityType+",");
        builder.append("postName:"+this.postName+",");
        builder.append("postType:"+this.postType+",");
        builder.append("communityName:"+this.communityName+",");
        builder.append("dDocName:"+this.dDocName+",");
        builder.append("dId:"+this.dId+",");
        builder.append("}");        
        
        return builder.toString();
    }
    
    public Notification(ActivityDisplayElement _element,ActivityNotification activityNoti){        
        this.postReadStatus=activityNoti.getPostReadStatus();
        
        asObject=false;
        if(_element !=null){
            asObject=true;  
            this.activity=new Activity(_element);
        }        
        
        String comActId = activityNoti.getComActorId();
        String likeActId = activityNoti.getLikeActorId();        
        Date comTimeStamp = activityNoti.getComTimeStamp();
        Date likeTimeStamp = activityNoti.getComTimeStamp();        
        this.creatorId = activityNoti.getActivityCreator();        

        
        if(comActId!=null)
        {this.actor=PersonReference.GetPersonByLoginId(comActId);this.actorId=comActId;}
        
        if(likeActId!=null)
        {this.actor=PersonReference.GetPersonByLoginId(likeActId);this.actorId=likeActId;}
        
        if(comTimeStamp !=null){
            this.activityTime=comTimeStamp;
        }
        
        if(likeTimeStamp !=null){
            this.activityTime=likeTimeStamp;
        }
        if(!asObject){
            if(creator !=null){
                this.creator=PersonReference.GetPersonByLoginId(this.creatorId);
            }            
        }
        
        this.detailUrl=activityNoti.getActDetailUrl();
        this.activityType = activityNoti.getActivityType();
        this.activityDescription=activityNoti.getActivityDescription();
        this.description=activityNoti.getComDescription();
        
        this.postName= activityNoti.getPostName();
        this.dDocName= activityNoti.getActDocId();
        this.dId=activityNoti.getActDId();
        this.postType=activityNoti.getPostType();        
        this.url=activityNoti.getFormCommunityUrl();
        this.communityName=activityNoti.getCommunityName();        
        
    }
    
    public void setActivity(Activity activity) {
        this.activity = activity;
    }

    public Activity getActivity() {
        return activity;
    }

    public void setPostReadStatus(boolean postReadStatus) {
        this.postReadStatus = postReadStatus;
    }

    public boolean isPostReadStatus() {
        return postReadStatus;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUrl() {
        return url;
    }

    public void setAsObject(boolean asObject) {
        this.asObject = asObject;
    }

    public boolean isAsObject() {
        return asObject;
    }

    public void setActor(PersonReference actor) {
        this.actor = actor;
    }

    public PersonReference getActor() {
        return actor;
    }

    public void setCreator(PersonReference creator) {
        this.creator = creator;
    }

    public PersonReference getCreator() {
        return creator;
    }

    public void setActivityTime(Date activityTime) {
        this.activityTime = activityTime;
    }

    public Date getActivityTime() {
        return activityTime;
    }

    public void setActivityDescription(String activityDescription) {
        this.activityDescription = activityDescription;
    }

    public String getActivityDescription() {
        return activityDescription;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public void setDetailUrl(String detailUrl) {
        this.detailUrl = detailUrl;
    }

    public String getDetailUrl() {
        return detailUrl;
    }

    public void setActivityType(String activityType) {
        this.activityType = activityType;
    }

    public String getActivityType() {
        return activityType;
    }

    public void setPostName(String postName) {
        this.postName = postName;
    }

    public String getPostName() {
        return postName;
    }

    public void setPostType(String postType) {
        this.postType = postType;
    }

    public String getPostType() {
        return postType;
    }

    public void setCommunityName(String communityName) {
        this.communityName = communityName;
    }

    public String getCommunityName() {
        return communityName;
    }

    public void setDDocName(String dDocName) {
        this.dDocName = dDocName;
    }

    public String getDDocName() {
        return dDocName;
    }

    public void setDId(int dId) {
        this.dId = dId;
    }

    public int getDId() {
        return dId;
    }

    public void setActorId(String actorId) {
        this.actorId = actorId;
    }

    public String getActorId() {
        return actorId;
    }

    public void setCreatorId(String creatorId) {
        this.creatorId = creatorId;
    }

    public String getCreatorId() {
        return creatorId;
    }
}
