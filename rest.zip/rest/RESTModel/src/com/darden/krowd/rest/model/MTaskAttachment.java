package com.darden.krowd.rest.model;

import java.io.Serializable;

import java.math.BigInteger;

import java.security.MessageDigest;

import java.security.NoSuchAlgorithmException;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import oracle.bpel.services.workflow.task.model.AttachmentType;

import com.darden.krowd.framework.PersonReference;

import java.nio.charset.StandardCharsets;

import javax.crypto.Cipher;

import org.bouncycastle.crypto.digests.SHA512Digest;
import org.bouncycastle.crypto.generators.PKCS5S2ParametersGenerator;
import org.bouncycastle.crypto.params.KeyParameter;

@XmlRootElement(name = "attachment")
@XmlType(name = "attachment")
public class MTaskAttachment implements Serializable{
    private static final long serialVersionUID = 5912588000964811411L;
    private String content;
    private String mimeType;
    private String name;
    private transient PersonReference updatedBy;
    private String uri;
    private String systemVersionFlag;
    private String taskId;
    private int version;
    private String acl;
    private boolean belongsToParent;
    private Date updatedDate;
    private String correlationId;
    private long size;
    private String description;
    private String storageType;
    private String ucmDocType;
    private String securityGroup;
    private String account;
    private String revision;
    private Date releaseDate;
    private Date expirationDate;
    private String title;
    private String scope;
    private boolean contentEncoded;
    private String updatedByDisplayName;
    private String id;
    private String operation;
    
    public MTaskAttachment(AttachmentType attachmentType) {
        super();
        this.content = attachmentType.getContent();
        this.mimeType = attachmentType.getMimeType();
        this.name = attachmentType.getName();
        this.updatedBy = PersonReference.GetPersonByLoginId(attachmentType.getUpdatedBy());
        this.uri = attachmentType.getURI();
        this.systemVersionFlag = attachmentType.getSystemVersionFlag();
        this.taskId=attachmentType.getTaskId();
        this.version=attachmentType.getVersion();
        this.acl = attachmentType.getAcl();
        this.belongsToParent = attachmentType.isDoesBelongToParent();
        this.updatedDate = attachmentType.getUpdatedDate().getTime();
        this.correlationId=attachmentType.getCorrelationId();
        this.size=attachmentType.getSize();
        this.description=attachmentType.getDescription();
        this.storageType=attachmentType.getStorageType();
        this.ucmDocType=attachmentType.getUcmDocType();
        this.securityGroup=attachmentType.getSecurityGroup();
        this.account=attachmentType.getAccount();
        this.revision = attachmentType.getRevision();
        this.releaseDate=attachmentType.getReleaseDate()==null?null:attachmentType.getReleaseDate().getTime();
        this.expirationDate=attachmentType.getExpirationDate()==null?null:attachmentType.getExpirationDate().getTime();
        this.title=attachmentType.getTitle();
        this.scope=attachmentType.getAttachmentScope();
        this.contentEncoded=attachmentType.isIsContentEncoded();
        this.updatedByDisplayName=attachmentType.getUpdatedByDisplayName();
        //this.id = attachmentType.getId();
        this.operation=attachmentType.getOperation();
        this.id = MTaskAttachment.getMD5(attachmentType);
    }
    
    private static String getMD5(String valStr){
        try{
            /*
                MessageDigest m = MessageDigest.getInstance("MD5");
                byte[] data = valStr.getBytes(); 
                m.update(data,0,data.length);
                BigInteger i = new BigInteger(1,m.digest());
                return String.format("%1$032X", i);
            */ //commented
            
            //subh,CWE ID: 327- Use of a Broken or Risky Cryptographic Algorithm 
            PKCS5S2ParametersGenerator paramGen = new PKCS5S2ParametersGenerator(new SHA512Digest());
            paramGen.init(
                    valStr.getBytes(StandardCharsets.UTF_8),
                    valStr.getBytes(StandardCharsets.UTF_8),
                    2048);
            final KeyParameter key = (KeyParameter) paramGen.generateDerivedParameters(512);
            
            BigInteger i = new BigInteger(1,key.getKey());
            return String.format("%1$032X", i);
            //

        }catch(Exception e){
            return null;
        }
    }    
    
    public static String getMD5(AttachmentType attachmentType){
        try{
            String name = attachmentType.getName();
            long size = attachmentType.getSize();
            long time = attachmentType.getUpdatedDate().getTimeInMillis();
            return MTaskAttachment.getMD5(name+size+time);            
        }catch(Exception e){
            return null;
        }
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    public String getMimeType() {
        return mimeType;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setUpdatedBy(PersonReference updatedBy) {
        this.updatedBy = updatedBy;
    }

    public PersonReference getUpdatedBy() {
        return updatedBy;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public String getUri() {
        return uri;
    }

    public void setSystemVersionFlag(String systemVersionFlag) {
        this.systemVersionFlag = systemVersionFlag;
    }

    public String getSystemVersionFlag() {
        return systemVersionFlag;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public int getVersion() {
        return version;
    }

    public void setAcl(String acl) {
        this.acl = acl;
    }

    public String getAcl() {
        return acl;
    }

    public void setBelongsToParent(boolean belongsToParent) {
        this.belongsToParent = belongsToParent;
    }

    public boolean isBelongsToParent() {
        return belongsToParent;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setSize(long size) {
        this.size = size;
    }

    public long getSize() {
        return size;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public void setStorageType(String storageType) {
        this.storageType = storageType;
    }

    public String getStorageType() {
        return storageType;
    }

    public void setUcmDocType(String ucmDocType) {
        this.ucmDocType = ucmDocType;
    }

    public String getUcmDocType() {
        return ucmDocType;
    }

    public void setSecurityGroup(String securityGroup) {
        this.securityGroup = securityGroup;
    }

    public String getSecurityGroup() {
        return securityGroup;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getAccount() {
        return account;
    }

    public void setRevision(String revision) {
        this.revision = revision;
    }

    public String getRevision() {
        return revision;
    }

    public void setReleaseDate(Date releaseDate) {
        this.releaseDate = releaseDate;
    }

    public Date getReleaseDate() {
        return releaseDate;
    }

    public void setExpirationDate(Date expirationDate) {
        this.expirationDate = expirationDate;
    }

    public Date getExpirationDate() {
        return expirationDate;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setScope(String scope) {
        this.scope = scope;
    }

    public String getScope() {
        return scope;
    }

    public void setContentEncoded(boolean contentEncoded) {
        this.contentEncoded = contentEncoded;
    }

    public boolean isContentEncoded() {
        return contentEncoded;
    }

    public void setUpdatedByDisplayName(String updatedByDisplayName) {
        this.updatedByDisplayName = updatedByDisplayName;
    }

    public String getUpdatedByDisplayName() {
        return updatedByDisplayName;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public String getOperation() {
        return operation;
    }
}
