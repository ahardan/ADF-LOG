package com.darden.krowd.rest.search.model;


import com.darden.krowd.rest.model.ContentItem;


import java.io.Serializable;

import java.util.HashMap;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import oracle.adf.share.logging.ADFLogger;

import oracle.search.query.webservice.client.CustomAttribute;
import oracle.search.query.webservice.client.OracleSearchResult;
import oracle.search.query.webservice.client.ResultElement;
import oracle.search.query.webservice.client.SuggestedLink;

@XmlRootElement(name="searchresult")
@XmlType(name="searchresult")
public class SesSearchResult implements Serializable{
    private static final ADFLogger LOGGER = ADFLogger.createADFLogger(SesSearchResult.class);
    private static final long serialVersionUID = -4353082231906888769L;
    private Boolean returnCount;
    private Integer estimatedHitCount;
    private Boolean dupRemoved;
    private Boolean dupMarked;
    private SuggestedLink[] suggestedLinks;
    private SesSearchResultItem[] results;
    private String query;
    private String altKeywords;
    private Integer startIndex;
    private Integer itemsPerPage;
    private transient OracleSearchResult searchResult;
        
    public SesSearchResult() {
        super();
    }

    public SesSearchResult(OracleSearchResult searchResult) {
        super();
        this.searchResult = searchResult;
    }
    
    public void processSearchResult(HashMap<Integer,ContentItem> contentItems){
        boolean processDataFiles = false;
        if(searchResult !=null){
            this.returnCount = searchResult.isReturnCount();
            this.estimatedHitCount = searchResult.getEstimatedHitCount();
            this.dupRemoved = searchResult.isDupRemoved();
            this.dupMarked = searchResult.isDupMarked();
            this.suggestedLinks = searchResult.getSuggestedLinks();
            this.query = searchResult.getQuery();
            this.altKeywords = searchResult.getAltKeywords();
            this.startIndex = searchResult.getStartIndex();
            this.itemsPerPage = searchResult.getDocsReturned();
            
            if(contentItems != null && contentItems.size()>0){
                processDataFiles = true;
            }
            
            if(searchResult.getResultElements() != null ){
                ResultElement[] resultElems = searchResult.getResultElements();                
                Integer dID = null;
                SesSearchResultItem sesSearchResultItem;
                results = new SesSearchResultItem[resultElems.length];
                for(int i=0;i<resultElems.length;i++){
                    sesSearchResultItem = new SesSearchResultItem(resultElems[i]);
                    results[i] = sesSearchResultItem;
                    LOGGER.info("=====> Processing DocID : " + sesSearchResultItem.getDocID());
                    if(processDataFiles){
                        dID = getDID(resultElems[i]);
                        if(dID != null){
                            sesSearchResultItem.setContent(contentItems.get(dID));
                        }else{
                            LOGGER.info("==> DID is NULL for " + sesSearchResultItem.getDocID());
                        }
                    }else{
                        LOGGER.info("==> processDataFiles is false ");
                    }
                }
            }
        }    
        
    }
    
    private Integer getDID(ResultElement resultElem){
        CustomAttribute[] customAttribs = resultElem.getCustomAttributes();
        if(customAttribs == null || customAttribs.length ==0){
            return null;
        }else{
            String attrName = null;
            String dIDStrVal = null;
            for(CustomAttribute tCustomAttrib : customAttribs){
                attrName = tCustomAttrib.getName();
                if(attrName.compareToIgnoreCase("dID_NUMBER")==0){
                    dIDStrVal = tCustomAttrib.getValue();
                }
            }
            
            if(dIDStrVal == null){
                return null;
            }else{
                try{
                    return Integer.parseInt(dIDStrVal);
                }catch(Exception e){
                    LOGGER.severe(e);
                }
                return null;
            }
        }
    }
    
    
    public void setReturnCount(Boolean returnCount) {
        this.returnCount = returnCount;
    }

    public Boolean getReturnCount() {
        return returnCount;
    }

    public void setEstimatedHitCount(Integer estimatedHitCount) {
        this.estimatedHitCount = estimatedHitCount;
    }

    public Integer getEstimatedHitCount() {
        return estimatedHitCount;
    }

    public void setDupRemoved(Boolean dupRemoved) {
        this.dupRemoved = dupRemoved;
    }

    public Boolean getDupRemoved() {
        return dupRemoved;
    }

    public void setDupMarked(Boolean dupMarked) {
        this.dupMarked = dupMarked;
    }

    public Boolean getDupMarked() {
        return dupMarked;
    }

    public void setSuggestedLinks(SuggestedLink[] suggestedLinks) {
        this.suggestedLinks = suggestedLinks;
    }

    public SuggestedLink[] getSuggestedLinks() {
        return suggestedLinks;
    }

    public void setQuery(String query) {
        this.query = query;
    }

    public String getQuery() {
        return query;
    }

    public void setAltKeywords(String altKeywords) {
        this.altKeywords = altKeywords;
    }

    public String getAltKeywords() {
        return altKeywords;
    }

    public void setStartIndex(Integer startIndex) {
        this.startIndex = startIndex;
    }

    public Integer getStartIndex() {
        return startIndex;
    }

    public void setItemsPerPage(Integer itemsPerPage) {
        this.itemsPerPage = itemsPerPage;
    }

    public Integer getItemsPerPage() {
        return itemsPerPage;
    }

    public void setResults(SesSearchResultItem[] results) {
        this.results = results;
    }

    public SesSearchResultItem[] getResults() {
        return results;
    }
}
