package com.darden.krowd.rest.model;

import com.darden.krowd.framework.PersonReference;

import java.io.Serializable;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import oracle.bpel.services.workflow.task.model.CommentType;

@XmlRootElement(name = "comment")
@XmlType(name = "comment")
public class MTaskComment implements Serializable {

    private static final long serialVersionUID = 6593658842081236546L;
    private String comment;
    private transient PersonReference updatedBy;
    private Date updatedDate;
    private String displayNameLanguage;
    private String action;
    private String systemVersionFlag;
    private String acl;
    private boolean belongsToParent;
    private boolean systemComment;
    private String taskId;
    private String commentScope;
    private String id;
    private String operation;

    public MTaskComment() {
        super();
    }
    
    public MTaskComment(CommentType commentType) {
        super();
        this.comment = commentType.getComment();
        this.updatedBy = PersonReference.GetPersonByLoginId(commentType.getUpdatedBy().getId());    
        this.updatedDate = commentType.getUpdatedDate().getTime();
        this.displayNameLanguage = commentType.getDisplayNameLanguage();
        this.action = commentType.getAction();
        this.systemVersionFlag = commentType.getSystemVersionFlag();
        this.acl = commentType.getAcl();
        this.belongsToParent = commentType.isDoesBelongToParent();
        this.systemComment = commentType.isIsSystemComment();
        this.taskId = commentType.getTaskId();
        this.commentScope = commentType.getCommentScope();
        this.id = commentType.getId();
        this.operation = commentType.getOperation();
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getComment() {
        return comment;
    }

    public PersonReference getUpdatedBy() {
        return updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setDisplayNameLanguage(String displayNameLanguage) {
        this.displayNameLanguage = displayNameLanguage;
    }

    public String getDisplayNameLanguage() {
        return displayNameLanguage;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getAction() {
        return action;
    }

    public void setSystemVersionFlag(String systemVersionFlag) {
        this.systemVersionFlag = systemVersionFlag;
    }

    public String getSystemVersionFlag() {
        return systemVersionFlag;
    }

    public void setAcl(String acl) {
        this.acl = acl;
    }

    public String getAcl() {
        return acl;
    }

    public void setBelongsToParent(boolean belongsToParent) {
        this.belongsToParent = belongsToParent;
    }

    public boolean isBelongsToParent() {
        return belongsToParent;
    }

    public void setSystemComment(boolean systemComment) {
        this.systemComment = systemComment;
    }

    public boolean isSystemComment() {
        return systemComment;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setCommentScope(String commentScope) {
        this.commentScope = commentScope;
    }

    public String getCommentScope() {
        return commentScope;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public String getOperation() {
        return operation;
    }
}
