package com.darden.krowd.rest.myshift.model;


import com.darden.krowd.common.dto.KrowdUserDTO;

import java.util.HashMap;
import java.util.Map;

public class MyShiftUser  {
    /*
     * 1. Picture - image url
     * 2. Name - displayName or First name, Last name
     * 4. Phone no - TBD
     * 5. Preference - TBD
     */

    private String photo;
    private String name;
    private String contactNo;
    private Map<String,Object> prefs;
    
    public MyShiftUser() {
        super();
    }

    public void setContactNo(String phoneNo) {
        this.contactNo = phoneNo;
    }

    public String getContactNo() {
        return contactNo;
    }

    public void setPrefs(Map<String, Object> prefs) {
        this.prefs = prefs;
    }

    public Map<String, Object> getPrefs() {
        return prefs;
    }

    public void setPhoto(String imageUrl) {
        this.photo = imageUrl;
    }

    public String getPhoto() {
        return photo;
    }

    public void setName(String firstName) {
        this.name = firstName;
    }

    public String getName() {
        return name;
    }

}
