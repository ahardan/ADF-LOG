package com.darden.krowd.rest.model;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import oracle.webcenter.jaxrs.framework.model.PaginatedLinked;
import oracle.webcenter.jaxrs.framework.param.StartIndexParam;


public class MapList  extends PaginatedLinked{
    protected List<Map<String,Object>> m_items;
    
    public MapList() {
    }
    
    public MapList(List<Map<String,Object>> _items, int _nStartIndex, int _nTotalResults)
    {
      this.m_items = _items;
      super.updatePaginationIndices(this.m_items, new StartIndexParam(String.valueOf(_nStartIndex)));
      if (_nTotalResults >= 0)
      {
        super.setTotalResults(Integer.valueOf(_nTotalResults));
      }
    }

    public MapList(Map<String,Object> _item)
    {
      this.m_items = new LinkedList<Map<String,Object>>();
      this.m_items.add(_item);
      super.updatePaginationIndices(this.m_items, new StartIndexParam(String.valueOf(0)));
      super.setTotalResults(Integer.valueOf(1));
    }
    public String resourceType() {
      return "urn:com:darden:krowd:rest:list";
    }
    public List<Map<String,Object>> getItems() {
      return this.m_items;
    }

    public void setItems(List<Map<String,Object>> _items)
    {
      this.m_items = _items;
    }    
}
