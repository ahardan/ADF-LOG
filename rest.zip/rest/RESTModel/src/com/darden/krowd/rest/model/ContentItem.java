package com.darden.krowd.rest.model;


import com.darden.krowd.RIDCCommon.util.UCMUtil;
import com.darden.krowd.common.KrowdUtility;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import oracle.adf.share.logging.ADFLogger;

import oracle.stellent.ridc.model.DataObject;

import oracle.webcenter.activitystreaming.ActivityException;
import oracle.webcenter.activitystreaming.ActivityObject;
import oracle.webcenter.activitystreaming.ActivityStreamingService;
import oracle.webcenter.activitystreaming.ActivityStreamingServiceFactory;
import oracle.webcenter.comments.Comment;
import oracle.webcenter.comments.CommentsException;
import oracle.webcenter.comments.CommentsManager;
import oracle.webcenter.comments.CommentsServiceFactory;
import oracle.webcenter.content.integration.AuthorizationException;
import oracle.webcenter.content.integration.Property;
import oracle.webcenter.content.integration.RepositoryException;
import oracle.webcenter.framework.service.ServiceObjectType;
import oracle.webcenter.likes.Like;
import oracle.webcenter.likes.LikesException;
import oracle.webcenter.likes.LikesManager;
import oracle.webcenter.likes.LikesServiceFactory;
import oracle.webcenter.likes.LikesSummary;


@XmlRootElement(name="content")
@XmlType(name="content")
public class ContentItem implements Serializable {
    private static final ADFLogger logger = ADFLogger.createADFLogger(ContentItem.class);
    private static final long serialVersionUID = -7164904289632081714L;
    protected String webUrl;
    private HashMap<String,Object> attributes;
    protected boolean editable;
    protected Integer likesCount;
    protected Integer commentsCount;
    protected String serviceId;
    protected boolean iLikeIt;
    protected String likeId;
    protected String objectId;
    protected String activityType;
    protected String objectType;
    protected boolean lcEnabled;
    private static final Map<String,Map<String,String>> CONTENT_TYPE_MAP;
    
    private static final String[] PROPERTIES_BLACKLIST =
        new String[] { "dChildManipulation", "dCollectionCreator",
                       "dCollectionEnabled", "dCollectionGUID",
                       "dCollectionInherit", "dCollectionMark",
                       "dCollectionModifier", "dCollectionQueries",
                       "dDependent", "dDocAccount", "dDocFunction",
                       "dIndexerState", "dIsCheckedOut", "dPromptForMetadata",
                       "dRevClassID", "dRevRank", "dWorkflowState",
                       "xCpdIsLocked", "xCpdIsTemplateEnabled",
                       "xDamConversionType", "xDepartment",
                       "xDepartmentPolicy", "xDepartmentsC16RType",
                       "xDepartmentsC19Rcategories", "xDepartmentsPagesType",
                       "xDepartmentsSubPagesType",
                       "xDontShowInListsForWebsites", "xDPAssetReviewDate",
                       "xDPNotes", "xEnrichmentId", "xEnrichmentIdType",
                       "xEnvironment", "xExternalDataSet",
                       "xForceFolderSecurity", "xHasBeenPublishedToDp",
                       "xIdcProfile", "xInhibitUpdate", "xIPMSYS_APP_ID",
                       "xIPMSYS_BATCH_ID1", "xIPMSYS_BATCH_SEQ",
                       "xIPMSYS_PARENT_ID", "xIPMSYS_REDACTION",
                       "xIPMSYS_SCKEY", "xIPMSYS_STATUS", "xPublishToDp",
    "dDocType",
    "dDocAuthor",
    "dRevisionID",
    "dRevLabel",
    "dSecurityGroup",
    "dCreateDate",
    "dInDate",
    "dOutDate",
    "dStatus",
    "dReleaseState",
    "dWebExtension",
    "dFormat",
    "xCollectionID",
    "xHidden",
    "xReadOnly",
    "xWCTags",
    "xWebsiteObjectType",
    "xClbraRoleList",
    "xLanguage",
    "xTranslationRequirement",
    "xWorkflowLevel",
    "xWebContentType",
    "xFeedbackStatus",
    "xSupportType",
    "xADGroups",
    "xADGroupsCategory",
    "xHrlyTileSeq",
    "xMgrTileSeq",
    "xDirTileSeq",
    "xRSCTileSeq"
                       
                        };
    
    static {
            Map<String,Map<String,String>> tMap = new HashMap<String,Map<String,String>>();
            Map<String,String> nMap = new HashMap<String,String>();
            nMap.put("serviceId", "com.darden.krowd.content.dardentv");
            nMap.put("objectType", "dardentv-object");
            nMap.put("activityType", "share-dardentv-activity");            
            tMap.put("RD_MYDARDEN_TVSPOT",nMap);
            tMap.put("KROWD_RD_MYDARDEN_TVSPOT",nMap);
            
            nMap = new HashMap<String,String>();
            nMap.put("serviceId", "com.darden.krowd.content.announcement");
            nMap.put("objectType", "announcement-object");
            nMap.put("activityType", "share-announcement-activity");            
            tMap.put("RD_ANNOUNCEMENT",nMap);                        
            tMap.put("KROWD_RD_ANNOUNCEMENT",nMap);                        

            nMap = new HashMap<String,String>();
            nMap.put("serviceId", "com.darden.krowd.content.news");
            nMap.put("objectType", "news-object");
            nMap.put("activityType", "share-news-activity");            
            tMap.put("RD_NEWS",nMap);            
            tMap.put("KROWD_RD_NEWS",nMap);            

            nMap = new HashMap<String,String>();
            nMap.put("serviceId", "com.darden.krowd.content.spotlight");
            nMap.put("objectType", "spotlight-object");
            nMap.put("activityType", "share-spotlight-activity");            
            tMap.put("RD_SPOTLIGHT",nMap);  
            tMap.put("KROWD_RD_SPOTLIGHT",nMap);  
            
            nMap = new HashMap<String,String>();
            nMap.put("serviceId", "com.darden.krowd.content.brandtv");
            nMap.put("objectType", "brandtv-object");
            nMap.put("activityType", "share-brandtv-activity");            
            tMap.put("RD_MYWORKS_TVSPOT",nMap);              
            tMap.put("KROWD_RD_MYWORKS_TVSPOT",nMap);               
            
            CONTENT_TYPE_MAP = Collections.unmodifiableMap(tMap);
        }      
    
    public ContentItem() {
        super();

    }
    
    private static String[] getPropertiesBlacklist(){
        try{
            java.util.Properties props = KrowdUtility.getInstance().getProperties();
            String blacklist = props.getProperty("PROPERTIES_BLACKLIST");
            return blacklist==null?PROPERTIES_BLACKLIST:blacklist.split(",");
        }catch(Exception e){
            return PROPERTIES_BLACKLIST;
        }
    }

    public ContentItem(oracle.webcenter.content.integration.Node node,boolean processLikesComments){                
        try {            
            attributes = resolveProperties(node.getProperties());
            this.webUrl = node.getURLEncodedPath();
            if(attributes !=null){
                attributes.put("webUrl",this.webUrl);
            }
            
            processServiceDefs();            
            if(processLikesComments){
                processLikes();
                processComments();           
            }
        } catch (AuthorizationException e) {
            logger.severe(e);
        } catch (RepositoryException e) {
            logger.severe(e);
        }
    }
    
    public ContentItem(HashMap<String,Object> attributes,boolean processLikesComments){
        this.attributes=attributes;
        if(attributes !=null){
            this.webUrl = (String)attributes.get("webUrl");
        }        
        processServiceDefs();            
        if(processLikesComments){
            this.commentsCount = (Integer) this.attributes.get("commentsCount");
            this.likesCount = (Integer) this.attributes.get("likesCount");
                        
            if(this.likesCount == null){
                processLikes();    
            }
            
            if(this.commentsCount == null){
                processComments();     
            }

        }
    }
    
    public ContentItem(DataObject dataObject,boolean processLikesComments){                
        try {
            processMetadata(dataObject);
            processServiceDefs();
            if(processLikesComments){
                processLikes();
                processComments();        
            }
        } catch (Exception e) {
            logger.severe(e);
        } 
    }
    
    private void processMetadata(DataObject dataObject){
        if(dataObject !=null){
            Set<Map.Entry<String,String>> attrSet = dataObject.entrySet();
            attributes = new HashMap<String,Object>();
            String val;
            String key;
            String[] blacklist = getPropertiesBlacklist();
            for(Map.Entry<String,String> attr : attrSet){
                key = attr.getKey();
                if(key !=null && !existsInArray(blacklist,key)){
                    val = attr.getValue();
                    if(val!=null && val.trim().compareTo("")!=0)
                        attributes.put(key,val);                    
                }
            }                    
            attributes.put("thumbnail","/cs/idcplg?IdcService=GET_FILE&dDocName="+attributes.get("dDocName")+"&dID="+attributes.get("dID")+"&RevisionSelectionMethod=specific&Rendition=Thumbnail&allowInterrupt=1"); 
            attributes.put("preview","/cs/idcplg?IdcService=GET_FILE&dDocName="+attributes.get("dDocName")+"&dID="+attributes.get("dID")+"&RevisionSelectionMethod=specific&Rendition=Preview&allowInterrupt=1"); 
        }        
    }

    public void setLikesCount(Integer likesCount) {
        this.likesCount = likesCount;
    }

    public Integer getLikesCount() {
        return likesCount;
    }

    public void setCommentsCount(Integer commentsCount) {
        this.commentsCount = commentsCount;
    }

    public Integer getCommentsCount() {
        return commentsCount;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    public String getServiceId() {
        return serviceId;
    }

    public void setILikeIt(boolean iLikeIt) {
        this.iLikeIt = iLikeIt;
    }

    public boolean isILikeIt() {
        return iLikeIt;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }

    public String getObjectId() {
        return objectId;
    }

    public void setActivityType(String activityType) {
        this.activityType = activityType;
    }

    public String getActivityType() {
        return activityType;
    }

    public void setObjectType(String objectType) {
        this.objectType = objectType;
    }

    public String getObjectType() {
        return objectType;
    }

    private static <T> boolean contains(final T[] array, final T v) {
        if (v == null) {
            for (final T e : array)
                if (e == null)
                    return true;
        } else {
            for (final T e : array)
                if (e == v || v.equals(e))
                    return true;
        }

        return false;
    }  
    
    private ActivityObject createActivityObject(String serviceId, String objectType, String objectId)
    {
      ActivityObject obj = null;
      try {
        ActivityStreamingService as = ActivityStreamingServiceFactory.getInstance().getActivityStreamingService();
        ServiceObjectType serviceObjType = as.findObjectType(serviceId, objectType);
        obj = as.createObject(objectId, serviceObjType, objectId);
        obj.setServiceID(serviceId);
      } catch (ActivityException e) {
        logger.warning(e);
        e.printStackTrace();
      }
      return obj;
    }    
    
    public void processLikes() {      
        try{
            if(this.lcEnabled){
                String serviceId = getServiceId();
                String objectType = getObjectType();
                String objectId=getObjectId();
                
                logger.info( "serviceId " + serviceId + " objectType " + objectType + " objectId " + objectId);            
                ActivityObject activityObject = createActivityObject(serviceId, objectType, objectId);
                LikesManager likesManager = LikesServiceFactory.getInstance().getLikesManager();   
                this.likesCount = likesManager.getLikesSummary(activityObject).getCount();
                this.attributes.put("likesCount", this.likesCount);     
            }
        }catch(Exception e){
            logger.severe(e);
        }
    }   
    

    public void processComments() {
        List<Comment> comments = null;        
        
        try{
            if(this.lcEnabled){
                String serviceId = getServiceId();
                String objectType = getObjectType();
                String objectId=getObjectId();
                
                logger.info("serviceId " + serviceId + " objectType " + objectType + " objectId " + objectId);
                ActivityObject activityObject = createActivityObject(serviceId, objectType, objectId);
                CommentsManager commentsManager = CommentsServiceFactory.getInstance().getCommentsManager();
                comments = commentsManager.getComments(activityObject, CommentsManager.SortCriteria.CREATED_ON_ASC);                        
                this.commentsCount = comments.size();                
                this.attributes.put("commentsCount", this.commentsCount);
            }            
        }catch(Exception e){
            logger.severe(e);
        }
    }   
    
    
    public void initializeCommentsAndLikes(String guid) throws CommentsException,
                                                    LikesException {
        if(this.lcEnabled){
            String serviceId = getServiceId();
            String objectType = getObjectType();
            String objectId=getObjectId();
            
            logger.info("serviceId " + serviceId + " objectType " + objectType + " objectId " + objectId);
            ActivityObject activityObject = createActivityObject(serviceId, objectType, objectId);

            try{
                CommentsManager commentsManager = CommentsServiceFactory.getInstance().getCommentsManager();
                oracle.webcenter.comments.Comment comment = commentsManager.postComment(activityObject,"INIT",null);
                logger.info("INIT Comment Created with "+comment==null?"NULL":comment.getId());
            }catch(CommentsException e){
                logger.severe("Error Initializing comments");
                logger.severe(e);
                throw e;
            }
            
            try{
                LikesManager likesManager = LikesServiceFactory.getInstance().getLikesManager();
                Like like = likesManager.like(activityObject, guid, null);
                logger.info("INIT Like Created with "+like==null?"NULL":like.getLikeId());
            }catch(LikesException e){
                logger.severe("Error Initializing likes");
                logger.severe(e);
                throw e;
            }            
        }
    }
    
    private String getContentId(){
        return (String)attributes.get("ddocname");
    }
    
    private String getRegionDefinition(){
        return (String)attributes.get("xregiondefinition");
    }
    
    private String getSpotlightType(){
        return (String)attributes.get("xspotlightcontent");
    }
    
    private String getWebcontent(){
        return (String)attributes.get("webcontent");
    }
    
    private void processServiceDefs(){
        String serviceId = null;
        String objectType = null;
        String objectId=null;
        String activityType = null;

        String dDocName = getContentId();
        String regionDefinition = getRegionDefinition();
        
        if(regionDefinition ==null || regionDefinition.trim().compareTo("")==0){
            this.lcEnabled=false;
            objectId = UCMUtil.getInstance().getPrimaryConnection()+"#dDocName:"+dDocName;  
            return;
        }
        
        if(regionDefinition.compareTo("RD_SPOTLIGHT")==0 || regionDefinition.compareTo("KROWD_RD_SPOTLIGHT")==0){
            this.lcEnabled=true;
            String spotLightType = getSpotlightType();
            String spotLightWebContent = getWebcontent();
            if (spotLightType == null || spotLightType.equals("custom")) {
                serviceId = CONTENT_TYPE_MAP.get(regionDefinition).get("serviceId");
                objectType = CONTENT_TYPE_MAP.get(regionDefinition).get("objectType");
                activityType = CONTENT_TYPE_MAP.get(regionDefinition).get("activityType");
                objectId = UCMUtil.getInstance().getPrimaryConnection()+"#dDocName:"+dDocName;                       
            }else{
                if (spotLightType.equals("news")) {
                    objectId = UCMUtil.getInstance().getPrimaryConnection()+"#dDocName:" + spotLightWebContent;
                    serviceId = CONTENT_TYPE_MAP.get("RD_NEWS").get("serviceId");
                    objectType = CONTENT_TYPE_MAP.get("RD_NEWS").get("objectType");
                    activityType = CONTENT_TYPE_MAP.get("RD_NEWS").get("activityType");
                }       
                
                if (spotLightType.equals("announcements")) {
                    objectId = UCMUtil.getInstance().getPrimaryConnection()+"#dDocName:" + spotLightWebContent;
                    serviceId = CONTENT_TYPE_MAP.get("RD_ANNOUNCEMENT").get("serviceId");
                    objectType = CONTENT_TYPE_MAP.get("RD_ANNOUNCEMENT").get("objectType");
                    activityType = CONTENT_TYPE_MAP.get("RD_ANNOUNCEMENT").get("activityType");
                }                    
            }
        }else{
            Map<String,String> serviceMap = CONTENT_TYPE_MAP.get(regionDefinition);
            if(serviceMap != null){
                serviceId = serviceMap.get("serviceId");
                objectType = serviceMap.get("objectType");
                activityType = serviceMap.get("activityType");                
                this.lcEnabled=true;
            }else{
                this.lcEnabled=false;
            }
            objectId = UCMUtil.getInstance().getPrimaryConnection()+"#dDocName:"+dDocName;            
        }      
        
        setServiceId(serviceId);
        setObjectType(objectType);
        setActivityType(activityType);
        setObjectId(objectId);
    }
    
    public static String toCamelCase(String s){
       String[] parts = s.split("_");
       String camelCaseString = parts[0].toLowerCase();
       String part;
       for (int i=1;i<parts.length;i++){
          part = parts[i];
          camelCaseString = camelCaseString + toProperCase(part);     
       }
       return camelCaseString;
    }

    private static String toProperCase(String s) {
        return s.substring(0, 1).toUpperCase() +
                   s.substring(1).toLowerCase();
    }   
    
    private  static boolean existsInArray(String[] arr, String targetValue) {
            for(String s: arr){
                    if(s.equals(targetValue))
                                return true;
            }
            return false;
    }
    
    private HashMap<String,Object> toMap(){
        HashMap<String,Object> map = new HashMap<String,Object>();
        map.put("webUrl",this.webUrl);
        map.put("attributes",this.attributes);
        map.put("editable",this.editable);
        map.put("likesCount",this.likesCount);
        map.put("commentsCount",this.commentsCount);
        map.put("serviceId",this.serviceId);
        map.put("iLikeIt",this.iLikeIt);
        map.put("likeId",this.likeId);
        map.put("objectId",this.objectId);
        map.put("activityType",this.activityType);
        map.put("objectType",this.objectType);
        map.put("lcEnabled",this.lcEnabled);
        
        return map;
    }
    
    private static ContentItem getContentItemById(String contentId){
        if(contentId ==null)
            return null;
        try{
            UCMUtil ucmUtil = UCMUtil.getInstance();
            String dDocName = ucmUtil.getUCMDocName(contentId);
            DataObject dataObject = ucmUtil.getDocumentInfo(dDocName);                        
            String type = dataObject.get("xWebsiteObjectType");
            if(type != null && type.compareToIgnoreCase("Data File")==0){
                oracle.webcenter.content.integration.Node node = ucmUtil.getWCContentNode(dDocName);    
                if(node != null){
                    return new ContentItem(node,false);
                }else{
                    return null;
                }
            }else{
                return new ContentItem(dataObject,false);
            }
        }catch(Exception e){
            logger.severe(e);
            return null;
        }        
    }
    
    private static HashMap<String,Object> resolveProperties(oracle.webcenter.content.integration.Property[] properties){
        String propName;
        String strVal;
        int propType;
        List<Object> objVals;
        int idxCol;
        oracle.webcenter.content.integration.Value[] values;
        HashMap<String,Object> props = null;
        Object obj;
        ContentItem contentItem;
        
        if(properties ==null || properties.length ==0)
            return props;
        String[] blacklist = getPropertiesBlacklist();
        for(oracle.webcenter.content.integration.Property property : properties){ 
            propName = property.getName()==null?null:property.getName();            
            if(propName !=null && !existsInArray(blacklist,propName)){
                propName = propName.toUpperCase();
                values = property.getValues();
                propType = property.getType();
                idxCol = propName.indexOf(":");
                if(idxCol > -1){
                    propName = propName.substring(idxCol+1);
                }
                if(props ==null){
                    props = new HashMap<String,Object>();
                }
                if(propType == Property.BOOLEAN || propType == Property.LONG || propType == Property.DOUBLE || propType == Property.STRING || propType == Property.CALENDAR || propType == Property.BOOLEAN){
                    if(values !=null && values.length>0){
                        objVals = new ArrayList<Object>();
                        for(int i=0;i<values.length;i++){
                            obj = values[i]==null?null:values[i].getValueByType(propType);                            
                            if(propName.compareTo("VIDEO")==0 && obj!=null && obj instanceof String){
                                strVal = (String)obj;
                                strVal = strVal.replaceAll("<iframe","<div kd-video");
                                strVal = strVal.replaceAll("</iframe","</div");
                                obj=strVal;
                                objVals.add(obj);
                            }else if((propName.compareTo("URL")==0 || propName.compareTo("LINK")==0) && obj!=null && obj instanceof String){
                                strVal = (String)obj;
                                if(strVal.startsWith(":")){
                                    strVal = strVal.substring(strVal.indexOf(":")+1);
                                    obj=strVal;
                                    objVals.add(obj);                                    
                                }else{
                                    if(strVal.startsWith("1:")){
                                        strVal = strVal.substring(strVal.indexOf(":")+1);
                                        contentItem = ContentItem.getContentItemById(strVal);
                                        if(contentItem == null){
                                            objVals.add(strVal);    
                                        }else{
                                            objVals.add(contentItem.toMap());    
                                        }                                        
                                    }else if(strVal.startsWith("2:")){
                                        strVal = strVal.substring(strVal.indexOf(":")+1);
                                        obj=strVal;
                                        objVals.add(obj);                                        
                                    }else if(strVal.startsWith("3:")){
                                        strVal = strVal.substring(strVal.indexOf(":")+1);
                                        obj=strVal;
                                        objVals.add(obj);                                        
                                    }else if(strVal.startsWith("4:")){
                                        strVal = strVal.substring(strVal.indexOf(":")+1);
                                        obj=strVal;
                                        objVals.add(obj);                                        
                                    }else{
                                        strVal = strVal.substring(strVal.indexOf(":")+1);
                                        obj=strVal;
                                        objVals.add(obj);                                        
                                    }
                                }
                            }else if(propName.compareTo("EMPLOYEESELECTOR")==0 && obj!=null && obj instanceof String){
                                strVal = (String)obj;
                                contentItem = ContentItem.getContentItemById(strVal);
                                if(contentItem == null){
                                    objVals.add(strVal);    
                                }else{
                                    objVals.add(contentItem.toMap());    
                                }                                                                        
                            }else{
                                if(obj !=null){
                                    if(obj instanceof Long){
                                        objVals.add(((Long)obj).intValue()); //convert long to int
                                    }else if(obj instanceof Calendar){
                                        objVals.add(((Calendar)obj).getTime());
                                    }else if(obj instanceof Double){
                                        objVals.add(((Double)obj).doubleValue());
                                    }else{
                                        objVals.add(obj);
                                    }                                    
                                }
                            }
                        }
                        if(objVals.size()>1){
                            props.put(toCamelCase(propName),objVals);
                        }else{
                            if(objVals.size()==1){
                                Object objValItm = objVals.get(0);
                                props.put(toCamelCase(propName),objValItm);    
                                
                                if(propName.compareTo("URL")==0 || propName.compareTo("LINK")==0){
                                    if(objValItm instanceof ContentItem){
                                        props.put(toCamelCase(propName+"_TYPE"),"CONTENT");
                                    }else if(objValItm instanceof String){
                                        props.put(toCamelCase(propName+"_TYPE"),"STRING");
                                    }else{
                                        props.put(toCamelCase(propName+"_TYPE"),objValItm.getClass().getName());
                                    }                                    
                                }
                            }
                        }
                    }
                }else if(propType == Property.LINK){
                }else if(propType == Property.NESTED){
                    if(values !=null && values.length>0){
                        objVals = new ArrayList<Object>(); 
                        oracle.webcenter.content.integration.Property[] nestedProperties;
                        HashMap<String,Object> nestedProps;
                        for(int i=0;i<values.length;i++){
                            nestedProperties = values[i].getNestedValue();
                            nestedProps = resolveProperties(nestedProperties);
                            if(nestedProps !=null){
                                objVals.add(nestedProps); 
                            }
                        }
                        if(objVals.size()>1){
                            props.put(toCamelCase(propName),objVals);
                        }else{
                            if(objVals.size()==1)
                                props.put(toCamelCase(propName),objVals.get(0));
                        }                        
                    }                    
                }else{
                    if(values !=null && values.length>0){
                        objVals = new ArrayList<Object>();                        
                        for(int i=0;i<values.length;i++){
                            obj=values[i]==null?null:values[i].getStringValue();
                            if(obj !=null)
                                objVals.add(obj);
                        }
                        if(objVals.size()>1){
                            props.put(toCamelCase(propName),objVals);
                        }else{
                            if(objVals.size()==1)
                                props.put(toCamelCase(propName),objVals.get(0));
                        }                        
                    }
                }                
            }else{
                logger.info("Property name is NULL");
            }
        }
        return props;
    }
    public boolean isLcEnabled() {
        return lcEnabled;
    }

    public HashMap<String, Object> getAttributes() {
        return attributes;
    }

    public String getWebUrl() {
        return webUrl;
    }

    public boolean isEditable() {
        return editable;
    }

    public void setEditable(boolean editable) {
        this.editable = editable;
    }

    public void setLikeId(String likeId) {
        this.likeId = likeId;
    }

    public String getLikeId() {
        return likeId;
    }
}
