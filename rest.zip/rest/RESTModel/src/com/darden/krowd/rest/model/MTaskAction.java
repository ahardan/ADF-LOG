package com.darden.krowd.rest.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import oracle.bpel.services.workflow.task.model.ActionType;

@XmlRootElement(name = "action")
@XmlType(name = "action")
public class MTaskAction implements Serializable{
    private static final long serialVersionUID = -1914364606658720236L;
    private String action;
    private String displayName;
    
    public MTaskAction() {
        super();
    }    
    
    public MTaskAction(ActionType actionType) {
        super();
        this.action=actionType.getAction();
        this.displayName=actionType.getDisplayName();
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getAction() {
        return action;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
