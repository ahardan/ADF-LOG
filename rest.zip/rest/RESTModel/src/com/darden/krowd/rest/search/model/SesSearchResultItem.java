package com.darden.krowd.rest.search.model;

import com.darden.krowd.rest.model.ContentItem;

import java.io.Serializable;

import java.util.Calendar;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import oracle.search.query.webservice.client.CustomAttribute;
import oracle.search.query.webservice.client.DataGroup;
import oracle.search.query.webservice.client.ResultElement;

@XmlRootElement(name="searchresultitem")
@XmlType(name="searchresultitem")
public class SesSearchResultItem implements Serializable{
    private static final long serialVersionUID = 99878651L;
    private String author;
    private String description;
    private String url;
    private String snippet;
    private String title;
    private Date lastModified;
    private String mimetype;
    private Integer score;
    private Integer docID;
    private String language;
    private Integer contentLength;
    private Long signature;
    private String infoSourceID;
    private String infoSourcePath;
    private DataGroup[] groups;
    private Boolean isDuplicate;
    private Boolean hasDuplicate;
    private String fedID;
    private CustomAttribute[] customAttributes;
    private ContentItem content;

    public SesSearchResultItem() {
        super();
    }

    public SesSearchResultItem(ResultElement resultElement) {
        super();
        
        if(resultElement != null){
            this.author = resultElement.getAuthor();
            this.description = resultElement.getDescription();
            this.url = resultElement.getUrl();
            
            this.snippet = resultElement.getSnippet();
            if(snippet != null){
                this.snippet = snippet.replaceAll("\"", "\\\"");
                this.snippet = snippet.replaceAll("[^\\x00-\\x7F]", "");//filter non-ascii chars
            }
            this.title = resultElement.getTitle().replaceAll("\"", "\\\"");
            if(title != null){
                this.title = title.replaceAll("\"", "\\\"");
                this.title = title.replaceAll("[^\\x00-\\x7F]", "");//filter non-ascii chars
            }
            this.lastModified = resultElement.getLastModified();
            this.mimetype = resultElement.getMimetype();
            this.score = resultElement.getScore();
            this.docID = resultElement.getDocID();
            this.language = resultElement.getLanguage();
            this.contentLength = resultElement.getContentLength();
            this.signature = resultElement.getSignature();
            this.infoSourceID = resultElement.getInfoSourceID();
            this.infoSourcePath = resultElement.getInfoSourcePath();
            this.groups = resultElement.getGroups();
            this.isDuplicate = resultElement.isIsDuplicate();
            this.hasDuplicate = resultElement.isHasDuplicate();
            this.fedID = resultElement.getFedID();
            this.customAttributes = resultElement.getCustomAttributes();
        }
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getAuthor() {
        return author;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUrl() {
        return url;
    }

    public void setSnippet(String snippet) {
        this.snippet = snippet;
    }

    public String getSnippet() {
        return snippet;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setLastModified(Date lastModified) {
        this.lastModified = lastModified;
    }

    public Date getLastModified() {
        return lastModified;
    }

    public void setMimetype(String mimetype) {
        this.mimetype = mimetype;
    }

    public String getMimetype() {
        return mimetype;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    public Integer getScore() {
        return score;
    }

    public void setDocID(Integer docID) {
        this.docID = docID;
    }

    public Integer getDocID() {
        return docID;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getLanguage() {
        return language;
    }

    public void setContentLength(Integer contentLength) {
        this.contentLength = contentLength;
    }

    public Integer getContentLength() {
        return contentLength;
    }

    public void setSignature(Long signature) {
        this.signature = signature;
    }

    public Long getSignature() {
        return signature;
    }

    public void setInfoSourceID(String infoSourceID) {
        this.infoSourceID = infoSourceID;
    }

    public String getInfoSourceID() {
        return infoSourceID;
    }

    public void setInfoSourcePath(String infoSourcePath) {
        this.infoSourcePath = infoSourcePath;
    }

    public String getInfoSourcePath() {
        return infoSourcePath;
    }

    public void setGroups(DataGroup[] groups) {
        this.groups = groups;
    }

    public DataGroup[] getGroups() {
        return groups;
    }

    public void setIsDuplicate(Boolean isDuplicate) {
        this.isDuplicate = isDuplicate;
    }

    public Boolean getIsDuplicate() {
        return isDuplicate;
    }

    public void setHasDuplicate(Boolean hasDuplicate) {
        this.hasDuplicate = hasDuplicate;
    }

    public Boolean getHasDuplicate() {
        return hasDuplicate;
    }

    public void setFedID(String fedID) {
        this.fedID = fedID;
    }

    public String getFedID() {
        return fedID;
    }

    public void setCustomAttributes(CustomAttribute[] customAttributes) {
        this.customAttributes = customAttributes;
    }

    public CustomAttribute[] getCustomAttributes() {
        return customAttributes;
    }

    public void setContent(ContentItem content) {
        this.content = content;
    }

    public ContentItem getContent() {
        return content;
    }
}
