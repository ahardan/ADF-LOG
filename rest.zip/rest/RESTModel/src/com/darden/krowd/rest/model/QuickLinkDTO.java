package com.darden.krowd.rest.model;
import java.util.Map;

import oracle.jbo.domain.Number;

public class QuickLinkDTO {
    public QuickLinkDTO() {
        super();
    }
    
    public QuickLinkDTO(Map quickLink) {
        super();
        oracle.jbo.domain.Number qlId = (Number)quickLink.get("QlId");
        oracle.jbo.domain.Number targt = (Number)quickLink.get("Target");
        String mandatory = (String)quickLink.get("IsMandatory");
        String dfault = (String)quickLink.get("IsDefault");
        String internalLink = (String)quickLink.get("InternalLink");
        String mobileLink = (String)quickLink.get("MobileLink");
        String keywords = (String)quickLink.get("Keywords");
        
        this.id=qlId.intValue();        
        this.target=targt==null?"_blank":(targt.intValue()==0?"_blank":"_self");
        //char encode
//        Object name = quickLink.get("DisplayName");
//        Charset utf8charset = Charset.forName("UTF-8");
//        ByteBuffer bf = utf8charset.encode(name.toString());
//        byte[] bytes = bf.array();
//        this.displayName = new String(bytes);
        this.displayName = quickLink.get("DisplayName").toString();
        
        
        if(mandatory!=null && mandatory.compareTo("Y")==0)
            this.mandatory=true;

        if(internalLink!=null && internalLink.compareTo("Y")==0)
            this.internalLink=true;
        
        if(mobileLink!=null && mobileLink.compareTo("Y")==0)
            this.mobileLink=true;
        
        if(dfault!=null && dfault.compareTo("Y")==0)
            this.dfault=true;
        
        this.url = (String)quickLink.get("Url");
        this.keywords = keywords;
    }
    
    private int id;
    private String displayName;
    private String target;
    private boolean mandatory;
    private String url;
    private boolean dfault;
    private boolean favorite;
    private boolean internalLink;
    private boolean mobileLink;
    
    private String keywords;

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
    
    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }
    
    public String getKeywords() {
        return keywords;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public String getTarget() {
        return target;
    }

    public void setMandatory(boolean mandatory) {
        this.mandatory = mandatory;
    }

    public boolean isMandatory() {
        return mandatory;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUrl() {
        return url;
    }

    public void setDfault(boolean dfault) {
        this.dfault = dfault;
    }

    public boolean isDfault() {
        return dfault;
    }

    public void setInternalLink(boolean internalLink) {
        this.internalLink = internalLink;
    }

    public boolean isInternalLink() {
        return internalLink;
    }

    public void setMobileLink(boolean mobileLink) {
        this.mobileLink = mobileLink;
    }

    public boolean isMobileLink() {
        return mobileLink;
    }
}
