package com.darden.krowd.rest.model;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="contact")
@XmlType(name="contact")
public class Contact {
    String name;
    String relationship;
    String primaryPhone;
    String otherPhone;
    Address address;
    
    public Contact() {
        super();
    }
}
