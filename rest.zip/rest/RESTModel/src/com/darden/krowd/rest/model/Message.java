package com.darden.krowd.rest.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="message")
@XmlType(name="message")
public class Message {
    private String subject;
    private List<String> receipents;
    private String message;
    private String serviceId;
    private String objectType;
    private String objectId;
    private String regionDef;
    
    private Long messageId;
    
    public Message() {
        super();
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getSubject() {
        return subject;
    }

    public void setReceipents(List<String> receipents) {
        this.receipents = receipents;
    }

    public List<String> getReceipents() {
        return receipents;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    public String getServiceId() {
        return serviceId;
    }

    public void setObjectType(String objectType) {
        this.objectType = objectType;
    }

    public String getObjectType() {
        return objectType;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }

    public String getObjectId() {
        return objectId;
    }

    public void setRegionDef(String regionDef) {
        this.regionDef = regionDef;
    }

    public String getRegionDef() {
        return regionDef;
    }

    public void setMessageId(Long messageId) {
        this.messageId = messageId;
    }

    public Long getMessageId() {
        return messageId;
    }
}
