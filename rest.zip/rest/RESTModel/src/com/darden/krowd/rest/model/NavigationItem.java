package com.darden.krowd.rest.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

public class NavigationItem implements Serializable{
    private String Id;
    private String title;
    private String goLinkPrettyUrl;
    private List<NavigationItem> children;
    public NavigationItem() {
        super();
        children = new ArrayList<NavigationItem>();
    }

    public void setId(String Id) {
        this.Id = Id;
    }

    public String getId() {
        return Id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setGoLinkPrettyUrl(String goLinkPrettyUrl) {
        this.goLinkPrettyUrl = goLinkPrettyUrl;
    }

    public String getGoLinkPrettyUrl() {
        return goLinkPrettyUrl;
    }

    public void setChildren(List<NavigationItem> children) {
        this.children = children;
    }

    public List<NavigationItem> getChildren() {
        return children;
    }
}
