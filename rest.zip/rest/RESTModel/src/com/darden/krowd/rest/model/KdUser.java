package com.darden.krowd.rest.model;

import com.darden.global.enterpriseobjects.core.commonebo.v1.PersonType;
import com.darden.global.enterpriseobjects.core.ebo.worker.v1.EmployeeProfileType;
import com.darden.global.enterpriseobjects.core.ebo.worker.v1.EmploymentAssignmentSupervisionType;
import com.darden.global.enterpriseobjects.core.ebo.worker.v1.ShowEmployeeProfileDataAreaType;

import com.darden.global.enterpriseobjects.core.ebo.worker.v1.ShowEmployeeProfileResponseType;

import java.util.Date;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import oracle.security.idm.User;

@XmlRootElement(name="user")
@XmlType(name="user")
public class KdUser {
    
    PersonType person;
    
    public KdUser(ShowEmployeeProfileDataAreaType empData,User user) {
        super();
    }
    
    public KdUser(ShowEmployeeProfileDataAreaType empData) {
        super();
        if(empData != null){
            ShowEmployeeProfileResponseType empProfRespType = empData.getShowEmployeeProfileResponse();
            if(empProfRespType !=null){
                EmployeeProfileType empProfType = empProfRespType.getEmployeeProfileDetails();
                if(empProfType != null){
                    person = empProfType.getPerson();
                }
            }
        }
    }

    public KdUser(User user) {
        super();
    }


    public PersonType getPerson() {
        return person;
    }
}
