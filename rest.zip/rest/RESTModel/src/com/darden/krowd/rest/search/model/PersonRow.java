package com.darden.krowd.rest.search.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import oracle.security.idm.IMException;
import oracle.security.idm.User;
import oracle.security.idm.UserProfile;

import org.apache.commons.lang.StringUtils;

@XmlRootElement(name = "person")
@XmlType(name = "person")
public class PersonRow implements Serializable {
    private static final long serialVersionUID = -9204974441916270935L;

    private transient User user;
    private String guid;
    private String encodedGuid;
    private boolean connected;
    private boolean invited;
    private String photoUri;
    
    private String userName;
    private String displayName;
    private String description;
    private String physicalDeliveryOfficeName;
    private String jobFunction;
    private String company;
    private String streetAddress;
    private String businessUnit;
    private String title;
    
    
    public PersonRow() {
        super();
    }
    
    public PersonRow(User user) {
        this.user = user;
    }
    
    public void setPhotoURI(String photoURI){
        this.photoUri = photoURI;
    }    
    
    public void setEncodedGuid(String encodedGuid){
        this.encodedGuid = encodedGuid;
    }
    
    public void processUser() {
        UserProfile userProfile;
        try {
            userProfile = user.getUserProfile();
            
            try{
                this.userName = userProfile.getUserName();
            }catch(Exception e){
                
            }

            try{
                this.displayName = userProfile.getDisplayName();
            }catch(Exception e){
                
            }

            try{
                guid = user.getUserProfile().getGUID();
            }catch(Exception e){
                
            }
            
            try{
                description = (String)userProfile.getPropertyVal("description");
                if(StringUtils.isBlank(description))
                    description=null;
            }catch(Exception e){
                
            }

            try{
                physicalDeliveryOfficeName = (String)userProfile.getPropertyVal("physicalDeliveryOfficeName");
                if(StringUtils.isBlank(physicalDeliveryOfficeName))
                    physicalDeliveryOfficeName=null;                
            }catch(Exception e){
                
            }
            
            try{
                jobFunction = (String)userProfile.getPropertyVal("Darden-Job-Function");
                if(StringUtils.isBlank(jobFunction))
                    jobFunction=null;                
            }catch(Exception e){
                
            }     
            
            try{
                title = (String)userProfile.getPropertyVal("title");
                if(StringUtils.isBlank(title))
                    title=null;                
            }catch(Exception e){
                
            }               
            
            try{
                company = (String)userProfile.getPropertyVal("company");
                if(StringUtils.isBlank(company))
                    company=null;                
            }catch(Exception e){
                
            }    
            
            try{
                streetAddress = (String)userProfile.getPropertyVal("streetAddress");
                if(StringUtils.isBlank(streetAddress))
                    streetAddress=null;                
            }catch(Exception e){
                
            }      
            
            try{
                businessUnit = (String)userProfile.getPropertyVal("Darden-Business-Unit");
                if(StringUtils.isBlank(businessUnit))
                    businessUnit=null;                
            }catch(Exception e){
                
            }  
                        
        } catch (IMException e) {
        }
    }
    
    public void setConnected(boolean connected) {
        this.connected = connected;
    }

    public boolean isConnected() {
        return connected;
    }

    public void setInvited(boolean invited) {        
        this.invited = invited;
    }

    public boolean isInvited() {
        return invited;
    }

    public String getGuid() {
        return guid;
    }

    public String getPhotoUri() {
        return photoUri;
    }

    public String getUserName() {
        return userName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getDescription() {
        return description;
    }

    public String getPhysicalDeliveryOfficeName() {
        return physicalDeliveryOfficeName;
    }

    public String getJobFunction() {
        return jobFunction;
    }

    public String getCompany() {
        return company;
    }

    public String getStreetAddress() {
        return streetAddress;
    }

    public String getBusinessUnit() {
        return businessUnit;
    }

    public String getTitle() {
        return title;
    }

    public String getEncodedGuid() {
        return encodedGuid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setPhysicalDeliveryOfficeName(String physicalDeliveryOfficeName) {
        this.physicalDeliveryOfficeName = physicalDeliveryOfficeName;
    }

    public void setJobFunction(String jobFunction) {
        this.jobFunction = jobFunction;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public void setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
    }

    public void setBusinessUnit(String businessUnit) {
        this.businessUnit = businessUnit;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
