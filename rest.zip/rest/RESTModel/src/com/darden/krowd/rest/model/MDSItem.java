package com.darden.krowd.rest.model;

import java.io.Serializable;

import java.math.BigInteger;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import oracle.mds.naming.DocumentName;
import oracle.mds.naming.PackageName;
import oracle.mds.naming.ResourceName;

import oracle.webcenter.jaxrs.framework.model.Linked;

@XmlRootElement(name="mdItem")
@XmlType(name="mdItem")
public class MDSItem extends Linked implements Serializable{    
    //for tree structure
    private static final long serialVersionUID = 8436887810803435804L;
    private String id;
    private String parent;
    private String text;
    private String icon;
    private boolean opened;
    private boolean disabled;
    private boolean selected;
    private Map<String,Boolean> state;
    private transient Object children;
    private Map<String,String> li_attr;
    private Map<String,String> a_attr;

    private String absoluteName;
    private String localName;
    private String packagePath;
    
    private boolean customizationName;
    private boolean custTranslationName;
    private boolean mDXName;
    private boolean packageName;
    private boolean sandboxName;
    private boolean specialName;
    private boolean translationName;
    private boolean metadataObjectName;
    
    private int hashCode;
    private String type;
    

    public MDSItem() {
        super();
    }
    
    public MDSItem(ResourceName resource){
//        BigInteger bigInt = new BigInteger(resource.getAbsoluteName().getBytes());
//        this.id = bigInt+"";
        this.id=resource.getAbsoluteName();
        this.text=resource.getLocalName();
        this.absoluteName=resource.getAbsoluteName();
        this.localName=resource.getLocalName();
        this.packagePath=resource.getPackageName();        
//        this.parent = resource.getPackageName();
//        if(this.parent.compareTo("/")==0)
//            this.parent="#";

        this.opened=false;
        this.disabled=false;
        this.selected = false;
        
        this.customizationName = resource.isCustomizationName();
        this.custTranslationName = resource.isCustTranslationName();
        this.mDXName = resource.isMDXName();
        this.packageName = resource.isPackageName();
        this.sandboxName = resource.isSandboxName();
        this.specialName = resource.isSpecialName();
        this.translationName = resource.isTranslationName();
        this.hashCode = resource.hashCode();
        
        if(resource instanceof DocumentName){
            DocumentName docName = (DocumentName)resource;
            this.type = docName.getExtension();
            this.metadataObjectName = docName.isMetadataObjectName();
            this.children=Boolean.FALSE;
        }
        if(resource instanceof PackageName){
            this.children=Boolean.TRUE;
            this.type="folder";
        }
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }

    public Map<String, Boolean> getState() {
        if(state == null)
            state = new HashMap<String,Boolean>();
        state.put("opened",this.opened);
        state.put("disabled",this.disabled);
        state.put("selected",this.selected);
        return state;
    }

    public String getId() {
        return id;
    }

    public String getIcon() {
        return icon;
    }

    public Object getChildren() {
        return children; //set as List<MDSItem>
    }

    public Map<String, String> getLi_attr() {
        return li_attr;
    }

    public Map<String, String> getA_attr() {
        return a_attr;
    }

    public String getParent() {
        return parent;
    }

    public String getAbsoluteName() {
        return absoluteName;
    }

    public String getLocalName() {
        return localName;
    }

    public String getPackagePath() {
        return packagePath;
    }

    public int getHashCode() {
        return hashCode;
    }

    public boolean isOpened() {
        return opened;
    }

    public boolean isDisabled() {
        return disabled;
    }

    public boolean isSelected() {
        return selected;
    }

    public boolean isCustomizationName() {
        return customizationName;
    }

    public boolean isCustTranslationName() {
        return custTranslationName;
    }

    public boolean isMDXName() {
        return mDXName;
    }

    public boolean isPackageName() {
        return packageName;
    }

    public boolean isSandboxName() {
        return sandboxName;
    }

    public boolean isSpecialName() {
        return specialName;
    }

    public boolean isTranslationName() {
        return translationName;
    }

    public void setMetadataObjectName(boolean metadataObjectName) {
        this.metadataObjectName = metadataObjectName;
    }

    public boolean isMetadataObjectName() {
        return metadataObjectName;
    }

    public String getType() {
        return type;
    }
}
