package com.darden.krowd.rest.model;

import java.io.Serializable;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

import oracle.webcenter.jaxrs.framework.model.Linked;
import com.darden.krowd.framework.PersonReference;
import oracle.webcenter.likes.Like;

@XmlRootElement(name="like")
@XmlType(name="like")
public class LikeItem extends Linked implements Serializable {
    private static final long serialVersionUID = 5893098255486293286L;
    protected String id;
    protected String authorId;
    protected Date created;
    protected boolean deletable;
    protected transient PersonReference author;


    public LikeItem()
    {
    }

    public LikeItem(Like like)
    {
      setId(like.getLikeId());
      setCreated(like.getVotedOn());
      setAuthorId(like.getVotedBy());
      setAuthor(PersonReference.GetPersonByGuid(like.getVotedBy()));
      this.deletable = like.isDeleteable();
    }

    public static LikeItem GetLike(Like like)
    {
      if (like == null) {
        return null;
      }

      if (like.getLikeId() == null) {
        return null;
      }

      return new LikeItem(like);
    }

    public String resourceType() {
      return "urn:oracle:webcenter:like";
    }
    
    public void setId(String likeId) {
        this.id = likeId;
    }

    public String getId() {
        return id;
    }

    public void setAuthorId(String votedBy) {
        this.authorId = votedBy;
    }

    public String getAuthorId() {
        return authorId;
    }

    public void setCreated(Date votedOn) {
        this.created = votedOn;
    }

    public Date getCreated() {
        return created;
    }

    public void setDeletable(boolean isDeletable) {
        this.deletable = isDeletable;
    }
    
    @XmlTransient
    public boolean isDeletable() {
        return deletable;
    }

    public void setAuthor(PersonReference author) {
        this.author = author;
    }

    public PersonReference getAuthor() {
        return author;
    }
}
