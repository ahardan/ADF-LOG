@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.stellent.com/wcm-data/ns/8.0.0",
                                     elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED,
                                     xmlns={@XmlNs(prefix="wcm",namespaceURI="http://www.stellent.com/wcm-data/ns/8.0.0")}                                     
                                     )
package com.darden.krowd.content.xml.wcm.data;

import javax.xml.bind.annotation.XmlNs;
import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;