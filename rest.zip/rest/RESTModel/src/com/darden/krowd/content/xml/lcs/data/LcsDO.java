package com.darden.krowd.content.xml.lcs.data;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class LcsDO {
    private String objectId;
    private String serviceId;
    private String objectType;
    private String activityType;
    private Integer likes;
    private Integer comments;
    private Integer shares;
    private Boolean hasUserLiked;
    private Boolean hasUserCommented;
    
    public LcsDO() {
        super();
    }

    public LcsDO(String objectId, String serviceId, String objectType) {
        super();
        this.objectId = objectId;
        this.serviceId = serviceId;
        this.objectType = objectType;
    }


    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }

    public String getObjectId() {
        return objectId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    public String getServiceId() {
        return serviceId;
    }

    public void setObjectType(String objectType) {
        this.objectType = objectType;
    }

    public String getObjectType() {
        return objectType;
    }

    public void setActivityType(String activityType) {
        this.activityType = activityType;
    }

    public String getActivityType() {
        return activityType;
    }

    public void setLikes(Integer likes) {
        this.likes = likes;
    }

    public Integer getLikes() {
        return likes;
    }

    public void setComments(Integer comments) {
        this.comments = comments;
    }

    public Integer getComments() {
        return comments;
    }

    public void setShares(Integer shares) {
        this.shares = shares;
    }

    public Integer getShares() {
        return shares;
    }

    public void setHasUserLiked(Boolean hasUserLiked) {
        this.hasUserLiked = hasUserLiked;
    }

    public Boolean getHasUserLiked() {
        return hasUserLiked;
    }

    public void setHasUserCommented(Boolean hasUserCommented) {
        this.hasUserCommented = hasUserCommented;
    }

    public Boolean getHasUserCommented() {
        return hasUserCommented;
    }
}
