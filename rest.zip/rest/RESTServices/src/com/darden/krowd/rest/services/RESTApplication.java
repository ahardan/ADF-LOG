package com.darden.krowd.rest.services;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("rest/*")
public class RESTApplication extends Application {
    public Set<Class<?>> getClasses() {
        Set classes = new HashSet();

        //    classes.add(ProcessesPath.class);
        //    classes.add(TasksPath.class);
        //    classes.add(IdentityPath.class);
        //    classes.add(BPMRuntimeEndpoint.class);
        //classes.add(HWManager.class);
        classes.add(ContentResource.class);
        classes.add(WCResource.class);
        classes.add(PeopleResource.class);
        classes.add(LCSResource.class);
        classes.add(RestaurantResource.class);
        classes.add(ReportResource.class);
        classes.add(LoginResource.class);
        classes.add(NotificationsResource.class);
        classes.add(SearchResource.class);
        //classes.add(JAXBContextResolver.class);

        return classes;
    }
}
