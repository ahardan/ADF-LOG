package com.darden.krowd.rest.services;

import com.darden.krowd.common.identity.LdapHelper;
import com.darden.krowd.common.navigation.Attribute;
import com.darden.krowd.common.navigation.Content;
import com.darden.krowd.common.navigation.Link;
import com.darden.krowd.common.util.CacheUtil;
import com.darden.krowd.rest.exceptions.BadRequestException;
import com.darden.krowd.spaceswidgets.ui.bean.AdditionalInfoBean;
import com.darden.krowd.spaceswidgets.ui.bean.AdditionalInfoPojo;
import com.darden.krowd.spaceswidgets.ui.bean.ListSpacesBean;
import com.darden.krowd.spaceswidgets.ui.bean.MemberPojo;
import com.darden.krowd.spaceswidgets.ui.bean.SpaceHeaderPojo;

import com.sun.jersey.multipart.FormDataBodyPart;
import com.sun.jersey.multipart.FormDataMultiPart;

import java.io.InputStream;
import java.io.StringWriter;

import java.security.SecureRandom;

import java.sql.SQLException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;

import javax.el.ELContext;
import javax.el.ExpressionFactory;
import javax.el.ValueExpression;

import javax.faces.application.Application;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import oracle.adf.rc.catalog.CatalogElement;
import oracle.adf.rc.config.ConfigurationException;
import oracle.adf.rc.core.NavigationManager;
import oracle.adf.rc.core.RCInstance;
import oracle.adf.rc.core.RCSession;
import oracle.adf.rc.core.SessionProperties;
import oracle.adf.rc.exception.CatalogException;
import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.share.prefs.ADFPreferencesFactory;
import oracle.adf.share.security.SecurityContext;

import oracle.mds.core.ConcurrentMOChangeException;
import oracle.mds.core.MDSSession;
import oracle.mds.core.MetadataNotFoundException;
import oracle.mds.core.MetadataObject;
import oracle.mds.core.ValidationException;
import oracle.mds.core.ValidationType;
import oracle.mds.cust.CustClassList;
import oracle.mds.cust.CustomizationClass;
import oracle.mds.naming.ReferenceException;
import oracle.mds.persistence.MDSIOException;

import oracle.security.idm.User;
import oracle.security.idm.UserProfile;

import oracle.webcenter.content.integration.cache.Cache;
import oracle.webcenter.framework.security.idm.UserCacheManager;
import oracle.webcenter.jaxrs.framework.annotation.CacheControl;
import oracle.webcenter.jaxrs.framework.service.RestService;
import oracle.webcenter.jaxrs.framework.uri.UriService;
import oracle.webcenter.navigationframework.ResourceNotFoundException;
import oracle.webcenter.page.model.PageDef;
import oracle.webcenter.page.model.PageService;
import oracle.webcenter.page.model.PageServiceFactory;
import oracle.webcenter.page.model.config.PageServiceConfig;
import oracle.webcenter.peopleconnections.profile.ProfileFactory;
import oracle.webcenter.peopleconnections.profile.UserProfileManager;
import oracle.webcenter.peopleconnections.profile.WCUserProfile;
import oracle.webcenter.portal.api.NavigationNode;
import oracle.webcenter.portal.api.NavigationNodePropertyBean;
import oracle.webcenter.portal.api.Page;
import oracle.webcenter.portal.api.PagePropertyBean;
import oracle.webcenter.portal.api.Portal;
import oracle.webcenter.portal.api.PortalObjectRepository;
import oracle.webcenter.portal.api.query.PortalObjectQueryFactory;
import oracle.webcenter.portal.utils.BeanLookup;
import oracle.webcenter.portalframework.sitestructure.SiteStructure;
import oracle.webcenter.portalframework.sitestructure.SiteStructureContext;
import oracle.webcenter.security.common.WCSecurityUtility;
import oracle.webcenter.webcenterapp.internal.metadata.WebCenterSiteCC;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;

import org.codehaus.jackson.map.ObjectMapper;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


@Path("/wc")
@Produces("application/json")
@CacheControl(eTag = "user")
public class WCResource {

    private static final ADFLogger logger = ADFLogger.createADFLogger(WCResource.class);      
    @Context private HttpServletRequest httpRequest;
    @Context private HttpServletResponse httpResponse;
    
    @Context javax.servlet.ServletContext context;
    
    @RestService
    protected UriService uriService;    
    private Map<String,PageService> pageServiceMap;
    
    private PortalObjectRepository mPortalObjectRepository;
    private PortalObjectQueryFactory mQueryFactory;
    
    private boolean elFailed;
    
    public WCResource() {
        super();
        this.mPortalObjectRepository = (PortalObjectRepository)BeanLookup.lookup((Class)PortalObjectRepository.class);
        this.mQueryFactory = this.mPortalObjectRepository.getQueryFactory();
        this.elFailed = false;
    }
    
    private PageService getPageService(String scope){
        if(pageServiceMap == null){
            pageServiceMap = new HashMap<String,PageService>();
        }
        
        PageService pageService = pageServiceMap.get(scope);
        
        if(pageService !=null){
            return pageService;
        }else{
            PageServiceConfig config = new PageServiceConfig(getMDSSession(),scope);
            pageService = PageServiceFactory.createInstance(config);
            pageService.setScope(scope);
            pageServiceMap.put(scope,pageService);
            return pageService;
        }            
    }
       
    
    @GET
    @Path("/trusttoken")
    @Produces("application/json")
    public Response getTrustServiceToken() {  
        try{
            logger.info("Before invoking Issue Trust Service Security Token.");
            String b64EncodedToken = WCSecurityUtility.issueTrustServiceSecurityToken();
            logger.info("Response from the Trust Service :"+ b64EncodedToken);
            HashMap<String,String> resp = new HashMap<String,String>();
            resp.put("trustToken",b64EncodedToken);
            return Response.status(200).entity(b64EncodedToken).build();
        }catch(Exception e){
            throw new BadRequestException(e.getMessage());
        }
    }    
    
    private FacesContext getFacesContext(){        
        // Get current FacesContext.
        FacesContext facesContext = FacesContext.getCurrentInstance();                 
        return facesContext;                 
    }
    
    private Object resovleFacesEl(String el){
        if(el == null){
            return null;
        }

        el = el.trim();
        int hashIdx = el.indexOf("#");
        int dolIdx = el.indexOf("$");

        if(hashIdx<0 && dolIdx <0){
            return el;
        }else{
            int pfsIdx = el.indexOf("pageFlowScope");
            if(pfsIdx >=0){
                return null;
            }
        }
        try{
            FacesContext facesContext = this.getFacesContext();
            Application app = facesContext.getApplication();
            ExpressionFactory elFactory = app.getExpressionFactory();
            ELContext elContext = facesContext.getELContext();
            ValueExpression valueExp = elFactory.createValueExpression(elContext,el,Object.class);
            Object result = valueExp.getValue(elContext);
            logger.finest("EL Expression : {0} with result {1}", new Object[]{el,result});    
            return valueExp.getValue(elContext);
        }catch(Exception e){
            logger.severe("---------------------- Failed to Evaluate EL ----" + el);
            this.elFailed = true;
            logger.severe(e);
            return null;
        }        
    }
    
    private String resolveTextEl(String textWithEl){
        Object ret =  this.resovleFacesEl(textWithEl);        
        if(ret == null){
            return null;
        }else{
            return ret.toString();
        }                
    }
    
   /* @GET
    @Path("/mergeMdsDocs")
    @Produces("application/json")
    public Response mergeMdsDocs(@QueryParam("layer") String layer,@QueryParam("package") String packageName,@QueryParam("endsWith") String endsWith){
        try {
            if(StringUtils.isBlank(layer) || StringUtils.isBlank(endsWith) || StringUtils.isBlank(packageName))
                throw new BadRequestException("layer / endsWith /packageName  cannot be blank");       
            layer = layer.toLowerCase();
            return Response.status(200).entity(mergeSiteLevelCustomizations(layer,packageName, endsWith)).build();
        } catch (Exception e) {
            logger.severe(e);
            throw new BadRequestException(e);    
        }            
    }    
    
    private List<String> mergeSiteLevelCustomizations(String layer,String packageName,String endsWith){
        MDSSession mdsReadSession =(MDSSession)ADFContext.getCurrent().getMDSSessionAsObject();
        MDSInstance mdsInstance = (MDSInstance)ADFContext.getCurrent().getMDSInstanceAsObject();
        MDSSession mdsWriteSession = mdsInstance.createSession(new SessionOptions(null, null,CustConfig.NO_CUSTOMIZATIONS),null);            
        ///oracle/webcenter/page/scopedMD/s8bba98ff_4cbb_40b8_beee_296c916a23ed/businessRolePages
        logger.info("-- Package Name -- "+packageName);
        logger.info("-- Ends with -- "+endsWith);
        NameQueryImpl query = new NameQueryImpl(mdsReadSession, ConditionFactory.createNameCondition(packageName+"/mdssys/cust/site/"+layer+"/","%"+endsWith,true));            
        Iterator<oracle.mds.query.DocumentResult> result = query.execute();
        List<String> docs = new ArrayList<String>();
        oracle.mds.naming.DocumentName mdsDocFullName=null;
        String docAbsName;
        while (result.hasNext()) {
            try {
                mdsDocFullName=null;
                oracle.mds.query.DocumentResult qr = result.next();
                mdsDocFullName = qr.getDocumentName();
                docAbsName = mdsDocFullName==null?null:mdsDocFullName.getAbsoluteName();
                logger.info("=== Processing MDS Doc === "+docAbsName);
                String mdsDocName = qr.getResourceName().getLocalName();                    
                mdsReadSession.flushChanges(false,new ValidationType[] { ValidationType.RELATIONSHIP_VALIDATION });                    
                mdsReadSession.flushChanges(false, new ValidationType[] { ValidationType.RELATIONSHIP_VALIDATION });                    
                String baseDocFilePath =packageName+"/"+mdsDocName.substring(0, mdsDocName.lastIndexOf("."));                                    
                CustomizationClass[] custClass = new CustomizationClass[] { new WebCenterSiteCC() };
                CustClassList custCCList = new CustClassList(custClass);                                    
                MetadataObject mo11 =mdsReadSession.getMetadataObject(baseDocFilePath,custCCList, null);
                Document mergedDoc = mo11.getDocument(true);
                String mergedXMLStr = getDocumentAsString(mergedDoc);
                docs.add(mergedXMLStr);           
                logger.fine("==== Constructed Merged XML ===");
                MOReference baseDocRef =mdsWriteSession.getMOReference(baseDocFilePath);
                MetadataObject baseMO = mdsWriteSession.getMutableMO(baseDocRef);                
                
                Document baseDoc = baseMO.getDocument();
                DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                DocumentBuilder builder;
                builder = factory.newDocumentBuilder();
                baseDoc = builder.parse(new InputSource(new StringReader(mergedXMLStr)));      
                logger.fine("==== Parsed and constructed Document ===");
                mdsWriteSession.deleteAllCustomizations(baseDocRef);
                logger.fine("==== Deleted All Customizations ===");
                mdsWriteSession.deleteMetadataObject(baseDocRef);
                logger.fine("==== Deleted Metadata Object ===");
                mdsWriteSession.createMetadataObject(baseDocFilePath, baseDoc);                
                logger.fine("==== Created New Metadata Object ===");
                mdsWriteSession.flushChanges(false,new ValidationType[] { ValidationType.RELATIONSHIP_VALIDATION });
                logger.fine("==== Flushed Changes ===");
                MetadataObject baseMO1 = mdsReadSession.getMetadataObject(baseDocFilePath);
                baseDoc = baseMO1.getDocument();                
                mdsWriteSession.deleteAllCustomizations(baseDocRef);
                mdsWriteSession.flushChanges(false,new ValidationType[] { ValidationType.RELATIONSHIP_VALIDATION });                
                logger.info("=== Completed Processing for ===="+mdsDocFullName);
            }catch(Exception e){
                docs.add("Failed for "+mdsDocFullName);
                logger.severe(e);
            }
        }                        
        return docs;   
    }
    */
    
    private static String getDocumentAsString(Document document) throws Exception{
        Transformer transformer = TransformerFactory.newInstance().newTransformer();
        //subh,CWE ID: 611-Improper Restriction of XML External Entity Reference
        /*TransformerFactory tFactory=TransformerFactory.newInstance();
        try
        {
            tFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            DocumentBuilderFactory dfactory = DocumentBuilderFactory.newInstance();        
            dfactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            dfactory.setFeature("http://xml.org/sax/features/external-general-entities", false);
            dfactory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            logger.info(ex.getMessage());
        }
         
        Transformer transformer = tFactory.newTransformer();*/
        //

        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        //initialize StreamResult with File object to save to file
        StreamResult result = new StreamResult(new StringWriter());
        String xmlString = null;
        try {
            DOMSource source = new DOMSource(document);
            transformer.transform(source, result);
            xmlString = result.getWriter().toString();          
        } catch (TransformerException te) {
            te.printStackTrace();
        } catch (Exception e) {
              e.printStackTrace();
        } finally {
            result.getWriter().close();
        }
        return xmlString;           
    }    
    

    private static synchronized RCInstance getRCInstance() throws ConfigurationException {
        return RCInstance.getOrCreateInstance();
    }
    

    private static synchronized SiteStructureContext getSiteStructureContext() throws ConfigurationException {
        RCInstance rcInstance = null;
        rcInstance = getRCInstance();
        SiteStructureContext siteCtx = SiteStructureContext.getInstance(rcInstance);
        return siteCtx;
    }
    
    @POST
    @Path("/profile/photo")
    @Consumes({"multipart/form-data"})
    public Response updatePhoto(FormDataMultiPart formData)
    {
      try
      {
        String userId = ADFContext.getCurrent().getSecurityContext().getUserName();
        UserProfileManager profileManager = ProfileFactory.getProfileManager();
        WCUserProfile userProfile = profileManager.getProfileForUpdate(userId);
        
        FormDataBodyPart fdbpFileUpload = formData.getField("file");        
        InputStream is = fdbpFileUpload.getValueAs(InputStream.class);
        
        byte[] bytes = IOUtils.toByteArray(is);
        userProfile.updatePhoto(bytes);
        userProfile.save();
        userProfile.invalidatePhotoCache();
          
        SecureRandom rand = new SecureRandom();
        int n = rand.nextInt(100) + 1;
        
        Cache peopleCache = CacheUtil.getInstance().getCache(CacheUtil.CacheType.PEOPLE_CACHE);  
        peopleCache.put("PROFILE_PHOTO_UPDATE_"+userId.toUpperCase()+"_"+n,userId);
          
        return Response.ok().build();
      }
      catch (Exception e)
      {
        throw new BadRequestException(e);
      }
    }
    
    
    @GET   
    @Path("/preferences/{context}")
    public Response getPreferences(@PathParam("context")String context) {
        if (context == null || StringUtils.isBlank(context)) {
            throw new BadRequestException("Context values : {user,useroversystem,shareduser,sharedsystem,system} is mandatory");
        }
        else{
            try {
                ADFPreferencesFactory prefsFactory = new ADFPreferencesFactory();
                Preferences prefs = null;
                if(context.equalsIgnoreCase("USER")){
                    prefs = prefsFactory.userRoot();
                }else if(context.equalsIgnoreCase("SHAREDUSER")){
                    prefs = prefsFactory.sharedUserRoot();
                }else if(context.equalsIgnoreCase("SHAREDSYSTEM")){
                    prefs = prefsFactory.sharedSystemRoot();
                }else if(context.equalsIgnoreCase("SYSTEM")){
                    prefs = prefsFactory.systemRoot();
                }else if(context.equalsIgnoreCase("USEROVERSYSTEM")){
                    prefs = prefsFactory.userOverSystemRoot();                   
                }else{
                    throw new BadRequestException("Valid Context values : {user,useroversystem,shareduser,sharedsystem,system} is mandatory");
                }  
                
                return Response.status(Response.Status.OK).entity(getMapFromPreferences(prefs)).type(MediaType.APPLICATION_JSON).build();                                        
            } catch (Exception e) {
                throw new BadRequestException(e);
            }
        }
    }  
    
    private void setPreferencesFromMap(Preferences preferences,HashMap<String,String> map){
        if(map != null && preferences != null){
            for(Map.Entry entry : map.entrySet()){
                preferences.put((String)entry.getKey(), (String)entry.getValue());
            }
        }
    }
    
    private Map<String,String> getMapFromPreferences(Preferences preferences){
        Map<String,String> resp = new HashMap<String,String>();
        
        if(preferences != null){
            String keys[];
            try {
                keys = preferences.keys();
                
                for(int i=0; i<keys.length;i++){
                    resp.put(keys[i],preferences.get(keys[i],null));
                }
                
            } catch (BackingStoreException e) {
                logger.severe(e);
            }
        }
        
        return resp;
    }

    @POST
    @Path("/preferences/{context}")
    public Response setPreferences(@PathParam("context")String context,HashMap<String,String> params) {
        if (context == null || StringUtils.isBlank(context)) {
            
            throw new BadRequestException("Context values : {user,useroversystem,shareduser,sharedsystem,system} is mandatory");
        }
        else{
            try {
                ADFPreferencesFactory prefsFactory = new ADFPreferencesFactory();
                Preferences prefs = null;
                if(context.equalsIgnoreCase("USER")){
                    prefs = prefsFactory.userRoot();
                    setPreferencesFromMap(prefs,params);                        
                }else if(context.equalsIgnoreCase("SHAREDUSER")){
                    prefs = prefsFactory.sharedUserRoot();
                    setPreferencesFromMap(prefs,params);                    
                }else if(context.equalsIgnoreCase("SHAREDSYSTEM")){
                    prefs = prefsFactory.sharedSystemRoot();
                    setPreferencesFromMap(prefs,params);                    
                }else if(context.equalsIgnoreCase("SYSTEM")){
                    prefs = prefsFactory.systemRoot();
                    setPreferencesFromMap(prefs,params);                    
                }else if(context.equalsIgnoreCase("USEROVERSYSTEM")){
                    prefs = prefsFactory.userOverSystemRoot();
                    setPreferencesFromMap(prefs,params);                    
                }else{
                    throw new BadRequestException("Context values : {user,useroversystem,shareduser,sharedsystem,system} is mandatory");
                }        
                
                return Response.status(Response.Status.OK).type(MediaType.APPLICATION_JSON).build();                                        
                
            } catch (Exception e) {
                throw new BadRequestException(e);
            }
        }
    }    
        
    @PUT
    @Path("/evaluate-expression")
    public Response evaluateELPUT(List<String> expressions) {
        if(expressions != null && expressions.size() > 0){
            HashMap<String, Object> evals = new HashMap<String, Object>();
            for(String expression : expressions) {               
                evals.put(expression, this.evaluateEl(expression));
            }
            return Response.status(Response.Status.OK).entity(evals).type(MediaType.APPLICATION_JSON).build();   
                        
        }else{
            return Response.status(Response.Status.OK).type(MediaType.APPLICATION_JSON).build();   
        }
    }    

    @GET
    @Path("/catalog")
    public synchronized Response getCatalogModel(@QueryParam("scope") String scope,
                                                                @QueryParam("name") String name){
        CatalogElement catalogElement=null;
        HttpSession session = httpRequest.getSession();  
        catalogElement =(CatalogElement)session.getAttribute("CATALOG:"+scope+":"+name);

        SiteStructure navModel = null;
        try {
            if(StringUtils.isBlank(name)){
                navModel =(SiteStructure)getSiteStructureContext().getCurrentNavigationModel();
            }else{
                navModel = (SiteStructure)getSiteStructureContext().getNavigationModel(scope, name);    
            }     
            
            if(navModel != null){
                MDSSession mdsSession = getMDSSession();
                NavigationManager navMgr = getRCSession().getNavigationManager(mdsSession);
                String navigationFile = navModel.getMetadataId();
                catalogElement =navMgr.edit(navMgr.getDefaultScope(), navigationFile);  
                session.setAttribute("CATALOG:"+scope+":"+name,catalogElement);
            }            
        } catch (ConfigurationException e) {
            e.printStackTrace();
            throw new WebApplicationException(Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).type(MediaType.APPLICATION_JSON_TYPE).build());
        } catch (ResourceNotFoundException e) {
            e.printStackTrace();
            throw new WebApplicationException(Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).type(MediaType.APPLICATION_JSON_TYPE).build());
        }catch (CatalogException e) {
            e.printStackTrace();
            throw new WebApplicationException(Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).type(MediaType.APPLICATION_JSON_TYPE).build());
        }
        return Response.status(Response.Status.OK).entity(catalogElement.getId()).type(MediaType.APPLICATION_JSON_TYPE).build();
    }    


    private static synchronized MDSSession getMDSSession() {
        MDSSession mdsSess = (MDSSession)ADFContext.getCurrent().getMDSSessionAsObject();
        return mdsSess;
    }

    private static synchronized RCSession getRCSession() throws ConfigurationException,
                                                               CatalogException {
        final SessionProperties props = new SessionProperties();
        RCSession session = getRCInstance().createSession(props);
        return session;
    }
    
    @GET
    @Path("/communities")
    public Response getCommunities(@DefaultValue("ALL") @QueryParam("queryType") String queryType){
        ListSpacesBean bean = new ListSpacesBean(queryType);
        List<List<SpaceHeaderPojo>> spacesData = new ArrayList<List<SpaceHeaderPojo>>();
        try {
                if (queryType == null || queryType.equalsIgnoreCase("All")) {
                    spacesData = bean.getUserSpaces();
                } else if (queryType.equalsIgnoreCase("Trending")) {
                    spacesData = bean.getAllTrendingSpaces();
                } else if (queryType.equalsIgnoreCase("New")) {
                    spacesData = bean.getNewSpaces();
                }
            } catch (SQLException e) {
                e.printStackTrace();
                
            }
        
        return Response.ok(spacesData).type(MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("/communities/info")
    public Response getAdditionalInfoForCommunities(@QueryParam("spaceGuid") String spaceGuid){
        AdditionalInfoBean bean = new AdditionalInfoBean();
        AdditionalInfoPojo additionalInfo = bean.getRelatedUsers(spaceGuid);
        return Response.ok(additionalInfo).type(MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("/communities/{spaceGuid}/members")
    public Response getSpaceMembers(@PathParam("spaceGuid") String spaceGuid){
        AdditionalInfoBean bean = new AdditionalInfoBean();
        List<MemberPojo> members = bean.getSpaceMembers(spaceGuid);
        return Response.ok(members).type(MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("/communities/search")
    public Response searchCommunityByName(@QueryParam("spaceName") String spaceName){
        ListSpacesBean bean = new ListSpacesBean("All");
        List<SpaceHeaderPojo> spacesData = new ArrayList<SpaceHeaderPojo>();
        try {
                spacesData = bean.searchSpace(spaceName);
            } catch (SQLException e) {
                e.printStackTrace();
                
            }
        return Response.ok(spacesData).type(MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("/requestScope")
    public Response debugReqScope(@QueryParam("param") String param){
        Map<String, Object> reqScope = ADFContext.getCurrent().getRequestScope();
        for (Map.Entry<String, Object> entry : reqScope.entrySet()){
            logger.info(entry.getKey() + "/" + entry.getValue());            
        }
        
        SecureRandom rand = new SecureRandom();
        int n = rand.nextInt(100) + 1;
        
         CacheUtil cacheUtil = CacheUtil.getInstance();
        Cache peopleCache = cacheUtil.getCache(CacheUtil.CacheType.PEOPLE_CACHE);
        peopleCache.put("PROFILE_PHOTO_UPDATE_"+param.toUpperCase()+"_"+n, param);
        
        UserCacheManager d;
/*        System.out.println(peopleCache.getCacheConfig().getCacheName());
        CacheFactory fac = getCacheFactory();
        System.out.println(fac.getName());

        for(String n : fac.getLocalCacheNames()){
            System.out.println("----- Name ------"+n);
        }
        
        for(String n1: fac.getCacheNames()){
            System.out.println("------- Name 1 -----"+ n1);
        }
        
        System.out.println(fac.getClass().toString());
        
        System.out.println(peopleCache.getClass().toString());
        
        this.factory = new DefaultConfigurableCacheFactory("content" + "-coherence-cache-config.xml", CacheFactory.class.getClassLoader());
        
        System.out.println(this.factory);
        
        if(this.factory != null){
            System.out.println(this.factory.getScopeName());
        }
        
        NamedCache cache = this.factory.ensureCache("com.darden.krowd.userContentQueryCache",CacheFactory.class.getClassLoader());
        System.out.println(cache);
        
        if(cache != null){
            System.out.println(cache.getCacheName());
            System.out.println(cache.size());
            System.out.println(cache.getCacheService());
            System.out.println(cache.getCacheService().getInfo());
        }
         */
        
        

        

        return Response.ok("Done").type(MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("/appScope")
    public Response debugAppScope(){
        Map<String, Object> reqScope = ADFContext.getCurrent().getApplicationScope();
        for (Map.Entry<String, Object> entry : reqScope.entrySet()){
            logger.info(entry.getKey() + "/" + entry.getValue());            
        }
        return Response.ok("Done").type(MediaType.APPLICATION_JSON).build();
    }
    

    private boolean isManager(){
        boolean ret = false;
        SecurityContext securityContext = ADFContext.getCurrent().getSecurityContext();
        String currentUser = securityContext.getUserName();
        
        try{
            User user = LdapHelper.getInstance().getUser(currentUser);
            UserProfile profile = user.getUserProfile();            
            String jobFunction = (String)profile.getPropertyVal("Darden-Job-Function");

            if(jobFunction !=null){
                jobFunction = jobFunction.trim();
                if(jobFunction.compareToIgnoreCase("MANAGER")==0 || 
                   jobFunction.compareToIgnoreCase("MANAGER IN TRAINING")==0 ||
                   jobFunction.compareToIgnoreCase("GENERAL MANAGER")==0
                ){
                    ret=true;
                }                
            }else{
                String[] rolesArr = securityContext.getUserRoles();
                for(String role : rolesArr){
                    if(role.compareTo("Portal - General Manager") == 0 || role.compareTo("Portal - Manager") == 0){
                        ret=true;
                        break;
                    }
                }                                
            }            
        }catch(Exception e){
            logger.severe(e);
        }
        return ret;
    }
    
    @GET
    @Path("/page/{mdsDocPath : .+}")
    public Response getPage(@PathParam("mdsDocPath") String documentPath,@QueryParam("cache") @DefaultValue("true") boolean cache,
                            @QueryParam("locale") @DefaultValue("en") String locale){
        this.elFailed=false;
        if(documentPath == null){
            throw new BadRequestException("documentPath is mandatory.");
        }else{
            documentPath = "/"+documentPath;
        }
        
        SecurityContext securityContext = ADFContext.getCurrent().getSecurityContext();
        String userId = securityContext.getUserName();
        String[] userRoles = securityContext.getUserRoles();
        boolean isAdminUser = isAdmin(userRoles);
        
        if(isAdminUser){
            cache=false;
        }
        
        String frmCache = cache?(String)CacheUtil.getInstance().get(locale+userId+documentPath,CacheUtil.CacheType.USER):null;
        
        if(frmCache != null){
            logger.info("------ CACHED Page change found for user :-----------"+locale+"-"+userId+"-"+documentPath);
            return Response.ok(frmCache).type(MediaType.APPLICATION_JSON).build();
        }else{
            
            if(locale.equalsIgnoreCase("es")){
                this.getFacesContext().setViewRoot(new UIViewRoot());
                logger.info("--- locale will be set to -- "+ this.getFacesContext().getViewRoot().getLocale());
                UIViewRoot iViewRoot = FacesContext.getCurrentInstance().getViewRoot();
                iViewRoot.setLocale(new Locale("es"));
            }
            
            logger.info("------NO CACHED Page change found for user :-----------"+locale+"-"+userId+"-"+documentPath);
            Document document = null;            
            document =cache?(Document)CacheUtil.getInstance().get("MDSDOCUMENT:"+documentPath,CacheUtil.CacheType.APPLICATION):null;            
            if(document == null){  
                logger.info("------ NOT FOUND CACHED MDSDOCUMENT :-----------"+documentPath);
                CustomizationClass[] custClass = new CustomizationClass[] { new WebCenterSiteCC() };
                CustClassList custCCList = new CustClassList(custClass);                                                    
                MDSSession mdsReadSession =(MDSSession)ADFContext.getCurrent().getMDSSessionAsObject();
                MetadataObject mo11 = null;
                try {
                    mdsReadSession.flushChanges(false,new ValidationType[] { ValidationType.RELATIONSHIP_VALIDATION });
                    mo11 = mdsReadSession.getMetadataObject(documentPath,custCCList, null);
                    document = mo11.getDocument(true);
                    logger.info("------ CACHING MDSDOCUMENT :-----------"+documentPath);
                    CacheUtil.getInstance().put("MDSDOCUMENT:"+documentPath,document,CacheUtil.CacheType.APPLICATION); 
                } catch (MDSIOException e) {
                    logger.severe(e);
                } catch (ConcurrentMOChangeException e) {
                    logger.severe(e);
                } catch (ValidationException e) {
                    logger.severe(e);
                } catch (MetadataNotFoundException e) {
                    logger.severe(e);
                } catch (ReferenceException e) {
                    logger.severe(e);
                }                                                 
            }else{
                logger.info("------ FOUND CACHED MDSDOCUMENT :-----------"+documentPath);
            }
            
            if(document != null){
                Element docElem = null;
                DocumentBuilder dBuilder = null;
                DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                Map<String,Content[]> page = new HashMap<String,Content[]>(); 
                ArrayList<Content> left;
                ArrayList<Content> right;
                ArrayList<Content> center;
                
                try {                
                    dBuilder = dbFactory.newDocumentBuilder();
                    document.getDocumentElement().normalize();
                    docElem = document.getDocumentElement();
                    NodeList allPgl = document.getElementsByTagName("panelGroupLayout");
                    
                    boolean isManager = isManager();
                    httpRequest.getSession().setAttribute("isMyWorkManager", isManager);
                    
                    logger.info("---------- Calculated isMyWorkManager ----------"+ isManager);
                    
                    Node node;
                    Element pgl;
                    String styleClass;
                    for(int i=0;i<allPgl.getLength();i++){
                        node = allPgl.item(i);
                        if (node.getNodeType() == Node.ELEMENT_NODE ){
                            pgl = (Element)node;
                            styleClass = pgl.getAttribute("styleClass");
                            styleClass = styleClass==null?null:styleClass.toUpperCase();
                            if(styleClass != null && styleClass.contains("COL-MD-4")){
                                left = processShowDetailFrames(pgl);
                                page.put("left",left==null?null:left.toArray(new Content[left.size()]));
                            }
                            
                                if(styleClass != null && styleClass.contains("COL-MD-8")){
                                right = processShowDetailFrames(pgl);
                                page.put("right",right==null?null:right.toArray(new Content[right.size()]));
                            }
                            
                                if(styleClass != null && styleClass.contains("COL-MD-12")){
                                center = processShowDetailFrames(pgl);
                                page.put("center",center==null?null:center.toArray(new Content[center.size()]));
                            }
                            
                        }
                    }
                    ObjectMapper objMapper = new ObjectMapper();
                    String userPageJson = objMapper.writeValueAsString(page);
                    if(!this.elFailed){                        
                        CacheUtil.getInstance().put(locale+userId+documentPath,userPageJson,CacheUtil.CacheType.USER);                                        
                    }else{
                        logger.info("------ Page: EL Expression evaluation failure detected");
                    }
                    
                    return Response.ok(userPageJson).type(MediaType.APPLICATION_JSON).build();
                } catch (Exception e) {
                    throw new BadRequestException(e);                
                }
            }else{
                throw new BadRequestException("Error reading document from MDS");
            }            
        }
    }
    
    private boolean evaluateBooleanEl(String boolAttr){
        boolean ret= true;
        if(boolAttr != null){
            boolAttr = boolAttr.trim();
            if(boolAttr.compareToIgnoreCase("#{true}")==0){
                ret = true;
            } else if(boolAttr.compareToIgnoreCase("#{false}")==0){                                
                ret = false;
            }else{
                Object visObject;
                if(boolAttr.length() >0 && (boolAttr.charAt(0) == '#' || boolAttr.charAt(0) == '$')){
                    visObject = resovleFacesEl(boolAttr);
                    
                    if(visObject != null){
                        if(visObject instanceof Boolean){
                            ret = ((Boolean)visObject).booleanValue();    
                        }else{
                            logger.info("-- Not Boolean ---" + visObject.getClass().toString());
                            // System.out.println(visObject);
                        }                        
                    }
                }else{
                    if(boolAttr.compareTo("")==0){
                        ret = true;
                    }else{
                        ret = Boolean.valueOf(boolAttr);
                    }
                }
            }                    
        } 
        return ret;
    }
    

    private Object evaluateEl(String expression){
        if(expression != null){
            expression = expression.trim();
            if(expression.compareToIgnoreCase("#{true}")==0){
                return Boolean.TRUE;
            } else if(expression.compareToIgnoreCase("#{false}")==0){                                               
                return Boolean.FALSE;
            }else{
                Object visObject;
                if(expression.length() >0 && (expression.charAt(0) == '#' || expression.charAt(0) == '$')){
                    visObject = resovleFacesEl(expression);
                    return visObject;
                }else{
                    return expression;
                }
            }                    
        }else{
            return expression;
        }
    }
    
    public ArrayList<Content> processShowDetailFrames(Element parPglEle){
         NodeList sdfNodeList =  parPglEle.getElementsByTagName("showDetailFrame");
         Element sdfEle;
         Node sdfNode;
         ArrayList<Content> contents = null;
         
         Node sdfChildNode;
         NodeList sdfChildNodes;
         Element kdContentPgl;
         String styleClass;
         Content content;
         String sdfRenderedStr;
         boolean sdfRendered;

        String pglRenderedStr;
        boolean pglRendered;
        String tagName;
        String sdfClass;
        String regionValue;
        String[] regionValParts;
        boolean isTaskflow;
        
        for(int i=0;i<sdfNodeList.getLength();i++){
            sdfNode = sdfNodeList.item(i);
            if (sdfNode.getNodeType() == Node.ELEMENT_NODE ){
                sdfEle = (Element)sdfNode;
                logger.info("-------Processing sdf with Id : ---"+sdfEle.getAttribute("id"));
                sdfRenderedStr = sdfEle.getAttribute("rendered");                
                sdfRendered = evaluateBooleanEl(sdfRenderedStr);                     
                sdfClass = resolveTextEl(sdfEle.getAttribute("styleClass"));
                logger.info("-------- Found sdfClass -----------"+sdfClass);
                
                if(sdfClass != null){
                    if(sdfClass.contains("html5hide")){
                        sdfRendered = false;
                    }

                    if(sdfClass.contains("html5show")){
                        sdfRendered = true;
                    }                    
                }
                
                if(sdfRendered){
                    sdfChildNodes =sdfEle.getElementsByTagName("*");
                    
                    for(int j=0;j<sdfChildNodes.getLength();j++){
                        sdfChildNode = sdfChildNodes.item(j);
                        if (sdfChildNode.getNodeType() == Node.ELEMENT_NODE ){
                            kdContentPgl = (Element)sdfChildNode;
                            tagName = kdContentPgl.getTagName();
                            if((tagName.compareToIgnoreCase("f:attribute") == 0) || (tagName.compareToIgnoreCase("attribute") == 0)){
                                continue;
                            }else{
                                styleClass = kdContentPgl.getAttribute("styleClass");
                                pglRenderedStr = kdContentPgl.getAttribute("rendered");
                                
                                logger.info("----- Style Class Found ---"+styleClass);                                    
                                pglRendered = evaluateBooleanEl(pglRenderedStr);
                                
                                isTaskflow = false;
                                if((tagName.compareToIgnoreCase("af:region") == 0) || (tagName.compareToIgnoreCase("region") == 0)){
                                    // found af:region
                                    isTaskflow = true;
                                    regionValue = kdContentPgl.getAttribute("value");
                                    logger.info("----------- Found af:region ----------------value"+regionValue);
                                    if(regionValue !=null){
                                        regionValParts = regionValue.split("\\.");
                                        if(regionValParts != null && regionValParts.length > 1){
                                            styleClass = regionValParts[1];  
                                            logger.info("---------- Determined styleClass --------"+styleClass);
                                        }
                                    }
                                }
                                
                                if(StringUtils.isEmpty(styleClass)){
                                    pglRendered = false;
                                }else{
                                    if(styleClass.contains("html5hide")){
                                        pglRendered = false;
                                    }

                                    if(styleClass.contains("html5show")){
                                        pglRendered = true;
                                    }                                                                    
                                }                                                                    
                                
                                if(pglRendered){    
                                    if(contents == null){
                                        contents = new ArrayList<Content>();
                                    }
                                    content = new Content();
                                    content.setId(sdfEle.getAttribute("id"));
                                    String titleXmlText = sdfEle.getAttribute("text");
                                    logger.info("--------------titleXmlText="+titleXmlText);
                                    String title = resolveTextEl(titleXmlText);
                                    content.setTitle(title);
                                    logger.info("------------------sdf resolved title="+ title);
                                    content.setDescription(resolveTextEl(sdfEle.getAttribute("shortDesc")));
                                    content.setKdContent(resolveTextEl(styleClass));
                                    content.setHeaderVisible(evaluateBooleanEl(sdfEle.getAttribute("displayHeader")));
                                    content.setTaskflow(isTaskflow);
                                    contents.add(content);  
                                }                                       
                            }                            
                        }                
                    }
                }
            }
        }
        return contents;         
    }
    
    @GET
    @Path("/pages")
    @Produces("*/*")
    public Response getPages(@QueryParam("scope") String scope,
                             @DefaultValue("false")  @QueryParam("admin") boolean admin,
                             @DefaultValue("false")  @QueryParam("nopermission") boolean nopermission,
                             @DefaultValue("false")  @QueryParam("business") boolean business,
                             @DefaultValue("false")  @QueryParam("list") boolean list,
                             @DefaultValue("false")  @QueryParam("cached") boolean cached){
        PageServiceConfig config = new PageServiceConfig(getMDSSession(),scope);
        PageService pageService = PageServiceFactory.createInstance(config);
        pageService.setScope(scope);
        
        List<PageDef> pageDefs = null;
        
        if(admin){
            pageDefs = pageService.getAllPagesForAdmin();
        }else{
            if(business){
                pageDefs = pageService.getBusinessRolePages();
            }else{
                if(nopermission){
                    pageDefs = pageService.getAllPagesNoPermission();
                }else{
                    if(cached){
                        pageDefs = pageService.getCachedPersonalPages();
                    }else{
                        if(list){
                           pageDefs = pageService.getPageList(); 
                        }else{
                            pageDefs = pageService.getAllPages();                
                        }                        
                    }                    
                }                            
            }
        }        
        return Response.ok(pageDefs).type(MediaType.APPLICATION_JSON).build();        
    }
    
    @DELETE
    @Path("/navigation/invalidate")
    @Produces("*/*")
    public Response invalidateCache(){
        String[] userRoles = ADFContext.getCurrent().getSecurityContext().getUserRoles();
        boolean isAdminUser = isAdmin(userRoles) ;        
        if(!isAdminUser){
            return Response.status(Response.Status.UNAUTHORIZED).build();
        }
        CacheUtil.getInstance().invalidate(CacheUtil.CacheType.USER);
        CacheUtil.getInstance().invalidate(CacheUtil.CacheType.APPLICATION);
        //TODO: be more specific
        
        return Response.ok().type(MediaType.APPLICATION_JSON).build();
    }
    
    private void putInCache(String key, Object object){
        CacheUtil.getInstance().put(key,object,CacheUtil.CacheType.APPLICATION);
    }
    
    private Object getFromCache(String key){
        return CacheUtil.getInstance().get(key,CacheUtil.CacheType.APPLICATION);
    }
    
    private Portal getPortalByName(String portalName){
        PortalObjectRepository mPortalObjectRepository = this.mPortalObjectRepository;
        Portal portal = mPortalObjectRepository.findByName( (oracle.webcenter.portal.api.Portal)null , "portal", portalName, true);        
        if(portal != null){
            return portal;
        }else{
            logger.info("------ Cannot find Portal in Repository------" + portalName);
            return null;
        }
    }
    
    private NavigationNode getPortalNavigationRootNode(String portalName){          
        Portal portal = getPortalByName(portalName);            
        if(portal != null){                
            NavigationNode rootNode = portal.getNavigationRootNode();                       
            if(rootNode != null){
                return rootNode;
            }else{
                logger.info("------ Cannot find Portal Root Node but found Portal------" + portalName);
                return null;
            }
        }else{
            return null;
        }
    }
    
    
    private Link getNavigationForPortal(String portalName){
        Link rootNavLink = null;
        NavigationNode rootNode = getPortalNavigationRootNode(portalName);       
         if(rootNode != null){
             rootNavLink = this.processNavigationNode(rootNode,null);                 
         }
         return rootNavLink;
    }    
    
    @GET
    @Path("/portal/{portalName}/navigation")
    @Produces("*/*")
    public Response getPortalNavigationEx(@PathParam("portalName") String portalName,@QueryParam("cache") @DefaultValue("true") boolean cache){
        SecurityContext securityContext = ADFContext.getCurrent().getSecurityContext();
        String userId = securityContext.getUserName();
        String[] userRoles = securityContext.getUserRoles();
        boolean isAdminUser = isAdmin(userRoles);
        
        if(isAdminUser){
            cache=false;
        }
        
        this.elFailed=false;
        
        String frmCache = cache?(String)CacheUtil.getInstance().get(userId+"-portal#"+portalName+"#navigation#"+"default",CacheUtil.CacheType.USER):null;
        
        if(frmCache != null){
            logger.info("------ Found Navigation cache for ======"+userId+"-"+portalName);
            return Response.ok(frmCache).type(MediaType.APPLICATION_JSON).build();
        }else{
            logger.info("------ Processing Navigation for ======"+userId+"-"+ portalName);
                try {
                    Link rootNavLink = getNavigationForPortal(portalName);
                    if(rootNavLink == null){
                        logger.info("------ Root Nav Link NULL------" + portalName);
                        return Response.status(Response.Status.NOT_FOUND).build();
                    }                    
                    Link root = this.processLinks(rootNavLink, null);  
                    ObjectMapper objMapper = new ObjectMapper();
                    String userNavJson = objMapper.writeValueAsString(root);
                    
                    if(!this.elFailed){
                        CacheUtil.getInstance().put(userId+"-portal#"+portalName+"#navigation#"+"default",userNavJson,CacheUtil.CacheType.USER);                        
                    }else{
                        logger.info("------ Navigation: EL Expression evaluation failure detected");
                    }
                    
                    
                    return Response.ok(userNavJson).type(MediaType.APPLICATION_JSON).build();
                } catch (Exception e) {
                    throw new BadRequestException(e);                
                }
        }
    }
    
    private Link getLinkForNavigationNode(NavigationNode navNode){
        try{
            NavigationNodePropertyBean propsBean =  navNode.getProperties();      // this method is failing
            if(propsBean != null){
                Link self = new Link();
                String desc = propsBean.getDescription();
                String externalId =  propsBean.getExternalId();
                String name = propsBean.getName();
                String pagePath = propsBean.getPagePath();
                String redirect = propsBean.getRedirect();
                String navPropBeanTitle = propsBean.getTitle();
                String navPropBeanUrl = propsBean.getURL();
                String visibleStr = propsBean.getVisible();    
                
                Map<String, String> customAttrs = propsBean.getCustomAttributes();
                Map<String,String> customParams =  propsBean.getCustomParameters();
                
                self.setDescription(desc);
                self.setName(name);
                self.setVisibleExpression(visibleStr);
                self.setPagePath(pagePath);
                self.setUrl(navPropBeanUrl);
                
                self.setTitle(navPropBeanTitle);
                self.setId(externalId);
                
                if(redirect == null){
                    self.setIsRedirect(false);
                }else{
                    if(redirect.compareToIgnoreCase("TRUE")==0){
                        self.setIsRedirect(true);
                    }else{
                        self.setIsRedirect(false);            
                    }
                }
                
                if(customAttrs != null){
                    for (Map.Entry<String, String> entry : customAttrs.entrySet()) {
                        Attribute attr = new Attribute();
                        attr.setId(entry.getKey());
                        attr.setValue(entry.getValue());
                        attr.setIsKey(false);
                        self.addAttribute(attr);
                    }                
                }

                if(customParams != null){
                    for (Map.Entry<String, String> entry : customParams.entrySet()) {
                        self.addParameter(entry.getKey(), entry.getValue());
                    }                
                }
                
                Page page = navNode.getPage();       
                
                if(page != null){
                    PagePropertyBean pagePropBean = page.getProperties();
                    if(pagePropBean != null){
                        pagePath = pagePropBean.getPagePath();                
                        self.setPagePath("page:/"+pagePath);
                    }
                }                
                
                return self;
            }else{
                logger.info("------ Props Bean NULL for ------" + navNode.getId());
                return null;
            }            
        }catch(Exception e){
            e.printStackTrace();
            logger.info("------ Props Bean NULL for ------" + navNode.getId());
            return null;            
        }        
    }
    
    public Link processNavigationNode(NavigationNode navNode, Link parLink){    
        Link self = new Link();
        
        String navNodeId = navNode.getId();
        
        Link navPropsBeanLink = (Link)getFromCache("NAVIGATION-PROP-BEAN-"+navNodeId);
        if(navPropsBeanLink == null){
            navPropsBeanLink = getLinkForNavigationNode(navNode);
            putInCache("NAVIGATION-PROP-BEAN-"+navNodeId, navPropsBeanLink);
        }
        
        if(navPropsBeanLink != null){
            self.setDescription(navPropsBeanLink.getDescription());
            self.setName(navPropsBeanLink.getName());
            self.setVisibleExpression(navPropsBeanLink.getVisibleExpression());
            self.setPagePath(navPropsBeanLink.getPagePath());
            self.setUrl(navPropsBeanLink.getUrl());            
            self.setTitle(navPropsBeanLink.getTitle());
            self.setId(navPropsBeanLink.getId());
            self.setIsRedirect(navPropsBeanLink.isIsRedirect());
            
            List<Attribute> attributes = navPropsBeanLink.getAttributes();
            Map<String, String> params = navPropsBeanLink.getParameters();
            
            if(attributes != null){
                for (Attribute entryAttr : attributes) {
                    Attribute attr = new Attribute();
                    attr.setId(entryAttr.getId());
                    attr.setValue(entryAttr.getValue());
                    attr.setIsKey(entryAttr.getIsKey());
                    self.addAttribute(attr);
                }                
            }

            if(params != null){
                for (Map.Entry<String, String> entry : params.entrySet()) {
                    self.addParameter(entry.getKey(), entry.getValue());
                }                
            } 
        }else{
            logger.info("------ Props Bean Link is NULL for ------" + navNode.getId());
        }
        
        if(parLink != null){
            parLink.addChild(self);
        }            

        List<NavigationNode> childNodes = navNode.getChildNodes();
        for(NavigationNode childNode : childNodes){
            this.processNavigationNode(childNode, self);
        }

        return self;            
    }
    
    
    public Link processLinks(Link navLink, Link parLink){
        Link self = new Link();

            String desc = navLink.getDescription();
            String externalId =  navLink.getId();
            String name = navLink.getName();
            String url = navLink.getUrl();
            boolean redirect = navLink.isIsRedirect();
            String title = navLink.getTitle();
            String visibleStr = navLink.getVisibleExpression();  
            String pagePath = navLink.getPagePath();
            
            ArrayList<Attribute> attributes = navLink.getAttributes();
            Map<String,String> params =  navLink.getParameters();
            
            //evaluate EL
            boolean hidden = visibleStr == null ? false : (!this.evaluateBooleanEl(visibleStr));
            String resolvedUrl = this.resolveTextEl(url);     

            self.setIsHidden(hidden);
            self.setDescription(desc);
            self.setName(name);
            
            if(url != null){
                self.setUrl(resolvedUrl);
            }else{
                self.setUrl(pagePath);
            }
            
            self.setTitle(title);
            self.setId(externalId);
            self.setIsRedirect(redirect);
            
            if(attributes != null){
                for (Attribute srcAttr : attributes) {
                    Attribute attr = new Attribute();
                    attr.setId(srcAttr.getId());
                    attr.setValue(this.resolveTextEl((String)srcAttr.getValue()));
                    attr.setIsKey(false);
                    self.addAttribute(attr);
                }                
            }

            if(params != null){
                for (Map.Entry<String, String> entry : params.entrySet()) {
                    self.addParameter(entry.getKey(), entry.getValue());
                }                
            }
            if((!hidden) && (parLink != null)){
                parLink.addChild(self);
            }            

        List<Link> childNodes = navLink.getChildren();
        if(childNodes != null){
            for(Link childNode : childNodes){
                this.processLinks(childNode, self);
            }            
        }

        return self;
    }    
    
    private boolean isAdmin(String[] userRoles){        
        if(userRoles == null){
            return false;
        }
        
        List<String> rolesList = Arrays.asList(userRoles);
        
        try {           
            if (rolesList.contains("ECM_IT_Contributor") || 
                rolesList.contains("ECM_IC_Contributor") || 
                rolesList.contains("Portal - Super Admin") || 
                rolesList.contains("Administrators")){
                return true;
            }else{
                return false;
            }
            
        } catch (Exception e) {
            logger.severe(e);
            return false;
        }
    }    

}

//page tempatel -- /oracle/webcenter/siteresources/scopedMD/s8bba98ff_4cbb_40b8_beee_296c916a23ed/siteTemplate/gsr90d16c92_4c9e_4c9b_8396_f3215d30cd9c/Template.jspx
//nav - /oracle/webcenter/siteresources/scopedMD/s6d4ef589_aff5_4027_b80f_24358f951213/navigation/gsrb604362d_971b_47be_91ae_f4f6c5c0674c/portal-default-navigation.xml


