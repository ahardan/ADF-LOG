package com.darden.krowd.rest.config;

import java.util.Collections;
import java.util.List;
 
import javax.ws.rs.core.HttpHeaders;
 
import com.darden.krowd.rest.config.CacheAnnotations.CacheMaxAge;
import com.darden.krowd.rest.config.CacheAnnotations.NoCache;
import com.sun.jersey.api.model.AbstractMethod;
import com.sun.jersey.spi.container.ContainerRequest;
import com.sun.jersey.spi.container.ContainerRequestFilter;
import com.sun.jersey.spi.container.ContainerResponse;
import com.sun.jersey.spi.container.ContainerResponseFilter;
import com.sun.jersey.spi.container.ResourceFilter;
import com.sun.jersey.spi.container.ResourceFilterFactory;




// Jersey 2 Changes -- Pending on testing
//import javax.ws.rs.container.ContainerRequestContext;
//import javax.ws.rs.container.ContainerResponseContext;
//import javax.ws.rs.container.ContainerResponseFilter;
//import java.io.IOException;
//import java.lang.annotation.Annotation;
//public class CacheFilterFactory implements ContainerResponseFilter

public class CacheFilterFactory implements ResourceFilterFactory   {
 
	@Override
	public List<ResourceFilter> create(AbstractMethod am) {
		if (am.isAnnotationPresent(CacheMaxAge.class)) {
			CacheMaxAge maxAge = am.getAnnotation(CacheMaxAge.class);
			return newCacheFilter("max-age: " + maxAge.unit().toSeconds(maxAge.time()));
		} else if (am.isAnnotationPresent(NoCache.class)) {
			return newCacheFilter("no-cache");
		} else {
			return Collections.emptyList();
		}
	}
 
	private List<ResourceFilter> newCacheFilter(String content) {
		return Collections
		        .<ResourceFilter> singletonList(new CacheResponseFilter(content));
	}
 
	private static class CacheResponseFilter implements ResourceFilter, ContainerResponseFilter {
		private final String headerValue;
 
		CacheResponseFilter(String headerValue) {
			this.headerValue = headerValue;
		}
 
		@Override
		public ContainerRequestFilter getRequestFilter() {
			return null;
		}
 
		@Override
		public ContainerResponseFilter getResponseFilter() {
			return this;
		}
 
		@Override
		public ContainerResponse filter(ContainerRequest request, ContainerResponse response) {
			response.getHttpHeaders().putSingle(HttpHeaders.CACHE_CONTROL, headerValue);
			return response;
		}
	}
        
        // Jersey 2 CacheContol changes below
        
//    @Override
//    public void filter(ContainerRequestContext containerRequestContext,
//                       ContainerResponseContext containerResponseContext) throws IOException {
//        for(Annotation ann : containerResponseContext.getEntityAnnotations()){
//            if(ann.annotationType() == CacheMaxAge.class){
//                CacheMaxAge maxAge = (CacheAnnotations.CacheMaxAge) ((CacheAnnotations.CacheMaxAge) ann).unit();
//                containerResponseContext.getHeaders().putSingle(HttpHeaders.CACHE_CONTROL, "max-age: "+
//                                                                + maxAge.unit().toSeconds(maxAge.time()));
//            } else if(ann.annotationType() == NoCache.class){
//                containerResponseContext.getHeaders().putSingle(HttpHeaders.CACHE_CONTROL, "no-cache");
//                }
//            }
//
//    }
}