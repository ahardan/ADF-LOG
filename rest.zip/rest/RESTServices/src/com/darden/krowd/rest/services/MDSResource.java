package com.darden.krowd.rest.services;


import com.darden.krowd.rest.exceptions.BadRequestException;
import com.darden.krowd.rest.model.MDSItem;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import java.io.StringWriter;

import java.net.URLConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.text.DecimalFormat;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import javax.swing.JOptionPane;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import oracle.adf.share.ADFContext;

import oracle.adf.share.config.SiteCC;
import oracle.adf.share.logging.ADFLogger;

import oracle.jdbc.OracleDriver;

import oracle.mds.config.CacheConfig;
import oracle.mds.config.CustConfig;
import oracle.mds.config.MDSConfig;
import oracle.mds.config.PConfig;
import oracle.mds.core.ConcurrentMOChangeException;
import oracle.mds.core.IsolationLevel;
import oracle.mds.core.MDSInstance;
import oracle.mds.core.MDSSession;
import oracle.mds.core.MetadataObject;
import oracle.mds.core.SessionOptions;
import oracle.mds.core.ValidationException;
import oracle.mds.cust.CustClassList;
import oracle.mds.cust.CustomizationClass;
import oracle.mds.exception.InvalidNamespaceException;
import oracle.mds.exception.UnsupportedUpdateException;
import oracle.mds.naming.DocumentName;
import oracle.mds.naming.InvalidReferenceException;
import oracle.mds.naming.InvalidReferenceTypeException;
import oracle.mds.naming.PackageName;
import oracle.mds.naming.ResourceName;
import oracle.mds.persistence.ConcurrentDocChangeException;
import oracle.mds.persistence.MDSIOException;
import oracle.mds.persistence.PContext;
import oracle.mds.persistence.PDocument;
import oracle.mds.persistence.PManager;
import oracle.mds.persistence.PPackage;
import oracle.mds.persistence.PResource;
import oracle.mds.persistence.PTransaction;
import oracle.mds.persistence.stores.db.DBMetadataStore;
import oracle.mds.persistence.stores.file.FileMetadataStore;
import oracle.mds.query.ConditionFactory;
import oracle.mds.query.DocumentResult;
import oracle.mds.query.NameCondition;
import oracle.mds.query.PackageResult;
import oracle.mds.query.QueryFactory;
import oracle.mds.query.QueryResult;
import oracle.mds.query.ResourceQuery;

import oracle.webcenter.jaxrs.framework.service.RestService;
import oracle.webcenter.jaxrs.framework.uri.UriService;



import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;

import org.w3c.dom.Document;

import org.xml.sax.InputSource;


@Path("/mds")
@Produces("application/json")
public class MDSResource {
    private final static DecimalFormat NANO_SEC_FMT = new DecimalFormat("#0.000000000");
    private static final ADFLogger logger = ADFLogger.createADFLogger(MDSResource.class);
    
    
    @RestService
    protected UriService uriService;

    @Context
    protected HttpServletRequest httpRequest;
    
    private MDSInstance mdsInstance;
    
    public MDSResource() {
        super();
    }
    
    private MDSInstance getMDSInstance(){
        if(mdsInstance == null){
//            mdsInstance = (MDSInstance)ADFContext.getCurrent().getMDSInstanceAsObject();
            try {
                mdsInstance = (MDSInstance)ADFContext.getCurrent().getMDSInstanceAsObject();
                //mdsInstance = initializeFileStore("C:\\Development\\DesignWebCenterSpaces\\WebCenterSpacesResources\\public_html", "","File");
                //mdsInstance = initializeDBStore("DEV2_MDS", "oracle01", "jdbc:oracle:thin:@padbd1.darden.com:1521/padbdev", "webcenter", "mdsDBConn");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return mdsInstance;
    }
    
    public void testMethod(){
        PDocument pDocument = getPDocument(getMDSInstance(), "/oracle/webcenter/page/scopedMD/s8bba98ff_4cbb_40b8_beee_296c916a23ed/Search.jspx");
        System.out.println(pDocument);
        try {
            //recursiveCreatePackage("/oracle/webcenter/one1/two1/three1",null);
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setNamespaceAware(true);            
            DocumentBuilder builder = factory.newDocumentBuilder();
            
            //subh,CWE ID: 611-Improper Restriction of XML External Entity Reference
            /*try
            {
                factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
                factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
                factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);                
            }
            catch(Exception ex) 
            {
                ex.printStackTrace();
                logger.info(ex.getMessage());                
            }*/
            //
            Document document = builder.parse(new File("C:\\Development\\portal\\trunk\\source\\webcenter\\Krowd\\Portal\\public_html\\oracle\\webcenter\\portalapp\\pages\\Content.jspx"));
            DOMSource domSource = new DOMSource(document);
            createOrUpdateResource("/oracle/webcenter/one1/two2/three3/Content.jspx", domSource);            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args){
        PackageName packageName;
        try {
            packageName = PackageName.createPackageName("/oracle/webcenter/page");
            System.out.println(packageName.getAbsoluteName());
            System.out.println(packageName.getLocalName());
            System.out.println(packageName.getPackageName());
            
            DocumentName docName = DocumentName.create("/oracle/webcenter/page/scopedMD/s8bba98ff_4cbb_40b8_beee_296c916a23ed/template.jspx");
            System.out.println(docName.getAbsoluteName());
            System.out.println(docName.getLocalName());
            System.out.println(docName.getPackageName());
            
            MDSResource mdsResource = new MDSResource();
            mdsResource.testMethod();
            //MDSInstance ins = mdsResource.initializeFileStore("C:\\Development\\DesignWebCenterSpaces\\WebCenterSpacesResources\\public_html", "","File");
//            MDSInstance ins = mdsResource.initializeDBStore("DEV2_MDS", "oracle01", "jdbc:oracle:thin:@padbd1.darden.com:1521/padbdev", "webcenter", "mdsDBConn");
//            PDocument pdoc = mdsResource.getPDocument(ins, "/oracle");            
//            System.out.println(pdoc);
//            Response response = mdsResource.create("/oracle/webcenter/test1",null);
//            System.out.println(response);
            
//            pdoc = mdsResource.getPDocument(ins, "/oracle/webcenter");
//            System.out.println(pdoc);            
//            
//            pdoc = mdsResource.getPDocument(ins, "/oracle");
//            System.out.println(pdoc);            
//            byte[] bytes = mdsResource.getDocumentByPath(ins, "/oracle/webcenter/page/scopedMD/s8bba98ff_4cbb_40b8_beee_296c916a23ed/template.jspx");
//            System.out.println(bytes);
//            System.out.println(ins);
//            Response response = mdsResource.getDocument("/oracle/webcenter/page/");
             //byte[] data = mdsResource.getDocumentByAbsolutePath(ins,"/oracle/webcenter/page/scopedMD/s8bba98ff_4cbb_40b8_beee_296c916a23ed/template.jspx");
            //Object obj = mdsResource.listPackageEntries(ins, "/oracle/webcenter/page/scopedMD/s8bba98ff_4cbb_40b8_beee_296c916a23ed/");
            //System.out.println(obj);
            
//            CustomizationClass[] custClass = new CustomizationClass[] { new SiteCC() };
//            CustClassList custCCList = new CustClassList(custClass);                                    
//            MDSSession session = ins.createSession(new SessionOptions(IsolationLevel.READ_COMMITTED, null, null), null);
//            MetadataObject mo11 =session.getMetadataObject("/oracle/webcenter/page/scopedMD/s8bba98ff_4cbb_40b8_beee_296c916a23ed/businessRolePages/testpage74.jspx",custCCList, null);
//            Document mergedDoc = mo11.getDocument(true);
//            String mergedXMLStr = getDocumentAsString(mergedDoc);
//            
//            System.out.println(mergedXMLStr);
            
//            System.out.println(response.getEntity());
        } catch (Exception e) {
            e.printStackTrace();
        } 
    }
    
    private List<MDSItem> getMDSItems(List<ResourceName> resources){
        if(resources == null)
            return null;
        else{
            List<MDSItem> mdsItems = new ArrayList<MDSItem>();
            for(ResourceName resource : resources){
                mdsItems.add(new MDSItem(resource));
            }
            return mdsItems;
        }
    }
    
    private PDocument getPDocument(MDSInstance mdsInstance,String documentFullPathInMDS){
        DocumentName docName = null;
        PDocument pDocument = null;
        try {
            docName = DocumentName.create(documentFullPathInMDS);
            MDSSession session = mdsInstance.createSession(new SessionOptions(IsolationLevel.READ_COMMITTED, null, null), null);
            PManager pManager = mdsInstance.getPersistenceManager();
            PContext pContext = session.getPContext();        
            pDocument = pManager.getDocument(pContext, docName);   
        } catch (Exception e) {
            e.printStackTrace();
        }
        return pDocument;
    }
    
    private PPackage getPPackage(MDSInstance mdsInstance,String packageFullPathInMDS){
        PackageName packageName = null;
        PPackage pPackage = null;
        try {
            packageName = PackageName.createPackageName(packageFullPathInMDS);
            MDSSession session = mdsInstance.createSession(new SessionOptions(IsolationLevel.READ_COMMITTED, null, null), null);
            PManager pManager = mdsInstance.getPersistenceManager();
            PContext pContext = session.getPContext();        
            pPackage= pManager.getPackage(pContext, packageName);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return pPackage;
    }

    @GET
    @Path("/tree")
    @Produces(MediaType.APPLICATION_JSON)
    public Response query(@QueryParam("q") String query,@QueryParam("id") String id){
        MDSInstance mdsInstance = getMDSInstance();
        String documentPath =null;
        if(id !=null && !StringUtils.isBlank(id)){
            documentPath = id;
        }
        if(documentPath == null || documentPath.compareTo("1")==0 || StringUtils.isBlank(documentPath))
            documentPath = "/";
        if(documentPath.endsWith("/")){
            List<ResourceName> resources = new ArrayList<ResourceName>();
            try {
                resources = listPackageEntries(mdsInstance, documentPath);
            } catch (Exception e) {
                throw new BadRequestException(e);
            }
            return Response.status(Response.Status.OK).entity(getMDSItems(resources)).type("application/json").build();
        }else{
            //Check if we can find a document
            PDocument pDocument = getPDocument(mdsInstance, documentPath);
            if(pDocument !=null){
                //found a matching document
                List<ResourceName> resources = new ArrayList<ResourceName>();
                try{
                    DocumentName docName = pDocument.getDocumentName();
                    resources.add(docName);
                }catch(Exception e){
                    logger.severe(e);
                    throw new BadRequestException(e);
                }            
                return Response.status(Response.Status.OK).entity(getMDSItems(resources)).type(MediaType.APPLICATION_JSON_TYPE).build();
            }else{
                //check if a package can be found with the specified name
                PPackage packageName = getPPackage(mdsInstance, documentPath);                
                if(packageName !=null){
                    List<ResourceName> resources = new ArrayList<ResourceName>();
                    try {
                        resources = listPackageEntries(mdsInstance, documentPath);
                    } catch (Exception e) {
                        throw new BadRequestException(e);
                    }
                    return Response.status(Response.Status.OK).entity(getMDSItems(resources)).type(MediaType.APPLICATION_JSON_TYPE).build();

                }else{
                    throw new BadRequestException("Specified document path is neither a package nor a document in MDS");
                }
            }
        }         
    }
    
    
    
    @GET
    @Path("/resource")
    @Produces("*/*")
    public Response getResource(@QueryParam("id") String documentPath){
        MDSInstance mdsInstance = getMDSInstance();
        
        if(documentPath == null || documentPath.compareTo("1")==0 || StringUtils.isBlank(documentPath))
            documentPath = "/";

        if(documentPath.endsWith("/")){
            List<ResourceName> resources = new ArrayList<ResourceName>();
            try {
                resources = listPackageEntries(mdsInstance, documentPath);
            } catch (Exception e) {
                throw new WebApplicationException(Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).type(MediaType.APPLICATION_JSON_TYPE).build());
            }
            return Response.status(Response.Status.OK).entity(getMDSItems(resources)).type(MediaType.APPLICATION_JSON_TYPE).build();
        }else{
            //Check if we can find a document
            PDocument pDocument = getPDocument(mdsInstance, documentPath);
            if(pDocument !=null){
                //found a matching document
                try{
                    DocumentName docName = DocumentName.create(documentPath);
                    String extension = docName.getExtension();
                    PackageName packageName = PackageName.createPackageName(documentPath);
                    String localName = packageName.getLocalName();
                    String mimeType="text/xml";
                    mimeType = URLConnection.guessContentTypeFromName(localName);
                    byte[] data = getDocumentByPath(mdsInstance,documentPath);
                    return Response.ok(new ByteArrayInputStream(data)).type(mimeType).build();
                }catch(Exception e){
                    e.printStackTrace();
                    throw new BadRequestException(e);
                }            
            }else{
                //check if a package can be found with the specified name
                PPackage packageName = getPPackage(mdsInstance, documentPath);                
                if(packageName !=null){
                    List<ResourceName> resources = new ArrayList<ResourceName>();
                    try {
                        resources = listPackageEntries(mdsInstance, documentPath);
                    } catch (Exception e) {
                        throw new WebApplicationException(Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).type(MediaType.APPLICATION_JSON_TYPE).build());
                    }
                    return Response.status(Response.Status.OK).entity(getMDSItems(resources)).type(MediaType.APPLICATION_JSON_TYPE).build();

                }else{                    
                    throw new BadRequestException("Specified document path is neither a package nor a document in MDS");
                }
            }
        } 
    }
    
    private void recursiveCreatePackage(String packagePath,LinkedList<String> toCreate) throws Exception {
        MDSInstance mdsInstance = getMDSInstance();
        PPackage pPackage = getPPackage(mdsInstance, packagePath);        
        if(pPackage !=null){
            //Package exists      
            if(toCreate!=null && !toCreate.isEmpty()){
                while(!toCreate.isEmpty()){
                    packagePath=packagePath+"/"+toCreate.removeLast();
                    createFolder(mdsInstance,packagePath);                    
                }                               
            }
        }else{
            //Package does not exist
            PackageName packageName = PackageName.createPackageName(packagePath);
            toCreate = toCreate==null?new LinkedList<String>():toCreate;
            toCreate.add(packageName.getLocalName());            
            recursiveCreatePackage(packageName.getPackageName(),toCreate);
        }  
    }
    
    @POST
    @Path("/resource")
    @Consumes(MediaType.APPLICATION_XML)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createOrUpdateResource(@QueryParam("id") String documentPath,DOMSource domSource){
        MDSInstance mdsInstance = getMDSInstance();
        if(documentPath == null || StringUtils.isBlank(documentPath))
            throw new WebApplicationException(Response.status(Response.Status.BAD_REQUEST).entity("Invalid Document Path..").type(MediaType.APPLICATION_JSON_TYPE).build());                
        PDocument pDocument = getPDocument(mdsInstance, documentPath);
        if(pDocument !=null){
            try{
                if(domSource !=null){
                    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                    Result outputTarget = new StreamResult(outputStream);
                    TransformerFactory.newInstance().newTransformer().transform(domSource, outputTarget);
                    //subh,CWE ID: 611-Improper Restriction of XML External Entity Reference
                    /*TransformerFactory tFactory=TransformerFactory.newInstance();
                    try
                    {
                        tFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
                        DocumentBuilderFactory dfactory = DocumentBuilderFactory.newInstance();        
                        dfactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
                        dfactory.setFeature("http://xml.org/sax/features/external-general-entities", false);
                        dfactory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
                    }
                    catch(Exception ex)
                    {
                        ex.printStackTrace();
                        logger.info(ex.getMessage());
                    }
                    
                    tFactory.newTransformer().transform(domSource, outputTarget);*/
                    //
                    InputStream is = new ByteArrayInputStream(outputStream.toByteArray());            
                    updateDocumentByPath(mdsInstance,documentPath,new InputStreamReader(is));
                    return Response.status(Response.Status.OK).entity("Successfully updated "+documentPath).type(MediaType.APPLICATION_JSON_TYPE).build(); 
                }else{
                    throw new BadRequestException("Failed to Update document"+documentPath+" in MDS.domSource is mandatory.");    
                }
            }catch(Exception e){
                throw new BadRequestException(e);
            }
        }else{
            //Check if a package exists               
            try {
                if(documentPath.endsWith("/")){
                    recursiveCreatePackage(documentPath,null);    
                    return Response.status(Response.Status.OK).entity("Successfully created Package "+documentPath+" in MDS.").type(MediaType.APPLICATION_JSON_TYPE).build(); 
                }else{
                    PackageName packageName = PackageName.createPackageName(documentPath);
                    String localName = packageName.getLocalName();
                    if(localName.contains(".")){
                        if(domSource !=null){
                            recursiveCreatePackage(packageName.getPackageName(),null);                         
                            //attempting to create a file
                            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                            Result outputTarget = new StreamResult(outputStream);
                            TransformerFactory.newInstance().newTransformer().transform(domSource, outputTarget);
                            InputStream is = new ByteArrayInputStream(outputStream.toByteArray());                            
                            uploadDocument(mdsInstance, documentPath, new InputStreamReader(is));
                            return Response.status(Response.Status.OK).entity("Successfully created document "+documentPath).type(MediaType.APPLICATION_JSON_TYPE).build();                        
                        }else{
                            throw new BadRequestException("Failed to Create document"+documentPath+" in MDS.domSource is mandatory.");     
                        }
                    }else{
                        recursiveCreatePackage(documentPath,null);
                        return Response.status(Response.Status.OK).entity("Successfully created Package "+documentPath+" in MDS.").type(MediaType.APPLICATION_JSON_TYPE).build(); 
                    }
                }                
            } catch (Exception e) {
                throw new BadRequestException(e);
            } 
        }    
    }    

    @PUT
    @Path("/resource")
    @Consumes(MediaType.APPLICATION_XML)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateResource(@QueryParam("id") String documentPath,DOMSource domSource){
        MDSInstance mdsInstance = getMDSInstance();
        if(documentPath == null || StringUtils.isBlank(documentPath))
            throw new WebApplicationException(Response.status(Response.Status.BAD_REQUEST).entity("Invalid Document Path..").type(MediaType.APPLICATION_JSON_TYPE).build());                
        PDocument pDocument = getPDocument(mdsInstance, documentPath);
        if(pDocument !=null){
            try{
                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                Result outputTarget = new StreamResult(outputStream);
                TransformerFactory.newInstance().newTransformer().transform(domSource, outputTarget);
                //subh,CWE ID: 611-Improper Restriction of XML External Entity Reference
                /*TransformerFactory tFactory=TransformerFactory.newInstance();
                try
                {
                    tFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
                    DocumentBuilderFactory dfactory = DocumentBuilderFactory.newInstance();        
                    dfactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
                    dfactory.setFeature("http://xml.org/sax/features/external-general-entities", false);
                    dfactory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
                }
                catch(Exception ex)
                {
                    ex.printStackTrace();
                    logger.info(ex.getMessage());
                }
                
                tFactory.newTransformer().transform(domSource, outputTarget);*/
                //
                
                InputStream is = new ByteArrayInputStream(outputStream.toByteArray());            
                updateDocumentByPath(mdsInstance,documentPath,new InputStreamReader(is));
                return Response.status(Response.Status.OK).type(MediaType.APPLICATION_JSON_TYPE).build();            
            }catch(Exception e){
                throw new BadRequestException(e);
            }
        }else{
            throw new BadRequestException("Document Path should be an existing file in MDS.");
        }    
    }

    @DELETE
    @Path("/resource")
    public Response delete(@QueryParam("id") String documentPath){
        MDSInstance mdsInstance = getMDSInstance();
        if(documentPath == null || StringUtils.isBlank(documentPath))
            throw new BadRequestException("Please specifiy a valid document path");
            //Check if we can find a document
            PDocument pDocument = getPDocument(mdsInstance, documentPath);
            if(pDocument !=null){
                //found a matching document
                try{
                    DocumentName docName = DocumentName.create(documentPath);
                    deleteResource(mdsInstance, docName);
                    return Response.status(Response.Status.OK).entity("Successfully deleted document "+documentPath+" in MDS.").type(MediaType.APPLICATION_JSON_TYPE).build(); 
                }catch(Exception e){
                    throw new BadRequestException(e);
                }            
            }else{
                //check if a package can be found with the specified name
                PPackage packageName = getPPackage(mdsInstance, documentPath);                
                if(packageName !=null){
                //found a package
                    try{
                        deleteFolder(mdsInstance, documentPath);
                        return Response.status(Response.Status.OK).entity("Successfully deleted package "+documentPath+" in MDS.").type(MediaType.APPLICATION_JSON_TYPE).build(); 
                    }catch(Exception e){
                        throw new BadRequestException(e);
                    }                  
                }else{
                    throw new BadRequestException("Specified document path is neither a package nor a document in MDS.");
                }
            }
    }

    /*@POST
    @Path("create-resource")
    @Consumes(MediaType.APPLICATION_XML)
    @Produces(MediaType.APPLICATION_JSON)    
    public Response create(@QueryParam("id") String documentPath,DOMSource domSource){
        MDSInstance mdsInstance = getMDSInstance();
        if(documentPath == null || StringUtils.isBlank(documentPath))
            throw new BadRequestException("Please specifiy a valid document path");        
        
        if(documentPath.endsWith("/")){
            try{
                PackageName packageName = PackageName.createPackageName(documentPath);
                PPackage pPackage = getPPackage(mdsInstance, packageName.getPackageName());
                if(pPackage !=null){
                    //Parent package exists
                    createFolder(mdsInstance,packageName);
                    return Response.ok().build();
                }else{
                    throw new BadRequestException("Cannot find parent package"+packageName.getPackageName());                    
                }
            }catch(Exception e){
                throw new WebApplicationException(Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).type(MediaType.APPLICATION_JSON_TYPE).build());
            }
        }else{
            try{
                PackageName packageName = PackageName.createPackageName(documentPath);
                PPackage pPackage = getPPackage(mdsInstance, packageName.getPackageName());
                if(pPackage !=null){
                    //parent package exists
                    String localName = packageName.getLocalName();
                    if(domSource !=null){
                        //attempting to create a file
                        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                        Result outputTarget = new StreamResult(outputStream);
                        TransformerFactory.newInstance().newTransformer().transform(domSource, outputTarget);
                        InputStream is = new ByteArrayInputStream(outputStream.toByteArray());                            
                        uploadDocument(mdsInstance, documentPath, new InputStreamReader(is));
                        return Response.ok().build();
                    }else{
                        //attempting to create a folder
                        if(localName.contains(".")){
                            //atempting to create a file without dom source -- error condition
                            throw new BadRequestException("Please specify domSource");                    
                        }else{
                            createFolder(mdsInstance, packageName);
                            return Response.ok().build();
                        }
                    }
                }else{
                    throw new BadRequestException("Cannot find parent package"+packageName.getPackageName());                    
                }
            }catch(Exception e){
                throw new BadRequestException(e);
            }            
        }    
    }
    */
    
    private List<ResourceName> listPackageEntries(MDSInstance mdsInstance,String packagePath) throws InvalidReferenceException,
                                                                             InvalidReferenceTypeException,
                                                                             InvalidNamespaceException,
                                                                             MDSIOException,
                                                                             ConcurrentMOChangeException,
                                                                             ValidationException {
        if(packagePath == null || StringUtils.isBlank(packagePath))
            packagePath = "/";
        PackageName packageName = PackageName.createPackageName(packagePath);
        MDSSession session = mdsInstance.createSession(new SessionOptions(IsolationLevel.READ_COMMITTED, null, null), null);
        PManager pManager = mdsInstance.getPersistenceManager();
        PContext pContext = session.getPContext();        
        Iterator<PResource> resources;
        List<ResourceName> items = new ArrayList<ResourceName>();
        try {
            resources = pManager.getResources(pContext,packageName);
            while(resources.hasNext()){
                items.add(resources.next().getResourceName());
            }
        } catch (InvalidNamespaceException e) {
            throw e;
        }finally{
            session.flushChanges();
        }
        return items;
    }
    
    private void updateDocumentByPath(MDSInstance mdsInstance,String documentFullPathInMDS,Reader updatedData) throws InvalidReferenceException,
                                                                 InvalidReferenceTypeException,
                                                                 MDSIOException,
                                                                 ConcurrentMOChangeException,
                                                                 ValidationException,
                                                                 ConcurrentDocChangeException,
                                                                 UnsupportedUpdateException {
        DocumentName docName = DocumentName.create(documentFullPathInMDS);
        MDSSession session = mdsInstance.createSession(new SessionOptions(IsolationLevel.READ_COMMITTED, null, null), null);
        PManager pManager = mdsInstance.getPersistenceManager();
        PContext pContext = session.getPContext();   
        PTransaction transaction = session.getPTransaction();
        PDocument pdocument = pManager.getDocument(pContext, docName);

        InputSource is = new InputSource(updatedData);

        try {
            transaction.saveDocument(pdocument, true, is);
        } catch (MDSIOException e) {
            throw e;
        } catch (ConcurrentDocChangeException e) {
            throw e;
        } catch (UnsupportedUpdateException e) {
            throw e;
        } finally{
            session.flushChanges();
        }        
    } 
    
    public byte[] getMDSDocument(String documentPath) throws InvalidReferenceException,
                                                                                  InvalidReferenceTypeException,
                                                                                  MDSIOException,
                                                                                  ConcurrentMOChangeException,
                                                                                  ValidationException,
                                                                                  IOException{
        MDSInstance mdsInstance = getMDSInstance();
        return this.getDocumentByPath(mdsInstance, documentPath);
    }

    private byte[] getDocumentByPath(MDSInstance mdsInstance,String documentFullPathInMDS) throws InvalidReferenceException,
                                                                                  InvalidReferenceTypeException,
                                                                                  MDSIOException,
                                                                                  ConcurrentMOChangeException,
                                                                                  ValidationException,
                                                                                  IOException {
        DocumentName docName = DocumentName.create(documentFullPathInMDS);
        MDSSession session = mdsInstance.createSession(new SessionOptions(IsolationLevel.READ_COMMITTED, null, null), null);
        PManager pManager = mdsInstance.getPersistenceManager();
        PContext pContext = session.getPContext();        
        PDocument pdocument = pManager.getDocument(pContext, docName);
        InputSource source = null;
        byte[] bytes = null;
        
        try {
            source = pdocument.read();
            Reader reader = source.getCharacterStream(); // Text files
            if (reader != null) {
                StringBuffer sb = new StringBuffer();
                BufferedReader br = new BufferedReader(reader);
                String line = "";
                boolean go = true;
                try{
                    while (go) {
                        line = br.readLine();
                        if (line == null)
                            go = false;
                        else
                            sb.append(line + "\n");
                    }                    
                    bytes = sb.toString().getBytes();                    
                }catch(IOException e){
                    throw e;
                }finally{
                    br.close();
                }
            }else{
                InputStream is = source.getByteStream();
                try {
                    int offset = 0;
                    int numRead = 0;
                    while (offset < bytes.length &&(numRead = is.read(bytes, offset,bytes.length - offset)) >= 0)
                        offset += numRead;
                    byte[] temp = new byte[offset];
                    for (int i = 0; i < offset; i++)
                        temp[i] = bytes[i];
                    bytes = temp;
                } catch (IOException ex) {
                    throw ex;
                } finally {
                    is.close();
                }                
            }            
        } catch (MDSIOException e) {
            throw e;
        }finally{
            session.flushChanges();
        }        
        return bytes;
    }
    
    /*
     * From Ateam MDSUtils
     * 
     */
    
    private void createFolder(MDSInstance mdsInstance,PackageName packageName) throws Exception {
      MDSSession session = mdsInstance.createSession(new SessionOptions(IsolationLevel.READ_COMMITTED, null, null), null);
      PTransaction transaction = session.getPTransaction();
      transaction.createPackage(packageName);
      session.flushChanges();
    }

    private void uploadDocument(MDSInstance mdsInstance,String documentFullNameInMDS,String documentFullPathOnFileSystem) throws Exception {
      Reader reader = new FileReader(documentFullPathOnFileSystem);
      uploadDocument(mdsInstance, documentFullNameInMDS, reader);
    }
    
    private void uploadDocument(MDSInstance mdsInstance,String documentFullNameInMDS,Reader documentContentReader) throws Exception {
      MDSSession session = mdsInstance.createSession(new SessionOptions(IsolationLevel.READ_COMMITTED, null, null), null);
      PTransaction transaction = session.getPTransaction();
    //  transaction.createPackage(packageName);
      DocumentName mdsDocumentName = DocumentName.create(documentFullNameInMDS);
      InputSource is = new InputSource(documentContentReader);
    /* PDocument pDoc = */ transaction.createDocument(mdsDocumentName, is);
    //  transaction.commit();
      session.flushChanges();
    }

    private void deleteResource(MDSInstance mdsInstance,ResourceName resource)throws Exception{
      MDSSession session = mdsInstance.createSession(new SessionOptions(IsolationLevel.READ_COMMITTED, null, null), null);
      PTransaction transaction = session.getPTransaction();
      PManager pManager = mdsInstance.getPersistenceManager();
      PContext pContext = session.getPContext();

      if (resource instanceof PackageName){
        PPackage ppackage = pManager.getPackage(pContext, (PackageName) resource);
        transaction.deletePackage(ppackage, true);
      }
      else{
        PDocument pdocument = pManager.getDocument(pContext, (DocumentName)resource);
        transaction.deleteDocument(pdocument, true);
      }    
    //  transaction.commit();
      session.flushChanges();
    }

    private void createFolder(MDSInstance instance,String folderName) throws Exception{
      try{
        System.out.println("Creating folder " + folderName);
        createFolder(instance, PackageName.createPackageName(folderName));
      }catch (Exception e){
        e.printStackTrace();
      }
    }
    
    public void deleteFolder(MDSInstance instance, String folderName){
      try{
        List<ResourceName> list = findResource(instance, folderName, false);
    //    System.out.println("List: (" + list.size() + " element(s))");
        for (ResourceName rn : list){
    //      System.out.println("Found : " + rn.getAbsoluteName() + " (a " + (rn.isPackageName()?"package":"document") + ")");
          if (rn.isPackageName() && rn.getAbsoluteName().equals(folderName)){
            System.out.println("Deleting " + rn.getAbsoluteName());
            deleteResource(instance, rn);
          }else
            System.out.println("Leaving " + rn.getAbsoluteName() + " alone.");
        }
      }
      catch (Exception ex){
        ex.printStackTrace();
      }    
    }  
    

    
    /*
     * Methods below are in-efficient
     */

    
    
    private  List<ResourceName> queryMDS(MDSInstance mdsInstance,PackageName packageName) throws Exception
    {

      if (packageName == null)
        packageName = PackageName.createPackageName("/");

      // Use Query APIs to enumerate the subpackages or documents
      NameCondition condition = ConditionFactory.createNameCondition(packageName.getAbsoluteName(), "%");
      ResourceQuery query = QueryFactory.createResourceQuery(mdsInstance, condition);
      Iterator<QueryResult> contents = query.execute();

      List<ResourceName> resources = new ArrayList<ResourceName>();
      if (contents == null)
        return resources;

      QueryResult result;
      while (contents.hasNext()){
        result = contents.next();
        if (result.getResultType() == QueryResult.ResultType.PACKAGE_RESULT){
          PackageResult pack = (PackageResult) result;
          resources.add(pack.getPackageName());
        }
        else{
          DocumentResult doc = (DocumentResult) result;
          resources.add(doc.getDocumentName());
        }
      }
      return resources;
    }

    
    private void updateDocument(MDSInstance mdsInstance,String documentName,Reader updatedData) throws Exception {
      MDSSession session = mdsInstance.createSession(new SessionOptions(IsolationLevel.READ_COMMITTED, null, null), null);
      PTransaction transaction = session.getPTransaction();
      PManager pManager = mdsInstance.getPersistenceManager();
      PContext pContext = session.getPContext();

      List<ResourceName> list = findResource(mdsInstance, documentName, false, false);
      System.out.println("List: (" + list.size() + " element(s))");
      if (list.size() != 1)
        throw new RuntimeException("Not good.\n" + 
                                   "Trying to update [" + documentName + "]\n" + 
                                   "Found " + list.size() + " instance(s) of it.");
      PDocument pdocument = pManager.getDocument(pContext, (DocumentName)list.get(0));
      InputSource is = new InputSource(updatedData);
      transaction.saveDocument(pdocument, true, is);
    //  transaction.commit();
      session.flushChanges();
    } 
    

    
    private byte[] downloadDocument(MDSInstance mdsInstance, String documentFullPathInMDS) throws Exception {
      long before = System.nanoTime();
      MDSSession session = mdsInstance.createSession(new SessionOptions(IsolationLevel.READ_COMMITTED, null, null), null);
      PManager pManager = mdsInstance.getPersistenceManager();
      PContext pContext = session.getPContext();

      List<ResourceName> list = findResource(mdsInstance, documentFullPathInMDS, false, false);
      System.out.println("List: (" + list.size() + " element(s))");
      if (list.size() != 1)
        throw new RuntimeException("Not good.\n" + 
                                   "Trying to download [" + documentFullPathInMDS + "]\n" + 
                                   "Found " + list.size() + " instance(s) of it.");  
      byte[] bytes = null;
      for (ResourceName rn : list){
        System.out.println("Found : " + rn.getAbsoluteName() + " (a " + (rn.isPackageName()?"package":"document") + ")");
        PDocument pdocument = pManager.getDocument(pContext, (DocumentName)rn);
        InputSource source = pdocument.read();
        
        Reader reader = source.getCharacterStream();    // Text files
        if (reader != null){
          StringBuffer sb = new StringBuffer();
          BufferedReader br = new BufferedReader(reader);
          String line = "";
          boolean go = true;
          while (go){
            line = br.readLine();
            if (line == null)
              go = false;
            else
              sb.append(line + "\n");
          }
          br.close();
          bytes = sb.toString().getBytes();
        }
        else{
          System.out.println("No reader. Switching to bytes");
          InputStream is = source.getByteStream();
          try { bytes = new byte[Integer.MAX_VALUE / 10]; }
          catch (OutOfMemoryError oome){
            System.out.println( "Failed to allocate " + Integer.toString(Integer.MAX_VALUE / 10) + " bytes.\nPlease increase your heap size...");
          }
          try{
            int offset = 0;
            int numRead = 0; // is.read(bytes, offset, bytes.length-offset);
            try{
              while (offset < bytes.length && (numRead = is.read(bytes, offset, bytes.length-offset)) >= 0) 
                offset += numRead;
            }
            catch (Exception ex){
              System.err.println("Downloading " + documentFullPathInMDS);
              ex.printStackTrace();
            }
            System.out.println("Resource read, " + Integer.toString(offset) + " byte(s).");
            // trim
            byte[] temp = new byte[offset];
            for (int i=0; i<offset; i++)
              temp[i] = bytes[i];
            bytes = temp;
          }
          catch (Exception ex)
          {
            ex.printStackTrace(); 
          }
          finally
          {
            is.close();
          }
        }
      }
      session.flushChanges();
      long after = System.nanoTime();
      String mess = documentFullPathInMDS + " downloaded in " + NANO_SEC_FMT.format((double)(after- before) / 1E9) + " s (" + formatMem(bytes.length).trim() + ")"; // (" + documentFullPathInMDS + ").";
      System.out.println(mess);
      return bytes;
    }

    private String formatMem(long amount){
      String str = "";
      String[] units = new String[] { "Tb", "Gb", "Mb", "Kb", "b" };
      long remainder = amount;
      for (int i = 0; i<units.length; i++){
        long divider = 1;
        for (int j=0; j<(units.length - i - 1); j++)
          divider *= 1024;
        System.out.println("Divider for [" + units[i] + "]:" + divider);
        long temp = remainder / divider;
        if (temp != 0){
          str += (Long.toString(temp) + " " + units[i] + " ");
          remainder -= (temp * divider);
        }
      }
      return str;
    }

    private  MDSInstance initializeFileStore(String filePath, String partitionName, String connName)throws Exception{
      // Updatable true so that the store can import new stuff
      FileMetadataStore store = new FileMetadataStore(filePath, partitionName);
      PConfig pConfig = new PConfig(store);
      MDSConfig config = new MDSConfig(null, pConfig, null);
      MDSInstance.releaseInstance(connName);
      return MDSInstance.getOrCreateInstance(connName, config);
    }

    private MDSInstance initializeDBStore(String username, String password, String dbURL, String partitionName,String connName)throws Exception{
      return initializeDBStore(username, password, dbURL, partitionName, connName, null);
    }

    private MDSInstance initializeDBStore(String username, String password, String dbURL, String partitionName,String connName,CacheConfig cacheConfig)throws Exception{
      DBMetadataStore store = new DBMetadataStore(username, password, dbURL, partitionName);
      PConfig pConfig = new PConfig(store);
      MDSConfig config = null;;
      if (cacheConfig == null)
        config = new MDSConfig(null, pConfig, null);
      else
        config = new MDSConfig(null, pConfig, null, null, cacheConfig);
      MDSInstance.releaseInstance(connName);
      return MDSInstance.getOrCreateInstance(connName, config);
    }

    private void recurse(MDSInstance instance, String pName, int level) throws Exception{
      PackageName packageName = null;
      if (pName != null){
        System.out.println("- Recursing on " + pName);
        packageName = PackageName.createPackageName(pName);
      }
      List<ResourceName> list = queryMDS(instance, packageName);
      for (ResourceName rn: list){
        System.out.println(lPad("+-", " ", level) + rn.getLocalName());
        if (rn.isPackageName())
          recurse(instance, rn.getAbsoluteName(), level + 2);
      }    
    }
    private List<ResourceName> findResource(MDSInstance mdsInstance, String regExpr,boolean stopAtFirstMatch) throws Exception{
      return findResource(mdsInstance, regExpr, stopAtFirstMatch, true);
    }
    
    private List<ResourceName> findResource(MDSInstance mdsInstance, String regExpr,boolean stopAtFirstMatch,boolean useRegExpr) throws Exception{
      List<ResourceName> rnList = new ArrayList<ResourceName>();
      if (useRegExpr){
        Pattern pattern = Pattern.compile(regExpr);
        findRecursively(mdsInstance, pattern, null, rnList, stopAtFirstMatch);
      }else
        findRecursively(mdsInstance, regExpr, null, rnList, stopAtFirstMatch);    
      return rnList;
    }
    
    private void findRecursively(MDSInstance instance, String pattern, String pName, List<ResourceName> rnList, boolean stopWhenFound) throws Exception{
      PackageName packageName = null;
      if (pName != null){
      System.out.println("- Recursing on " + pName);
        packageName = PackageName.createPackageName(pName);
      }
      List<ResourceName> list = queryMDS(instance, packageName);
      for (ResourceName rn: list){
        if (rn.getAbsoluteName().equals(pattern)){
          rnList.add(rn);
          if (stopWhenFound)
            break;
        }
        if (rn.isPackageName())
          findRecursively(instance, pattern, rn.getAbsoluteName(), rnList, stopWhenFound);
      }    
    }

    private void findRecursively(MDSInstance instance, Pattern pattern, String pName, List<ResourceName> rnList, boolean stopWhenFound) throws Exception{
      PackageName packageName = null;
      if (pName != null){
      System.out.println("- Recursing on " + pName);
        packageName = PackageName.createPackageName(pName);
      }
      List<ResourceName> list = queryMDS(instance, packageName);
      for (ResourceName rn: list){
        Matcher matcher = pattern.matcher(rn.getAbsoluteName());
        boolean matchFound = matcher.find();
        if (matchFound){
          rnList.add(rn);
          if (stopWhenFound)
            break;
        }
        if (rn.isPackageName())
          findRecursively(instance, pattern, rn.getAbsoluteName(), rnList, stopWhenFound);
      }    
    }
    
    private String lPad(String s, String p, int nb)
    {
      String pad = "";
      for (int i=0; i<nb; i++)
        pad += p;
      return pad + s;
    }
    
// commented as code is not being used, subh , CWE 245-J2EE Bad Practices: Direct Management of Connections
//    private Connection getConnection(String username, String password, String jdbcString)
//      throws SQLException
//    {
//      DriverManager.registerDriver(new OracleDriver());
//      Connection conn = DriverManager.getConnection(jdbcString, username, password);
//      conn.setAutoCommit(false);
//      return conn;
//    }
    
//    private List<String> getPartitionList(String username, String password, String jdbcString)
//    {
//      List<String> list = new ArrayList<String>();
//      try
//      {
//        Connection conn = getConnection(username, password, jdbcString);
//        if (conn != null)
//        {
//          final String sqlQuery = "select partition_name from mds_partitions order by 1";
//          PreparedStatement ps = conn.prepareStatement(sqlQuery);
//          ResultSet rs = ps.executeQuery();
//          while (rs.next())
//          {
//            String pName = rs.getString(1);
//            list.add(pName);
//          }
//          rs.close();
//          ps.close();
//          conn.close();
//        }
//      }
//      catch (Exception ex)
//      {
//        JOptionPane.showMessageDialog(null, ex.getLocalizedMessage(), "DB Connection", JOptionPane.ERROR_MESSAGE);
//        ex.printStackTrace();
//      }
//      return list;
//    }    
}
