package com.darden.krowd.rest.services;

import com.darden.common.header.HeaderType;
import com.darden.commonv3.GiftCardType;
import com.darden.commonv3.TokenType;
import com.darden.giftcardservice.CheckBalanceRequestType;
import com.darden.giftcardservice.CheckBalanceResponseType;
import com.darden.giftcardservice.TransactionHistoryRequestType;
import com.darden.giftcardservice.TransactionHistoryResponseType;
import com.darden.krowd.common.identity.LdapHelper;
import com.darden.krowd.rest.config.CacheAnnotations;
import com.darden.krowd.rest.config.CacheAnnotations.CacheMaxAge;


import com.darden.krowd.rest.exceptions.BadRequestException;

import com.darden.krowd.services.giftcard.BusinessFault;
import com.darden.krowd.services.giftcard.GiftCardServicePortType;
import com.darden.krowd.services.giftcard.TechnicalFault;
import com.darden.krowd.services.util.ServicesUtil;

import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;

import oracle.security.idm.User;

import oracle.webcenter.jaxrs.framework.service.RestService;
import oracle.webcenter.jaxrs.framework.uri.UriService;

import org.apache.commons.lang.StringUtils;


@Path("/giftcard")
@Produces("application/json")
public class GiftCardResource {
    
    @Context private HttpServletRequest httpRequest;
    @RestService protected UriService uriService;
    
    private static final ADFLogger logger = ADFLogger.createADFLogger(GiftCardResource.class);

    public GiftCardResource() {
        super();
    }
    
    @GET
    @CacheMaxAge(time = 360, unit = TimeUnit.MINUTES)
    @Path("/balance")    
    public Response getBalance(@QueryParam("cardnumber") String cardnumber,
                               @QueryParam("token") String token, 
                               @DefaultValue("US") @QueryParam("country") String country){
        if (cardnumber == null || StringUtils.isBlank(cardnumber)) {
            try{
                String userId = ADFContext.getCurrent().getSecurityContext().getUserName();
                User user = LdapHelper.getInstance().getUser(userId);            
                cardnumber = (String)user.getUserProfile().getPropertyVal("Darden-Giftcard-Number");            
            }catch(Exception e){
                logger.severe(e);
            }
        }
        
        if(cardnumber != null){
            GiftCardServicePortType gcPortType = ServicesUtil.getInstance().getGiftCardService();
            HeaderType header = new HeaderType();
            
            CheckBalanceRequestType checkBalanceRequest = new CheckBalanceRequestType();
            checkBalanceRequest.setHeader(header);
            CheckBalanceRequestType.GiftCards gcs = new CheckBalanceRequestType.GiftCards();
            
            
            GiftCardType gcType = new GiftCardType();
            gcType.setCardNumber(cardnumber); 
            gcType.setIssuedCountry(country);
            if(token !=null){
                TokenType tt = new TokenType();
                tt.setValue(token);
                gcType.setToken(tt);
            }
            gcs.getGiftCard().add(gcType);            
            checkBalanceRequest.setGiftCards(gcs);             
            CheckBalanceResponseType resp;
            
            try {
                resp = gcPortType.checkBalance(checkBalanceRequest);
                List gcresps = resp.getGiftCards();
                return Response.ok(gcresps).type(MediaType.APPLICATION_JSON).build();  
            } catch (Exception e) {
                logger.severe(e);
                throw new BadRequestException(e);
            } 
        }else{
            throw new BadRequestException("Gift Card Number is mandatory.");
        }
        
    }
    
    @GET
    @CacheMaxAge(time = 360, unit = TimeUnit.MINUTES)
    @Path("/transactionhistory")    
    public Response getTransactionHistory(@QueryParam("cardnumber") String cardnumber,
                               @QueryParam("token") String token, 
                               @DefaultValue("US") @QueryParam("country") String country){
        if (cardnumber == null || StringUtils.isBlank(cardnumber)) {
            try{
                String userId = ADFContext.getCurrent().getSecurityContext().getUserName();
                User user = LdapHelper.getInstance().getUser(userId);            
                cardnumber = (String)user.getUserProfile().getPropertyVal("Darden-Giftcard-Number");            
            }catch(Exception e){
                logger.severe(e);
            }
        }
        
        if(cardnumber != null){
            GiftCardServicePortType gcPortType = ServicesUtil.getInstance().getGiftCardService();
            HeaderType header = new HeaderType();
            
            TransactionHistoryRequestType transactionHistoryReq = new TransactionHistoryRequestType();

            GiftCardType gcType = new GiftCardType();
            gcType.setCardNumber(cardnumber); 
            gcType.setIssuedCountry(country);
            if(token !=null){
                TokenType tt = new TokenType();
                tt.setValue(token);
                gcType.setToken(tt);
            }
            
            transactionHistoryReq.setGiftCard(gcType);

            TransactionHistoryResponseType resp = null;
            
            try {
                resp = gcPortType.getTransactionHistory(transactionHistoryReq);                
                return Response.ok(resp).type(MediaType.APPLICATION_JSON).build();  
            } catch (Exception e) {
                logger.severe(e);
                throw new BadRequestException(e);
            } 
        }else{
            throw new BadRequestException("Gift Card Number is mandatory.");
        }
        
    }
    
}
