package com.darden.krowd.rest.services;

import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import oracle.adf.share.logging.ADFLogger;

@Path("/shifts")
@Produces("application/json")
public class ShiftsResource {
    private static final ADFLogger logger = ADFLogger.createADFLogger(ShiftsResource.class);    
    public ShiftsResource() {
        super();
    }
    
    
}
