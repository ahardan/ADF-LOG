package com.darden.krowd.rest.filter;

import com.sun.jersey.spi.container.ContainerRequest;
import com.sun.jersey.spi.container.ContainerResponse;
import com.sun.jersey.spi.container.ContainerResponseFilter;

import java.io.IOException;

import javax.ws.rs.ext.Provider;

import oracle.adf.share.logging.ADFLogger;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

@Provider
public class ADFLoggingResponseFilter
		implements ContainerResponseFilter {

	private static final ADFLogger logger = ADFLogger.createADFLogger(ADFLoggingResponseFilter.class);
    

    public ContainerResponse filter(ContainerRequest containerRequest,
                                    ContainerResponse containerResponse) {
        String method = containerRequest.getMethod();

        logger.info("Requesting " + method + " for path " + containerRequest.getPath());
        Object entity = containerResponse.getEntity();
        if (entity != null) {
            try {
                logger.info("Response " + new ObjectMapper().defaultPrettyPrintingWriter().writeValueAsString(entity));
            } catch (JsonGenerationException e) {
                logger.severe(e);
            } catch (JsonMappingException e) {
                logger.severe(e);
            } catch (IOException e) {
                logger.severe(e);
            }
        }
        
        return containerResponse;
    }
}
