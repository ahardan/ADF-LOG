package com.darden.krowd.rest.filter;

import com.darden.krowd.enhancedmessages.model.applicationmodule.common.KrowdEnhancedMessagesAppModule;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import oracle.adf.model.BindingContext;
import oracle.adf.model.DataControlFrame;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.model.servlet.HttpBindingContext;
import oracle.adf.share.ADFContext;
import oracle.adf.share.el.OracleExpressionEvaluatorImpl;

public class PrepareRestServiceFilter implements Filter {
    private FilterConfig _filterConfig = null;
    private static String PAGE_DEF = "com_darden_krowd_rest_pageDefs_RestPageDef"; 

    public void init(FilterConfig filterConfig) throws ServletException {
        _filterConfig = filterConfig;
    }

    public void destroy() {
        _filterConfig = null;
    }

    public void doFilter(ServletRequest request, ServletResponse response,
                         FilterChain chain) throws IOException,
                                                   ServletException {
        
        BindingContext bindingContext = BindingContext.getCurrent();
        if(bindingContext !=null){
            DCBindingContainer amx = bindingContext.findBindingContainer(PAGE_DEF);
            if(amx!=null)
                amx.refresh(DCBindingContainer.PREPARE_MODEL);
        }        
        chain.doFilter(request, response);
    }
}