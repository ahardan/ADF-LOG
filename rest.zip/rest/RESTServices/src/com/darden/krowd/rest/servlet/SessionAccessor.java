package com.darden.krowd.rest.servlet;

import java.io.IOException;

import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class SessionAccessor extends HttpServlet {

    /** Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     */
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //get the parameters from request
        //set parameters in session context
        Enumeration<String> parameterNames = request.getParameterNames();
        HttpSession session = request.getSession();
        if(null != session){
            while (parameterNames.hasMoreElements()){
                String parameterName = parameterNames.nextElement();
                session.setAttribute(parameterName, request.getParameter(parameterName));
            }
        } 
    }
}
