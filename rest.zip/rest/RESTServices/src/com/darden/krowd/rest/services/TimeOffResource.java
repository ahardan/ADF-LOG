package com.darden.krowd.rest.services;


import com.darden.krowd.common.identity.LdapHelper;
import com.darden.krowd.common.util.CacheUtil;
import com.darden.krowd.model.ps.applicationModule.common.PeopleSoftAM;
import com.darden.krowd.rest.exceptions.BadRequestException;
import com.darden.krowd.timeoff.model.applicationModule.common.TimeOffAM;

import java.security.SecureRandom;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import oracle.adf.model.BindingContext;
import oracle.adf.model.DataControlFrame;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;

import oracle.security.idm.User;
import oracle.security.idm.UserProfile;

import oracle.webcenter.jaxrs.framework.param.ItemsPerPageParam;
import oracle.webcenter.jaxrs.framework.param.PaginationParams;
import oracle.webcenter.jaxrs.framework.param.StartIndexParam;
import oracle.webcenter.jaxrs.framework.service.RestService;
import oracle.webcenter.jaxrs.framework.uri.UriService;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;


@Path("/timeoff")
public class TimeOffResource {
    @Context private HttpServletRequest httpRequest;
    @Context private HttpServletResponse httpResponse;
    private static final ADFLogger logger = ADFLogger.createADFLogger(TimeOffResource.class);
    
    private static String PAGE_DEF = "com_darden_krowd_rest_pageDefs_RestPageDef";  
    private static String TIME_OFF_DATACONTROL = "TimeOffAMDataControl"; //TimeOffAMDataControl
    private static String PEOPLESOFT_DATACONTROL = "PeopleSoftAMDataControl";
    
    private static ArrayList<String> AD_ATTRIBUTES = new ArrayList<String>() {{
        add("cn");
        //add("co");
        //add("company");
        add("physicalDeliveryOfficeName");
        add("Darden-Area");
        add("Darden-Business-Unit");
        //add("Darden-Company-Number");
        //add("Darden-Empl-ID");
        add("Darden-Job-Function");
        add("Darden-Job-Sub-Function");
        //add("Darden-Manager-Level");
        add("Darden-POS-ID");
        //add("Darden-PS-OPRID");
        //add("Darden-Region");
        add("description");
        add("displayName");
        //add("division");
        add("givenName");
        add("l");
        add("name");        
    }};      
    
    private static ArrayList<String> JOB_CLASSES = new ArrayList<String>() {{
        add("Alley/Expeditor");
        add("Bartender");
        add("Busser");
        add("Host");
        add("Line");
        add("Other- Culinary");
        add("Other- Service");
        add("Prep Cook/Production");
        add("Professional- Culinary");
        add("Professional- Service");
        add("Server");
        add("Service Assistant");
        add("To-Go");
        add("Utility");
    }};      

    @RestService
    protected UriService uriService;
    
    private static String[] getJobClasses(UserProfile profile){
        String defaultJobClass = null;
        if(profile != null){
            try{
            defaultJobClass = (String)profile.getPropertyVal("Darden-Job-Sub-Function");
            }catch(Exception e){
                logger.severe(e);
            }
        }
        
        SecureRandom generator = new SecureRandom();
        int jobClassCount = generator.nextInt(2)+1;
        int maxJobClasses = JOB_CLASSES.size();
        String[] jobsClasses = new String[jobClassCount];
        
        if(defaultJobClass !=null){
            jobClassCount--;
        }
        
        String jobClass;
        for(int i=0; i<jobClassCount;){            
            jobClass = JOB_CLASSES.get(generator.nextInt(maxJobClasses));
            if(!ArrayUtils.contains(jobsClasses, jobClass)){
                jobsClasses[i] = jobClass;
                i++;
            }                            
        }

        if(defaultJobClass !=null){
            jobsClasses[jobClassCount] = defaultJobClass;
        }
        
        return jobsClasses;        
    }
    
    private static String getRandomPhoneNumber(){
        int num1, num2, num3; //3 numbers in area code
        int set2, set3; //sequence 2 and 3 of the phone number
        
        SecureRandom generator = new SecureRandom();
        
        //Area code number; Will not print 8 or 9
        num1 = generator.nextInt(7) + 1; //add 1 so there is no 0 to begin  
        num2 = generator.nextInt(8); //randomize to 8 becuase 0 counts as a number in the generator
        num3 = generator.nextInt(8);
        
        // Sequence two of phone number
        // the plus 100 is so there will always be a 3 digit number
        // randomize to 643 because 0 starts the first placement so if i randomized up to 642 it would only go up yo 641 plus 100
        // and i used 643 so when it adds 100 it will not succeed 742 
        set2 = generator.nextInt(643) + 100;
        
        //Sequence 3 of numebr
        // add 1000 so there will always be 4 numbers
        //8999 so it wont succed 9999 when the 1000 is added
        set3 = generator.nextInt(8999) + 1000;
        
        return "(" + num1 + "" + num2 + "" + num3 + ")" + "-" + set2 + "-" + set3;        
    }
    
    private String convertStringToHex(String str){     
          char[] chars = str.toCharArray();     
          StringBuffer hex = new StringBuffer();
          for(int i = 0; i < chars.length; i++){
            hex.append(Integer.toHexString((int)chars[i]));
          }     
          return hex.toString();
      }
    
    private static String toJavaMethodName(final String nonJavaMethodName){
        final StringBuilder nameBuilder = new StringBuilder();
        boolean capitalizeNextChar = false;
        boolean first = true;

        for(int i = 0; i < nonJavaMethodName.length(); i++){
            final char c = nonJavaMethodName.charAt(i);
            if(!Character.isLetterOrDigit(c)){
                if(!first){
                    capitalizeNextChar = true;
                }
            } else{
                nameBuilder.append(capitalizeNextChar
                    ? Character.toUpperCase(c)
                    : Character.toLowerCase(c));
                capitalizeNextChar = false;
                first = false;
            }
        }
        return nameBuilder.toString();
    }    

    private Map<String,Object> getUserProfile(User user){
        try{
            if(user != null){
                UserProfile profile = user.getUserProfile();
                Map<String,Object> profileMp = new HashMap<String,Object>();
                for(String attr : AD_ATTRIBUTES){
                    profileMp.put(toJavaMethodName(attr),profile.getPropertyVal(attr));
                }                
                String[] jobCodes = getJobClasses(profile);
                profileMp.put("sAMAccountName", profile.getUserID());
                profileMp.put("jobCodes", jobCodes);
                profileMp.put("imageUrl", convertStringToHex(profile.getUserID()) + "/MEDIUM");
                
                if(ArrayUtils.contains(jobCodes, "Busser") || ArrayUtils.contains(jobCodes, "Server") || ArrayUtils.contains(jobCodes, "Host")){
                    String restNumber = (String)profileMp.get("physicaldeliveryofficename");
                    if(restNumber != null && restNumber.compareTo("1005")==0){
                        SecureRandom generator = new SecureRandom();
                        int randomInt = generator.nextInt(9)+1;
                        profileMp.put("nickName", "TestNickName"+randomInt);
                        profileMp.put("phoneNumber", getRandomPhoneNumber());
                    }
                }                
                return profileMp;                
            }else{
                return null;
            }
        }catch(Exception e){
            logger.severe(e);
            return null;
        }
    }                   
    
    private Object getFromCache(String key){
        return CacheUtil.getInstance().get(key,CacheUtil.CacheType.PEOPLE_CACHE);
    }
    
    private void putInCache(String key, Object object){    
        CacheUtil.getInstance().encodeAndPut(key, object, CacheUtil.CacheType.PEOPLE_CACHE);
    }
    
    
    private TimeOffAM getTimeOffAM(){
        BindingContext bindingContext = BindingContext.getCurrent();
        TimeOffAM am =null;
        DCDataControl dc = null; 
        if(bindingContext !=null){
            String dcFrameName = bindingContext.getCurrentDataControlFrame();
            DataControlFrame dcframe = dcFrameName == null? null : bindingContext.findDataControlFrame(dcFrameName);
            dc = dcframe == null ? null : dcframe.findDataControl(TIME_OFF_DATACONTROL);        
            dc = dc == null ? bindingContext.findDataControl(TIME_OFF_DATACONTROL) : dc;
            
            if(dc == null){
               DCBindingContainer amx = bindingContext.findBindingContainer(PAGE_DEF);
                dc = amx.findDataControl(TIME_OFF_DATACONTROL); 
                am = (TimeOffAM)dc.getDataProvider();
            }else{
                am = (TimeOffAM)dc.getDataProvider();
            }
        }
        return am;
    }     
    
    private PeopleSoftAM getPeopleSoftAM(){
        BindingContext bindingContext = BindingContext.getCurrent();
        PeopleSoftAM am =null;
        DCDataControl dc = null; 
        if(bindingContext !=null){
            String dcFrameName = bindingContext.getCurrentDataControlFrame();
            DataControlFrame dcframe = dcFrameName == null? null : bindingContext.findDataControlFrame(dcFrameName);
            dc = dcframe == null ? null : dcframe.findDataControl(PEOPLESOFT_DATACONTROL);        
            dc = dc == null ? bindingContext.findDataControl(PEOPLESOFT_DATACONTROL) : dc;
            
            if(dc == null){
               DCBindingContainer amx = bindingContext.findBindingContainer(PAGE_DEF);
                dc = amx.findDataControl(PEOPLESOFT_DATACONTROL); 
                am = (PeopleSoftAM)dc.getDataProvider();
            }else{
                am = (PeopleSoftAM)dc.getDataProvider();
            }
        }
        return am;
    }     
    
    
    public TimeOffResource() {
        super();
    }
    
    private Map<String,String> getSamEmpMap(Map<String,User> samsMap){
        if(samsMap == null){
            return null;
        }
        
        Map<String,String> samEmpMap = new HashMap<String,String>();
        String empId;
        for(Map.Entry<String,User> samEmpEntry : samsMap.entrySet()){
            try{
                empId = (String)samEmpEntry.getValue().getUserProfile().getPropertyVal("Darden-Empl-ID");
                samEmpMap.put(samEmpEntry.getKey().toLowerCase(),empId);
            }catch(Exception e){
                logger.severe(e);
            }
        }
        return samEmpMap;
    }
    
    private Map<String,User> makeKeysUpper(Map<String,User> maps){
        if(maps == null)
            return maps;
        Map<String,User> nMap = new HashMap<String,User>();
        for(Map.Entry<String,User> entry : maps.entrySet()){
            nMap.put(entry.getKey().toUpperCase(), entry.getValue());
        }
        return nMap;
    }
    
    private List<Map<String,Object>> enrichRequests(List<Map<String,Object>> requests){
        if(requests != null && !requests.isEmpty()){
            ArrayList<String> sams = new ArrayList<String>();    
            String fldSAM;
            for(Map<String,Object> req : requests){
                fldSAM = req.get("fldSAM").toString();
                fldSAM = fldSAM.toUpperCase();
                if(fldSAM.startsWith("88") && !fldSAM.endsWith("T")){
                    fldSAM = fldSAM+"T";
                }
                if(!sams.contains(fldSAM)){
                    sams.add(fldSAM);    
                }                
            }
            try{
                Map<String,User> samsMap = LdapHelper.getInstance().getUsersBySAM(sams);
                samsMap = makeKeysUpper(samsMap);
                Map<String,String> samToEmpMap = getSamEmpMap(samsMap);
                Collection<String> empVals = samToEmpMap.values();
                if(empVals.size() <= 0){                
                    Map<String,Object> profMap;
                    if(samsMap != null && samsMap.size() >0){
                        for(Map<String,Object> req : requests){
                            fldSAM = req.get("fldSAM").toString();
                            fldSAM = fldSAM.toUpperCase();
                            if(fldSAM.startsWith("88") && !fldSAM.endsWith("T")){
                                fldSAM = fldSAM+"T";
                            }
                            profMap = getUserProfile(samsMap.get(fldSAM));
                            if(profMap != null){
                                req.put("fldSAMRef",profMap);
                            }
                        }                        
                    }
                }else{
                    PeopleSoftAM am = getPeopleSoftAM();
                    List<Map<String,Object>> result = am.getEmployees(new ArrayList<String>(empVals), null,null,null,null,null, null,null,null, 0, requests.size());                    
                    Map<String,Map<String,Object>> resultMap = convertToMap(result);                          
                    if(resultMap != null){
                        Map<String,Object> fldEmpIDRef;
                        String sam;
                        String empId;
                        for(Map<String,Object> req : requests){
                            sam = (String)req.get("fldSAM");
                            sam = sam.toUpperCase();
                            if(sam.startsWith("88") && !sam.endsWith("T")){
                                sam = sam+"T";
                            }
                            empId = samToEmpMap.get(sam);
                            if(empId != null){
                                fldEmpIDRef = resultMap.get(empId);
                                if(fldEmpIDRef != null){
                                    req.put("fldSAMRef",fldEmpIDRef);
                                }else{
                                    req.put("fldSAMRef",getUserProfile(samsMap.get(sam)));
                                }
                            }else{
                                req.put("fldSAMRef",getUserProfile(samsMap.get(sam)));
                            }
                        }                
                    }else{
                        Map<String,Object> profMap;
                        if(samsMap != null && samsMap.size() >0){
                            for(Map<String,Object> req : requests){
                                fldSAM = req.get("fldSAM").toString();
                                fldSAM = fldSAM.toUpperCase();
                                if(fldSAM.startsWith("88") && !fldSAM.endsWith("T")){
                                    fldSAM = fldSAM+"T";
                                }
                                profMap = getUserProfile(samsMap.get(fldSAM));
                                if(profMap != null){
                                    req.put("fldSAMRef",profMap);
                                }
                            }                        
                        }                        
                    }
                }
                return requests;                
            }catch(Exception e){
                logger.severe(e);
                return null;
            }
        }else{
            return null;
        }        
    }

    private Map<String,Object> enrichRequest(Map<String,Object> request){
        List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
        list.add(request);
        list = enrichRequests(list);
        if(list != null && list.size() >0){
            return list.get(0);
        }else{
            return null;
        }
    }
    
    private Map<String,Map<String,Object>> convertToMap(List<Map<String,Object>> results){
        if(results == null || results.isEmpty()){
            return null;
        }
        
        Map<String,Map<String,Object>> ret = new HashMap<String,Map<String,Object>>();
        for(Map<String,Object> result: results){
            ret.put(result.get("EmployeeId").toString(), result);
        }
        return ret;
    }

    @POST
    @Path("/blockeddates/create")
    @Produces("application/json")
    public Response createBlockedDate(HashMap<String,Object> data){
        Integer restaurantNumber = (Integer)data.get("restaurantNumber");
        String corpCode = (String)data.get("corpCode");
        String dateOffStr = (String)data.get("blockedDate");
        
        if(restaurantNumber == null || corpCode == null  || dateOffStr == null){
            throw new BadRequestException("Restaurant Number, Corp Code and Date Off are mandatory.");
        }
        
        try{
            DateTimeFormatter parser = ISODateTimeFormat.dateTimeParser();
            DateTime dateOff = parser.parseDateTime(dateOffStr);
            
            TimeOffAM am = getTimeOffAM();
            am.createBlockedDate(corpCode, restaurantNumber, dateOff.toDate());
            
            return Response.status(Response.Status.OK).build();
        }catch(Exception e){
            throw new BadRequestException(e);
        }
    }

    @GET
    @Path("/blockeddates")
    @Produces("application/json")
    public Response getBlockedDates(@QueryParam("restaurantNumber") Integer restaurantNumber,
                                    @QueryParam("startDate") String startDateStr,
                                    @QueryParam("endDate") String endDateStr,
                                    @DefaultValue("0") @QueryParam("startIndex") StartIndexParam startIndex,
                                    @DefaultValue("25") @QueryParam("itemsPerPage") ItemsPerPageParam itemsPerPage){
        
        if(StringUtils.isBlank(startDateStr) || StringUtils.isBlank(endDateStr)){
            throw new BadRequestException("RestaurantNumber, Start Date and End Date are mandatory.");
        }
        try{
            if(restaurantNumber == null){
                String userId = ADFContext.getCurrent().getSecurityContext().getUserName();                
                User user = LdapHelper.getInstance().getUser(userId);
                UserProfile profile = user.getUserProfile();        
                String restaurantNumberStr = (String)profile.getPropertyVal("physicalDeliveryOfficeName");
                restaurantNumber = Integer.parseInt(restaurantNumberStr);
            }
            
            DateTimeFormatter parser = ISODateTimeFormat.dateTimeParser();
            DateTime startDate = parser.parseDateTime(startDateStr);
            DateTime endDate = parser.parseDateTime(endDateStr);
    
            logger.info("--- Restaurant Number-----"+restaurantNumber);
            logger.info("--- Start Date-----{0}",startDate);
            logger.info("--- End Date-----{0}",endDate);
            
    
            PaginationParams pagination = new PaginationParams(startIndex, itemsPerPage);
    
            TimeOffAM am = getTimeOffAM();
            logger.info("---Application Module---"+am);
            List<Map<String,Object>> blockedDates = am.getBlockedDates(restaurantNumber, startDate.toDate(), endDate.toDate(), pagination.getStartIndexValue(),pagination.getItemsPerPageValue());
            return Response.status(Response.Status.OK).entity(blockedDates).type(MediaType.APPLICATION_JSON).build();
        }catch(Exception e){
            logger.severe(e);
            throw new BadRequestException(e);
        }
    }

    @POST
    @Path("/requests/create")
    @Produces("application/json")
    public Response createRequest(List<Map<String,Object>> requests){
        TimeOffAM am = getTimeOffAM();
        if(requests == null || requests.size() ==0 ){
            logger.severe("Invalid Request");
            throw new BadRequestException("Invalid Request");
        }
        try{
            am.createTimeOffRequests(requests);
            return Response.status(Response.Status.OK).type(MediaType.APPLICATION_JSON).build();
        }catch(Exception e){
            logger.severe(e);
            throw new BadRequestException(e);
        }
    }
    
    private Response getTimeOffRequestsIntern(  String queryBy,
                                                Integer restaurantNumber,
                                                List<String> sAMAccountNames,   
                                                String corpCode,   
                                                String orderBy,                                                                      
                                                Integer dardenPOSId,                                   
                                                Integer status,                                   
                                                String startDateStr,
                                                String endDateStr,
                                                StartIndexParam startIndex,
                                                ItemsPerPageParam itemsPerPage){
        if(StringUtils.isBlank(startDateStr) || StringUtils.isBlank(endDateStr)){
            throw new BadRequestException("RestaurantNumber, Start Date , End Date, corp code and darden pos id are mandatory.");
        }
        
        try{        
            String userId = ADFContext.getCurrent().getSecurityContext().getUserName();                
            User user = LdapHelper.getInstance().getUser(userId);
            UserProfile profile = user.getUserProfile();        
            if(restaurantNumber == null){
                String restaurantNumberStr = (String)profile.getPropertyVal("physicalDeliveryOfficeName");
                if(restaurantNumberStr != null){
                    restaurantNumber = Integer.parseInt(restaurantNumberStr);        
                }else{
                    throw new BadRequestException("AD User does not associated Restaurant Number.");
                }                    
            }

            if(corpCode == null){
                corpCode = (String)profile.getPropertyVal("company");
            }
            
            if(dardenPOSId == null){
                String dardenPoSIdStr = (String)profile.getPropertyVal("Darden-POS-ID");
                if(dardenPoSIdStr != null){
                    dardenPOSId = Integer.parseInt(dardenPoSIdStr);                            
                }                    
            }    
            
            if(sAMAccountNames == null || sAMAccountNames.size() == 0){
                //sAMAccountNames = new ArrayList<String>();
                //sAMAccountNames.add(userId);
                sAMAccountNames = null;
            }
            
            DateTimeFormatter parser = ISODateTimeFormat.dateTimeParser();
            DateTime startDate = parser.parseDateTime(startDateStr);
            DateTime endDate = parser.parseDateTime(endDateStr);
        
            logger.info("--- Restaurant Number-----"+restaurantNumber);
            logger.info("--- Corp Code-----"+corpCode);
            logger.info("--- Order By-----"+orderBy);
            logger.info("--- POS ID-----"+dardenPOSId);
            logger.info("--- Start Date-----{0}",startDate);
            logger.info("--- End Date-----{0}",endDate);
            
        
            PaginationParams pagination = new PaginationParams(startIndex, itemsPerPage);
        
            TimeOffAM am = getTimeOffAM();
            if(queryBy == null || queryBy.compareToIgnoreCase("REQUEST") == 0){
                List<Map<String,Object>> requests = am.getTimeOffRequestsByRequestDate(sAMAccountNames,corpCode, restaurantNumber, dardenPOSId, startDate.toDate(), endDate.toDate(), status, pagination.getStartIndexValue(),pagination.getItemsPerPageValue(), orderBy);    
                requests = enrichRequests(requests);
                return Response.status(Response.Status.OK).entity(requests).type(MediaType.APPLICATION_JSON).build();
            }
            
            if(queryBy.compareToIgnoreCase("ENTRY") == 0){
                List<Map<String,Object>> requests = am.getTimeOffRequestsByEntryDate(sAMAccountNames,corpCode, restaurantNumber, dardenPOSId, startDate.toDate(), endDate.toDate(), status, pagination.getStartIndexValue(),pagination.getItemsPerPageValue(), orderBy);    
                requests = enrichRequests(requests);
                return Response.status(Response.Status.OK).entity(requests).type(MediaType.APPLICATION_JSON).build();                
            }
            
            logger.severe("Invalid queryBy Provided.");
            throw new BadRequestException("Invalid queryBy Provided.");
                        
        }catch(Exception e){
            logger.severe(e);
            throw new BadRequestException(e);
        }        
    }
    
    @GET
    @Path("/requests")
    @Produces("application/json")
    public Response getTimeOffRequests(@QueryParam("restaurantNumber") Integer restaurantNumber,
                                    @QueryParam("userId") List<String> sAMAccountNames,   
                                    @QueryParam("company") String corpCode,   
                                    @QueryParam("orderBy") String orderBy,                                                                      
                                    @QueryParam("dardenPOSId") Integer dardenPOSId,                                   
                                    @QueryParam("status") Integer status,                                   
                                    @QueryParam("startDate") String startDateStr,
                                    @QueryParam("endDate") String endDateStr,
                                    @DefaultValue("REQUEST_DATE") @QueryParam("dateCriteria") String dateCriteria,
                                    @DefaultValue("0") @QueryParam("startIndex") StartIndexParam startIndex,
                                    @DefaultValue("25") @QueryParam("itemsPerPage") ItemsPerPageParam itemsPerPage){
        if(dateCriteria.compareToIgnoreCase("REQUEST_DATE") == 0){
            return getTimeOffRequestsIntern("REQUEST", restaurantNumber, sAMAccountNames, corpCode, orderBy, dardenPOSId, status, startDateStr, endDateStr, startIndex, itemsPerPage);    
        }

        if(dateCriteria.compareToIgnoreCase("ENTRY_DATE") == 0){
            return getTimeOffRequestsIntern("ENTRY", restaurantNumber, sAMAccountNames, corpCode, orderBy, dardenPOSId, status, startDateStr, endDateStr, startIndex, itemsPerPage);    
        }
        
        logger.severe("Invalid dateCriteria specified. Please specify REQUEST_DATE or ENTRY_DATE");
        throw new BadRequestException("Invalid dateCriteria specified. Please specify REQUEST_DATE or ENTRY_DATE");
    }   

    @GET
    @Path("/request/{requestId}")
    @Produces("application/json")
    public Response getRequestById(@PathParam("requestId") Long requestId){
        try{
            TimeOffAM am = getTimeOffAM();
            Map<String,Object> request = am.getTimeOffRequestById(requestId);
            request = enrichRequest(request);
            return Response.status(Response.Status.OK).entity(request).type(MediaType.APPLICATION_JSON).build();
        }catch(Exception e){
            e.printStackTrace();
            logger.severe(e);
            throw new BadRequestException(e);
        }
    }
    
    @GET
    @Path("/blockeddate/{blockedDateId}")
    @Produces("application/json")
    public Response getBlockedDateById(@PathParam("blockedDateId") Long blockedDateId){
        try{
            TimeOffAM am = getTimeOffAM();
            Map<String,Object> request = am.getBlockedDateById(blockedDateId);
            return Response.status(Response.Status.OK).entity(request).type(MediaType.APPLICATION_JSON).build();
        }catch(Exception e){
            logger.severe(e);            
            throw new BadRequestException(e);
        }
    }
    
    @DELETE
    @Path("/blockeddate/{blockedDateId}")
    @Produces("application/json")
    public Response deleteBlockedDateById(@PathParam("blockedDateId") Long blockedDateId){
        try{
            TimeOffAM am = getTimeOffAM();
            am.deleteBlockedDateById(blockedDateId);
            return Response.status(Response.Status.OK).build();
        }catch(Exception e){
            logger.severe(e);            
            throw new BadRequestException(e);
        }
    }

    @GET
    @Path("/request/{requestId}/related")
    @Produces("application/json")
    public Response getRelatedRequests(@PathParam("requestId") Long requestId,
                                    @DefaultValue("0") @QueryParam("startIndex") StartIndexParam startIndex,
                                    @DefaultValue("25") @QueryParam("itemsPerPage") ItemsPerPageParam itemsPerPage){
        try{
            PaginationParams pagination = new PaginationParams(startIndex, itemsPerPage);        
            TimeOffAM am = getTimeOffAM();
            List<Map<String,Object>> requests = am.getRelatedRequests(requestId, pagination.getStartIndexValue(), pagination.getItemsPerPageValue());
            requests = enrichRequests(requests);
            return Response.status(Response.Status.OK).entity(requests).type(MediaType.APPLICATION_JSON).build();
        }catch(Exception e){
            logger.severe(e);                        
            throw new BadRequestException(e);
        }
    }

    @DELETE
    @Path("/request/{requestId}")
    @Produces("application/json")
    public Response deleteRequest(@PathParam("requestId") Long requestId){
        try{
            TimeOffAM am = getTimeOffAM();
            am.deleteTimeOffRequest(requestId);
            return Response.status(Response.Status.OK).type(MediaType.APPLICATION_JSON).build();
        }catch(Exception e){
            logger.severe(e);                        
            throw new BadRequestException(e);
        }
    }

    @PUT
    @Path("/requests")
    @Produces("application/json")
    public Response updateRequests(List<Map<String,Object>> dataList){
        TimeOffAM am = getTimeOffAM();        
        try{
            for(Map<String,Object> data : dataList){
                Object statusObj = data.get("status");
                Object requestIdObj = data.get("requestId");
                
                String comment = (String)data.get("comment");                                
                Long requestId = Long.parseLong(requestIdObj.toString());  
                Integer status = Integer.parseInt(statusObj.toString());
                am.updateRequest(requestId,status,comment);  
            }
            am.commit();
            return Response.status(Response.Status.OK).type(MediaType.APPLICATION_JSON).build();
        }catch(Exception e){
            logger.severe(e);                        
            am.rollback();
            throw new BadRequestException(e);
        }
    }
    
    @PUT
    @Path("/request/{requestId}")
    @Produces("application/json")
    public Response updateRequest(@PathParam("requestId") Long requestId, Map<String,Object> data){
        TimeOffAM am = getTimeOffAM();        
        try{
            Integer status = (Integer)data.get("status");
            String comment = (String)data.get("comment");        
            am.updateRequest(requestId,status,comment);      
            am.commit();
            return Response.status(Response.Status.OK).type(MediaType.APPLICATION_JSON).build();
        }catch(Exception e){
            logger.severe(e);                        
            throw new BadRequestException(e);
        }
    }
    
    @GET
    @Path("/jobclass")
    @Produces("application/json")
    public Response getJobClass(@QueryParam("corpCode") String corpCode,
                                  @QueryParam("jobClass") String jobClass){
        TimeOffAM am = getTimeOffAM();
        try{
            Map<String,Object> jobClassDet = am.getJobClassDetails(corpCode, jobClass);
            return Response.status(Response.Status.OK).entity(jobClassDet).type(MediaType.APPLICATION_JSON).build();
        }catch(Exception e){
            logger.severe(e);       
            throw new BadRequestException(e);
        }
    }
    
    public static void main(String[] args){
        String[] jobClasses = TimeOffResource.getJobClasses(null);
        for(String job: jobClasses){
            System.out.println(job);
        }
        
    }

}
