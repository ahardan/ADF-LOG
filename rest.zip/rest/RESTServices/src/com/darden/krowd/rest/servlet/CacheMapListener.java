package com.darden.krowd.rest.servlet;

import com.tangosol.util.AbstractMapListener;
import com.tangosol.util.MapEvent;

import java.util.Map;

import oracle.adf.share.logging.ADFLogger;

import oracle.security.idm.User;

import oracle.webcenter.framework.security.idm.UserCacheManager;
import oracle.webcenter.peopleconnections.profile.ProfileFactory;
import oracle.webcenter.peopleconnections.profile.UserProfileManager;
import oracle.webcenter.peopleconnections.profile.WCUserProfile;

public class CacheMapListener extends AbstractMapListener {
    private static final ADFLogger logger = ADFLogger.createADFLogger(CacheMapListener.class);
    
    public CacheMapListener() {
        super();
    }

    @Override
    public void entryUpdated(MapEvent mapEvent) {
        super.entryUpdated(mapEvent);
        try{
            logger.info("==== UPDATE : Received Update Event ======");
            Map.Entry entry = mapEvent.getNewEntry();
            String key = (String)entry.getKey();
            if(key.indexOf("PROFILE_PHOTO_UPDATE") ==0){
                logger.info("==== UPDATE : Received Profile Photo Update Event ======");
                String userId = (String)entry.getValue();
                invalidateUserProfilePhotoCache(userId);
                logger.info("==== Invalidated photo cache for ======"+ userId);
            }
        }catch(Exception e){
            logger.severe(e);
        }        
    }
    
    private void invalidateUserProfilePhotoCache(String userId){
        try{
            User user = (User) UserCacheManager.getUserFromUserName(userId);
            if(user != null){
                logger.info("======= User ======"+user.getClass().toString());                
                if(user instanceof WCUserProfile){
                    logger.info("=========== Instance Found ===========");
                    ((WCUserProfile)user).invalidatePhotoCache();
                }
            }
        }catch(Exception e){
            logger.severe(e);
        }
        
    }

    @Override
    public void entryInserted(MapEvent mapEvent) {
        super.entryInserted(mapEvent);
        try{
            logger.info("==== INSERT : Received Insert Event ======");
            Map.Entry entry = mapEvent.getNewEntry();
            String key = (String)entry.getKey();
            if(key.indexOf("PROFILE_PHOTO_UPDATE") ==0){
                logger.info("==== INSERT : Received Profile Photo Insert Event ======");
                String userId = (String)entry.getValue();
                invalidateUserProfilePhotoCache(userId);
                logger.info("==== Invalidated photo cache for ======"+ userId);
            }
        }catch(Exception e){
            logger.severe(e);
        }
    }

    @Override
    public void entryDeleted(MapEvent mapEvent) {
        super.entryDeleted(mapEvent);
    }
}
