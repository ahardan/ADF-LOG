package com.darden.krowd.rest.support;

import com.sun.xml.bind.marshaller.NamespacePrefixMapper;

public class WcmNamespaceMapper extends NamespacePrefixMapper {
    private static final String WCM_PREFIX = "wcm";
    private static final String WCM_URI = "http://www.stellent.com/wcm-data/ns/8.0.0";
    
    @Override
    public String getPreferredPrefix(String namespaceUri, String suggestion, boolean requirePrefix) {
        if(WCM_URI.equals(namespaceUri)) {
            return WCM_PREFIX;
        }
        return suggestion;
    }
    
    @Override
    public String[] getPreDeclaredNamespaceUris() {
        return new String[] { WCM_URI};
    }
}
