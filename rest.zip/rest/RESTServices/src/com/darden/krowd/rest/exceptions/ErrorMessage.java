package com.darden.krowd.rest.exceptions;

import com.sun.jersey.api.NotFoundException;

import java.io.PrintWriter;
import java.io.StringWriter;

import java.lang.reflect.InvocationTargetException;


import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.beanutils.BeanUtils;


@XmlRootElement
public class ErrorMessage {
        public static final int GENERIC_APP_ERROR_CODE = 5001;          
        public static final String KROWD_URL = "https://krowd.darden.com";
    
	
	/** contains the same HTTP Status code returned by the server */
	@XmlElement(name = "status")
	int status;
	
	/** application specific error code */
	@XmlElement(name = "code")
	int code;
	
	/** message describing the error*/
	@XmlElement(name = "message")
	String message;
		
	/** link point to page where the error message is documented */
	@XmlElement(name = "link")
	String link;
	
	/** extra information that might useful for developers */
	@XmlElement(name = "developerMessage")
	String developerMessage;	

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getDeveloperMessage() {
		return developerMessage;
	}

	public void setDeveloperMessage(String developerMessage) {
		this.developerMessage = developerMessage;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}
	

        public ErrorMessage(Throwable ex){
            if(ex instanceof AppException){
                try {
                        BeanUtils.copyProperties(this, ex);
                } catch (IllegalAccessException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                } catch (InvocationTargetException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                }                
            }else{
                if(ex instanceof NotFoundException){
                    this.status = Response.Status.NOT_FOUND.getStatusCode();
                    this.message = ex.getMessage();
                    this.link = "https://jersey.java.net/apidocs/1.15/jersey/com/sun/jersey/api/NotFoundException.html";                    
                }else{
                    this.status=GENERIC_APP_ERROR_CODE;
                    this.message=ex.getMessage();                    
                    StringWriter errorStackTrace = new StringWriter();
                    ex.printStackTrace(new PrintWriter(errorStackTrace));                    
                    this.developerMessage=errorStackTrace.toString();
                    this.link=KROWD_URL;
                    
                    if(ex instanceof WebApplicationException ) { //NICE way to combine both of methods, say it in the blog 
                        this.status = ((WebApplicationException)ex).getResponse().getStatus();
                    } else {
                        this.status = Response.Status.INTERNAL_SERVER_ERROR.getStatusCode();
                    }                    
                }
            }
        }
        
        public static ErrorMessage getErrorMessageInstance(Throwable ex){
            return new ErrorMessage(ex);
        }

	public ErrorMessage() {}
}