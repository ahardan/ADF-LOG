package com.darden.krowd.rest.params;

import java.text.DateFormat;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.Date;

import java.util.GregorianCalendar;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang.StringUtils;

public class DateParam {
  private  Date date = null;
  private  XMLGregorianCalendar calendar = null;

  public DateParam(String dateStr) throws WebApplicationException {
    if (StringUtils.isBlank(dateStr)) {
      this.date = null;
      return;
    }
    final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    try {
      this.date = dateFormat.parse(dateStr);
      GregorianCalendar gc = (GregorianCalendar) GregorianCalendar.getInstance();
        gc.setTime(date);
        calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gc);
        calendar.setTimezone(DatatypeConstants.FIELD_UNDEFINED);
    } catch (ParseException e) {
      throw new WebApplicationException(Response.status(Response.Status.BAD_REQUEST)
        .entity("Couldn't parse date string: " + e.getMessage())
        .build());
    } catch (DatatypeConfigurationException e) {
            new WebApplicationException(Response.status(Response.Status.BAD_REQUEST)
                    .entity("Couldn't parse date string: " + e.getMessage())
                    .build());
        }
    }

  public Date getDate() {
    return date;
  }
  
    public XMLGregorianCalendar getXMLCalendar() {
      return calendar;
    }
  
}