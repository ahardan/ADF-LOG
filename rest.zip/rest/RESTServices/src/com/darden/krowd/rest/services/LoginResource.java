package com.darden.krowd.rest.services;

import com.darden.krowd.loginflow.rest.ActivationFlowRESTImpl;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;


@Path("/login")
@Produces("application/json")
public class LoginResource {
    private static final ADFLogger logger = ADFLogger.createADFLogger(LoginResource.class);    

    public LoginResource() {
        super();
    }

    /**
     * Sends Password Reset code to the user's email ID.
     */
    @POST
    @Path("/sendPasscodeEmail/{samAccountName}")
    public Response sendTemporaryPasscode(@PathParam("samAccountName") String  samAccountName){
        ActivationFlowRESTImpl activationFlowRESTImpl = new ActivationFlowRESTImpl();
        Boolean ret = activationFlowRESTImpl.sendTemporaryPasscode(samAccountName);         
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }

    /**
     * Resets user's account in Krowd
     */
    @POST
    @Path("/resetUserAccount/{samAccountName}")
 public Response resetUserAccount(@PathParam("samAccountName") String  samAccountName){
            ActivationFlowRESTImpl activationFlowRESTImpl = new ActivationFlowRESTImpl();
        Boolean ret = activationFlowRESTImpl.resetUserAccount(samAccountName);
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }


    @POST
    @Path("/acceptTerms/{contentId}")
    public Response acceptTermsAndActivate(@PathParam("contentId")
        String contentId) {
        ActivationFlowRESTImpl activationFlowRESTImpl = new ActivationFlowRESTImpl();
        String userId = ADFContext.getCurrent().getSecurityContext().getUserName();
        activationFlowRESTImpl.acceptTermsAndActivate(userId,contentId);
        return Response.ok().build();
    }
}
