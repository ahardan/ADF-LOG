package com.darden.krowd.rest.servlet;


import com.tangosol.net.DefaultConfigurableCacheFactory;
import com.tangosol.net.NamedCache;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import oracle.adf.share.logging.ADFLogger;

import oracle.webcenter.content.integration.cache.CacheFactory;


public class CacheListener extends HttpServlet {
    private static final ADFLogger logger = ADFLogger.createADFLogger(CacheListener.class);
    
    private static final long serialVersionUID = -4617440838407196407L;
    private final DefaultConfigurableCacheFactory factory;
    private CacheMapListener cacheMapListener;
    private NamedCache cache;
    
    public CacheListener() {
        super();
        this.factory = new DefaultConfigurableCacheFactory("content" + "-coherence-cache-config.xml", CacheFactory.class.getClassLoader());
        this.cacheMapListener = new CacheMapListener();
    }
    
    @Override
    public void init(ServletConfig servletConfig) throws ServletException {
        logger.info("========== Init from Coherence Cache Listener =========");
        super.init(servletConfig);
        this.cache = this.factory.ensureCache("com.darden.krowd.stringsCache",CacheFactory.class.getClassLoader());
        cache.addMapListener(this.cacheMapListener);
    }

    @Override
    public void destroy() {
        super.destroy();
        if(this.cache != null){
            cache.removeMapListener(this.cacheMapListener);
        }
    }
}
