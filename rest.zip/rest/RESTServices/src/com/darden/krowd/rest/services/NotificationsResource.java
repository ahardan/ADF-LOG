package com.darden.krowd.rest.services;


import com.darden.krowd.common.util.MDSUtils;
import com.darden.krowd.model.serialize.ActivityNotification;
import com.darden.krowd.model.serialize.NotificationSetting;
import com.darden.krowd.model.storeMds.MdsStoreObject;
import com.darden.krowd.model.storeMds.StoreMDS;
import com.darden.krowd.rest.exceptions.BadRequestException;


import com.darden.krowd.rest.model.QuickLinkDTO;

import java.io.IOException;

import java.util.ArrayList;

import java.util.Arrays;
import java.util.Collections;

import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import javax.xml.parsers.ParserConfigurationException;

import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;

import oracle.webcenter.peopleconnections.profile.ProfileException;
import oracle.webcenter.peopleconnections.profile.ProfileFactory;
import oracle.webcenter.peopleconnections.profile.UserProfileManager;
import oracle.webcenter.peopleconnections.profile.WCUserProfile;

import oracle.webcenter.peopleconnections.profile.internal.model.ProfileInternalUtils;

import oracle.webcenter.peopleconnections.wall.internal.model.WallServiceUtils;

import org.xml.sax.SAXException;


@Path("/notifications")
@Produces("application/json")
public class NotificationsResource {
    
    private static final ADFLogger logger = ADFLogger.createADFLogger(NotificationsResource.class);
    
    public NotificationsResource() {
        super();
    }
    
    @GET
    @Path("/testEL")
    public Response getResults(){
        String output = "DefaultValue";
        String output1 = "DefaultValue";
        try{
            output = (String)ADFContext.getCurrent().getExpressionEvaluator().evaluate("#{securityContext.userName}");
            logger.info("Result of expresion=" + output);
            output1 = (String)ADFContext.getCurrent().getExpressionEvaluator().evaluate("#{LDStoreBean['#{securityContext.userName}:DISPLAY_NAME']}");
            logger.info("Result of expresion=" + output1);
        }
        catch(Exception e){
            logger.severe(e);
        }
        output = output.concat("#####").concat(output1);
        return Response.ok(output).type(MediaType.APPLICATION_JSON).build();
    }
   
    @GET
    @Path("/inbox")
    public Response getNotifications(){
        ArrayList<ActivityNotification> notifications = new ArrayList<ActivityNotification>();
        String userName = ADFContext.getCurrent().getSecurityContext().getUserName();
        try {
            StoreMDS mds = StoreMDS.getInstance();
            notifications = mds.getNotifications(userName);
            logger.info("Notifications from StoreMDS = " + notifications);
            if(null != notifications){     
                logger.info("Processing Notifications");
            for(ActivityNotification activityNotification:notifications){
                if("Comment".equalsIgnoreCase(activityNotification.getActivityType())){
                    try{
                        UserProfileManager profileManager = ProfileFactory.getProfileManager();
                        WCUserProfile userProfile = profileManager.getProfile(activityNotification.getComActorId());
                        if(userProfile != null){
                            String guid = WallServiceUtils.userNameToGuid(userProfile.getUserName());
                            activityNotification.setComActorName(userProfile.getDisplayName());
                            activityNotification.setComActorPhotoURI(generatePhotoURI(guid,"SMALL"));
                        }
                    }
                    catch (ProfileException e) {
                               logger.severe(e);
                    }
                }
                if("Like".equalsIgnoreCase(activityNotification.getActivityType())){
                    try {
                        UserProfileManager profileManager = ProfileFactory.getProfileManager();
                        WCUserProfile userProfile =
                            profileManager.getProfile(activityNotification.getLikeActorId());
                        if (userProfile != null) {
                            String guid =WallServiceUtils.userNameToGuid(userProfile.getUserName());
                            activityNotification.setLikeActorName(userProfile.getDisplayName());
                            activityNotification.setLikeActorPhotoURI(generatePhotoURI(guid,"SMALL"));
                        }
                    } catch (ProfileException e) {
                        logger.severe(e);
                    }
                }
            }
            }
            if (notifications != null){
                Collections.reverse(notifications);
            }
        } catch (Exception e) {
            logger.severe(e);
            //suppressing the exception to ignore the duplicate MDS files issue
            //throw new BadRequestException(e);            
        }
        if(null == notifications){
            //MDS returns null object hence creating empty object
            notifications = new ArrayList<ActivityNotification>();
        }
        return Response.ok(notifications.toArray(new ActivityNotification[notifications.size()])).type(MediaType.APPLICATION_JSON).build();
    }
    
    @PUT
    @Path("/read/{index}")
    public Response readNotification(@PathParam("index") int index){
        StoreMDS mds = StoreMDS.getInstance();
        MdsStoreObject ret = null;
        try {
            ret = mds.updateNotification(index, ADFContext.getCurrent().getSecurityContext().getUserName());
            ArrayList<ActivityNotification> notifications = null;
            notifications = ret.getActivityNotification();
            for(ActivityNotification activityNotification:notifications){
                if("Comment".equalsIgnoreCase(activityNotification.getActivityType())){
                    try{
                        UserProfileManager profileManager = ProfileFactory.getProfileManager();
                        WCUserProfile userProfile = profileManager.getProfile(activityNotification.getComActorId());
                        if(userProfile != null){
                            String guid = WallServiceUtils.userNameToGuid(userProfile.getUserName());
                            activityNotification.setComActorName(userProfile.getDisplayName());
                            activityNotification.setComActorPhotoURI(generatePhotoURI(guid,"SMALL"));
                        }
                    }
                    catch (ProfileException e) {
                               logger.severe(e);
                    }
                }
                if("Like".equalsIgnoreCase(activityNotification.getActivityType())){
                    try {
                        UserProfileManager profileManager = ProfileFactory.getProfileManager();
                        WCUserProfile userProfile =
                            profileManager.getProfile(activityNotification.getLikeActorId());
                        if (userProfile != null) {
                            String guid =WallServiceUtils.userNameToGuid(userProfile.getUserName());
                            activityNotification.setLikeActorName(userProfile.getDisplayName());
                            activityNotification.setLikeActorPhotoURI(generatePhotoURI(guid,"SMALL"));
                        }
                    } catch (ProfileException e) {
                        logger.severe(e);
                    }
                }
            }
            
        } catch (IOException e) {
            logger.severe(e);
            throw new BadRequestException(e);
        } catch (ParserConfigurationException e) {
            logger.severe(e);
            throw new BadRequestException(e);
        } catch (SAXException e) {
            logger.severe(e);
            throw new BadRequestException(e);
        }
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    @DELETE
    @Path("/delete/{index}")
    public Response deleteNotification(@PathParam("index") int index){
        StoreMDS mds = StoreMDS.getInstance();
        MdsStoreObject ret = null;
        try {
            ret = mds.removeNotification(index, ADFContext.getCurrent().getSecurityContext().getUserName());
        } catch (IOException e) {
            logger.severe(e);
            throw new BadRequestException(e);
        } catch (ParserConfigurationException e) {
            logger.severe(e);
            throw new BadRequestException(e);
        } catch (SAXException e) {
            logger.severe(e);
            throw new BadRequestException(e);            
        }
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("/prefs")
    public Response getNotificationsPreferences(){
        List<String> userPreferences = new ArrayList<String>();
        StoreMDS mds = StoreMDS.getInstance();
        ArrayList<String> preferences = null;
        List<NotificationSetting> notificationSettings = new ArrayList<NotificationSetting>();
        try {
            preferences = mds.getNotificationsPreferences(ADFContext.getCurrent().getSecurityContext().getUserName());
        } catch (IOException e) {
            logger.severe(e);
            throw new BadRequestException(e);
        }
        if(preferences != null){
        for(String preference:preferences){
            if(preference != null && preference.contains("userPreferences")){
              userPreferences.add(preference.substring((preference.lastIndexOf("\"")+1),preference.length()));
            }else if (preference != null && preference.contains("\"}")){
                userPreferences.add(preference.substring(0,(preference.lastIndexOf("\""))));
            }else{
                userPreferences.add(preference);
            }
        }
        }
        if(userPreferences != null){
            for(int i=0;i<7;i++){
                String index=Integer.toString(i+1);
                NotificationSetting notificationSetting = new  NotificationSetting();
                if(userPreferences.contains(index)){
                  
                    notificationSetting.setName(index);
                    notificationSetting.setValue(true);
                }else{
                  
                    notificationSetting.setName("0");
                    notificationSetting.setValue(false);
                }
                notificationSettings.add(notificationSetting);
            }
        }
        NotificationSetting[] ret=notificationSettings.toArray(new NotificationSetting[notificationSettings.size()]);
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
        
    }
    
    @POST
    @Path("/saveprefs")
    public Response saveNotificationPreferences(String userPreferences){
        StoreMDS mds = StoreMDS.getInstance();
        ArrayList<String> userPreferenceList=new ArrayList<String>();
        List<String> userPreferencesTemp = new ArrayList<String>();
        if(userPreferences != null && !userPreferences.isEmpty()){
            String[] userNotiPreferences = userPreferences.split(",");
            for(String preference:userNotiPreferences){
                if(preference != null && preference.contains("userPreferences")){
                  userPreferencesTemp.add(preference.substring((preference.lastIndexOf("\"")+1),preference.length()));
                }else if (preference != null && preference.contains("\"}")){
                    userPreferencesTemp.add(preference.substring(0,(preference.lastIndexOf("\""))));
                }else{
                    userPreferencesTemp.add(preference);
                }
            }
            for(String userNotiPrefence:userPreferencesTemp){
                if(userNotiPrefence != null && !userNotiPrefence.isEmpty() && !userNotiPrefence.equalsIgnoreCase("0")){
                    userPreferenceList.add(userNotiPrefence);
                }
                
            }
        }
        MdsStoreObject ret = null;
        try {
            ret = mds.storeInMDS(ADFContext.getCurrent().getSecurityContext().getUserName(), 0, userPreferenceList, null);
        } catch (IOException e) {
            logger.severe(e);
            throw new BadRequestException(e);
        } catch (ParserConfigurationException e) {
            logger.severe(e);
            throw new BadRequestException(e);
        } catch (SAXException e) {
            logger.severe(e);
            throw new BadRequestException(e);            
        } catch (ClassNotFoundException e) {
            logger.severe(e);
            throw new BadRequestException(e);    
        }
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
        
    }
    
    @GET
    @Path("/count")
    public Response getNotificationsCount(){
        StoreMDS mds = StoreMDS.getInstance();
        int count = -1;
        try {
            count = mds.getMessageCount(ADFContext.getCurrent().getSecurityContext().getUserName());
        } catch (IOException e) {
            logger.severe(e);
            throw new BadRequestException(e);
        }
        return Response.ok(count).type(MediaType.APPLICATION_JSON).build();
    }

    private String generatePhotoURI(String guid, String size) {
        String encodedGuid = null;
        if (guid != null)
            encodedGuid = ProfileInternalUtils.asciiToHex(guid);

        StringBuilder uriBuilder =
            new StringBuilder(64).append("/").append("webcenter").append("/").append("profilephoto").append("/").append(encodedGuid).append('/').append(size);
        String photoUID = "xxxxxxx";
        try {
            UserProfileManager profileManager =
                ProfileFactory.getProfileManager();
            WCUserProfile profile = profileManager.getProfileByGUID(guid);
            photoUID = profile.getPhotoUID();
        } catch (Exception e) {
            logger.severe(e);
        }

        uriBuilder.append('/').append(photoUID);
        uriBuilder.append("?_xResourceMethod=wsrp");
        return uriBuilder.toString();
    }
}
