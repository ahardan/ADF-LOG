package com.darden.krowd.rest.services;


import com.darden.global.enterpriseobjects.core.common.v2.IdentificationType;
import com.darden.global.enterpriseobjects.core.common.v2.IdentifierType;
import com.darden.global.enterpriseobjects.core.commonebo.v1.PersonAddressCommunicationType;
import com.darden.global.enterpriseobjects.core.commonebo.v1.PersonEmailCommunicationType;
import com.darden.global.enterpriseobjects.core.commonebo.v1.PersonPhoneCommunicationType;
import com.darden.global.enterpriseobjects.core.commonebo.v1.PersonType;
import com.darden.global.enterpriseobjects.core.ebo.worker.v1.AcknowledgeEmployeeProfileDataAreaType;
import com.darden.global.enterpriseobjects.core.ebo.worker.v1.EmployeeProfileType;
import com.darden.global.enterpriseobjects.core.ebo.worker.v1.ShowEmployeeProfileDataAreaType;
import com.darden.krowd.common.PortalConstants;
import com.darden.krowd.common.identity.LdapHelper;
import com.darden.krowd.common.model.applicationModule.common.UserProfileAM;
import com.darden.krowd.common.model.applicationModule.preferences.common.PreferencesAM;
import com.darden.krowd.model.serialize.ActivityNotification;
import com.darden.krowd.model.storeMds.MdsStoreObject;
import com.darden.krowd.model.storeMds.StoreMDS;
import com.darden.krowd.rest.config.CacheAnnotations.CacheMaxAge;
import com.darden.krowd.rest.exceptions.BadRequestException;
import com.darden.krowd.rest.support.MessagesHypermediaGenerator;
import com.darden.krowd.rest.model.Bookmark;
import com.darden.krowd.rest.model.Notification;
import com.darden.krowd.rest.model.ObjectReference;
import com.darden.krowd.rest.model.QuickLinkDTO;
import com.darden.krowd.rest.model.QuickLinkListDTO;
import com.darden.krowd.rest.search.model.PersonList;
import com.darden.krowd.rest.search.model.PersonRow;
import com.darden.krowd.services.dao.BirthAndAnniversaryDatesDAO;
import com.darden.krowd.services.dao.ESSLinksDAO;
import com.darden.krowd.services.dao.OnTheMoveDAO;
import com.darden.krowd.services.helper.ServicesHelper;

import com.sun.jersey.api.json.JSONConfiguration;
import com.sun.jersey.api.json.JSONJAXBContext;
import com.sun.jersey.api.json.JSONMarshaller;
import com.sun.jersey.api.json.JSONUnmarshaller;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.StringWriter;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.prefs.Preferences;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import oracle.adf.model.BindingContext;
import oracle.adf.model.DataControlFrame;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.share.prefs.ADFPreferencesFactory;

import oracle.jbo.Row;
import oracle.jbo.RowIterator;
import oracle.jbo.RowSet;
import oracle.jbo.domain.Number;

import oracle.security.idm.ComplexSearchFilter;
import oracle.security.idm.IMException;
import oracle.security.idm.Identity;
import oracle.security.idm.Property;
import oracle.security.idm.PropertySet;
import oracle.security.idm.RoleManager;
import oracle.security.idm.SearchResponse;
import oracle.security.idm.User;
import oracle.security.idm.UserProfile;

import oracle.webcenter.content.integration.cache.Cache;
import oracle.webcenter.content.integration.cache.CacheFactory;

import oracle.webcenter.activitystreaming.ActivityActor;
import oracle.webcenter.activitystreaming.ActivityDisplayElement;
import oracle.webcenter.activitystreaming.ActivityException;
import oracle.webcenter.activitystreaming.ActivityObject;
import oracle.webcenter.activitystreaming.ActivityStreamingService;
import oracle.webcenter.activitystreaming.ActivityStreamingServiceFactory;
import oracle.webcenter.activitystreaming.FollowManager;
import oracle.webcenter.framework.service.ServiceObjectType;
import oracle.webcenter.jaxrs.framework.param.ItemsPerPageParam;
import oracle.webcenter.jaxrs.framework.param.PaginationParams;
import oracle.webcenter.jaxrs.framework.param.StartIndexParam;
import oracle.webcenter.jaxrs.framework.service.RestService;
import com.darden.krowd.framework.PersonReference;

import javax.xml.stream.XMLInputFactory;

import oracle.webcenter.jaxrs.framework.uri.UriService;
import oracle.webcenter.peopleconnections.connections.Connection;
import oracle.webcenter.peopleconnections.connections.ConnectionsException;
import oracle.webcenter.peopleconnections.connections.ConnectionsManager;
import oracle.webcenter.peopleconnections.connections.ConnectionsServiceFactory;
import oracle.webcenter.peopleconnections.connections.Invitation;
import oracle.webcenter.peopleconnections.connections.InvitationsManager;
import oracle.webcenter.peopleconnections.profile.ProfileException;
import oracle.webcenter.peopleconnections.profile.ProfileFactory;
import oracle.webcenter.peopleconnections.profile.UserProfileManager;
import oracle.webcenter.peopleconnections.profile.WCUserProfile;
import oracle.webcenter.peopleconnections.profile.internal.model.ProfileInternalUtils;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.SerializationUtils;


@Path("/users")
@Produces("application/json")
public class PeopleResource {
    private static final String[] USER_SEARCH_BASES =
    new String[] { "OU=Field,DC=darden,DC=com",
    "OU=Field,OU=PortalDev,DC=darden,DC=com",
    "OU=Restaurants,DC=darden,DC=com",
    "OU=Restaurants,OU=PortalDev,DC=darden,DC=com",
    "OU=RSC,DC=darden,DC=com",
    "OU=RSC,OU=PortalDev,DC=darden,DC=com",
    "OU=Employees,DC=mydish,DC=darden,DC=com", 
    "OU=Employees,OU=PortalDev,DC=mydish,DC=darden,DC=com" };

    private static final String[] RESTAURANT_SEARCH_BASES =
    new String[] { "OU=RestaurantsOWA,DC=darden,DC=com",
                   "OU=RestaurantsVM,DC=darden,DC=com"};

    private static final int LDAP_COUNT_LIMIT = 20;
    private static final int LDAP_PROFILE_COUNT_LIMIT = 500;
    private static final int LDAP_PAGE_LIMIT = 1;
    public static final String DARDEN_EMPL_ID="DARDEN-EMPL-ID";
    public static final String FIRST_NAME="FIRST_NAME";
    public static final String LAST_NAME="LAST_NAME";
    public static final String PROFILE_ATTRS = "Darden-Business-Unit##Darden-Company-Number##Darden-Job-Function##Darden-Job-Sub-Function##Darden-Region##division##physicalDeliveryOfficeName##Darden-Area##Darden-Job-Code##Darden-POS-ID##Darden-Work-State##displayName";
    public static final Map<String,String> PROFILE_ATTRS_KEYS= new HashMap<String,String>();
    static {
        String[] profileAttrs = PROFILE_ATTRS.split("##");        
        for(String attr : profileAttrs){
            String value = attr.replace("-", "");
            char c[] = value.toCharArray();
            c[0] = Character.toLowerCase(c[0]);
            value = new String(c);
            PROFILE_ATTRS_KEYS.put(attr, value);
        }
    }
    
    private UserProfileManager userProfileManager;
    private ConnectionsManager connectionsManager;
    private InvitationsManager invitationsManager;
    private String currentUserGUID;
    private List<Invitation> sentInvitations;
    private List<Invitation> receivedInvitations;
    
    private List<Connection> userConnections = null;

    
    @Context private HttpServletRequest httpRequest;
    private static final ADFLogger logger = ADFLogger.createADFLogger(PeopleResource.class);
    
    private static String PAGE_DEF = "com_darden_krowd_rest_pageDefs_RestPageDef";  
    private static String DATACONTROL = "UserProfileAMDataControl";
    private static String PREF_DATACONTROL = "PreferencesAMDataControl";

    @RestService
    protected UriService uriService;
    
    private static ArrayList<String> PERSON_REF_ATTRIBUTES = new ArrayList<String>() {{
    }};  
    
    private CacheFactory cacheFactory;
   
   
    private Cache getCache(){
        Cache cache = null;
        try {
            cache = getCacheFactory().getCache("com.darden.krowd.stringsCache");
        } catch (Exception e){
            logger.severe("Coherence Cache is not acquired in PeopleResource" + e);
        }
        return cache;
    }
    
    private CacheFactory getCacheFactory(){
        if(cacheFactory==null) {
            try {
                cacheFactory = CacheFactory.getInstance("content");
            } catch (Exception e){
                logger.severe("Coherence Cache Factory is not acquired in PeopleResource" + e);
            }            
        }            
        return cacheFactory;
    }
    
    
    private UserProfileAM getUserProfileAM(){
        BindingContext bindingContext = BindingContext.getCurrent();
        UserProfileAM am =null;
        DCDataControl dc = null; 
        if(bindingContext !=null){
            String dcFrameName = bindingContext.getCurrentDataControlFrame();
            DataControlFrame dcframe = dcFrameName == null? null : bindingContext.findDataControlFrame(dcFrameName);
            dc = dcframe == null ? null : dcframe.findDataControl(DATACONTROL);        
            dc = dc == null ? bindingContext.findDataControl(DATACONTROL) : dc;
            
            if(dc == null){
               DCBindingContainer amx = bindingContext.findBindingContainer(PAGE_DEF);
                dc = amx.findDataControl(DATACONTROL); 
                am = (UserProfileAM)dc.getDataProvider();
            }else{
                am = (UserProfileAM)dc.getDataProvider();
            }
        }
        return am;
    }     
    
    private PreferencesAM getPreferencesAM(){
        BindingContext bindingContext = BindingContext.getCurrent();
        PreferencesAM am =null;
        DCDataControl dc = null; 
        if(bindingContext !=null){
            String dcFrameName = bindingContext.getCurrentDataControlFrame();
            DataControlFrame dcframe = dcFrameName == null? null : bindingContext.findDataControlFrame(dcFrameName);
            dc = dcframe == null ? null : dcframe.findDataControl(PREF_DATACONTROL);        
            dc = dc == null ? bindingContext.findDataControl(PREF_DATACONTROL) : dc;
            
            if(dc == null){
               DCBindingContainer amx = bindingContext.findBindingContainer(PAGE_DEF);
                dc = amx.findDataControl(PREF_DATACONTROL); 
                am = (PreferencesAM)dc.getDataProvider();
            }else{
                am = (PreferencesAM)dc.getDataProvider();
            }
        }
        return am;
    }
    
    private ConnectionsManager getConnectionsManager(){
        if(this.connectionsManager == null)
         this.connectionsManager = ConnectionsServiceFactory.getInstance().getConnectionsManager(); 
        
        return this.connectionsManager;
    }
    
    private InvitationsManager getInvitationsManager() {
        if(this.invitationsManager == null){
            this.invitationsManager = ConnectionsServiceFactory.getInstance().getInvitationsManager();
        }
      return this.invitationsManager;
    }   
    
    private String getCurentUserGUID(){
        if(currentUserGUID == null)
            currentUserGUID = ADFContext.getCurrent().getSecurityContext().getUserProfile().getGUID();
        return currentUserGUID;
    }
    
    
    private UserProfileManager getUserProfileManager(){
        if(this.userProfileManager == null){
            try {
                this.userProfileManager = ProfileFactory.getProfileManager();
            } catch (ProfileException e) {
            }
        }
        return this.userProfileManager;
    }
    
    private List<PersonReference> getUserConnections(String userId) throws ProfileException,
                                                                                   ConnectionsException {
        ConnectionsManager connectionsManager = ConnectionsServiceFactory.getInstance().getConnectionsManager();
        UserProfileManager profileManager = ProfileFactory.getProfileManager();
        WCUserProfile userProfile = profileManager.getProfile(userId);
        String userGuid = userProfile.getGuid();
        List<Connection> connections = connectionsManager.getConnections(userGuid);        
        List<PersonReference> connRes = new ArrayList<PersonReference>();
        
        for(Connection connection : connections){
            HashMap<String,Object> connInfo = new HashMap<String,Object>();
            connInfo.put("userId",connection.getConnecteeUserId());
            WCUserProfile connecteeProfile = connection.getConnecteeUserProfile();
            PersonReference perRef = PersonReference.GetPersonByGuid(connecteeProfile.getGuid());
            perRef = MessagesHypermediaGenerator.addLinks(uriService, perRef);
            connRes.add(perRef);            
        }
        return connRes;
    }
    
    
    
    
    
    private  Map<String,Object> toMap(Row row,boolean expandRs){
        
        if(row == null)
            return null;
        
        String[] attrs = row.getAttributeNames();
        Map map = new HashMap<String,Object>();
        Object val;
        
        for(String attributeName : attrs){
           val = row.getAttribute(attributeName);           
           if(val instanceof oracle.jbo.RowSet) {
               if(expandRs){
                   RowSet rwSet = (RowSet)val;
                   ArrayList<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
                   while(rwSet.hasNext()){
                       list.add(toMap(rwSet.next(),expandRs));
                   }
                    map.put(attributeName,list);
                    map.put("has"+attributeName,list.size()==0?false:true);
               }else{
                   map.put(attributeName,null);
               }
           }else{
               //PersonReference.GetPersonByGuid(comment.getAuthorId())
               if(PERSON_REF_ATTRIBUTES.contains(attributeName)){                
                if(val ==null){
                    map.put(attributeName, null);
                }else{

                    String usersCSV = (String)(val==null?val:val.toString());  
                    String[]users = usersCSV.split(",");
                    if(users.length==0){
                        map.put(attributeName, null);
                    }else{
                        if(users.length==1){
                            map.put(attributeName,MessagesHypermediaGenerator.addLinks(uriService, PersonReference.GetPersonByLoginId(users[0])));  
                        }else{
                            ArrayList<PersonReference> result = new ArrayList<PersonReference>();
                            for(String user : users){
                                result.add(MessagesHypermediaGenerator.addLinks(uriService, PersonReference.GetPersonByLoginId(user)));
                            }
                            map.put(attributeName, result);
                        }
                    }
                }
               }else{
                   if(val == null)
                    map.put(attributeName, null);
                   else{
                       map.put(attributeName, val.toString());
                    }
               }
           }
        }
        return map;
    }       

    public PeopleResource() {
        super();
    }
    


    private  List<Map<String,Object>> toMap(RowIterator ri,
                                                                   int maxRows,
                                                                   int startRow,
                                                                   boolean singleRow){
        Row[] rows;
        if (singleRow) { // indicates a single row representation
            rows = new Row[] { ri.getCurrentRow() };
        } else {
            ri.reset();
            ri.setRangeSize(maxRows);
            ri.setRangeStart(startRow);
            rows = ri.getAllRowsInRange();
        }
        List<Map<String,Object>> result = new ArrayList<Map<String,Object>>();
        for (Row row : rows) {
            result.add(toMap(row,false));
        }
        return result;
    }
    
    private User getUserByEmplId(String emplId) throws Exception {
        if(emplId != null && StringUtils.isNotBlank(emplId)){
            HashMap<String,String> params = new HashMap<String,String>();
            params.put("Darden-Empl-ID",emplId);
            List<Identity> list = LdapHelper.getInstance().getIdentitiesWithAttributes(params, ComplexSearchFilter.TYPE_OR); 
            if(list != null && list.size() >0){
                User user = (User)list.get(0);
                return user;
            }else{
                return null;
            }         
        }else{
            return null;
        }
        
    }
    
    @GET
    @Path("/connections")
    @Produces("application/json")
    public Response getConnections(){ 
        try {
            String userId = ADFContext.getCurrent().getSecurityContext().getUserName();
            if(StringUtils.isBlank(userId))
                throw new BadRequestException("User ID cannot be blank"); 
            List<PersonReference>  connRes = getUserConnections(userId);
            return Response.status(200).entity(connRes).build();
        } catch (Exception e) {
            logger.severe(e);
            throw new BadRequestException(e);    
        }            
    } 
    
    private List<PersonReference> toPersonReferences(List<String> userNames){
        List<PersonReference> personList = new ArrayList<PersonReference>();
        if(userNames != null){
            PersonReference perRef =null;
            for(String userName:userNames){
                try{
                    perRef = PersonReference.GetPersonByLoginId(userName);
                    if(perRef !=null){
                        perRef = MessagesHypermediaGenerator.addLinks(uriService, perRef);
                        personList.add(perRef);                        
                    }
                }catch(Exception e){
                    logger.severe(e);
                }
            }
        }
        return personList;
    }

    private List<PersonReference> identitiesToPersonReferences(List<Identity> identities){
        List<PersonReference> personList = new ArrayList<PersonReference>();
        if(identities != null){
            PersonReference perRef;
            for(Identity identity:identities){
                try {
                    String guid = identity.getGUID();
                    perRef = PersonReference.GetPersonByGuid(guid);
                    perRef = MessagesHypermediaGenerator.addLinks(uriService, perRef);
                    personList.add(perRef);
                } catch (IMException e) {
                    logger.severe(e);
                }
            }
        }
        return personList;
    }
    
    private List<PersonReference> filterPersonReferences(List<PersonReference> persons, String searchStr){
        if(searchStr ==null || StringUtils.isBlank(searchStr) || persons==null || persons.size()==0)
            return persons;
        else{
            String[] parts = searchStr.split("\\s+");
            Pattern pattern=null;
            if(parts.length==0)
                return persons;
            if(parts.length==1){
                pattern = Pattern.compile(".*"+parts[0]+".*", Pattern.CASE_INSENSITIVE);
            }
            if(parts.length>1){
                pattern = Pattern.compile(parts[0]+".*"+parts[1]+".*", Pattern.CASE_INSENSITIVE);
            }
            Matcher matcher;
            List<PersonReference> result = new ArrayList<PersonReference>();
            for(PersonReference perRef : persons){
                if(perRef !=null){
                    matcher = pattern.matcher(perRef.getDisplayName());
                    if(matcher.matches())
                        result.add(perRef);                    
                }
            }
            return result;
        }
    }
    
    
    
    private ArrayList<String> getRoles(User user) throws Exception {
        RoleManager roleManager = LdapHelper.getInstance().getIdentityStore().getRoleManager();
        SearchResponse searchResponse = roleManager.getGrantedRoles(user.getPrincipal(), false);
        ArrayList<String> rolesList = new ArrayList<String>();
        while(searchResponse.hasNext()){
            Identity identity = searchResponse.next();
            String roleName = identity.getName();
            rolesList.add(roleName);          
        }
        return rolesList;
    }
    
    public String getGroup(User user) throws Exception {
        List<String> userRoles = getRoles(user);
        return getGroup(user, userRoles);
    }    

        public String getGroup(User user, List<String> userRoles) throws Exception {
                
                if (userRoles.contains("Portal - RSC Emp")){
                    String businessUnit = (String)user.getUserProfile().getPropertyVal("Darden-Business-Unit");
                    if (businessUnit.compareTo("YHUSA") == 0)
                        return "RSCY";
                    else
                        return "RSC";
                }
                else if (userRoles.contains("Portal - RSC Emp � Canada")){
                    return "CRSC";
                }
                else{
                    UserProfile userProfile = user.getUserProfile();
                    String businessUnit = (String)userProfile.getPropertyVal("Darden-Business-Unit");
                    String area = (String)userProfile.getPropertyVal("Darden-Area");
                    String region = (String)userProfile.getPropertyVal("Darden-Region");
                    String office = (String)userProfile.getPropertyVal("physicalDeliveryOfficeName");
                    String managerLevel = (String)userProfile.getPropertyVal("Darden-Manager-Level");
                    
                    return businessUnit + "|" + area + "|" + region + "|" + office + "|" + managerLevel;
                }
        }    
    
    @GET
    @CacheMaxAge(time = 360, unit = TimeUnit.MINUTES)
    @Path("/roles")
    public ArrayList<String> getBirthdays(@QueryParam("userId") String userId){
        boolean self=false;
        if (userId == null || StringUtils.isBlank(userId)) {
            userId = ADFContext.getCurrent().getSecurityContext().getUserName();
            self=true;
        }        
        
        try {            
            if(self){
                String[] userRoles = ADFContext.getCurrent().getSecurityContext().getUserRoles();
                ArrayList<String> items = new ArrayList<String>();
                for (String role: userRoles) {
                    items.add(role);
                }                
                return items;
            }else{
                User user;
                user = LdapHelper.getInstance().getUser(userId);            
                return this.getRoles(user);
            }
        } catch (Exception e) {
            return null;
        }
    }
    
    
    @GET
    @CacheMaxAge(time = 360, unit = TimeUnit.MINUTES)
    @Path("/bdaysannvs")
    public BirthAndAnniversaryDatesDAO getBirthdays(@QueryParam("userId")
        String userId, @QueryParam("fromDate")
        String fromDate, @QueryParam("toDate")
        String toDate) {        
        
        if (userId == null || StringUtils.isBlank(userId)) {
            userId = ADFContext.getCurrent().getSecurityContext().getUserName();
        }
        
        ServicesHelper sevHelper = new ServicesHelper();
        User user;
        try {
            user = LdapHelper.getInstance().getUser(userId);
            String emplId = (String)user.getUserProfile().getPropertyVal("Darden-Empl-ID");
            String group = getGroup(user);
            BirthAndAnniversaryDatesDAO result = sevHelper.getBirthdaysAndAnniversaries(emplId, fromDate,toDate,group);
            return result;                
        } catch (Exception e) {
            throw new BadRequestException(e);
        }
        
    }
    
    @GET
    @CacheMaxAge(time = 360, unit = TimeUnit.MINUTES)
    @Path("/onthemove")
    public OnTheMoveDAO getOnTheMoves(@QueryParam("userId")
        String userId, @QueryParam("fromDate")
        String fromDate, @QueryParam("toDate")
        String toDate) {
        if (userId == null || StringUtils.isBlank(userId)) {
            userId = ADFContext.getCurrent().getSecurityContext().getUserName();
        }
        
        ServicesHelper sevHelper = new ServicesHelper();
        User user;
        try {
            user = LdapHelper.getInstance().getUser(userId);
            String emplId = (String)user.getUserProfile().getPropertyVal("Darden-Empl-ID");
            UserProfile userProfile = user.getUserProfile();
            String concept = (String)userProfile.getPropertyVal("Darden-Business-Unit");
            List<String> userRoles = getRoles(user);
            String managerLevel = (String)userProfile.getPropertyVal("Darden-Manager-Level");            
            boolean isRsc = isRsc(userRoles,managerLevel);
            boolean isOps = isOps(userRoles);
            OnTheMoveDAO result = sevHelper.getOnTheMoves(emplId, fromDate,toDate,concept,isRsc,isOps);
            return result;
        } catch (Exception e) {
            throw new BadRequestException(e);
        }        
    }    
    
    private boolean isRsc(User user) throws Exception {
        String managerLevel = (String)user.getUserProfile().getPropertyVal("Darden-Manager-Level");
        List<String> userRoles = getRoles(user);
        return isRsc(userRoles, managerLevel);
    }
    
    private boolean isRsc(List<String> roles,String managerLevel){        
        if(managerLevel != null &&  (managerLevel.compareTo("G")==0 || managerLevel.compareTo("H")==0))
            return true;
        else{
            if (roles.contains(PortalConstants.Portal_RSC_Emp) || roles.contains(PortalConstants.Portal_RSC_Emp_Canada))
                return true;
            else
                return false;
        }        
    }
    
    private boolean isOps(User user) throws Exception {
        List<String> userRoles = getRoles(user);
        return isOps(userRoles);
    }    
    
    private boolean isOps(List<String> roles){
        if (!roles.contains(PortalConstants.Portal_Hourly) && !roles.contains(PortalConstants.Portal_RSC_Emp))
            return true; 
        else
            return false;        
    }

    
    @GET
    @CacheMaxAge(time = 360, unit = TimeUnit.MINUTES)
    @Path("/preferences/{context}")
    public Response getPreferences(@PathParam("context")String context) {
        if (context == null || StringUtils.isBlank(context)) {
            throw new BadRequestException("Context values : {user,useroversystem,shareduser,sharedsystem,system} is mandatory");
        }
        else{
            try {
                ADFPreferencesFactory prefsFactory = new ADFPreferencesFactory();
                Preferences prefs = null;
                if(context.equalsIgnoreCase("USER")){
                    prefs = prefsFactory.userRoot();
                    return Response.status(Response.Status.OK).entity(prefs).type("application/json").build();
                }else if(context.equalsIgnoreCase("SHAREDUSER")){
                    prefs = prefsFactory.sharedUserRoot();
                    return Response.status(Response.Status.OK).entity(prefs).type("application/json").build();                    
                }else if(context.equalsIgnoreCase("SHAREDSYSTEM")){
                    prefs = prefsFactory.sharedSystemRoot();
                    return Response.status(Response.Status.OK).entity(prefs).type("application/json").build();                                        
                }else if(context.equalsIgnoreCase("SYSTEM")){
                    prefs = prefsFactory.systemRoot();
                    return Response.status(Response.Status.OK).entity(prefs).type("application/json").build();                                        
                }else if(context.equalsIgnoreCase("USEROVERSYSTEM")){
                    prefs = prefsFactory.userOverSystemRoot();
                    return Response.status(Response.Status.OK).entity(prefs).type("application/json").build();                                        
                }else{
                    throw new BadRequestException("Valid Context values : {user,useroversystem,shareduser,sharedsystem,system} is mandatory");
                }                
            } catch (Exception e) {
                throw new BadRequestException(e);
            }
        }
    }  
    
    private void setPreferencesFromMap(Preferences preferences,HashMap<String,String> map){
        if(map != null && preferences != null){
            for(Map.Entry entry : map.entrySet()){
                preferences.put((String)entry.getKey(), (String)entry.getValue());
            }
        }
    }

    @POST
    @Path("/preferences/{context}")
    public Response setPreferences(@PathParam("context")String context,HashMap<String,String> params) {
        if (context == null || StringUtils.isBlank(context)) {
            
            throw new BadRequestException("Context values : {user,useroversystem,shareduser,sharedsystem,system} is mandatory");
        }
        else{
            try {
                ADFPreferencesFactory prefsFactory = new ADFPreferencesFactory();
                Preferences prefs = null;
                if(context.equalsIgnoreCase("USER")){
                    prefs = prefsFactory.userRoot();
                    setPreferencesFromMap(prefs,params);                        
                    return Response.status(Response.Status.OK).entity("Done").type("application/json").build();
                }else if(context.equalsIgnoreCase("SHAREDUSER")){
                    prefs = prefsFactory.sharedUserRoot();
                    setPreferencesFromMap(prefs,params);                    
                    return Response.status(Response.Status.OK).entity("Done").type("application/json").build();
                }else if(context.equalsIgnoreCase("SHAREDSYSTEM")){
                    prefs = prefsFactory.sharedSystemRoot();
                    setPreferencesFromMap(prefs,params);                    
                    return Response.status(Response.Status.OK).entity("Done").type("application/json").build();
                }else if(context.equalsIgnoreCase("SYSTEM")){
                    prefs = prefsFactory.systemRoot();
                    setPreferencesFromMap(prefs,params);                    
                    return Response.status(Response.Status.OK).entity("Done").type("application/json").build();
                }else if(context.equalsIgnoreCase("USEROVERSYSTEM")){
                    prefs = prefsFactory.userOverSystemRoot();
                    setPreferencesFromMap(prefs,params);                    
                    return Response.status(Response.Status.OK).entity("Done").type("application/json").build();
                }else{
                    throw new BadRequestException("Context values : {user,useroversystem,shareduser,sharedsystem,system} is mandatory");
                }                
            } catch (Exception e) {
                throw new BadRequestException(e);
            }
        }
    }    
    
    @POST
    @CacheMaxAge(time = 360, unit = TimeUnit.MINUTES)
    @Path("/profile") 
    public Response updateUserProfile(@DefaultValue("anonymous") @QueryParam("userId")  String userId,@DefaultValue("PST") @QueryParam("source") String source,@QueryParam("processCode") String code,String employeeProfile){
        
        if(userId.compareToIgnoreCase("anonymous")==0)
            userId = ADFContext.getCurrent().getSecurityContext().getUserName();

        
        try{
            ServicesHelper sevHelper = new ServicesHelper();
            User user = LdapHelper.getInstance().getUser(userId);
            String emplId = (String)user.getUserProfile().getPropertyVal("Darden-Empl-ID");            
            
            String UPDATEEMERGENCYCONTACTINFO = "UpdateECChange";
            String UPDATEHOMEMAILINGINFO = "UpdateAddress,UpdatePhone,UpdateEmail";
            String UPDATEPROFILEHEADER = "UpdatePhone,UpdateEmail";
            String UPDATEBIRTHANDANNIVERSARYPREFERENCE = "UpdateSSOptions";
            
            Map<String,String> ns2json = new HashMap<String, String>();            
            ns2json.put("http://www.darden.com/Global/EnterpriseObjects/Core/Custom/EBO/Worker/V1", "ns1");   
            ns2json.put("http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd","ns10");
            ns2json.put("http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2","ns2");
            ns2json.put("http://www.darden.com/Global/EnterpriseObjects/Core/CommonEBO/V1","ns3");
            ns2json.put("http://www.darden.com/Global/EnterpriseObjects/Core/EBO/Worker/V1","ns4");
            ns2json.put("http://schemas.xmlsoap.org/ws/2003/03/addressing","ns5");
            ns2json.put("http://www.w3.org/2000/09/xmldsig#","ns6");
            ns2json.put("http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd","ns7");
            ns2json.put("urn:oasis:names:tc:xacml:2.0:context:schema:cd:04","ns8");
            ns2json.put("urn:oasis:names:tc:xacml:2.0:policy:schema:cd:04","ns9");                        
            
            
            JSONJAXBContext marshallingContext=new JSONJAXBContext(JSONConfiguration.mapped().xml2JsonNs(ns2json).build(),ShowEmployeeProfileDataAreaType.class);                    
            JSONUnmarshaller um = marshallingContext.createJSONUnmarshaller(); 
            InputStream stream = new ByteArrayInputStream(employeeProfile.getBytes());
            ShowEmployeeProfileDataAreaType newProfileInfo = um.unmarshalFromJSON(stream, ShowEmployeeProfileDataAreaType.class);            
            EmployeeProfileType empProfType = newProfileInfo.getShowEmployeeProfileResponse().getEmployeeProfileDetails();            
            AcknowledgeEmployeeProfileDataAreaType ack =null;            
            
            
            IdentificationType identificationType = new IdentificationType();
            IdentifierType identifierType = new IdentifierType();
            identifierType.setValue(emplId);
            identificationType.setID(identifierType);
                        
            EmployeeProfileType upProf = new EmployeeProfileType();
            upProf.setIdentification(identificationType);            
            PersonType per = new PersonType();            
            upProf.setPerson(per);                
            
            if(code.compareToIgnoreCase("ss")==0){
                per.setHideAnniversaryDate(empProfType.getPerson().isHideAnniversaryDate());
                per.setHideBirthDate(empProfType.getPerson().isHideBirthDate());                 
                ack= sevHelper.processUserProfile(emplId,"UpdateSSOptions",upProf);
            }
            
            if(code.compareToIgnoreCase("ec")==0){
                List<PersonType.PersonEmergencyContactInformation> ecInfoList =  empProfType.getPerson().getPersonEmergencyContactInformation();
                for(PersonType.PersonEmergencyContactInformation ecInfo : ecInfoList){
                    per.getPersonEmergencyContactInformation().add(ecInfo);
                }
                ack= sevHelper.processUserProfile(emplId,"UpdateECChange",upProf);
            }
            
            if(code.compareToIgnoreCase("phone")==0){
                List<PersonPhoneCommunicationType> cInfoList =  empProfType.getPerson().getPersonPhoneCommunication();
                for(PersonPhoneCommunicationType cInfo : cInfoList){
                    per.getPersonPhoneCommunication().add(cInfo);
                }
                ack= sevHelper.processUserProfile(emplId,"UpdatePhone",upProf);                
            }

            if(code.compareToIgnoreCase("email")==0){
                List<PersonEmailCommunicationType> emailList =  empProfType.getPerson().getPersonEmailCommunication();
                for(PersonEmailCommunicationType emailInfo : emailList){
                    per.getPersonEmailCommunication().add(emailInfo);
                }
                ack= sevHelper.processUserProfile(emplId,"UpdateEmail",upProf);                
            }
            
            if(code.compareToIgnoreCase("address")==0){
                List<PersonAddressCommunicationType> addressList =  empProfType.getPerson().getPersonAddressCommunication();
                for(PersonAddressCommunicationType addressInfo : addressList){
                    per.getPersonAddressCommunication().add(addressInfo);
                }
                ack= sevHelper.processUserProfile(emplId,"UpdateAddress",upProf);                
            }            
            
            if(ack !=null){
                return Response.status(Response.Status.OK).entity(ack.getEmployeeEditProfileResponse().get(0)).type("application/json").build();
            }else{
                throw new BadRequestException("Failed to update Peoplesoft Profile Information.");
            }            
            /*JSONJAXBContext ackMarshallingContext=new JSONJAXBContext(JSONConfiguration.mapped().xml2JsonNs(ns2json).build(),AcknowledgeEmployeeProfileDataAreaType.class);                    
            JSONMarshaller m = ackMarshallingContext.createJSONMarshaller();
            StringWriter jsonWriter = new StringWriter();
            m.marshallToJSON(ack,jsonWriter);
            String json = jsonWriter.toString();
            return Response.status(Response.Status.OK).entity(json).type("application/json").build();   
            */
        }catch(Exception e){
            logger.severe(e);
            throw new BadRequestException(e);
        }
    }    
    
    public static String toCamelCase(String s){
       String[] parts = s.split("(_|-)");
       String camelCaseString = parts[0].toLowerCase();
       String part;
       for (int i=1;i<parts.length;i++){
          part = parts[i];
          camelCaseString = camelCaseString + toProperCase(part);     
       }
       return camelCaseString;
    }    

    private static String toProperCase(String s) {
        return s.substring(0, 1).toUpperCase() +
                   s.substring(1).toLowerCase();
    }   
        
    
    @GET
    @CacheMaxAge(time = 360, unit = TimeUnit.MINUTES)
    @Path("/profile") 
    public Response getUserProfile(@DefaultValue("anonymous") @QueryParam("userId")  String userId,@DefaultValue("PST") @QueryParam("source") String source){
        
        if(userId.compareToIgnoreCase("anonymous")==0)
            userId = ADFContext.getCurrent().getSecurityContext().getUserName();
        
        if(source.compareToIgnoreCase("PST")==0){
            ServicesHelper sevHelper = new ServicesHelper();
            try {
                User user = LdapHelper.getInstance().getUser(userId);
                String emplId = (String)user.getUserProfile().getPropertyVal("Darden-Empl-ID");
                ShowEmployeeProfileDataAreaType empInfo = null;  
                empInfo = sevHelper.getUserProfile(emplId); 
                
                Map<String,String> ns2json = new HashMap<String, String>();            
                ns2json.put("http://www.darden.com/Global/EnterpriseObjects/Core/Custom/EBO/Worker/V1", "ns1");   
                ns2json.put("http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd","ns10");
                ns2json.put("http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2","ns2");
                ns2json.put("http://www.darden.com/Global/EnterpriseObjects/Core/CommonEBO/V1","ns3");
                ns2json.put("http://www.darden.com/Global/EnterpriseObjects/Core/EBO/Worker/V1","ns4");
                ns2json.put("http://schemas.xmlsoap.org/ws/2003/03/addressing","ns5");
                ns2json.put("http://www.w3.org/2000/09/xmldsig#","ns6");
                ns2json.put("http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd","ns7");
                ns2json.put("urn:oasis:names:tc:xacml:2.0:context:schema:cd:04","ns8");
                ns2json.put("urn:oasis:names:tc:xacml:2.0:policy:schema:cd:04","ns9");                                
                
                //JSONJAXBContext marshallingContext=new JSONJAXBContext(JSONConfiguration.natural().build(),ShowEmployeeProfileDataAreaType.class);
                //JSONJAXBContext marshallingContext=new JSONJAXBContext(JSONConfiguration.natural().rootUnwrapping(false).humanReadableFormatting(true).build(),ShowEmployeeProfileDataAreaType.class);        
                JSONJAXBContext marshallingContext=new JSONJAXBContext(JSONConfiguration.mapped().xml2JsonNs(ns2json).build(),ShowEmployeeProfileDataAreaType.class);        
                JSONMarshaller m = marshallingContext.createJSONMarshaller();
                StringWriter jsonWriter = new StringWriter();
                m.marshallToJSON(empInfo,jsonWriter);
                String json = jsonWriter.toString();
                return Response.status(Response.Status.OK).entity(json).type("application/json").build();                                                
            } catch (Exception e) {
                logger.severe(e);
                throw new BadRequestException(e);
            }            
        }else{            
            if(source.compareToIgnoreCase("AD")==0){                
                try {
                    User user = LdapHelper.getInstance().getUser(userId);
                    UserProfile profile = user.getUserProfile();
                    PropertySet props = profile.getAllUserProperties();
                    Iterator itr = props.getAll();
                    Property prop;                    
                    Map<String,Object> vals = new HashMap<String,Object>();
                    List<Object> values;
                    Object val;
                    while(itr.hasNext()){
                        prop = (Property)itr.next();
                        values = prop.getValues();
                        if(values !=null && values.size()>0){
                            val = values.get(0);
                            vals.put(toCamelCase(prop.getName()),val==null?null:val.toString());
                        }
                    }
                    
                    String dn = profile.getUniqueName();
                    
                    vals.put("dn",dn);
                    vals.put("guid",profile.getGUID());
                    
                    ArrayList<String> roles = this.getRoles(user);
                    if(roles != null){
                        vals.put("userRoles", roles.toArray(new String[0]));
                    }
                    
                    String managerLevel = (String)profile.getPropertyVal("Darden-Manager-Level");
                    String jobFunction = (String)profile.getPropertyVal("Darden-Job-Function");
                    String jobSubFunction = (String)profile.getPropertyVal("Darden-Job-Sub-Function");
                    
                                        
                    Map<String,Object> derived = new HashMap<String,Object>();
                    derived.put("roleGroup",this.getGroup(user,roles));
                    derived.put("isRscRole",this.isRsc(roles,managerLevel));
                    derived.put("isOpsRole",this.isOps(roles));
                    
                    boolean isRsc = false;
                    boolean isHourly = false;
                    boolean isRestManager = false;
                    
                    if(dn.toUpperCase().contains("OU=USERS,OU=RSC,DC=DARDEN,DC=COM")){
                        isRsc=true;
                    }else{
                        jobFunction = jobFunction.trim();
                        if(jobFunction.compareToIgnoreCase("HOURLY EMPLOYEE")==0){
                            isHourly=true;
                        }else{
                            if(jobFunction.compareToIgnoreCase("MANAGER")==0 || 
                               jobFunction.compareToIgnoreCase("MANAGER IN TRAINING")==0 ||
                               jobFunction.compareToIgnoreCase("GENERAL MANAGER")==0
                            ){
                                isRestManager = true;
                            }else{
                                isRsc=true;
                            }
                        }
                    }
                    
                    derived.put("isRsc",isRsc);
                    derived.put("isHourly",isHourly);
                    derived.put("isRestManager",isRestManager);
                    
                    vals.put("derived",derived);

                    
                    return Response.status(Response.Status.OK).entity(vals).build(); 
                } catch (Exception e) {
                    logger.severe(e);
                    throw new BadRequestException(e);
                }                
            }else{
                if(source.compareTo("WC")==0){                    
                    try {
                        UserProfileManager profileManager = ProfileFactory.getProfileManager();
                        WCUserProfile userProfile = profileManager.getProfile(userId);
                        //oracle.webcenter.peopleconnections.profile.internal.model.PrivacyCheckingProfileWrapper l;
                        return Response.status(Response.Status.OK).entity(userProfile).build(); 
                    } catch (ProfileException e) {
                        logger.severe(e);
                        throw new BadRequestException(e);
                    }                    
                }else{
                    UserProfileAM am = getUserProfileAM();
                    Row row = am.getProfileByUserName(userId);
                    return Response.ok(toMap(row,false)).build();                                    
                }
            }            
        }
    }
    
    private ActivityObject createActivityObject(String serviceId, String objectType, String objectId)
    {
      ActivityObject obj = null;
      try {
        ActivityStreamingService as = ActivityStreamingServiceFactory.getInstance().getActivityStreamingService();
        ServiceObjectType serviceObjType = as.findObjectType(serviceId, objectType);
        obj = as.createObject(objectId, serviceObjType, objectId);
        obj.setServiceID(serviceId);
      } catch (ActivityException e) {
          logger.severe(e);
      }
      return obj;
    }   
        
    
    @POST
    @Path("/services/{serviceId}/objectTypes/{objectType}/objects/({objectId})/follow")
    public ObjectReference followObject(@PathParam("serviceId") String serviceId, @PathParam("objectType") String objectType, @PathParam("objectId") String objectId){        
        try {
            ActivityStreamingServiceFactory activityStreamingFactory = ActivityStreamingServiceFactory.getInstance();
            ActivityStreamingService activityStreamingService =  activityStreamingFactory.getActivityStreamingService();        
            FollowManager followManager =  activityStreamingService.getFollowManager();            
            String userId = ADFContext.getCurrent().getSecurityContext().getUserName();
            PersonReference personReference = PersonReference.GetPersonByLoginId(userId);            
            ActivityObject activityObject = createActivityObject(serviceId, objectType, objectId);
            ActivityActor activityActor = activityStreamingService.createActor(personReference.getGuid());
            followManager.followObject(activityActor,activityObject);            
            return new ObjectReference(activityObject);
        } catch (ActivityException e) {
            logger.severe(e);
            throw new BadRequestException(e);
        }
    }
    
    @DELETE
    @Path("/services/{serviceId}/objectTypes/{objectType}/objects/({objectId})/follow")
    public ObjectReference unFollowObject(@PathParam("serviceId") String serviceId, @PathParam("objectType") String objectType, @PathParam("objectId") String objectId,@QueryParam("userId") String userId){        
        try {
            ActivityStreamingServiceFactory activityStreamingFactory = ActivityStreamingServiceFactory.getInstance();
            ActivityStreamingService activityStreamingService =  activityStreamingFactory.getActivityStreamingService();        
            FollowManager followManager =  activityStreamingService.getFollowManager();            
            ActivityObject activityObject = createActivityObject(serviceId, objectType, objectId);
            
            if(userId == null){
                followManager.unfollowObject(activityObject);
            }else{
                if(userId.compareToIgnoreCase("self")==0){
                    userId = ADFContext.getCurrent().getSecurityContext().getUserName();
                }
                PersonReference personReference = PersonReference.GetPersonByLoginId(userId);                    
                followManager.unfollowObject(activityStreamingService.createActor(personReference.getGuid()),activityObject);            
            }
            
            return new ObjectReference(activityObject);
        } catch (ActivityException e) {
            logger.severe(e);
            throw new BadRequestException(e);
        }
    }    
    
    @GET
    @Path("/following")
    public List<ObjectReference> getFollowedObjects(@QueryParam("userId") String userId,@QueryParam("objectsecured") boolean objectsecured) {          
        List<ObjectReference> objects = new ArrayList<ObjectReference>();
        
        if(userId ==null)
            userId = ADFContext.getCurrent().getSecurityContext().getUserName();
        
        try{
            PersonReference personReference = PersonReference.GetPersonByLoginId(userId);            
            ActivityStreamingServiceFactory activityStreamingFactory = ActivityStreamingServiceFactory.getInstance();
            ActivityStreamingService activityStreamingService =  activityStreamingFactory.getActivityStreamingService();
            FollowManager followManager =  activityStreamingService.getFollowManager();
            List<ActivityObject> followedObjects = followManager.getFollowedObjects(activityStreamingService.createActor(personReference.getGuid()),objectsecured);
            
            if(followedObjects !=null){
                for(ActivityObject activityObject : followedObjects){
                    objects.add(new ObjectReference(activityObject));
                }
            }
        }catch(Exception e){
            logger.severe(e);
            throw new BadRequestException(e);
        }
        return objects;
    }    
    
    @GET
    @Path("/services/{serviceId}/objectTypes/{objectType}/objects/({objectId})/doesfollow")
    public boolean doesFollow(@PathParam("serviceId") String serviceId, @PathParam("objectType") String objectType, @PathParam("objectId") String objectId,@QueryParam("userId") String userId) {          
        if(userId ==null || userId.compareToIgnoreCase("self")==0)
            userId = ADFContext.getCurrent().getSecurityContext().getUserName();
        
        try{
            PersonReference personReference = PersonReference.GetPersonByLoginId(userId);            
            ActivityStreamingServiceFactory activityStreamingFactory = ActivityStreamingServiceFactory.getInstance();
            ActivityStreamingService activityStreamingService =  activityStreamingFactory.getActivityStreamingService();
            FollowManager followManager =  activityStreamingService.getFollowManager();
            ActivityObject activityObject = createActivityObject(serviceId, objectType, objectId);            
            return followManager.doesFollowObject(activityStreamingService.createActor(personReference.getGuid()),activityObject);
        }catch(Exception e){
            logger.severe(e);
            throw new BadRequestException(e);
        }
    }     
    
    @GET
    @CacheMaxAge(time = 360, unit = TimeUnit.MINUTES)
    @Path("/esslinks")
    public ESSLinksDAO getEssLinks(@QueryParam("userId") String userId) {  
        
        if (userId == null || StringUtils.isBlank(userId)) {
            userId = ADFContext.getCurrent().getSecurityContext().getUserName();
        }
                
        ServicesHelper sevHelper = new ServicesHelper();
        User user;
        try {
            user = LdapHelper.getInstance().getUser(userId);                
            String emplId = (String)user.getUserProfile().getPropertyVal("Darden-Empl-ID");
            //String emplId = (String)ADFContext.getCurrent().getSecurityContext().getUserProfile().getProperty("Darden-Empl-ID");
            //String emplId = "101512788";
            ESSLinksDAO result = sevHelper.getEmployeeSelfServiceLinks(emplId);
            return result;                
        } catch (Exception e) {
            throw new BadRequestException(e);
        }
    }
     
    @GET
    @CacheMaxAge(time = 360, unit = TimeUnit.MINUTES)
    @Path("/managerlinks")
    public ESSLinksDAO getManagerLinks(@QueryParam("userId") String userId) {          
        if (userId == null || StringUtils.isBlank(userId)) {
            userId = ADFContext.getCurrent().getSecurityContext().getUserName();
        }
                
        ServicesHelper sevHelper = new ServicesHelper();
        User user;
        try {
            user = LdapHelper.getInstance().getUser(userId);                
            String emplId = (String)user.getUserProfile().getPropertyVal("Darden-Empl-ID");
            //String emplId = (String)ADFContext.getCurrent().getSecurityContext().getUserProfile().getProperty("Darden-Empl-ID");
            //String emplId = "101512788";
            ESSLinksDAO result = sevHelper.getManagerLinks(emplId);
            return result;                
        } catch (Exception e) {
            throw new BadRequestException(e);
        }
    }     
    
    @PUT
    @Path("/notification")
    public Response updateNotification(Notification notification){
        try{
            logger.info("---Updating read status for Notification ----"+notification);
            String userName = ADFContext.getCurrent().getSecurityContext().getUserName();
            List<ActivityNotification> userNoti = StoreMDS.getNotifications(userName);
            ActivityNotification userNot=null;
            int foundAtIdx=-1;
            if(userNoti !=null){
                for(int i=0;i<userNoti.size();i++){
                    userNot = userNoti.get(i);
                    if(notification.compare(userNot)){
                        foundAtIdx=i;
                        break;  
                    }
                }
            }
            if(userNot !=null){
                MdsStoreObject mds = StoreMDS.updateNotification(foundAtIdx,userName);
                List<ActivityNotification> activityNotifications = mds.getActivityNotification();
                List<Notification> notifications = processActivityNotifications(activityNotifications);
                return Response.ok(notifications).build();                
            }else{
                return Response.status(Response.Status.BAD_REQUEST).build();
            }
        }catch(Exception e){
            throw new BadRequestException(e);
        }
    }

    @POST
    @Path("/delete-notification")
    public Response deleteNotification(Notification notification){
        try{
            logger.info("---Deleting read status for Notification ----"+notification);
            String userName = ADFContext.getCurrent().getSecurityContext().getUserName();
            List<ActivityNotification> userNoti = StoreMDS.getNotifications(userName);
            ActivityNotification userNot=null;
            int foundAtIdx=-1;
            if(userNoti !=null){
                for(int i=0;i<userNoti.size();i++){
                    userNot = userNoti.get(i);
                    if(notification.compare(userNot)){
                        foundAtIdx=i;
                        break;  
                    }
                }
            }

            if(userNot !=null){
                MdsStoreObject mds = StoreMDS.removeNotification(foundAtIdx,userName);
                List<ActivityNotification> activityNotifications = mds.getActivityNotification();
                List<Notification> notifications = processActivityNotifications(activityNotifications);
                return Response.ok(notifications).build();                
            }else{
                return Response.status(Response.Status.BAD_REQUEST).build();
            }
        }catch(Exception e){
            throw new BadRequestException(e);
        }
    }
    
    private Notification processPersonReferences(Notification notification){
        if(notification.isAsObject()){
            List<PersonReference> personRefs = notification.getActivity().getActors();
            for(PersonReference personRef : personRefs){
                personRef = MessagesHypermediaGenerator.addLinks(uriService, personRef);
            }            
        }
        PersonReference creator = notification.getCreator();
        PersonReference actor = notification.getActor();
        
        if(creator !=null){
            creator = MessagesHypermediaGenerator.addLinks(uriService,creator);
        }
        if(actor !=null){
            actor = MessagesHypermediaGenerator.addLinks(uriService,actor);
        }
        
        return notification;
    }
    
    private List<Notification> processActivityNotifications(List<ActivityNotification> userNoti){
        List<Notification> notifications = null;
        if (userNoti != null){
             //Collections.reverse(userNoti);                     
             notifications=new ArrayList<Notification>();
             
             ActivityStreamingServiceFactory factory = ActivityStreamingServiceFactory.getInstance();
             ActivityStreamingService activityService = factory.getActivityStreamingService();
             ActivityDisplayElement actDisEl;
             Notification notification;
             ActivityNotification userNot;
             for(int i=0;i<userNoti.size();i++){
                 userNot = userNoti.get(i);
                 if(userNot.getActivityId()!=null){
                     try{
                         actDisEl = activityService.findActivity(null,userNot.getActivityId());
                         notification = new Notification(actDisEl,userNot);
                         notification=processPersonReferences(notification);
                         notifications.add(notification);
                     }catch(Exception e){
                         logger.severe(e);
                         notification = new Notification(null,userNot);
                         notification=processPersonReferences(notification);
                         notifications.add(notification);                         
                     }
                 }else{
                     notification = new Notification(null,userNot);
                     notification=processPersonReferences(notification);
                     notifications.add(notification);
                 }                         
             }
         }
         return notifications;
    }
    
    @GET
    @CacheMaxAge(time = 360, unit = TimeUnit.MINUTES)
    @Path("/notifications")
    public Response getNotifications(@QueryParam("userId") String userId) {          
        if (userId == null || StringUtils.isBlank(userId)) {
            userId = ADFContext.getCurrent().getSecurityContext().getUserName();
        }
        
        List<Notification> notifications = null;
          
        try{
            List<ActivityNotification> userNoti = StoreMDS.getNotifications(userId);
            notifications = processActivityNotifications(userNoti);
            return Response.ok(notifications).build();
        }catch(Exception e){
            throw new BadRequestException(e);
        }

    }    
    
    @GET
    @CacheMaxAge(time = 360, unit = TimeUnit.MINUTES)
    @Path("/notifications/prefs")
    public Response getNotificationPrefs(){

        List<String> prefs = null;
           
            try{
                String userName = ADFContext.getCurrent().getSecurityContext().getUserName();
                prefs = StoreMDS.getNotificationsPreferences(userName);
                return Response.ok(prefs).build();
            }catch(Exception e){
                throw new BadRequestException(e);
            }

    }   
    
    
    private HashMap<oracle.jbo.domain.Number,Bookmark> generateLinksMap(List<HashMap> quickLinks,String lang){
      HashMap<oracle.jbo.domain.Number,Bookmark> map = null;      
      if(quickLinks != null && !quickLinks.isEmpty()){             
           map = new HashMap<oracle.jbo.domain.Number,Bookmark>();             
           for(HashMap linkMap : quickLinks){
               map.put((Number)linkMap.get("QlId"), new Bookmark(linkMap,lang));
           }
      }
      return map;
    }   
    
    
    private Map<oracle.jbo.domain.Number,QuickLinkDTO> generateLinksMapBookmark(List<HashMap> quickLinks,String lang){
     Map<oracle.jbo.domain.Number,QuickLinkDTO> map = null;      
      if(quickLinks != null && !quickLinks.isEmpty()){             
           map = new HashMap<oracle.jbo.domain.Number,QuickLinkDTO>();             
           for(Map linkMap : quickLinks){
               map.put((Number)linkMap.get("QlId"), new QuickLinkDTO(linkMap));
           }
      }
      return map;
    }   
    
    private ArrayList<oracle.jbo.domain.Number> filterImproperlyAssignedQuicklinks(List<oracle.jbo.domain.Number> allUserLinks, List<HashMap> quickLinks) {
        List<oracle.jbo.domain.Number> userLinks = new ArrayList<oracle.jbo.domain.Number>();        
        for(HashMap linkMap:quickLinks) {                        
            Number linkId = (Number)linkMap.get("QlId");            
                for (Number id:allUserLinks)   {
                    if (linkId.equals(id)) {                        
                        userLinks.add(id);
                        break;
                }
            }
        }        
        return (ArrayList<Number>)userLinks;
    }     
    
    @GET
    @CacheMaxAge(time = 360, unit = TimeUnit.MINUTES)
    @Path("/bookmarks")
    public Response getBookmarks(@DefaultValue("en") @QueryParam("lang") String lang){              
            try{
                List<oracle.jbo.domain.Number> userLinks = null;
                UserProfileAM am = getUserProfileAM();
                am.setLocale(lang);
                String userName = ADFContext.getCurrent().getSecurityContext().getUserName();

                String[] userRoles = ADFContext.getCurrent().getSecurityContext().getUserRoles();        
                List<HashMap> quickLinks = getUserProfileAM().retrieveQuickLinks(userRoles); 
                Collections.sort(quickLinks,new Comparator<HashMap>(){
                        public int compare(HashMap first,HashMap second){
                            String firstDisplayName=first.get("DisplayName").toString();
                            String secondDisplayName=second.get("DisplayName").toString();
                            return firstDisplayName.compareTo(secondDisplayName);
                        }
                    }
                );             
                Map<oracle.jbo.domain.Number,Bookmark> quickLinksMap = generateLinksMap(quickLinks,lang);
                Bookmark bookmark;
                List<oracle.jbo.domain.Number> allUserLinks = am.retrieveSelectedLinks(userName);   
                if (allUserLinks != null) {
                    userLinks = filterImproperlyAssignedQuicklinks(allUserLinks, quickLinks);
                }
                if(userLinks !=null && !userLinks.isEmpty()){
                    for(oracle.jbo.domain.Number qlId : userLinks){
                        bookmark = quickLinksMap.get(qlId);
                        if(bookmark!=null){
                            bookmark.setFavorite(true);
                        }
                    }
                }

                return Response.ok(quickLinksMap.values()).build();
            }catch(Exception e){
                throw new BadRequestException(e);
            }

    }
 
    @PUT
    @Path("/notifications/prefs")
    public Response setNotificationPrefs(ArrayList<String> prefs){

        try{
            String userName = ADFContext.getCurrent().getSecurityContext().getUserName();
            StoreMDS.storeInMDS(userName,-1,prefs,null);
            return Response.ok(prefs).build();
        }catch(Exception e){
            throw new BadRequestException(e);
        }
    }   
    
    private List<String[]> getQueryParamVals(String operator,List<String> param){
        if(param !=null && param.size() >0){
            List<String[]> vals = new ArrayList<String[]>();
            
            for(String args : param){
                vals.add(new String[]{operator,args});
            }
            return vals;
        }else{
            return null;
        }
    }
    
    private List<String> getRestaurants(List<String> description){
        List<String[]> queryParamVals;
        ArrayList<Identity> identities;
        
        if(description !=null && description.size() >0){
            HashMap<String[],List<String[]>> akaQueryParams = new HashMap<String[],List<String[]>>();
            
            queryParamVals = getQueryParamVals("_like_",description);
            akaQueryParams.put(new String[]{"Darden-AKA"}, queryParamVals);
            
            try {
                LdapHelper ldapHelper = LdapHelper.getInstance();
                ldapHelper.setCountLimit(null);
                ldapHelper.setPageLimit(null);
                ldapHelper.setUserSearchBase(RESTAURANT_SEARCH_BASES);
                identities =ldapHelper.getIdentitiesWithComplexAttributes(akaQueryParams,
                                                                      ComplexSearchFilter.TYPE_AND);
                ldapHelper.resetUserSearchBase();
                if(identities != null && identities.size()!=0){
                    List<String> restNumbers = new ArrayList<String>();
                    String restNum;
                    for(Identity restaurant : identities){
                        restNum =
                                (String)((User)restaurant).getUserProfile().getPropertyVal("physicalDeliveryOfficeName");
                        if(StringUtils.isNotBlank(restNum) && !restNumbers.contains(restNum)){
                            restNumbers.add(restNum);
                        }
                    }
                    
                    if(restNumbers.size()!=0){
                        return restNumbers;
                    }else{
                        return null;
                    }
                }else{
                    return null;
                }
            } catch (Exception e) {
                return null;
            }            
        }else{
            return null;
        }
    }
    
    
    private String generatePhotoURI(String guid, String size) {
      String encodedGuid = null;

      if (guid != null)
        encodedGuid = ProfileInternalUtils.asciiToHex(guid);

        StringBuilder uriBuilder =
            new StringBuilder(64).append("/").append("profilephoto").append("/").append(encodedGuid).append('/').append(size);
      String photoUID = "xxxxxxx";
      try{
            UserProfileManager userProfileManager = this.getUserProfileManager();
            WCUserProfile profile =  userProfileManager.getProfileByGUID(guid);
            photoUID = profile.getPhotoUID();
      }catch(Exception e) {

      }

      uriBuilder.append('/').append(photoUID);
      uriBuilder.append("?_xResourceMethod=wsrp");

      return uriBuilder.toString();
    }   
    
    private boolean _isConnected(String targetUserGuid) {
        if(connectionsManager == null){
            connectionsManager = getConnectionsManager();            
        }

        try {
            String guid = getCurentUserGUID();
            if(userConnections == null){
                userConnections = connectionsManager.getConnections(guid);
            }
            
            if(userConnections!=null && userConnections.size()>0){
                logger.info("_isConnected : connectionsManager="+connectionsManager + ", guid = "+ guid + ","+ userConnections.size());
                String connectedUserId;
                for(Connection conn : userConnections){
                    connectedUserId = conn.getConnecteeUserId();
                    logger.info("is a connection: "+ connectedUserId);
                    if(connectedUserId.compareTo(targetUserGuid)==0){
                        return true;
                    }
                }
                return false;
            }else{
                return false;
            }
        } catch (ConnectionsException e) {
            logger.severe(e);
        }
        
        return false;
    }
    
    private boolean _isInvited(String targetUserGuid){
        boolean isInvited = false;
        InvitationsManager invitationsManager = this.getInvitationsManager();
        if(sentInvitations == null){
            try {
                sentInvitations = invitationsManager.getSentInvitations();
            } catch (ConnectionsException e) {
            }
        }
        
        if(sentInvitations != null){
            String inviteeId;
            for(Invitation invite : sentInvitations){
                inviteeId = invite.getInviteeUserid();
                if(targetUserGuid.compareTo(inviteeId)==0){
                    isInvited = true;
                    break;
                }
            }
        }
        
        if(!isInvited){
            if(receivedInvitations == null){
                try {
                    receivedInvitations =
                            invitationsManager.getReceivedInvitations();
                } catch (ConnectionsException e) {
                }
                
            }
            
            if(receivedInvitations != null){
                String invitorId;
                for(Invitation invite : receivedInvitations){
                    invitorId = invite.getInvitorUserid();
                    if(targetUserGuid.compareTo(invitorId)==0){
                        isInvited = true;
                        break;
                    }
                }                
            }
        }
        
        return isInvited;        
    }
    
    
    private List<PersonRow> createPersonRows(int beginInx,int itemsPerPage,ArrayList<Identity> identities) {
        List<PersonRow> rows = new ArrayList<PersonRow>();
        
        if(identities !=null && identities.size()>0){
            int endInx = identities.size();        
            int pageEndIndex = beginInx + itemsPerPage;
            
            if(pageEndIndex > endInx){
                pageEndIndex = endInx;
            }
            logger.info("Creating Person Rows for records : "+ identities.size());
            for (int i = beginInx; i < pageEndIndex; i++) {
                PersonRow person = new PersonRow((User)identities.get(i));
                person.processUser();
                person.setPhotoURI(generatePhotoURI(person.getGuid(), "LARGE"));
                person.setEncodedGuid(ProfileInternalUtils.asciiToHex(person.getGuid()));
                logger.info("Checking for connection : "+ person.getUserName() + ", guid = "+ person.getGuid());
                boolean isConnected = _isConnected(person.getGuid());
                person.setConnected(isConnected);

                if (!isConnected) {
                    person.setInvited(_isInvited(person.getGuid()));
                }

                rows.add(person);
            }
        }        
        return rows;        
    }    
    
    @GET
    @CacheMaxAge(time = 360, unit = TimeUnit.MINUTES)
    @Path("/search")
    public Response searchPeople(@QueryParam("firstName") List<String> firstName,
                                              @QueryParam("middleName") List<String> middleName,
                                              @QueryParam("lastName") List<String> lastName,
                                              @QueryParam("title") List<String> title,
                                              @QueryParam("concept") List<String> brand,
                                              @QueryParam("restaurant") List<String> restaurant,
                                              @QueryParam("description") List<String> description,
                                              @QueryParam("country") List<String> country,
                                              @QueryParam("state") List<String> state,
                                              @QueryParam("city") List<String> city,
                                              @QueryParam("employeeId") List<String> employeeId,
                                              @QueryParam("userName") List<String> username,
                                              @DefaultValue("0") @QueryParam("startIndex") StartIndexParam startIndex,
                                              @DefaultValue("25") @QueryParam("itemsPerPage") ItemsPerPageParam itemsPerPage){        
        
        HashMap<String[],List<String[]>> queryParams = new HashMap<String[],List<String[]>>();
        List<String[]> queryParamVals;
        PaginationParams pagination = new PaginationParams(startIndex, itemsPerPage);
        
        if(restaurant == null || restaurant.size()==0){
            if(description !=null && description.size() >0){
                restaurant = getRestaurants(description);
            }            
        }
                        
        queryParamVals = getQueryParamVals("_startswith_",firstName);
        if(queryParamVals !=null){
            queryParams.put(new String[]{UserProfile.FIRST_NAME,
                                           UserProfile.DISPLAY_NAME}, queryParamVals);
        }
        
        queryParamVals = getQueryParamVals("_startswith_",middleName);
        if(queryParamVals !=null){
            queryParams.put(new String[]{UserProfile.DISPLAY_NAME}, queryParamVals);
        }        

        queryParamVals = getQueryParamVals("_startswith_",lastName);
        if(queryParamVals !=null){
            queryParams.put(new String[]{UserProfile.LAST_NAME}, queryParamVals);
        }        
        
        queryParamVals = getQueryParamVals("_like_",title);
        if(queryParamVals !=null){
            queryParams.put(new String[]{ "Darden-Job-Function",
                                           "Darden-Sub-Function",
                                           UserProfile.TITLE}, queryParamVals);
        }        
        
       
        queryParamVals = getQueryParamVals("_eq_",brand);
        if(queryParamVals !=null){
            queryParams.put(new String[]{ "company", "Darden-Business-Unit"}, queryParamVals);
        }         

        queryParamVals = getQueryParamVals("_eq_",restaurant);
        if(queryParamVals !=null){
            queryParams.put(new String[]{ "physicalDeliveryOfficeName"}, queryParamVals);
        }         

        queryParamVals = getQueryParamVals("_eq_",country);
        if(queryParamVals !=null){
            queryParams.put(new String[]{ "co"}, queryParamVals);
        }         

        queryParamVals = getQueryParamVals("_eq_",state);
        if(queryParamVals !=null){
            queryParams.put(new String[]{ UserProfile.BUSINESS_STATE }, queryParamVals);
        }       
        

        queryParamVals = getQueryParamVals("_eq_",city);
        if(queryParamVals !=null){
            queryParams.put(new String[]{ UserProfile.BUSINESS_CITY }, queryParamVals);
        }       
        
        queryParamVals = getQueryParamVals("_eq_",employeeId);
        if(queryParamVals !=null){
            queryParams.put(new String[]{ "Darden-Empl-ID" }, queryParamVals);
        }       
        
        queryParamVals = getQueryParamVals("_eq_",username);
        if(queryParamVals !=null){
            queryParams.put(new String[]{ UserProfile.USER_NAME,UserProfile.USER_ID }, queryParamVals);
        }       
        
        try {
            LdapHelper ldapHelper = LdapHelper.getInstance();
            ldapHelper.setCountLimit(LDAP_COUNT_LIMIT);
            ldapHelper.setPageLimit(LDAP_PAGE_LIMIT);
            ldapHelper.setUserSearchBase(USER_SEARCH_BASES);
            ArrayList<Identity> identities = ldapHelper.getIdentitiesWithComplexAttributes(queryParams,ComplexSearchFilter.TYPE_AND);
            ldapHelper.resetUserSearchBase();
            List<PersonRow> result = createPersonRows(pagination.getStartIndexValue(),pagination.getItemsPerPageValue(),identities);            
            int totalCount = identities==null?0:identities.size();
            logger.info("Total number of users returned = "+ identities.size());
            PersonList list = new PersonList(result,pagination.getStartIndexValue(),totalCount);
            return Response.ok(list).build();
        } catch (Exception e) {
            logger.severe(e);
            LdapHelper ldapHelper;
            try {
                ldapHelper = LdapHelper.getInstance();
                ldapHelper.resetUserSearchBase();
            } catch (Exception f) {
                logger.severe(f);
            }                
            throw new BadRequestException(e);
        }  
    }    
    
    
    private List<String> getContacts(){
        ADFPreferencesFactory factory = new ADFPreferencesFactory();
        byte[] usersByteArray = new byte[0];
        List<String> personList = new ArrayList<String>();
        usersByteArray = factory.userRoot().getByteArray("MyContacts", usersByteArray);
        if(usersByteArray.length>0){
            LinkedList<String> contacts = (LinkedList<String>)SerializationUtils.deserialize(usersByteArray);
            if(contacts != null){
                String userName;
                for(int i=0;i<contacts.size();){
                    userName = contacts.get(i);
                    personList.add(userName);
                    i=i+2;
                }
            }
        }
        return personList;
    }
    
    private List<PersonReference> mergeContacts(List<PersonReference> toList, List<PersonReference> fromList){
        if(toList == null){
            if(fromList == null)
                return null;
            else
                return fromList;
        }else{
            if(fromList == null)
                return toList;
            else{                
                for(PersonReference fPerRef : fromList){
                    for(int i=0;i<toList.size();i++){
                        if(toList.get(i).getGuid().compareTo(fPerRef.getGuid())==0){
                            toList.remove(i);
                            break;
                        }
                    }
                }
                fromList.addAll(toList);
                return fromList;
            }
        }
    }
    
    @GET
    @CacheMaxAge(time = 360, unit = TimeUnit.MINUTES)
    @Path("/ssearch")
    public List<PersonReference> searchPeople(@QueryParam("query") String query){        
        if(query == null){
            List<PersonReference> contacts = toPersonReferences(getContacts());
            if(contacts == null || contacts.isEmpty() || contacts.size()<10){
                String userName = ADFContext.getCurrent().getSecurityContext().getUserName();
                try {
                    if(contacts == null)
                        contacts = getUserConnections(userName);
                    else
                        contacts = mergeContacts(contacts, getUserConnections(userName));
                } catch (Exception e) {
                    logger.severe(e);
                } 
            }            
            return contacts;
        }else{
            query = query.toUpperCase();
            HttpSession session = httpRequest.getSession();        
            List<PersonReference> contacts = (List<PersonReference>)session.getAttribute("SEARCH_CONTACTS_"+query);
            if(contacts !=null) 
                return contacts;
            contacts = toPersonReferences(getContacts());
            contacts = filterPersonReferences(contacts,query);
            if(contacts==null || contacts.isEmpty() || contacts.size()<10){
                String userName = ADFContext.getCurrent().getSecurityContext().getUserName();
                try {
                    if(contacts == null){
                        contacts = getUserConnections(userName);
                        contacts = filterPersonReferences(contacts,query);
                    }else{
                        List<PersonReference> tContacts = getUserConnections(userName);
                        tContacts = filterPersonReferences(tContacts,query);
                        contacts = mergeContacts(contacts, tContacts);
                    }
                } catch (Exception e) {
                    logger.severe(e);
                } 
                
                if(contacts == null || contacts.isEmpty() || contacts.size()<10){
                    String[] parts = query.split("\\s+");               
                    List<PersonReference> tContacts = new ArrayList<PersonReference>();
                    try { 
                        LdapHelper ldapHelper = LdapHelper.getInstance();
                        ldapHelper.resetUserSearchBase();
                        ldapHelper.setCountLimit(LDAP_COUNT_LIMIT);
                        ldapHelper.setPageLimit(LDAP_PAGE_LIMIT);
                        ldapHelper.setUserSearchBase(USER_SEARCH_BASES);
                        
                        List<Identity> identities =null;
                        
                        if(parts.length==1 && parts[0].length()>3){                    
                            HashMap<String[],List<String[]>> params = new HashMap<String[],List<String[]>>();
                            
                            //first , display
                            String[] operFD = new String[]{"_startswith_",parts[0]};
                            ArrayList<String[]> operFDList = new ArrayList<String[]>();
                            operFDList.add(operFD);
                            
                            //last
                            String[] operL = new String[]{"_startswith_",parts[0]};
                            ArrayList<String[]> operLList = new ArrayList<String[]>();
                            operLList.add(operL);
                            
                            
                            params.put(new String[] {UserProfile.FIRST_NAME,UserProfile.DISPLAY_NAME},operFDList);
                            params.put(new String[] {UserProfile.LAST_NAME},operLList);
                            identities = ldapHelper.getIdentitiesWithComplexAttributes(params,ComplexSearchFilter.TYPE_OR);                            

                        }
                        if(parts.length>1 && (parts[0].length()>3 || parts[1].length()>3)){
                            HashMap<String[],List<String[]>> params = new HashMap<String[],List<String[]>>();
                            
                            //first , display
                            String[] operFD = new String[]{"_startswith_",parts[0]};
                            ArrayList<String[]> operFDList = new ArrayList<String[]>();
                            operFDList.add(operFD);
                            
                            //last
                            String[] operL = new String[]{"_startswith_",parts[1]};
                            ArrayList<String[]> operLList = new ArrayList<String[]>();
                            operLList.add(operL);
                            
                            
                            params.put(new String[] {UserProfile.FIRST_NAME,UserProfile.DISPLAY_NAME},operFDList);
                            params.put(new String[] {UserProfile.LAST_NAME},operLList);
                            identities = ldapHelper.getIdentitiesWithComplexAttributes(params,ComplexSearchFilter.TYPE_AND);                            
                        }
                        
                        if(identities !=null){
                            if(LDAP_COUNT_LIMIT<identities.size()){
                             identities=identities.subList(0,LDAP_COUNT_LIMIT);   
                            }
                            tContacts = identitiesToPersonReferences(identities);    
                        }                        
                        
                    } catch (Exception e) {
                        logger.severe(e);
                    }
                    if(contacts == null)
                        contacts = tContacts;
                    else{
                        contacts = mergeContacts(contacts, tContacts);
                    }
                }
                session.setAttribute("SEARCH_CONTACTS_"+query, contacts);
                return contacts;
            }else{
                session.setAttribute("SEARCH_CONTACTS_"+query, contacts);
                return contacts;
            }
        }
    }
    
    @GET
    @Path("/allquicklinks")
    public Response retrieveAllQuickLinks() {
        try {
            UserProfileAM am = getUserProfileAM();
            am.setLocale("en");
            String[] userRoles = ADFContext.getCurrent().getSecurityContext().getUserRoles();
            List<HashMap> quickLinks = am.retrieveQuickLinks(userRoles);
            Collections.sort(quickLinks, new Comparator<HashMap>() {
                    public int compare(HashMap first, HashMap second) {
                        String firstDisplayName =
                            first.get("DisplayName").toString();
                        String secondDisplayName =
                            second.get("DisplayName").toString();
                        return firstDisplayName.compareTo(secondDisplayName);
                    }
                });
            List<QuickLinkDTO> quickLinkList = new ArrayList<QuickLinkDTO>();
            for(Map quickLink:quickLinks){
                QuickLinkDTO quickLinkDTO = new QuickLinkDTO(quickLink); 
                quickLinkList.add(quickLinkDTO);
            }
            QuickLinkDTO[] ret=quickLinkList.toArray(new QuickLinkDTO[quickLinkList.size()]);
            return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
        } catch (Exception e) {
            throw new BadRequestException(e);
        }
    }

    @GET
    @Path("/userquicklinks")
    public Response retrieveUserQuickLinks() {
        try {
            List<oracle.jbo.domain.Number> quickLinksUI = new ArrayList<oracle.jbo.domain.Number>();
            UserProfileAM am = getUserProfileAM();
            am.setLocale("en");
            String[] userRoles = ADFContext.getCurrent().getSecurityContext().getUserRoles();
            String userName = ADFContext.getCurrent().getSecurityContext().getUserName();
            //1. Derrive ALL Quick Links
            List<HashMap> allAvailableQuickLinks = am.retrieveQuickLinks(userRoles);
            Collections.sort(allAvailableQuickLinks, new Comparator<HashMap>() {
                    public int compare(HashMap first, HashMap second) {
                        String firstDisplayName =
                            first.get("DisplayName").toString();
                        String secondDisplayName =
                            second.get("DisplayName").toString();
                        return firstDisplayName.compareTo(secondDisplayName);
                    }
                });
            Map<oracle.jbo.domain.Number,QuickLinkDTO> allAvailableQuickLinksMap = generateLinksMapBookmark(allAvailableQuickLinks,"en");
            
            //2. Now Derrive Personalized Links
            List<oracle.jbo.domain.Number> personalizedLinks = am.retrieveSelectedLinks(userName);   
            //2.1 Filter improperly assigned links
            if (personalizedLinks != null) {
                personalizedLinks = filterImproperlyAssignedQuicklinks(personalizedLinks, allAvailableQuickLinks);
            }
            
            
            // 2.2 If no personalized Links exist, Derrive the default links to be shown as personalized
            //TODO:Check if this is still a valid requirement for 4.2
            if (personalizedLinks == null || personalizedLinks.isEmpty()){
                logger.info("userLinks for user is null");
                personalizedLinks = new ArrayList<oracle.jbo.domain.Number>();
                for(HashMap linkMap: allAvailableQuickLinks) {
                    String mandatory = (String) linkMap.get("IsMandatory");
                    String def = (String) linkMap.get("IsDefault");
                    oracle.jbo.domain.Number qlId = (Number)linkMap.get("QlId"); // this is related_ql_id from DB
                    if (mandatory != null && mandatory.compareToIgnoreCase("Y") == 0) {
                        personalizedLinks.add((Number)linkMap.get("QlId")); // this is related_ql_id from DB
                    }
                    
                    if(def != null && def.compareToIgnoreCase("Y") == 0 && !containsLink(personalizedLinks, qlId)){
                        personalizedLinks.add((Number)linkMap.get("QlId")); // this is related_ql_id from DB
                    }
                }
//                for(HashMap linkMap: allAvailableQuickLinks) {
//                    String def = (String) linkMap.get("IsDefault");
//                    oracle.jbo.domain.Number qlId = (Number)linkMap.get("QlId"); // this is related_ql_id from DB
//                    if (def != null && def.compareToIgnoreCase("Y") == 0 && !containsLink(userLinks, qlId)) {
//                        userLinks.add(qlId);
//                    }
//                }
            }
            //2.3 removing duplicate from personalized quick links
            if(personalizedLinks != null){
                logger.info("userLinks for user at the end before removing duplicates: "+personalizedLinks);
                personalizedLinks= new ArrayList<oracle.jbo.domain.Number>(new LinkedHashSet<oracle.jbo.domain.Number>(personalizedLinks));
                //Collections.sort(userLinks);
                logger.info("userLinks for user at the end after removing duplicates: "+personalizedLinks);
            }
            
            //3. Prepare for UI
            List<QuickLinkDTO> personalizedQLList = new ArrayList<QuickLinkDTO>();
            List<QuickLinkDTO> allAvailableQLList = new ArrayList<QuickLinkDTO>();
            List<QuickLinkDTO> mandatoryQLList = new ArrayList<QuickLinkDTO>();
            //3.1 prepare a personalized Map for comparision
            Map<oracle.jbo.domain.Number, oracle.jbo.domain.Number> personalizedLinksMap = new HashMap<oracle.jbo.domain.Number, oracle.jbo.domain.Number>();
            for(oracle.jbo.domain.Number qlId : personalizedLinks){
                personalizedLinksMap.put(qlId, qlId);
            }
            Set<oracle.jbo.domain.Number> allLinks = allAvailableQuickLinksMap.keySet();
            for(oracle.jbo.domain.Number linkId : allLinks){
                QuickLinkDTO dto = allAvailableQuickLinksMap.get(linkId);
                if(dto.isMandatory()){
                    mandatoryQLList.add(dto);
                }else if(personalizedLinksMap.containsKey(new oracle.jbo.domain.Number(dto.getId()))){
                    personalizedQLList.add(dto);
                }else{
                    allAvailableQLList.add(dto);
                }
                
            }
//            for(HashMap linkMap: allAvailableQuickLinks) {
//                oracle.jbo.domain.Number qlId = (Number)linkMap.get("QlId");
//                if(personalizedLinks.contains(qlId)){
//                    quickLinksUI.add(qlId);
//                }
//            }
            
            
//            for(HashMap linkMap: allAvailableQuickLinks) {
//                oracle.jbo.domain.Number qlId = (Number)linkMap.get("QlId");
//                if(!userLinks.contains(qlId)){
//                    quickLinksUI.add(qlId);
//                }
//            }

//            if (userLinks != null && !userLinks.isEmpty()) {
//                for (oracle.jbo.domain.Number qlId : userLinks) {
//                   QuickLinkDTO  quickLinkDTO = quickLinksMap.get(qlId);
//                    if (quickLinkDTO != null) {
//                        quickLinkUserList.add(quickLinkDTO);
//                    }
//                }
//            }
//            if (quickLinksUI != null && !quickLinksUI.isEmpty()) {
//                for (oracle.jbo.domain.Number qlId : quickLinksUI) {
//                   QuickLinkDTO  quickLinkDTO = quickLinksMap.get(qlId);
//                    if (quickLinkDTO != null) {
//                        quickLinkAvailableForUserList.add(quickLinkDTO);
//                    }
//                }
//            }
            
            QuickLinkListDTO resultList = new QuickLinkListDTO();
            resultList.setMandatoryQuickLinks(mandatoryQLList);
            resultList.setPersonalizedQuickLinks(personalizedQLList);
            resultList.setAvailableQuickLinks(allAvailableQLList);
            return Response.ok(resultList).type(MediaType.APPLICATION_JSON).build();
        } catch (Exception e) {
            throw new BadRequestException(e);
        }
    }
    
    @POST
    @Path("/saveQuickLinkPersonalization")
    public Response saveQuickLinkPersonalization(Integer[] quickLinkIds) {
        logger.info("Got Personalized Links : "+ quickLinkIds);
        String userName = ADFContext.getCurrent().getSecurityContext().getUserName();
        UserProfileAM am = getUserProfileAM();
        am.setLocale("en");
        List<Number> selectedLinkIds = new ArrayList<Number>();
        for(int i=0;i<quickLinkIds.length;i++){
            selectedLinkIds.add(new Number(quickLinkIds[i].intValue()));
        }
        logger.info("Saving Personalized Links for user : "+userName +"  Links : "+ selectedLinkIds + ", "+selectedLinkIds.size());
        boolean result = am.saveSelectedQuickLinks(userName, selectedLinkIds);    
        logger.info("Result after saving Selected QuickLinks "+result);
        return Response.ok(result).type(MediaType.APPLICATION_JSON).build();
    }
    
    
    private boolean containsLink(List<oracle.jbo.domain.Number> userLinks,oracle.jbo.domain.Number linkId){
        boolean found=false;
        if(userLinks != null && linkId != null){
            for(oracle.jbo.domain.Number userLinkId : userLinks){
                if(userLinkId.compareTo(linkId)==0){
                    found=true;
                    break;
                }
            }
        }
        return found;                    
    }
    
    @GET
    @Path("/userPasswordEmail")
    public Response getUserPasswordEmail() {
        UserProfileAM am = getUserProfileAM(); 
        String userName = ADFContext.getCurrent().getSecurityContext().getUserName();
        String ret = am.getUserPasswordEmail(userName);       
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Path("/userPasswordEmail")    
    public Response setUserPasswordEmail(String eMail) {
        UserProfileAM am = getUserProfileAM();    
        String userName = ADFContext.getCurrent().getSecurityContext().getUserName();
        boolean ret = am.setUserPasswordEmail(userName,eMail);       
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }
    
    
    
    public static void main(String[] args) throws JAXBException {
        String profileXML = "<ns1:ShowEmployeeProfileDataAreaTypeRoot xmlns:ns1=\"http://www.darden.com/Global/EnterpriseObjects/Core/EBO/Worker/V1\"><ns1:ShowEmployeeProfileResponse><ns1:EmployeeProfileDetails><ns1:WorkerEmployment><corecom:Identification xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"><corecom:ID>101512788</corecom:ID></corecom:Identification><ns1:StartDate>2013-04-22</ns1:StartDate><ns1:EmploymentTerm><ns1:EmploymentAssignment><corecom:Status xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"><corecom:Code>A</corecom:Code></corecom:Status><corecom:DepartmentReference xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"><corecom:DepartmentIdentification><corecom:ID>0971</corecom:ID></corecom:DepartmentIdentification><corecom:OrganizationUnitIdentification><corecom:ID>DRUSA</corecom:ID></corecom:OrganizationUnitIdentification></corecom:DepartmentReference><corecom:LocationReference xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"><corecom:LocationIdentification><corecom:ID>RSC - Restaurant Support Cntr</corecom:ID></corecom:LocationIdentification><corecom:Address><corecom:LineOne>3827 Pine Gate Trail</corecom:LineOne><corecom:LineTwo></corecom:LineTwo><corecom:CityName>Orlando</corecom:CityName><corecom:StateName>FL</corecom:StateName><corecom:CountryCode>USA</corecom:CountryCode><corecom:PostalCode>32824</corecom:PostalCode></corecom:Address></corecom:LocationReference><ns1:EmploymentAssignmentSupervision><ns1:SupervisionWorkerDirectReports><ns1:DirectReportID></ns1:DirectReportID><ns1:DirectReportName></ns1:DirectReportName></ns1:SupervisionWorkerDirectReports><ns1:ReportsToID>990008937</ns1:ReportsToID><ns1:ReportsToName>Test Copeland</ns1:ReportsToName></ns1:EmploymentAssignmentSupervision></ns1:EmploymentAssignment><ns1:WorkerJobCodes><ns1:JobCode>7948</ns1:JobCode><ns1:JobTitle>Sr Systems Engineer Portal</ns1:JobTitle><ns1:JobCodeSeq>0</ns1:JobCodeSeq></ns1:WorkerJobCodes></ns1:EmploymentTerm></ns1:WorkerEmployment><ns1:WorkerCertification><corecom:Identification xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"><corecom:ID></corecom:ID></corecom:Identification><corecom:Certification xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"><corecom:Name></corecom:Name><corecom:TypeOfCert></corecom:TypeOfCert><corecom:IssueDate></corecom:IssueDate><corecom:ExpirationDate></corecom:ExpirationDate></corecom:Certification></ns1:WorkerCertification><corecomEBO:Person xmlns:corecomEBO=\"http://www.darden.com/Global/EnterpriseObjects/Core/CommonEBO/V1\"><corecomEBO:BirthDateTime>1981-08-29</corecomEBO:BirthDateTime><corecomEBO:GenderCode>M</corecomEBO:GenderCode><corecomEBO:HighestEducLevel>09</corecomEBO:HighestEducLevel><corecomEBO:EthnicGroup></corecomEBO:EthnicGroup><corecomEBO:HideBirthDate>false</corecomEBO:HideBirthDate><corecomEBO:HideAnniversaryDate>false</corecomEBO:HideAnniversaryDate><corecomEBO:PersonName><corecom:PersonName xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"><corecom:FirstName>Rakesh</corecom:FirstName><corecom:MiddleName></corecom:MiddleName><corecom:FamilyName>Gajula</corecom:FamilyName><corecom:Prefix></corecom:Prefix><corecom:Suffix></corecom:Suffix></corecom:PersonName></corecomEBO:PersonName><corecomEBO:PersonAddressCommunication><corecom:AddressCommunication xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"><corecom:Address><corecom:LineOne>3827 Pine Gate Trail</corecom:LineOne><corecom:LineTwo></corecom:LineTwo><corecom:CityName>Orlando</corecom:CityName><corecom:StateName>FL</corecom:StateName><corecom:CountryCode>USA</corecom:CountryCode><corecom:PostalCode>32824</corecom:PostalCode></corecom:Address></corecom:AddressCommunication></corecomEBO:PersonAddressCommunication><corecomEBO:PersonPhoneCommunication><corecom:PhoneCommunication xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"><corecom:CompleteNumber>321/704-6585</corecom:CompleteNumber><corecom:ExtensionNumber></corecom:ExtensionNumber><corecom:TypeCode>CELL</corecom:TypeCode><corecom:PreferredIndicator>N</corecom:PreferredIndicator></corecom:PhoneCommunication><corecom:PhoneCommunication xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"><corecom:CompleteNumber>321/323-9427</corecom:CompleteNumber><corecom:ExtensionNumber></corecom:ExtensionNumber><corecom:TypeCode>HOME</corecom:TypeCode><corecom:PreferredIndicator>Y</corecom:PreferredIndicator></corecom:PhoneCommunication><corecom:PhoneCommunication xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"><corecom:CompleteNumber>321/821-0128</corecom:CompleteNumber><corecom:ExtensionNumber></corecom:ExtensionNumber><corecom:TypeCode>OTR</corecom:TypeCode><corecom:PreferredIndicator>N</corecom:PreferredIndicator></corecom:PhoneCommunication><corecom:PhoneCommunication xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"><corecom:CompleteNumber>407/245-4697</corecom:CompleteNumber><corecom:ExtensionNumber></corecom:ExtensionNumber><corecom:TypeCode>WORK</corecom:TypeCode><corecom:PreferredIndicator>N</corecom:PreferredIndicator></corecom:PhoneCommunication></corecomEBO:PersonPhoneCommunication><corecomEBO:PersonEmailCommunication><corecom:EmailCommunication xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"><corecom:URI></corecom:URI><corecom:UseCode></corecom:UseCode><corecom:PreferredIndicator></corecom:PreferredIndicator></corecom:EmailCommunication></corecomEBO:PersonEmailCommunication><corecomEBO:PersonEmergencyContactInformation><corecomEBO:ECName></corecomEBO:ECName><corecomEBO:ECSameAddressEmpl>N</corecomEBO:ECSameAddressEmpl><corecomEBO:ECPreferred>Y</corecomEBO:ECPreferred><corecomEBO:ECCountry></corecomEBO:ECCountry><corecomEBO:ECAddress1></corecomEBO:ECAddress1><corecomEBO:ECAddress2></corecomEBO:ECAddress2><corecomEBO:ECCity></corecomEBO:ECCity><corecomEBO:ECState></corecomEBO:ECState><corecomEBO:ECPostal></corecomEBO:ECPostal><corecomEBO:ECRelationship></corecomEBO:ECRelationship><corecomEBO:ECSamePhoneEmpl>N</corecomEBO:ECSamePhoneEmpl><corecomEBO:ECAddressTypeEmpl></corecomEBO:ECAddressTypeEmpl><corecomEBO:ECPhoneTypeEmpl></corecomEBO:ECPhoneTypeEmpl><corecomEBO:EmergencyContactPhone><corecomEBO:ECPhoneType>PRIM</corecomEBO:ECPhoneType><corecomEBO:ECPhone></corecomEBO:ECPhone><corecomEBO:ECPhoneExtension></corecomEBO:ECPhoneExtension></corecomEBO:EmergencyContactPhone></corecomEBO:PersonEmergencyContactInformation></corecomEBO:Person><ns1:ErrorMessage><corecom:ReportingDateTime xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"></corecom:ReportingDateTime><corecom:ErrorCode xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"></corecom:ErrorCode><corecom:ErrorText xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"></corecom:ErrorText><corecom:ErrorActor xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"></corecom:ErrorActor><corecom:ErrorDetail xmlns:corecom=\"http://www.darden.com/Global/EnterpriseObjects/Core/Common/V2\"></corecom:ErrorDetail></ns1:ErrorMessage></ns1:EmployeeProfileDetails></ns1:ShowEmployeeProfileResponse></ns1:ShowEmployeeProfileDataAreaTypeRoot>";
        JAXBContext jc = JAXBContext.newInstance(ShowEmployeeProfileDataAreaType.class);
        Unmarshaller unmarshaller = jc.createUnmarshaller();
        //Subh, CWE ID: 611 - Improper Restriction of XML External Entity Reference
        try
        {
            XMLInputFactory xmlInputFactory = XMLInputFactory.newFactory();
            xmlInputFactory.setProperty(XMLInputFactory.SUPPORT_DTD, false);
            xmlInputFactory.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            logger.info(ex.getMessage());
        }
        //
        ShowEmployeeProfileDataAreaType obj =  (ShowEmployeeProfileDataAreaType)unmarshaller.unmarshal(new ByteArrayInputStream(profileXML.getBytes()));
        System.out.println(obj);
        
        
        
        Map<String,String> ns2json = new HashMap<String, String>();
        ns2json.put("http://www.darden.com/Global/EnterpriseObjects/Core/EBO/Worker/V1", "ps");        
        
        //JSONJAXBContext marshallingContext=new JSONJAXBContext(JSONConfiguration.natural().build(),ShowEmployeeProfileDataAreaType.class);
        //JSONJAXBContext marshallingContext=new JSONJAXBContext(JSONConfiguration.natural().rootUnwrapping(false).humanReadableFormatting(true).build(),ShowEmployeeProfileDataAreaType.class);        
        JSONJAXBContext marshallingContext=new JSONJAXBContext(JSONConfiguration.mapped().xml2JsonNs(ns2json).build(),ShowEmployeeProfileDataAreaType.class);        
        /*JSONMarshaller m = marshallingContext.createJSONMarshaller();
        StringWriter jsonWriter = new StringWriter();
        m.marshallToJSON(obj,jsonWriter);
        String json = jsonWriter.toString();
        
        System.out.println(json);*/
        
        String json = "{\"ps.ShowEmployeeProfileResponse\":{\"ps.EmployeeProfileDetails\":{\"ps.WorkerEmployment\":{\"Identification\":{\"ID\":\"101512788\"},\"ps.StartDate\":\"2013-04-22\",\"ps.EmploymentTerm\":{\"ps.EmploymentAssignment\":{\"Status\":{\"Code\":\"A\"},\"DepartmentReference\":{\"DepartmentIdentification\":{\"ID\":\"0971\"},\"OrganizationUnitIdentification\":{\"ID\":\"DRUSA\"}},\"LocationReference\":{\"LocationIdentification\":{\"ID\":\"RSC - Restaurant Support Cntr\"},\"Address\":{\"LineOne\":\"3827 Pine Gate Trail\",\"LineTwo\":\"\",\"CityName\":\"Orlando\",\"StateName\":\"FL\",\"CountryCode\":\"USA\",\"PostalCode\":\"32824\"}},\"ps.EmploymentAssignmentSupervision\":{\"ps.SupervisionWorkerDirectReports\":{\"ps.DirectReportID\":\"\",\"ps.DirectReportName\":\"\"},\"ps.ReportsToID\":\"990008937\",\"ps.ReportsToName\":\"Test Copeland\"}},\"ps.WorkerJobCodes\":{\"ps.JobCode\":\"7948\",\"ps.JobTitle\":\"Sr Systems Engineer Portal\",\"ps.JobCodeSeq\":\"0\"}}},\"ps.WorkerCertification\":{\"Identification\":{\"ID\":\"\"},\"Certification\":{\"Name\":\"\",\"TypeOfCert\":\"\"}},\"Person\":{\"BirthDateTime\":\"1981-08-29\",\"GenderCode\":\"M\",\"HighestEducLevel\":\"09\",\"EthnicGroup\":\"\",\"HideBirthDate\":\"false\",\"HideAnniversaryDate\":\"false\",\"PersonName\":{\"PersonName\":{\"FirstName\":\"Rakesh\",\"MiddleName\":\"\",\"FamilyName\":\"Gajula\",\"Prefix\":\"\",\"Suffix\":\"\"}},\"PersonAddressCommunication\":{\"AddressCommunication\":{\"Address\":{\"LineOne\":\"3827 Pine Gate Trail\",\"LineTwo\":\"\",\"CityName\":\"Orlando\",\"StateName\":\"FL\",\"CountryCode\":\"USA\",\"PostalCode\":\"32824\"}},\"AddrDeleteIndicator\":\"false\"},\"PersonPhoneCommunication\":{\"PhoneCommunication\":[{\"CompleteNumber\":\"321/704-6585\",\"ExtensionNumber\":\"\",\"TypeCode\":\"CELL\",\"PreferredIndicator\":\"false\"},{\"CompleteNumber\":\"321/323-9427\",\"ExtensionNumber\":\"\",\"TypeCode\":\"HOME\",\"PreferredIndicator\":\"false\"},{\"CompleteNumber\":\"321/821-0128\",\"ExtensionNumber\":\"\",\"TypeCode\":\"OTR\",\"PreferredIndicator\":\"false\"},{\"CompleteNumber\":\"407/245-4697\",\"ExtensionNumber\":\"\",\"TypeCode\":\"WORK\",\"PreferredIndicator\":\"false\"}],\"PhoneDeleteIndicator\":\"false\"},\"PersonEmailCommunication\":{\"EmailCommunication\":{\"URI\":\"\",\"UseCode\":\"\"},\"EmailDeleteIndicator\":\"false\"},\"PersonEmergencyContactInformation\":{\"ECName\":\"\",\"ECSameAddressEmpl\":\"N\",\"ECPreferred\":\"Y\",\"ECCountry\":\"\",\"ECAddress1\":\"\",\"ECAddress2\":\"\",\"ECCity\":\"\",\"ECState\":\"\",\"ECPostal\":\"\",\"ECRelationship\":\"\",\"ECSamePhoneEmpl\":\"N\",\"ECAddressTypeEmpl\":\"\",\"ECPhoneTypeEmpl\":\"\",\"ECDeleteIndicator\":\"false\",\"EmergencyContactPhone\":{\"ECPhoneType\":\"PRIM\",\"ECPhone\":\"\",\"ECPhoneExtension\":\"\"}}},\"ps.ErrorMessage\":{\"ErrorCode\":\"\",\"ErrorText\":\"\",\"ErrorActor\":\"\",\"ErrorDetail\":null}}}}";
        
        JSONUnmarshaller um = marshallingContext.createJSONUnmarshaller(); 
        InputStream stream = new ByteArrayInputStream(json.getBytes());
        //Object newProfileInfo  = um.unmarshalJAXBElementFromJSON(stream, ShowEmployeeProfileDataAreaType.class);
        ShowEmployeeProfileDataAreaType newProfileInfo = um.unmarshalFromJSON(stream, ShowEmployeeProfileDataAreaType.class);
        

        
    }
    
    @GET
    @Path("/networkAccessType")
    public Response isUserInNetwork(){
        String headerType = httpRequest.getHeader("Krowd-NetworkAccessType");  
        logger.severe("headerType == "+ headerType);
        if(headerType == null){
            headerType = "Not Available";
        }
        
        logger.info("/********debug********/");
        Enumeration enm = httpRequest.getHeaderNames();
        while(enm.hasMoreElements()){
            String header = enm.nextElement().toString();
            logger.info(">>  "+ header + " : "+ httpRequest.getHeader(header));
        }
        logger.info("/***** debug ends***/");
        return Response.ok(headerType).type(MediaType.APPLICATION_JSON).build();
    }
    
    @GET
    @Path("/query")
    @Produces("application/json")
    public Response queryGet( @QueryParam("id") List<String> emplIds,@DefaultValue("false") @QueryParam("prefs") boolean prefs,@DefaultValue("KROWD_MOBILE_APP") @QueryParam("app") String app,@DefaultValue("false") @QueryParam("cache") boolean cache){
        List<String> appNames = new ArrayList<String>();
        appNames.add(app);
        return query(emplIds, prefs, appNames, cache, false);
    }
    
    private Response query(List<String> emplIds,boolean prefs,List<String> appNames,boolean cache, boolean isPost) {
        Map<String,Map<String,Object>> empIdProfiles = null;
        Map<String,Map<String,Object>> cachedEmpIdProfiles = null;
        PreferencesAM am = null;  
        Map<String,Object> masterPrefs = null;        
        List<Map<String,Object>> appWiseMasterPrefsSOA = null;
        Map<String,Map<String,Object>> samIdProfiles = null;
        List<String> samIds = null;        
        List<String> noCachedEmpIds = null;
        
        if(null != emplIds && emplIds.size()>0){
            empIdProfiles = new HashMap<String,Map<String,Object>>();
            noCachedEmpIds = new ArrayList<String>();
            cachedEmpIdProfiles = new HashMap<String,Map<String,Object>>();
            //get from cache based on prefrenece needed or not, (or) fill error profiles
            logger.severe("-----------------------------------------------Before Cache call");
            createCachedProfiles(emplIds, prefs, noCachedEmpIds, empIdProfiles, cachedEmpIdProfiles,cache);
            logger.severe("------------------------------------------------After Cache call");
            //profiles not in cache
            if(null != noCachedEmpIds && (noCachedEmpIds.size() > 0)){
                if(prefs){
                    am = getPreferencesAM();
                    if(isPost){
                        Map<String,Map<String,Map<String,Object>>> appWiseMasterPrefs = am.getMasterPrefs(appNames);
                        //transform as required by SOA    
                        appWiseMasterPrefsSOA = transformPrefs(appWiseMasterPrefs);
                    } else {
                        masterPrefs = am.getMasterPrefs(appNames.get(0));
                    }                    
                    samIdProfiles = new HashMap<String,Map<String,Object>>();
                    samIds = new ArrayList<String>();
                }
                //AD call
                logger.severe("------------------------------------------------before AD call");
                List<Identity> identities = getIdentities(noCachedEmpIds);
                logger.severe("------------------------------------------------After AD call");
                createProfiles(identities,masterPrefs, empIdProfiles, samIdProfiles, samIds, appWiseMasterPrefsSOA, isPost);                
                //users preference db call
                if(prefs){
                    logger.severe("------------------------------------------------before DB call");
                    Map<String,Map<String,Object>> usersPrefs = null;
                    Map<String,Map<String,Map<String,Map<String,Object>>>> appWiseUsersPrefs = null;
                    if(isPost){
                        appWiseUsersPrefs = am.getUsersPrefs(samIds,appNames);
                        if(null != appWiseUsersPrefs && appWiseUsersPrefs.size() > 0 ){
                            for(Map.Entry<String,Map<String,Map<String,Map<String,Object>>>> appWiseUserPrefs : appWiseUsersPrefs.entrySet()){
                                Map<String,Object> profile = samIdProfiles.get(appWiseUserPrefs.getKey());
                                //transform as required by SOA
                                List<Map<String,Object>> soaPrefs = transformPrefs(appWiseUserPrefs.getValue());
                                profile.put("prefs", soaPrefs);
                            }
                        }
                    } else {
                        usersPrefs = am.getUsersPrefs(samIds, appNames.get(0));
                        if(null != usersPrefs && usersPrefs.size() > 0){
                            for(Map.Entry<String,Map<String,Object>> userPrefs : usersPrefs.entrySet()){
                                Map<String,Object> profile = samIdProfiles.get(userPrefs.getKey());
                                profile.put("prefs", userPrefs.getValue());                    
                            }
                        }
                    }
                    
                    logger.severe("------------------------------------------------after DB call");
                    
                }                
                //fill the cache
                getCache().putAll(empIdProfiles);
                //copy cached profiles to response
                empIdProfiles.putAll(cachedEmpIdProfiles);
            } else {
                //assign cached profiles to repsonse
                empIdProfiles = cachedEmpIdProfiles;
            }
            //response
            Response response = getProfileResponse(empIdProfiles, isPost);
            return response;
            
        } else {
            throw new BadRequestException("No Employee Id is provided");
        }
    }
    
    private void createCachedProfiles(List<String> emplIds, boolean prefs, List<String> noCachedEmpIds, Map<String,Map<String,Object>> empIdProfiles, Map<String,Map<String,Object>> cachedEmpIdProfiles, boolean cache){
        Map<String,Object> errProfile = new HashMap<String,Object>();
        errProfile.put("error", Boolean.TRUE);
        errProfile.put("errorDetail", "Profile details are not available");
        for(String empId : emplIds){
            if(null != empId && !(empId.trim().isEmpty())){
                Map<String,Object> cachedProfile = null;
                if(cache){
                    cachedProfile = (Map<String,Object>)getCache().get(empId);
                }
                if(null != cachedProfile && cachedProfile.size() > 0){
                    if(prefs){
                        if(null != cachedProfile.get("prefs")){
                            cachedEmpIdProfiles.put(empId, cachedProfile);
                        } else {
                            noCachedEmpIds.add(empId);
                            empIdProfiles.put(empId, errProfile);
                        }
                    } else {
                        if(null != cachedProfile.get("prefs")){
                            Map<String,Object> noPrefProfile = new HashMap<String,Object>();
                            noPrefProfile.putAll(cachedProfile);
                            noPrefProfile.remove("prefs");
                            cachedEmpIdProfiles.put(empId, noPrefProfile);
                        } else {
                            cachedEmpIdProfiles.put(empId, cachedProfile);
                        }                            
                    }
                } else {
                    noCachedEmpIds.add(empId);
                    empIdProfiles.put(empId, errProfile);
                }
            }
        }
    }
    
    private List<Identity> getIdentities(List<String> noCachedEmpIds) {
        HashMap<String[],List<String[]>> queryParams = new HashMap<String[],List<String[]>>();
        List<String[]> queryParamVals;
        queryParamVals = getQueryParamVals("_eq_",noCachedEmpIds);
        if(queryParamVals !=null){
            queryParams.put(new String[]{ "Darden-Empl-ID" }, queryParamVals);
        }
        try{
            LdapHelper ldapHelper = LdapHelper.getInstance();                
            ldapHelper.setCountLimit(LDAP_PROFILE_COUNT_LIMIT);
            ldapHelper.setPageLimit(LDAP_PAGE_LIMIT);
            ldapHelper.setUserSearchBase(USER_SEARCH_BASES);
            List<Identity> identities = ldapHelper.getIdentitiesWithComplexAttributes(queryParams, ComplexSearchFilter.TYPE_OR);                               
            ldapHelper.resetUserSearchBase();
            return identities;
        }
        catch (Exception e){
            logger.severe(e);
            LdapHelper ldapHelper;
            try {
                ldapHelper = LdapHelper.getInstance();
                ldapHelper.resetUserSearchBase();
            } catch (Exception f) {
                logger.severe(f);
            }                
            throw new BadRequestException(e);
        }
    }
        
    private void createProfiles(List<Identity> identities, Map<String,Object> masterPrefs, Map<String,Map<String,Object>> empIdProfiles, Map<String,Map<String,Object>> samIdProfiles , List<String> samIds, List<Map<String,Object>> appWiseMasterPrefs, boolean isPost) {
        Map<String,Object> profile = null;
        boolean prefs = false;
        
        if(null != identities && identities.size() > 0) {           
            if((null !=masterPrefs && masterPrefs.size() > 0) || (null != appWiseMasterPrefs && appWiseMasterPrefs.size() > 0)){
                prefs = true;
            }
            for(Identity identity : identities){
                try{
                    User userIdentity = (User)identity;
                    profile = new HashMap<String, Object>();
                    UserProfile userProfile = userIdentity.getUserProfile();
                    profile.put("employeeId", userProfile.getPropertyVal(DARDEN_EMPL_ID));
                    profile.put("samAccountName", userIdentity.getPrincipal().getName());
                    profile.put("imageUrl", constructImageURL(userIdentity.getGUID(),"LARGE"));
                    profile.put("firstName",userProfile.getPropertyVal(FIRST_NAME));
                    profile.put("lastName",userProfile.getPropertyVal(LAST_NAME));
                    profile.put("phoneNo","4072804615");
                    for (Map.Entry<String, String> entry : PROFILE_ATTRS_KEYS.entrySet()) {
                        String value = (String)userProfile.getPropertyVal(entry.getKey());
                        if(null != value && !(value.trim().isEmpty())){
                            profile.put(entry.getValue(), value);              
                        }                
                    }
                    if(prefs){
                        if(isPost){
                            profile.put("prefs", appWiseMasterPrefs);
                        } else {
                            profile.put("prefs", masterPrefs);
                        }                        
                        samIdProfiles.put(userIdentity.getPrincipal().getName(), profile);
                        samIds.add(userIdentity.getPrincipal().getName());
                    }                    
                    empIdProfiles.put((String)userProfile.getPropertyVal(DARDEN_EMPL_ID), profile);                    
                }
                catch(Exception e){
                    logger.severe(e);
                }                              
            }
        }        
    }
    
    private Response getProfileResponse(Map<String,Map<String,Object>> empIdProfiles, boolean isPost){        
        if(empIdProfiles.size() > 0 ){
            if(1 == empIdProfiles.size()){
                Map<String,Object> ret = empIdProfiles.values().iterator().next();
                if(ret.containsKey("error")){
                    if(isPost){
                        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
                    } else {
                        return Response.status(404).type(MediaType.APPLICATION_JSON).build();
                    }                    
                }
                if(isPost){
                    Map<String,Collection> ret1 = new HashMap<String,Collection>();
                    ret1.put("employees", empIdProfiles.values());
                    return Response.ok(ret1).type(MediaType.APPLICATION_JSON).build();
                } else {
                    return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
                }                
            } else {
                if(isPost){
                    Map<String,Collection> ret = new HashMap<String,Collection>();
                    ret.put("employees", empIdProfiles.values());
                    return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
                } else {
                    return Response.ok(empIdProfiles).type(MediaType.APPLICATION_JSON).build();
                }
            }
            
        } else {
            return Response.status(404).type(MediaType.APPLICATION_JSON).build();
        }   
    }
    
    public String constructImageURL(String guid, String size) {
        String imageURL = null;
        if(guid != null && guid.length() != 0){
            String userHex = ProfileInternalUtils.asciiToHex(guid);
            imageURL   =  userHex + "/"+size;
        }
        return imageURL;
    }
    
    
    @POST
    @Path("/query")
    @Produces("application/json")
    public Response queryPost(Map<String,Object> payload,@DefaultValue("false") @QueryParam("cache") boolean cache){
        List<String> emplIds = null;
        List<String> appNames = null;
        boolean prefs = false;
        emplIds = extractParams(payload, "ids", "id");
        appNames = extractParams(payload, "prefs", "app");
        if(null !=appNames && appNames.size()>0){
            prefs = true;
        }
        return query(emplIds, prefs, appNames, cache, true);  
    }
    
    private List<Map<String,Object>> transformPrefs(Map<String,Map<String,Map<String,Object>>> appWisePrefs){
        List<Map<String,Object>> soaAppWisePrefs = new ArrayList<Map<String,Object>>();
        if(null != appWisePrefs && appWisePrefs.size()>0){
            for(Map.Entry<String,Map<String,Map<String,Object>>> appWisePref : appWisePrefs.entrySet()){
                Map<String,Object> soaAppWisePref = new HashMap<String,Object>();
                soaAppWisePref.put("appId", appWisePref.getKey());                            
                List<Map<String,Object>> soaPrefs = new ArrayList<Map<String,Object>>();
                for(Map.Entry<String,Map<String,Object>> pref : appWisePref.getValue().entrySet()){
                    soaPrefs.add(pref.getValue());
                }
                soaAppWisePref.put("prefs", soaPrefs);
                soaAppWisePrefs.add(soaAppWisePref);
            }   
        }        
        return soaAppWisePrefs;
    }
    
    private List<String> extractParams(Map<String,Object> payload, String type, String subType){
        List<String> paramsValues = null;
        if(null != payload && payload.size() > 0){
            Object paramsPayload = payload.get(type);
            if(null != paramsPayload && ((List)paramsPayload).size() > 0 ){
                paramsValues = new ArrayList<String>();
                for(Map<String,String> li : (List<Map<String,String>>) paramsPayload){
                    if(null != li && li.size()>0){
                        paramsValues.add(li.get(subType).trim());
                    }                    
                }
            }
        }
        return paramsValues;
    }
    
    
    @POST
     @Path("/logout")
     public Response logoutPost(@Context HttpServletRequest req, @Context HttpServletResponse res){
          return logout(req, res);
     }
     
     @GET
     @Path("/logout")
     public Response logoutGet(@Context HttpServletRequest req, @Context HttpServletResponse res){
         return logout(req, res);
     }
     
     
     private Response logout (HttpServletRequest req, HttpServletResponse res){
         boolean status = false;
         if(null != req){
//             Cookie[] cookies = req.getCookies();
//             if(null != cookies && cookies.length > 0) {
//                 for(Cookie cookie : cookies){
//                     cookie.setValue("");
//                     cookie.setMaxAge(0);
//                     cookie.setPath("/");
//                     cookie.setDomain(".darden.com");
//                     logger.info("cookie is reset:"+cookie.getName());
//                     res.addHeader("Set-Cookie", cookie.getName()+"=RESET; expires=Thu, 01-Jan-1970 01:00:00 GMT; path=/;domain=.darden.com");
//                 }
//             }
             
             String[] customCookies =
                 new String[] { 
                                 "krowdmobilesession=RESET; expires=Thu, 01-Jan-1970 01:00:00 GMT; path=/MobileKrowd; HttpOnly",
                                 "_WL_AUTHCOOKIE_krowdmobilesession=RESET; expires=Thu, 01-Jan-1970 01:00:00 GMT; path=/MobileKrowd; HttpOnly",
                                 "krowdmobilesession=RESET; expires=Thu, 01-Jan-1970 01:00:00 GMT; path=/MobileKrowd",
                                 "_WL_AUTHCOOKIE_krowdmobilesession=RESET; expires=Thu, 01-Jan-1970 01:00:00 GMT; path=/MobileKrowd",
                                 "JSESSIONID=RESET; expires=Thu, 01-Jan-1970 01:00:00 GMT; path=/; HttpOnly",
                                 "_WL_AUTHCOOKIE_JSESSIONID=RESET; expires=Thu, 01-Jan-1970 01:00:00 GMT; path=/; HttpOnly",
                                 "JSESSIONID=RESET; expires=Thu, 01-Jan-1970 01:00:00 GMT; path=/",
                                 "_WL_AUTHCOOKIE_JSESSIONID=RESET; expires=Thu, 01-Jan-1970 01:00:00 GMT; path=/",
                                 "JSESSIONID=RESET; expires=Thu, 01-Jan-1970 01:00:00 GMT; path=/webcenter; HttpOnly",
                                 "_WL_AUTHCOOKIE_JSESSIONID=RESET; expires=Thu, 01-Jan-1970 01:00:00 GMT; path=/webcenter; HttpOnly",
                                 "JSESSIONID=RESET; expires=Thu, 01-Jan-1970 01:00:00 GMT; path=/webcenter",
                                 "_WL_AUTHCOOKIE_JSESSIONID=RESET; expires=Thu, 01-Jan-1970 01:00:00 GMT; path=/webcenter",
                                 "JSESSIONID=RESET; expires=Thu, 01-Jan-1970 01:00:00 GMT; path=/rest; HttpOnly",
                                 "_WL_AUTHCOOKIE_JSESSIONID=RESET; expires=Thu, 01-Jan-1970 01:00:00 GMT; path=/rest; HttpOnly",
                                 "JSESSIONID=RESET; expires=Thu, 01-Jan-1970 01:00:00 GMT; path=/rest",
                                 "_WL_AUTHCOOKIE_JSESSIONID=RESET; expires=Thu, 01-Jan-1970 01:00:00 GMT; path=/rest",
                                 "SMSESSION=RESET; expires=Thu, 01-Jan-1970 01:00:00 GMT; path=/;domain=.darden.com",
                                 "ActivateUser=RESET; expires=Thu, 01-Jan-1970 01:00:00 GMT; path=/;domain=.darden.com",
                                 "RedirectHomePage=RESET; expires=Thu, 01-Jan-1970 01:00:00 GMT; path=/;domain=.darden.com"
                              };
             logger.info("Custom Cookies size:"+customCookies.length);
             for (String cookie : customCookies) {
                 res.addHeader("Set-Cookie", cookie);
                 logger.info("Custom cookie is set:"+cookie);
             }
             status = true;
         }
         return Response.ok(status).type(MediaType.APPLICATION_JSON).build();
     }
     
     private void printCookieDetails(Cookie cookie){
         logger.info(cookie.getName()+"###"+cookie.getComment()+"###"+cookie.getDomain()+"###"+cookie.getMaxAge()+"###"+cookie.getPath()+"###"+cookie.getSecure()+"###"+cookie.getVersion()+"###"+cookie.getValue());
     }
    }
