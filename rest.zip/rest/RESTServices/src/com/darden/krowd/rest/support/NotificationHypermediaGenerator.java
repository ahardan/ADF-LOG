package com.darden.krowd.rest.support;

public class NotificationHypermediaGenerator {
    public NotificationHypermediaGenerator() {
        super();
    }
}
