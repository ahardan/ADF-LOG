package com.darden.krowd.rest.support;


import com.darden.krowd.rest.model.MTask;

import com.darden.krowd.rest.model.MTaskAttachment;

import java.io.IOException;

import java.io.InputStream;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import oracle.adf.share.logging.ADFLogger;

import oracle.bpel.services.workflow.IWorkflowConstants;
import oracle.bpel.services.workflow.StaleObjectException;
import oracle.bpel.services.workflow.WorkflowException;
import oracle.bpel.services.workflow.client.IWorkflowServiceClient;
import oracle.bpel.services.workflow.query.ITaskQueryService;
import oracle.bpel.services.workflow.repos.Ordering;
import oracle.bpel.services.workflow.repos.Predicate;
import oracle.bpel.services.workflow.repos.TableConstants;
import oracle.bpel.services.workflow.runtimeconfig.IRuntimeConfigService;
import oracle.bpel.services.workflow.task.ITaskService;
import oracle.bpel.services.workflow.task.model.AttachmentType;
import oracle.bpel.services.workflow.task.model.ObjectFactory;
import oracle.bpel.services.workflow.task.model.Task;
import oracle.bpel.services.workflow.verification.IWorkflowContext;

//import oracle.webcenter.bpel.config.BPELConnectionUtil;
//import oracle.webcenter.bpel.config.ConfigurationException;

import org.springframework.web.multipart.MultipartFile;


public class WorklistService {
//    private static final ADFLogger logger =
//        ADFLogger.createADFLogger(WorklistService.class);
//
//
//    private IRuntimeConfigService runtimeConfigService;
//    private ITaskQueryService taskQueryService;
//    private ITaskService taskService;
//    private IWorkflowContext workflowContext;
//    private IWorkflowServiceClient workflowClient;
//    private String linkUrl;
//    private String name;
//    private String url;
//    private String serverUrl;
//
//    public WorklistService(BPELConnectionUtil connection) {
//        super();
//        runtimeConfigService = connection.getIRuntimeConfigService();
//        taskQueryService = connection.getITaskQueryService();
//        taskService = connection.getITaskService();
//        try {
//            workflowContext = connection.getIWorkflowContext();
//        } catch (ConfigurationException e) {
//            logger.severe("Cannot get Workflow Context.");
//            logger.severe(e);
//        }
//        workflowClient = connection.getIWorkflowServiceClient();
//        linkUrl = connection.getLinkUrl();
//        name = connection.getName();
//        url = connection.getUrl();
//
//        try {
//            serverUrl = runtimeConfigService.getServerURLFromFabricConfig();
//        } catch (WorkflowException e) {
//            logger.severe("Cannot get Server URL.");
//            logger.severe(e);
//        }
//    }
//
//    public String getTaskIdFromTaskNumber(String taskNumber) throws WorkflowException {
//        Task task =
//            taskQueryService.getTaskDetailsByNumber(workflowContext, Integer.parseInt(taskNumber));
//        return task.getSystemAttributes().getTaskId();
//    }
//
//    /**
//        Add an attachment to a task.
//        @param taskNumber The number of the task to add the attachment to.
//        @param attachment The attachment to add to the task.
//     */
//    public void addAttachmentToTask(String taskNumber,
//                                    MultipartFile attachment) throws WorkflowException,
//                                                                     IOException,
//                                                                     StaleObjectException {
//        Task task =
//            taskQueryService.getTaskDetailsByNumber(workflowContext, Integer.parseInt(taskNumber));
//
//        AttachmentType xAttachment = new ObjectFactory().createAttachment();
//        xAttachment.setName(attachment.getOriginalFilename());
//        xAttachment.setInputStream(attachment.getInputStream());
//        xAttachment.setMimeType(attachment.getContentType());
//        xAttachment.setDescription(attachment.getOriginalFilename());
//
//        taskService.addAttachment(workflowContext,
//                                  task.getSystemAttributes().getTaskId(),
//                                  xAttachment);
//    }
//
//    /**
//        Add an attachment to a task.
//        @param taskNumber The number of the task to add the attachment to.
//        @param attachment The attachment to add to the task.
//     */
//    public void addAttachmentToTask(String taskNumber,String fileName,InputStream inputStream,String mimeType,String description) throws WorkflowException,
//                                                                     IOException,
//                                                                     StaleObjectException {
//        Task task =
//            taskQueryService.getTaskDetailsByNumber(workflowContext, Integer.parseInt(taskNumber));
//
//        AttachmentType xAttachment = new ObjectFactory().createAttachment();
//        xAttachment.setName(fileName);
//        xAttachment.setInputStream(inputStream);
//        xAttachment.setMimeType(mimeType);
//        xAttachment.setDescription(description);
//
//        taskService.addAttachment(workflowContext,
//                                  task.getSystemAttributes().getTaskId(),
//                                  xAttachment);
//    }
//    
//    public AttachmentType getAttachmentForTask(String taskNumber,String attachmentId) throws WorkflowException {
//        Task task =taskQueryService.getTaskDetailsByNumber(workflowContext, Integer.parseInt(taskNumber));
//        AttachmentType attType;
//        List attcs = task.getAttachment();
//        String md5;
//        if(attcs !=null){            
//            for(int i=0 ; i<=attcs.size();i++){
//                if(attcs.get(i) !=null && attcs.get(i) instanceof AttachmentType){
//                    attType = (AttachmentType)attcs.get(i);
//                    md5 = MTaskAttachment.getMD5(attType);
//                    if(md5 !=null && md5.compareTo(attachmentId)==0){
//                        return attType;
//                    }
//                }
//            }
//        }
//        return null;
//    }
//
//    /**
//        Add a comment to a task.
//        @param taskNumber The number of the task to add the comment to.
//        @param comment The comment to add to the task.
//     */
//    public void addComment(String taskNumber,
//                           String comment) throws WorkflowException,
//                                                  StaleObjectException {
//        Task task =
//            taskQueryService.getTaskDetailsByNumber(workflowContext, Integer.parseInt(taskNumber));
//        taskService.addComment(workflowContext,
//                               task.getSystemAttributes().getTaskId(),
//                               comment);
//    }
//
//    /**
//        Process a task, i.e.&nbsp;take an action on the task.
//        This method will process a task.  This may mean taking a 'custom' action
//        on the task, i.e. those defined in the Task Definition as the outcomes
//        for the task, or taking a 'system' action, e.g. escalate, suspend,
//        withdraw.
//        The allowed system actions are:
//        <code>SYS_ESCALATE</code>,
//        <code>SYS_WITHDRAW</code>,
//        <code>SYS_SUSPEND</code>,
//        <code>SYS_RESUME</code>,
//        <code>SYS_PURGE</code>,
//        <code>SYS_ERROR</code>,
//        <code>SYS_ACQUIRE</code>.
//        Note that this method will just fail (throw an Exception) if the user
//        does not have the right to take the action.  This needs to be tidied
//        up in a future version.
//        @param taskNumber The number of task to take the action on.
//        @param outcome The action to take on the task.
//     */
//    public void processTask(String taskNumber,
//                            String outcome) throws WorkflowException,
//                                                   StaleObjectException {
//        Task task =
//            taskQueryService.getTaskDetailsByNumber(workflowContext, Integer.parseInt(taskNumber));
//
//        if ("SYS_ESCALATE".compareTo(outcome) == 0) {
//            taskService.escalateTask(workflowContext, task);
//        } else if ("SYS_WITHDRAW".compareTo(outcome) == 0) {
//            taskService.withdrawTask(workflowContext, task);
//        } else if ("SYS_SUSPEND".compareTo(outcome) == 0) {
//            taskService.suspendTask(workflowContext, task);
//        } else if ("SYS_RESUME".compareTo(outcome) == 0) {
//            taskService.resumeTask(workflowContext, task);
//        } else if ("SYS_PURGE".compareTo(outcome) == 0) {
//            taskService.purgeTask(workflowContext, task);
//        } else if ("SYS_ERROR".compareTo(outcome) == 0) {
//            taskService.errorTask(workflowContext, task);
//        } else if ("SYS_ACQUIRE".compareTo(outcome) == 0) {
//            taskService.acquireTask(workflowContext, task);
//        } else {
//            // this is a CustomAction
//            logger.info("TaskList",
//                        "Updating outcome of task " + task.getSystemAttributes().getTaskNumber() +
//                        " to " + outcome);
//            taskService.updateTaskOutcome(workflowContext,
//                                          task.getSystemAttributes().getTaskId(),
//                                          outcome);
//        }
//    }
//    
//    public  List<Task> getTasks(String filter, String state) throws WorkflowException {
//      Predicate predicate = null;
//      return getTasks(filter, state, predicate);
//    }
//
//    /**
//        Get all of the details for a <code>Task</code>.
//        This method will return all of the details for a <code>Task</code>,
//        wrapped in an <code>MTask</code> object.  This method should be
//        used to retrieve a task with all of its details populated, suitable
//        for a task detail View.
//        @param taskNumber The number of the task to retireve.
//        @return The task details, wrapped in an <code>MTask</code>.
//     */
//    public Task getTaskDetails(String taskNumber) throws WorkflowException {
//        logger.info("TaskList", "Entering getTaskDetails()");
//        Task task =
//            taskQueryService.getTaskDetailsByNumber(workflowContext, Integer.parseInt(taskNumber));
//        return task;
//    }
//    
//    public static boolean isNumeric(String str) {
//        if (str == null) {
//            return false;
//        }
//        int sz = str.length();
//        for (int i = 0; i < sz; i++) {
//            if (Character.isDigit(str.charAt(i)) == false) {
//                return false;
//            }
//        }
//        return true;
//    }    
//    
//    public List<Task> queryTasks(int noOfRecords,
//                                 String orderBy,
//                                 String searchString) throws WorkflowException {
//    
//    
//        List<String> queryColumns = new ArrayList<String>();
//    
//        queryColumns.add(TableConstants.WFTASK_TITLE_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_PRIORITY_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_OUTCOME_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_STATE_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_SUBSTATE_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_ACQUIREDBY_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_TASKID_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_TASKNUMBER_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_PROCESSNAME_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_PROCESSID_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_INSTANCEID_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_PROCESSVERSION_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_IDENTIFICATIONKEY_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_ASSIGNEEGROUPS_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_ASSIGNEEUSERS_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_EXPIRATIONDATE_COLUMN.getName());
//
//    
//        // specific "text string" columns
//        queryColumns.add(TableConstants.WFTASK_TEXTATTRIBUTE1_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_TEXTATTRIBUTE2_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_TEXTATTRIBUTE3_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_TEXTATTRIBUTE4_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_URLATTRIBUTE1_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_URLATTRIBUTE2_COLUMN.getName());
//    
//    
//        // Correct state
//        List<String> correctStates = new ArrayList<String>();
//    
//        correctStates.add(IWorkflowConstants.TASK_STATE_ALERTED);
//        correctStates.add(IWorkflowConstants.TASK_STATE_ASSIGNED);
//        correctStates.add(IWorkflowConstants.TASK_STATE_INFO_REQUESTED);
//        correctStates.add(IWorkflowConstants.TASK_STATE_OUTCOME_UPDATED);
//    
//        
//    
//        // only these states 
//        Predicate predicateBasic =
//           new Predicate(TableConstants.WFTASK_STATE_COLUMN, 
//                         Predicate.OP_IN,
//                         correctStates);
//        // not stale tasks
//        predicateBasic.addClause(Predicate.AND,
//                            TableConstants.WFTASK_STATE_COLUMN,
//                            Predicate.OP_NEQ,
//                            IWorkflowConstants.TASK_STATE_STALE);
//       
//        Predicate predicateSearch = null;
//        if ( searchString != null && !"".equals(searchString) ) {
//            
//            
//           predicateSearch = new Predicate(TableConstants.WFTASK_TEXTATTRIBUTE1_COLUMN,
//                                           Predicate.OP_CONTAINS,
//                                           searchString);
//           predicateSearch.addClause(Predicate.OR,
//                               TableConstants.WFTASK_TEXTATTRIBUTE2_COLUMN,
//                               Predicate.OP_CONTAINS,
//                               searchString);
//           predicateSearch.addClause(Predicate.OR,
//                               TableConstants.WFTASK_TEXTATTRIBUTE3_COLUMN,
//                               Predicate.OP_CONTAINS,
//                               searchString);
//           if ( isNumeric(searchString) ){  
//              predicateSearch.addClause(Predicate.OR,
//                                        TableConstants.WFTASK_TASKNUMBER_COLUMN,
//                                        Predicate.OP_EQ,
//                                        searchString);
//           }
//         }
//        
//        Predicate predicate = null;
//        if ( predicateSearch == null ) {
//          predicate = predicateBasic; 
//        } else {
//          predicate = new Predicate (predicateBasic,Predicate.AND,predicateSearch);
//        }
//          
//        
//        // Ordering
//        Ordering taskOrdering = null;
//        logger.info("set the default Priority / EscalationDate Ordering");
//        if ( "PRIO".equalsIgnoreCase(orderBy) ) {
//           taskOrdering = new Ordering(TableConstants.WFTASK_PRIORITY_COLUMN, true,false); 
//           taskOrdering.addClause(TableConstants.WFTASK_TASKNUMBER_COLUMN, true,false);
//        } else if  ("ID".equalsIgnoreCase(orderBy) ) { 
//           taskOrdering = new Ordering(TableConstants.WFTASK_TASKNUMBER_COLUMN, false,true);
//        } else if ("ESC_DESC".equalsIgnoreCase(orderBy)  ) {
//            taskOrdering = new Ordering(TableConstants.WFTASK_EXPIRATIONDATE_COLUMN, false, false);
//        }  else if ("ESC_ASC".equalsIgnoreCase(orderBy) ) {
//            taskOrdering = new Ordering(TableConstants.WFTASK_EXPIRATIONDATE_COLUMN, true, false);
//        } else if ("CRE_DESC".equalsIgnoreCase(orderBy)  ) {
//              taskOrdering = new Ordering(TableConstants.WFTASK_CREATEDDATE_COLUMN, false, false);
//        }  else if ("CRE_ASC".equalsIgnoreCase(orderBy) ) {
//              taskOrdering = new Ordering(TableConstants.WFTASK_CREATEDDATE_COLUMN, true, false);
//        } 
//    
//        List<ITaskQueryService.OptionalInfo> optionalInfo = new ArrayList<ITaskQueryService.OptionalInfo>();
//        optionalInfo.add(ITaskQueryService.OptionalInfo.CUSTOM_ACTIONS);
//        optionalInfo.add(ITaskQueryService.OptionalInfo.COMMENTS);
//        optionalInfo.add(ITaskQueryService.OptionalInfo.PAYLOAD);
//        optionalInfo.add(ITaskQueryService.OptionalInfo.DISPLAY_INFO);
//    
//        List<Task> tasks =
//            taskQueryService.queryTasks(workflowContext, 
//                                             queryColumns,
//                                             optionalInfo,
//                                             ITaskQueryService.AssignmentFilter.MY_AND_GROUP,
//                                             null, 
//                                             predicate, 
//                                             taskOrdering,
//                                             0,
//                                             noOfRecords);
//    
//        logger.info("[EINDE] queryTasks()");    
//        
//        return tasks;
//    }    
//    
//    public static List<MTask> toMTasks(List<Task> tasks){
//        // iterate over tasks and build return data
//        List result = new ArrayList<MTask>();
//        if(tasks !=null){
//            for (int i = 0; i < tasks.size(); i++) {
//                Task task = (Task)tasks.get(i);
//                result.add(new MTask(task.getSystemAttributes().getTaskNumber(),notNull(task.getSystemAttributes().getTaskId()),
//                                     notNull(task.getTitle()),
//                                     notNull(task.getSystemAttributes().getOutcome()),
//                                     task.getPriority(),
//                                     notNull(task.getSystemAttributes().getState())));
//            }
//
//            // sort the list by priority
//            Collections.sort(result, new MTaskComparator());
//        }        
//        return result;           
//    }
//
//    public List<Task> getTasks(String filter, String state,
//                                  Predicate predicate) throws WorkflowException {
//
//        logger.info("MTaskList", "Entering getMTasks()");
//        List<String> queryColumns = new ArrayList<String>();
//        List<Task> tasks;
//
//            if (filter == null)
//                filter = "megroup";
//            if (state == null)
//                state = "any";
//
//            logger.info("MTaskList", "Got context... " + workflowContext);
//
//        queryColumns.add(TableConstants.WFTASK_TITLE_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_PRIORITY_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_OUTCOME_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_STATE_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_SUBSTATE_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_ACQUIREDBY_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_TASKID_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_TASKNUMBER_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_PROCESSNAME_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_PROCESSID_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_INSTANCEID_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_PROCESSVERSION_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_IDENTIFICATIONKEY_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_ASSIGNEEGROUPS_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_ASSIGNEEUSERS_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_EXPIRATIONDATE_COLUMN.getName());
//        
//        // specific "text string" columns
//        queryColumns.add(TableConstants.WFTASK_TEXTATTRIBUTE1_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_TEXTATTRIBUTE2_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_TEXTATTRIBUTE3_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_TEXTATTRIBUTE4_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_URLATTRIBUTE1_COLUMN.getName());
//        queryColumns.add(TableConstants.WFTASK_URLATTRIBUTE2_COLUMN.getName());            
//
//            Predicate pred;
//            if (predicate == null) {
//                // build predicate
//                pred =new Predicate(TableConstants.WFTASK_STATE_COLUMN, Predicate.OP_EQ,IWorkflowConstants.TASK_STATE_ASSIGNED);
//                if ("any".compareTo(state) == 0) {
//                    pred = null;
//                } else if ("completed".compareTo(state) == 0) {
//                    pred =new Predicate(TableConstants.WFTASK_STATE_COLUMN, Predicate.OP_EQ,IWorkflowConstants.TASK_STATE_COMPLETED);
//                } else if ("suspended".compareTo(state) == 0) {
//                    pred =new Predicate(TableConstants.WFTASK_STATE_COLUMN, Predicate.OP_EQ,IWorkflowConstants.TASK_STATE_SUSPENDED);
//                } else if ("withdrawn".compareTo(state) == 0) {
//                    pred =new Predicate(TableConstants.WFTASK_STATE_COLUMN, Predicate.OP_EQ,IWorkflowConstants.TASK_STATE_WITHDRAWN);
//                } else if ("expired".compareTo(state) == 0) {
//                    pred =new Predicate(TableConstants.WFTASK_STATE_COLUMN, Predicate.OP_EQ,IWorkflowConstants.TASK_STATE_EXPIRED);
//                } else if ("errored".compareTo(state) == 0) {
//                    pred =new Predicate(TableConstants.WFTASK_STATE_COLUMN, Predicate.OP_EQ,IWorkflowConstants.TASK_STATE_ERRORED);
//                } else if ("alerted".compareTo(state) == 0) {
//                    pred =new Predicate(TableConstants.WFTASK_STATE_COLUMN, Predicate.OP_EQ,IWorkflowConstants.TASK_STATE_ALERTED);
//                } else if ("info".compareTo(state) == 0) {
//                    pred =new Predicate(TableConstants.WFTASK_STATE_COLUMN, Predicate.OP_EQ,IWorkflowConstants.TASK_STATE_INFO_REQUESTED);
//                }
//            } else {
//                // predicate was provided
//                pred = predicate;
//            }
//
//            // set assignment filter
//            ITaskQueryService.AssignmentFilter aFilter =
//                ITaskQueryService.AssignmentFilter.MY_AND_GROUP;
//            if ("me".compareTo(filter) == 0) {
//                aFilter = ITaskQueryService.AssignmentFilter.MY;
//            } else if ("group".compareTo(filter) == 0) {
//                aFilter = ITaskQueryService.AssignmentFilter.GROUP;
//            } else if ("megroup".compareTo(filter) == 0) {
//                aFilter = ITaskQueryService.AssignmentFilter.MY_AND_GROUP;
//            } else if ("previous".compareTo(filter) == 0) {
//                aFilter = ITaskQueryService.AssignmentFilter.PREVIOUS;
//            } else if ("reviewer".compareTo(filter) == 0) {
//                aFilter = ITaskQueryService.AssignmentFilter.REVIEWER;
//            }
//
//            // get list of tasks
//            logger.info("MTaskList", "About to queryTasks()");
//            boolean moreTasks = true;
//            tasks = new ArrayList<Task>();
//            int start = 1;
//            int end = 200;
//            while (moreTasks) {
//                List someTasks =
//                    taskQueryService.queryTasks(workflowContext, queryColumns, null,
//                                                // additional info
//                        aFilter, // asssignment filter
//                        null, // keywords
//                        pred, // custom predicate
//                        null, // order
//                        start, // paging - start
//                        end); // paging - end
//                tasks.addAll(someTasks);
//                if (someTasks.size() < 200) {
//                    moreTasks = false;
//                } else {
//                    start += 200;
//                    end += 200;
//                }
//            }
//            
//            return tasks;
//
//    }
//
//    /**
//        Utility method to ensure that a <code>String</code> is not <code>null</code>.
//        @param input The <code>String</code> that you wish to ensure is not <code>null</code>.
//        @return A <code>String</code> equivalent to the input, except that it is guaranteed to
//        be not <code>null</code>.
//     */
//    private static String notNull(String input) {
//        if (input == null)
//            return "";
//        return input;
//    }


}
