package com.darden.krowd.rest.services;


import com.darden.krowd.rest.exceptions.BadRequestException;

import com.sun.jersey.core.header.FormDataContentDisposition;
import com.sun.jersey.multipart.FormDataParam;

import groovy.lang.GroovyClassLoader;
import groovy.lang.GroovyObject;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Reader;

import java.lang.reflect.Method;
import java.lang.reflect.Type;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;

import oracle.mds.core.ConcurrentMOChangeException;
import oracle.mds.core.IsolationLevel;
import oracle.mds.core.MDSInstance;
import oracle.mds.core.MDSSession;
import oracle.mds.core.SessionOptions;
import oracle.mds.core.ValidationException;
import oracle.mds.naming.DocumentName;
import oracle.mds.naming.InvalidReferenceException;
import oracle.mds.naming.InvalidReferenceTypeException;
import oracle.mds.persistence.MDSIOException;
import oracle.mds.persistence.PContext;
import oracle.mds.persistence.PDocument;
import oracle.mds.persistence.PManager;

import oracle.webcenter.content.integration.cache.Cache;

import oracle.webcenter.content.integration.cache.CacheFactory;

import oracle.webcenter.jaxrs.framework.service.RestService;
import oracle.webcenter.jaxrs.framework.uri.UriService;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import org.xml.sax.InputSource;
import org.apache.commons.codec.binary.Base64;


@Path("/dyn")
public class DynamicResource {
    @RestService
    protected UriService uriService;
    private GroovyClassLoader groovyClassLoader;
    private CacheFactory cacheFactory;

    @Context private HttpServletRequest httpRequest;
    private static final ADFLogger logger = ADFLogger.createADFLogger(DynamicResource.class);
    
    private MDSInstance mdsInstance;
    
    private static final String BASE_PATH="/oracle/apps/meta/groovy/";
    
    private Cache appCache;
    
    public DynamicResource() {
        super();
    }
    private MDSInstance getMDSInstance(){
        if(mdsInstance == null){
            try {
                mdsInstance = (MDSInstance)ADFContext.getCurrent().getMDSInstanceAsObject();
            } catch (Exception e) {
                logger.severe(e);
            }
        }
        return mdsInstance;
    }
    
    private CacheFactory getCacheFactory(){
        if(cacheFactory==null)
            cacheFactory = CacheFactory.getInstance("content");
        return cacheFactory;
    }
        
    
    private Cache getAppCache(){
        if(appCache == null){
            appCache = getCacheFactory().getCache("com.darden.krowd.contentQueryCache");
        }
        return appCache;
    }
    
    private Object getFromCache(String key){
        if(key == null){
            return null;
        }else{
            Cache cache=getAppCache();

            if(cache == null){
                return null;
            }else{
                String base64 = (String)cache.get(key);
                if(base64 == null){
                    return null;
                }else{
                    byte[] bytes = null;
                    Object object = null;
                    bytes = Base64.decodeBase64(base64.getBytes());                    
                    if(bytes != null && bytes.length>0){
                        ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
                        ObjectInputStream in = null;                        
                        try {
                            in = new ObjectInputStream(bis);
                            object = in.readObject();      
                        } catch (IOException e) {
                            logger.severe("----- Unable to convert base64 to object IOException ------------");
                            logger.severe(base64);
                            logger.severe(e);                                                    
                        } catch (ClassNotFoundException e) {
                            logger.severe("----- Unable to convert base64 to object Class not found ------------");
                            logger.severe(base64);
                            logger.severe(e);                                                                                
                            } finally{                            
                                try {
                                  if (in != null) {
                                    in.close();
                                  }
                                } catch (IOException ex) {
                                  // ignore close exception
                                }                                                            
                                
                                try {
                                  if (bis != null) {
                                    bis.close();
                                  }
                                } catch (IOException ex) {
                                  // ignore close exception
                                }                                                            
                                
                            }
                    }
                    
                    return object;
                }
            }
        }
    }
    
    private void putInCache(String key, Object object){        
        if(key != null && object != null){
            Cache cache = getAppCache();

            if(cache !=  null){
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                ObjectOutputStream out = null;

                try {
                    out = new ObjectOutputStream(bos);
                    out.writeObject(object);
                    out.flush();
                    byte[] bytes = bos.toByteArray();
                    if(bytes != null && bytes.length>0){
                        bytes = Base64.encodeBase64(bytes); 
                        String base64 = new String(bytes);    
                        cache.put(key,base64);
                    }
                } catch (IOException e) {
                        logger.severe("----- Unable to serialize object ------------");
                        logger.severe(e);                                                                        
                    }finally{
                    
                        try {
                          bos.close();
                        } catch (IOException ex) {
                          // ignore close exception
                        }                        
                        
                        try {
                          out.close();
                        } catch (IOException ex) {
                          // ignore close exception
                        }                        
                        
                    }
            }
        }
    }
        
    
    private byte[] getDocumentByPath(MDSInstance mdsInstance,String documentFullPathInMDS) throws IOException,
                                                                          MDSIOException,
                                                                          ConcurrentMOChangeException,
                                                                          ValidationException,
                                                                          InvalidReferenceException,
                                                                          InvalidReferenceTypeException {
        DocumentName docName = DocumentName.create(documentFullPathInMDS);
        MDSSession session = mdsInstance.createSession(new SessionOptions(IsolationLevel.READ_COMMITTED, null, null), null);
        PManager pManager = mdsInstance.getPersistenceManager();
        PContext pContext = session.getPContext();        
        PDocument pdocument = pManager.getDocument(pContext, docName);
        InputSource source = null;
        byte[] bytes = null;
        
        if(pdocument == null){
            return bytes;
        }
        
        try {
            source = pdocument.read();
            Reader reader = source.getCharacterStream(); // Text files
            if (reader != null) {
                StringBuffer sb = new StringBuffer();
                BufferedReader br = new BufferedReader(reader);
                String line = "";
                boolean go = true;
                try{
                    while (go) {
                        line = br.readLine();
                        if (line == null)
                            go = false;
                        else
                            sb.append(line + "\n");
                    }                    
                    bytes = sb.toString().getBytes();                    
                }catch(IOException e){
                    throw e;
                }finally{
                    br.close();
                }
            }else{
                InputStream is = source.getByteStream();
                try {
                    int offset = 0;
                    int numRead = 0;
                    while (offset < bytes.length &&(numRead = is.read(bytes, offset,bytes.length - offset)) >= 0)
                        offset += numRead;
                    byte[] temp = new byte[offset];
                    for (int i = 0; i < offset; i++)
                        temp[i] = bytes[i];
                    bytes = temp;
                } catch (IOException ex) {
                    throw ex;
                } finally {
                    is.close();
                }                
            }            
        } catch (MDSIOException e) {
            throw e;
        }finally{
            session.flushChanges();
        }        
        return bytes;
    }    
    
    private String getScriptFromDocument(byte[] bytes){
        String ret = null;
        
        if(bytes == null)
            return ret;
        
        try{
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            
            //subh, CWE ID: 611 - Improper Restriction of XML External Entity Reference
            //dbFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            //dbFactory.setFeature("http://xml.org/sax/features/external-general-entities", false);
            //dbFactory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
            //
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();                    
            Document doc = dBuilder.parse(new ByteArrayInputStream(bytes));
            doc.getDocumentElement().normalize();            

            NodeList nodeList = doc.getElementsByTagName("script");
            if(nodeList != null && nodeList.getLength() >0){
                Node node = nodeList.item(0);
                nodeList = node.getChildNodes();
                for(int i=0;i<nodeList.getLength();i++){
                    node = nodeList.item(i);
                    if(node.getNodeType() == Node.CDATA_SECTION_NODE){
                        if(ret == null){
                            ret = node.getTextContent();
                        }else{
                            ret = ret + node.getTextContent();    
                        }                        
                    }
                }           
            }
            logger.info("----------------Groovy Script-----------------");
            logger.info(ret);
        }catch(Exception e){
            logger.severe(e);
        }
        return ret;
    }
        
    
    private GroovyClassLoader getGroovyClassLoader(){
        if(this.groovyClassLoader == null){
            ClassLoader currentLoader = getClass().getClassLoader();
            this.groovyClassLoader = new GroovyClassLoader(currentLoader);
        }
        return this.groovyClassLoader;
    }
    
    private Class getClass(String canonicalName){
        GroovyClassLoader classLoader = getGroovyClassLoader();
        Class[] loadedClasses = classLoader.getLoadedClasses();
        Class loadedClass;
        Class ret= null;
        for(int i=0;i<loadedClasses.length;i++){
            loadedClass = loadedClasses[i];
            if(loadedClass.getCanonicalName().compareTo(canonicalName)==0) {
                ret=loadedClass;
                break;
            }
        }
        return ret;
    }

    private void debugInfo(Class c) {
        Method[] allMethods = c.getDeclaredMethods();
        for (Method m : allMethods) {

            logger.info(m.toGenericString());

            logger.info("ReturnType " + m.getReturnType());
            logger.info("GenericReturnType" + m.getGenericReturnType());

            Class<?>[] pType = m.getParameterTypes();
            Type[] gpType = m.getGenericParameterTypes();
            for (int i = 0; i < pType.length; i++) {
                logger.info("ParameterType" + pType[i]);
                logger.info("GenericParameterType" + gpType[i]);
            }
        }
    }

    private Response execute(String httpOp, String scriptPath,Object data,boolean cache) throws IOException,
                                                     MDSIOException,
                                                     ConcurrentMOChangeException,
                                                     ValidationException,
                                                     InvalidReferenceException,
                                                     InvalidReferenceTypeException,
                                                     InstantiationException,
                                                     IllegalAccessException {
        GroovyClassLoader classLoader = getGroovyClassLoader(); 
        logger.info("Requesting script "+scriptPath);
        scriptPath = BASE_PATH+scriptPath+".xml";     
        
        Map<String,String> mapping = (Map<String,String>)(cache?getFromCache(scriptPath):null);
        
        String script = null;
        Class groovy = null;
        String classCanonicalName = null;
        if(mapping == null){            
            byte[] bytes = getDocumentByPath(getMDSInstance(),scriptPath);
            if(bytes == null)
                return Response.status(Response.Status.BAD_REQUEST).build();            
            logger.info("-----------Retried MDS Document ---------------");            
            script = getScriptFromDocument(bytes);
            groovy = classLoader.parseClass(script);
            classCanonicalName = groovy.getCanonicalName();
            logger.info("---------- Groovy Class ----------"+classCanonicalName);
            //debugInfo(groovy);
            mapping = new HashMap<String,String>();
            mapping.put("script",script);
            mapping.put("canonicalName", classCanonicalName);
            putInCache(scriptPath,mapping);
        }else{
            logger.info("----------- Cached Object found -------------");
            script = mapping.get("script");
            classCanonicalName = mapping.get("canonicalName");
            groovy = getClass(classCanonicalName);
            if(groovy == null){
                logger.info("------- No loaded class found ------------");
                groovy = classLoader.parseClass(script);
            }
        }
      
        GroovyObject groovyObj = (GroovyObject) groovy.newInstance();
        
        logger.info("----------- Invoking operation --------"+httpOp);
        if(httpOp.compareToIgnoreCase("POST")==0){
            return (Response) groovyObj.invokeMethod("doPost", new Object[] {uriService,data});              
        }else if(httpOp.compareToIgnoreCase("PUT")==0){
            return (Response) groovyObj.invokeMethod("doPut", new Object[] {uriService,data});              
        }else{
            return Response.status(Response.Status.BAD_REQUEST).build();
        }
    }    
    
    private Response execute(String httpOp, String scriptPath,boolean cache) throws IOException,
                                                     MDSIOException,
                                                     ConcurrentMOChangeException,
                                                     ValidationException,
                                                     InvalidReferenceException,
                                                     InvalidReferenceTypeException,
                                                     InstantiationException,
                                                     IllegalAccessException {
        GroovyClassLoader classLoader = getGroovyClassLoader(); 
        logger.info("Requesting script "+scriptPath);
        scriptPath = BASE_PATH+scriptPath+".xml";     

        Map<String,String> mapping = (Map<String,String>)(cache?getFromCache(scriptPath):null);
        
        String script = null;
        Class groovy = null;
        String classCanonicalName = null;
        if(mapping == null){            
            byte[] bytes = getDocumentByPath(getMDSInstance(),scriptPath);
            if(bytes == null)
                return Response.status(Response.Status.BAD_REQUEST).build();            
            logger.info("-----------Retried MDS Document ---------------");            
            script = getScriptFromDocument(bytes);
            groovy = classLoader.parseClass(script);
            classCanonicalName = groovy.getCanonicalName();
            logger.info("---------- Groovy Class ----------"+classCanonicalName);
            //debugInfo(groovy);
            mapping = new HashMap<String,String>();
            mapping.put("script",script);
            mapping.put("canonicalName", classCanonicalName);
            putInCache(scriptPath,mapping);
        }else{
            logger.info("----------- Cached Object found -------------");
            script = mapping.get("script");
            classCanonicalName = mapping.get("canonicalName");
            groovy = getClass(classCanonicalName);
            if(groovy == null){
                logger.info("------- No loaded class found ------------");
                groovy = classLoader.parseClass(script);
            }
        }        

        GroovyObject groovyObj = (GroovyObject) groovy.newInstance();
        
        logger.info("----------- Invoking operation --------"+httpOp);
        if(httpOp.compareToIgnoreCase("GET")==0){
            return (Response) groovyObj.invokeMethod("doGet", new Object[] {uriService});              
        }else if(httpOp.compareToIgnoreCase("DELETE")==0){
            return (Response) groovyObj.invokeMethod("doDelete", new Object[] {uriService});              
        }else{
            return Response.status(Response.Status.BAD_REQUEST).build();
        }        
    }

    private Response execute(String httpOp, String scriptPath, InputStream file,FormDataContentDisposition fileDetail,boolean cache ) throws IOException,
                                                     MDSIOException,
                                                     ConcurrentMOChangeException,
                                                     ValidationException,
                                                     InvalidReferenceException,
                                                     InvalidReferenceTypeException,
                                                     InstantiationException,
                                                     IllegalAccessException {
        GroovyClassLoader classLoader = getGroovyClassLoader(); 
        logger.info("Requesting script "+scriptPath);
        scriptPath = BASE_PATH+scriptPath+".xml";     
        
        Map<String,String> mapping = (Map<String,String>)(cache?getFromCache(scriptPath):null);
        
        String script = null;
        Class groovy = null;
        String classCanonicalName = null;
        if(mapping == null){            
            byte[] bytes = getDocumentByPath(getMDSInstance(),scriptPath);
            if(bytes == null)
                return Response.status(Response.Status.BAD_REQUEST).build();            
            logger.info("-----------Retried MDS Document ---------------");            
            script = getScriptFromDocument(bytes);
            groovy = classLoader.parseClass(script);
            classCanonicalName = groovy.getCanonicalName();
            logger.info("---------- Groovy Class ----------"+classCanonicalName);
            //debugInfo(groovy);
            mapping = new HashMap<String,String>();
            mapping.put("script",script);
            mapping.put("canonicalName", classCanonicalName);
            putInCache(scriptPath,mapping);
        }else{
            logger.info("----------- Cached Object found -------------");
            script = mapping.get("script");
            classCanonicalName = mapping.get("canonicalName");
            groovy = getClass(classCanonicalName);
            if(groovy == null){
                logger.info("------- No loaded class found ------------");
                groovy = classLoader.parseClass(script);
            }
        }
        
        GroovyObject groovyObj = (GroovyObject) groovy.newInstance();
        
        logger.info("----------- Invoking operation --------"+httpOp);
        if(httpOp.compareToIgnoreCase("POST")==0){
            return (Response) groovyObj.invokeMethod("doPost", new Object[] {uriService,file,fileDetail});              
        }else if(httpOp.compareToIgnoreCase("PUT")==0){
            return (Response) groovyObj.invokeMethod("doPut", new Object[] {uriService,file,fileDetail});              
        }else{
            return Response.status(Response.Status.BAD_REQUEST).build();
        }        
    }
    
    
    @GET
    @Path("/{mdsDocPath : .+}")
    @Produces(MediaType.WILDCARD) 
    public Response testGroovyGet(@Context UriInfo uriInfo,@PathParam("mdsDocPath") String documentPath,@QueryParam("cache") @DefaultValue("true") boolean cache){    
        try{
            return execute("GET", documentPath,cache);
        } catch (IOException e) {
            logger.severe(e);
            throw new BadRequestException(e);            
        } catch (InstantiationException e) {
            logger.severe(e);
            throw new BadRequestException(e);            
        } catch (IllegalAccessException e) {
            logger.severe(e);
            throw new BadRequestException(e);            
        } catch (MDSIOException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (ConcurrentMOChangeException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (ValidationException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (InvalidReferenceException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (InvalidReferenceTypeException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        }
    }    
    
    
    @POST
    @Path("/{mdsDocPath : .+}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.WILDCARD)    
    public Response testGroovyPost(@Context UriInfo uriInfo,@PathParam("mdsDocPath") String documentPath, Map postData,@QueryParam("cache") @DefaultValue("true") boolean cache){
        try{
            return execute("POST", documentPath, postData,cache);
        } catch (IOException e) {
            logger.severe(e);
            throw new BadRequestException(e);            
        } catch (InstantiationException e) {
            logger.severe(e);
            throw new BadRequestException(e);            
        } catch (IllegalAccessException e) {
            logger.severe(e);
            throw new BadRequestException(e);            
        } catch (MDSIOException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (ConcurrentMOChangeException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (ValidationException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (InvalidReferenceException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (InvalidReferenceTypeException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        }
    }       
    
    @POST
    @Path("/{mdsDocPath : .+}")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.WILDCARD)       
    public Response testGroovyUpload(@Context UriInfo uriInfo,@PathParam("mdsDocPath") String documentPath,@QueryParam("cache") @DefaultValue("true") boolean cache,
    @FormDataParam("file") InputStream uploadedInputStream,
    @FormDataParam("file") FormDataContentDisposition fileDetail){
        try{
            return execute("POST", documentPath, uploadedInputStream,fileDetail,cache);
        } catch (IOException e) {
            logger.severe(e);
            throw new BadRequestException(e);            
        } catch (InstantiationException e) {
            logger.severe(e);
            throw new BadRequestException(e);            
        } catch (IllegalAccessException e) {
            logger.severe(e);
            throw new BadRequestException(e);            
        } catch (MDSIOException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (ConcurrentMOChangeException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (ValidationException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (InvalidReferenceException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (InvalidReferenceTypeException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        }
    }           
    
    @POST
    @Path("/{mdsDocPath : .+}")
    @Produces(MediaType.WILDCARD)     
    public Response testGroovyPostAll(@Context UriInfo uriInfo,@QueryParam("cache") @DefaultValue("true") boolean cache,@PathParam("mdsDocPath") String documentPath,String data){
        try{
            return execute("POST", documentPath, data,cache);
        } catch (IOException e) {
            logger.severe(e);
            throw new BadRequestException(e);            
        } catch (InstantiationException e) {
            logger.severe(e);
            throw new BadRequestException(e);            
        } catch (IllegalAccessException e) {
            logger.severe(e);
            throw new BadRequestException(e);            
        } catch (MDSIOException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (ConcurrentMOChangeException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (ValidationException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (InvalidReferenceException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (InvalidReferenceTypeException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        }
    }           

    @PUT
    @Path("/{mdsDocPath : .+}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.WILDCARD)    
    public Response testGroovyPut(@Context UriInfo uriInfo,@QueryParam("cache") @DefaultValue("true") boolean cache,@PathParam("mdsDocPath") String documentPath, Map postData){
        try{
            return execute("PUT", documentPath, postData,cache);
        } catch (IOException e) {
            logger.severe(e);
            throw new BadRequestException(e);            
        } catch (InstantiationException e) {
            logger.severe(e);
            throw new BadRequestException(e);            
        } catch (IllegalAccessException e) {
            logger.severe(e);
            throw new BadRequestException(e);            
        } catch (MDSIOException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (ConcurrentMOChangeException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (ValidationException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (InvalidReferenceException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (InvalidReferenceTypeException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        }
    }       
    
    @PUT
    @Path("/{mdsDocPath : .+}")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.WILDCARD)       
    public Response testGroovyPutUpload(@Context UriInfo uriInfo,@QueryParam("cache") @DefaultValue("true") boolean cache,@PathParam("mdsDocPath") String documentPath,
    @FormDataParam("file") InputStream uploadedInputStream,
    @FormDataParam("file") FormDataContentDisposition fileDetail){
        try{
            return execute("PUT", documentPath, uploadedInputStream,fileDetail,cache);
        } catch (IOException e) {
            logger.severe(e);
            throw new BadRequestException(e);            
        } catch (InstantiationException e) {
            logger.severe(e);
            throw new BadRequestException(e);            
        } catch (IllegalAccessException e) {
            logger.severe(e);
            throw new BadRequestException(e);            
        } catch (MDSIOException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (ConcurrentMOChangeException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (ValidationException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (InvalidReferenceException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (InvalidReferenceTypeException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        }
    }           
    
    @PUT
    @Path("/{mdsDocPath : .+}")
    @Produces(MediaType.WILDCARD)     
    public Response testGroovyPutAll(@Context UriInfo uriInfo,@QueryParam("cache") @DefaultValue("true") boolean cache,@PathParam("mdsDocPath") String documentPath,String data){
        try{
            return execute("PUT", documentPath, data,cache);
        } catch (IOException e) {
            logger.severe(e);
            throw new BadRequestException(e);            
        } catch (InstantiationException e) {
            logger.severe(e);
            throw new BadRequestException(e);            
        } catch (IllegalAccessException e) {
            logger.severe(e);
            throw new BadRequestException(e);            
        } catch (MDSIOException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (ConcurrentMOChangeException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (ValidationException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (InvalidReferenceException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (InvalidReferenceTypeException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        }
    }   
    
    @DELETE
    @Path("/{mdsDocPath : .+}")
    @Produces(MediaType.WILDCARD)   
    public Response testGroovyDelete(@Context UriInfo uriInfo,@QueryParam("cache") @DefaultValue("true") boolean cache,@PathParam("mdsDocPath") String documentPath){
        try{
            return execute("DELETE", documentPath,cache);
        } catch (IOException e) {
            logger.severe(e);
            throw new BadRequestException(e);            
        } catch (InstantiationException e) {
            logger.severe(e);
            throw new BadRequestException(e);            
        } catch (IllegalAccessException e) {
            logger.severe(e);
            throw new BadRequestException(e);            
        } catch (MDSIOException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (ConcurrentMOChangeException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (ValidationException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (InvalidReferenceException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        } catch (InvalidReferenceTypeException e) {
            logger.severe(e);
            throw new BadRequestException(e);              
        }
    }     
}
