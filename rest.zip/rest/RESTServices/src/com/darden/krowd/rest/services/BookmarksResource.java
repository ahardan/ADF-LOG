package com.darden.krowd.rest.services;

import com.darden.krowd.RIDCCommon.util.UCMUtil;
import com.darden.krowd.common.model.applicationModule.common.UserProfileAM;
import com.darden.krowd.rest.config.CacheAnnotations;
import com.darden.krowd.rest.exceptions.BadRequestException;
import com.darden.krowd.rest.model.Bookmark;
import com.darden.krowd.rest.support.MessagesHypermediaGenerator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;

import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;

import javax.ws.rs.core.Response;

import oracle.adf.model.BindingContext;
import oracle.adf.model.DataControlFrame;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;

import oracle.jbo.Row;
import oracle.jbo.RowIterator;
import oracle.jbo.RowSet;

import oracle.jbo.domain.Number;

import oracle.webcenter.jaxrs.framework.service.RestService;
import com.darden.krowd.framework.PersonReference;
import oracle.webcenter.jaxrs.framework.uri.UriService;

@Path("/bookmarks")
@Produces("application/json")
public class BookmarksResource {
    
    @Context private HttpServletRequest httpRequest;
    private static final ADFLogger logger = ADFLogger.createADFLogger(PeopleResource.class);
    
    private static String PAGE_DEF = "com_darden_krowd_rest_pageDefs_RestPageDef";    
    private static String DATACONTROL = "UserProfileAMDataControl";

    @RestService
    protected UriService uriService;
    
    private static ArrayList<String> PERSON_REF_ATTRIBUTES = new ArrayList<String>() {{
    }};    

    public BookmarksResource() {
        super();
    }
    
    private UserProfileAM getUserProfileAM(){
        BindingContext bindingContext = BindingContext.getCurrent();
        UserProfileAM am =null;
        DCDataControl dc = null; 
        if(bindingContext !=null){
            String dcFrameName = bindingContext.getCurrentDataControlFrame();
            DataControlFrame dcframe = dcFrameName == null? null : bindingContext.findDataControlFrame(dcFrameName);
            dc = dcframe == null ? null : dcframe.findDataControl(DATACONTROL);        
            dc = dc == null ? bindingContext.findDataControl(DATACONTROL) : dc;
            
            if(dc == null){
               DCBindingContainer amx = bindingContext.findBindingContainer(PAGE_DEF);
                dc = amx.findDataControl(DATACONTROL); 
                am = (UserProfileAM)dc.getDataProvider();
            }else{
                am = (UserProfileAM)dc.getDataProvider();
            }
        }
        return am;
    }     
    
    private  Map<String,Object> toMap(Row row,boolean expandRs){
        
        if(row == null)
            return null;
        
        String[] attrs = row.getAttributeNames();
        Map map = new HashMap<String,Object>();
        Object val;
        for(String attributeName : attrs){
           val = row.getAttribute(attributeName);           
           if(val instanceof oracle.jbo.RowSet) {
               if(expandRs){
                   RowSet rwSet = (RowSet)val;
                   ArrayList<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
                   while(rwSet.hasNext()){
                       list.add(toMap(rwSet.next(),expandRs));
                   }
                    map.put(attributeName,list);
                    map.put("has"+attributeName,list.size()==0?false:true);
               }else{
                   map.put(attributeName,null);
               }
           }else{
               //PersonReference.GetPersonByGuid(comment.getAuthorId())
               if(PERSON_REF_ATTRIBUTES.contains(attributeName)){                
                if(val ==null){
                    map.put(attributeName, null);
                }else{

                    String usersCSV = (String)(val==null?val:val.toString());  
                    String[]users = usersCSV.split(",");
                    if(users.length==0){
                        map.put(attributeName, null);
                    }else{
                        if(users.length==1){
                            map.put(attributeName,MessagesHypermediaGenerator.addLinks(uriService, PersonReference.GetPersonByLoginId(users[0])));  
                        }else{
                            ArrayList<PersonReference> result = new ArrayList<PersonReference>();
                            for(String user : users){
                                result.add(MessagesHypermediaGenerator.addLinks(uriService, PersonReference.GetPersonByLoginId(user)));
                            }
                            map.put(attributeName, result);
                        }
                    }
                }
               }else{
                   if(val == null)
                    map.put(attributeName, null);
                   else{
                       map.put(attributeName, val.toString());
                    }
               }
           }
        }
        return map;
    }       

    private  List<Map<String,Object>> toMap(RowIterator ri,int maxRows,int startRow,boolean singleRow){
        Row[] rows;
        if (singleRow) {
            rows = new Row[] { ri.getCurrentRow() };
        } else {
            ri.reset();
            ri.setRangeSize(maxRows);
            ri.setRangeStart(startRow);
            rows = ri.getAllRowsInRange();
        }
        List<Map<String,Object>> result = new ArrayList<Map<String,Object>>();
        for (Row row : rows) {
            result.add(toMap(row,false));
        }
        return result;
    }
    
    private HashMap<oracle.jbo.domain.Number,Bookmark> generateLinksMap(List<HashMap> quickLinks,String lang){
      HashMap<oracle.jbo.domain.Number,Bookmark> map = null;      
      if(quickLinks != null && !quickLinks.isEmpty()){             
           map = new HashMap<oracle.jbo.domain.Number,Bookmark>();             
           for(HashMap linkMap : quickLinks){
               map.put((Number)linkMap.get("QlId"), new Bookmark(linkMap,lang));
           }
      }
      return map;
    }   
    
    private ArrayList<oracle.jbo.domain.Number> filterImproperlyAssignedBookmarks(List<oracle.jbo.domain.Number> allUserLinks, List<HashMap> bookmarks) {
        List<oracle.jbo.domain.Number> userLinks = new ArrayList<oracle.jbo.domain.Number>();        
        for(HashMap linkMap:bookmarks) {                        
            Number linkId = (Number)linkMap.get("QlId");            
                for (Number id:allUserLinks)   {
                    if (linkId.equals(id)) {                        
                        userLinks.add(id);
                        break;
                }
            }
        }        
        return (ArrayList<Number>)userLinks;
    }    
    
    private boolean containsLink(List<oracle.jbo.domain.Number> userLinks,oracle.jbo.domain.Number linkId){
        boolean found=false;
        if(userLinks != null && linkId != null){
            for(oracle.jbo.domain.Number userLinkId : userLinks){
                if(userLinkId.compareTo(linkId)==0){
                    found=true;
                    break;
                }
            }
        }
        return found;                    
    }  
    
    @POST
    @Path("/bookmark")    
    public Response createBookmark(@QueryParam("similarTo") Long similarTo,Bookmark bookmark){
        UCMUtil ucmUtil = UCMUtil.getInstance();
        if(ucmUtil.isContributor()){ 
            if(bookmark == null)
                throw new BadRequestException("Invalid post request");
            UserProfileAM am = getUserProfileAM();
            String displayNameEn = bookmark.getDisplayNameEn();
            String displayNameEs = bookmark.getDisplayNameEs();
            String urlEn = bookmark.getUrlEn();
            String urlEs = bookmark.getUrlEs();
            boolean newWindow = bookmark.getTarget()==null?true:(bookmark.getTarget().compareTo("_blank")==0?true:false);
            boolean isMandatory = bookmark.isMandatory();
            String keywords = bookmark.getKeywords();

            HashMap rslt = new HashMap<String,Object>();
            
            if(similarTo !=null){
                Map keyMap = am.createQuickLink(similarTo,displayNameEn,displayNameEs,urlEn,urlEs,newWindow,isMandatory, keywords);
                rslt.put("EN", am.getQuickLink((Long)keyMap.get("EN")));
                rslt.put("ES", am.getQuickLink((Long)keyMap.get("ES")));                
                
            }else{
                Map keyMap = am.createQuickLink(displayNameEn,displayNameEs,urlEn,urlEs,newWindow,isMandatory, keywords);
                rslt.put("EN", am.getQuickLink((Long)keyMap.get("EN")));
                rslt.put("ES", am.getQuickLink((Long)keyMap.get("ES")));                
            }
            return Response.ok(rslt).build();
        }else{
            throw new BadRequestException("Available only for Contributors.");
        }
    }
    
    @PUT
    @Path("/bookmark/{id}")    
    public Response updateBookmark(@PathParam("id")Long id,Bookmark bookmark){
        UCMUtil ucmUtil = UCMUtil.getInstance();
        if(ucmUtil.isContributor()){
            if(bookmark == null)
                throw new BadRequestException("Invalid post request");
            UserProfileAM am = getUserProfileAM();
            String displayName = bookmark.getDisplayName();
            String url = bookmark.getUrl();
            boolean newWindow = bookmark.getTarget()==null?true:(bookmark.getTarget().compareTo("_blank")==0?true:false);
            boolean isMandatory = bookmark.isMandatory();
            String keywords = bookmark.getKeywords();
            Long bookmarkId = am.updateQuickLink(id, displayName, url, newWindow, isMandatory, keywords);
            
            HashMap bkmrk = am.getQuickLink(bookmarkId);
            return Response.ok(bkmrk).build();
        }else{
            throw new BadRequestException("Available only for Contributors.");
        }
    }
    
    @GET
    @Path("/bookmark/{bookmarkId}")    
    public Response getBookmark(@PathParam("bookmarkId")Long bookmarkId){
        UCMUtil ucmUtil = UCMUtil.getInstance();
        if(ucmUtil.isContributor()){
            UserProfileAM am = getUserProfileAM();
            HashMap bkmrk = am.getQuickLink(bookmarkId);
            return Response.ok(bkmrk).build();
        }else{
            throw new BadRequestException("Available only for Contributors.");
        }
    }    
    
    @GET
    @Path("/bookmark/{bookmarkId}/securitygroups")
    public Response getSecurityGroupsForBookmark(@PathParam("bookmarkId") Long bookmarkId){
        UCMUtil ucmUtil = UCMUtil.getInstance();
        if(ucmUtil.isContributor()){
            UserProfileAM am = getUserProfileAM();
            List<HashMap>secGrps = am.getSecurityGroupsForQuickLink(bookmarkId);
            return Response.ok(secGrps).build();
        }else{
            throw new BadRequestException("Available only for Contributors.");
        }        
    }
    
    @GET
    @Path("/bookmark/securitygroups")
    public Response getSecurityGroups(){
        UCMUtil ucmUtil = UCMUtil.getInstance();
        if(ucmUtil.isContributor()){
            UserProfileAM am = getUserProfileAM();
            List<HashMap>secGrps = am.getSecurityGroups();
            return Response.ok(secGrps).build();
        }else{
            throw new BadRequestException("Available only for Contributors.");
        }        
    }
    
    
    @POST
    @Path("/bookmark/{bookmarkId}/securitygroups")
    public Response provisionSecurityGroups(@PathParam("bookmarkId") Long bookmarkId,@DefaultValue("false") @QueryParam("default") boolean isDefault,List<Long> securityGroups){
        UCMUtil ucmUtil = UCMUtil.getInstance();
        if(ucmUtil.isContributor()){
            UserProfileAM am = getUserProfileAM();
            if(bookmarkId == null || securityGroups == null || securityGroups.size() <=0){
                throw new BadRequestException("Bookmark Id & Security Groups list is mandatory.");
            }else{
                Long[] securityGrps = new Long[securityGroups.size()];
                securityGroups.toArray(securityGrps);
                am.provisionQuickLink(bookmarkId,securityGrps, isDefault);
                List<HashMap>secGrps = am.getSecurityGroupsForQuickLink(bookmarkId);
                return Response.ok(secGrps).build();
            }            
        }else{
            throw new BadRequestException("Available only for Contributors.");
        }        
    }
    
    @DELETE
    @Path("/bookmark/{bookmarkId}/securitygroups")
    public Response unProvisionSecurityGroups(@PathParam("bookmarkId") Long bookmarkId,List<Long> securityGroups){
        UCMUtil ucmUtil = UCMUtil.getInstance();
        if(ucmUtil.isContributor()){
            UserProfileAM am = getUserProfileAM();
            if(bookmarkId == null || securityGroups == null || securityGroups.size() <=0){
                throw new BadRequestException("Bookmark Id & Security Groups list is mandatory.");
            }else{
                Long[] securityGrps = new Long[securityGroups.size()];
                securityGroups.toArray(securityGrps);
                am.unProvisionQuickLink(bookmarkId, securityGrps);
                List<HashMap>secGrps = am.getSecurityGroupsForQuickLink(bookmarkId);
                return Response.ok(secGrps).build();
            }            
        }else{
            throw new BadRequestException("Available only for Contributors.");
        }        
    }
    
    @PUT
    @Path("/{id}")    
    public Response saveBookmark(@PathParam("id")String id,Bookmark bookmark){        
        if(bookmark!=null && bookmark.getId()>-1 || bookmark.getLang()!=null){
            UserProfileAM am = getUserProfileAM();
            String userName = ADFContext.getCurrent().getSecurityContext().getUserName();
            List<oracle.jbo.domain.Number> allUserLinks = am.retrieveSelectedLinks(userName);
            boolean updated=false;
            if(allUserLinks!=null && !allUserLinks.isEmpty()){
                oracle.jbo.domain.Number lnkId;
                boolean lnkFound=false;
                int lnkIdx=0;
                while(lnkIdx<allUserLinks.size()){                    
                    lnkId=allUserLinks.get(lnkIdx);
                    if(bookmark.getId()==lnkId.intValue()){
                        lnkFound=true;
                        break;
                    }
                    lnkIdx++;
                }
                if(bookmark.isFavorite()){
                    if(lnkFound){
                        //do nothing
                    }else{
                        allUserLinks.add(new oracle.jbo.domain.Number(bookmark.getId()));
                        am.saveSelectedQuickLinks(userName, allUserLinks);
                        updated=true;
                    }
                }else{
                    if(lnkFound){
                        allUserLinks.remove(lnkIdx);
                        am.saveSelectedQuickLinks(userName, allUserLinks);
                        updated=true;
                    }else{
                        //do nothing
                    }
                }                                
            }else{
                if(bookmark.isFavorite()){
                    allUserLinks = new ArrayList<oracle.jbo.domain.Number>();
                    allUserLinks.add(new oracle.jbo.domain.Number(bookmark.getId()));
                    am.saveSelectedQuickLinks(userName, allUserLinks);
                    updated=true;
                }
            }
            
            return Response.ok(bookmark).build();
        }else{
            throw new BadRequestException("Invalid update of Bookmarks");
        }
    }
    
    @GET
    public Response getBookmarks(@DefaultValue("en") @QueryParam("lang") String lang){              
        try{
            List<oracle.jbo.domain.Number> userLinks = null;
            UserProfileAM am = getUserProfileAM();
            am.setLocale(lang);
            String userName = ADFContext.getCurrent().getSecurityContext().getUserName();

            String[] userRoles = ADFContext.getCurrent().getSecurityContext().getUserRoles();        
            List<HashMap> quickLinks = getUserProfileAM().retrieveQuickLinks(userRoles); 
            Collections.sort(quickLinks,new Comparator<HashMap>(){
                    public int compare(HashMap first,HashMap second){
                        String firstDisplayName=first.get("DisplayName").toString();
                        String secondDisplayName=second.get("DisplayName").toString();
                        return firstDisplayName.compareTo(secondDisplayName);
                    }
                }
            );             
            HashMap<oracle.jbo.domain.Number,Bookmark> quickLinksMap = generateLinksMap(quickLinks,lang);
            Bookmark bookmark;
            List<oracle.jbo.domain.Number> allUserLinks = am.retrieveSelectedLinks(userName);   
            if (allUserLinks != null) {
                userLinks = filterImproperlyAssignedBookmarks(allUserLinks, quickLinks);
            }
            if(userLinks !=null && !userLinks.isEmpty()){
                for(oracle.jbo.domain.Number qlId : userLinks){
                    bookmark = quickLinksMap.get(qlId);
                    if(bookmark!=null){
                        bookmark.setFavorite(true);
                    }
                }
            }

            return Response.ok(quickLinksMap.values()).build();
        }catch(Exception e){
            throw new BadRequestException(e);
        }
    }
}
