package com.darden.krowd.rest.services;

import com.darden.krowd.RIDCCommon.util.UCMUtil;
import com.darden.krowd.content.xml.lcs.data.LcsDO;

import com.darden.krowd.rest.exceptions.BadRequestException;

import java.util.List;

import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import javax.servlet.http.HttpServletRequest;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import javax.xml.bind.JAXBElement;

import oracle.adf.share.logging.ADFLogger;

import oracle.webcenter.activitystreaming.ActivityException;
import oracle.webcenter.activitystreaming.ActivityObject;
import oracle.webcenter.activitystreaming.ActivityStreamingService;
import oracle.webcenter.activitystreaming.ActivityStreamingServiceFactory;
import oracle.webcenter.activitystreaming.internal.model.jpa.ActivityEntityManagerFactory;
import oracle.webcenter.comments.Comment;
import oracle.webcenter.comments.CommentsManager;
import oracle.webcenter.comments.CommentsServiceFactory;
import oracle.webcenter.framework.service.ServiceObjectType;
import oracle.webcenter.likes.Like;
import oracle.webcenter.likes.LikesManager;
import oracle.webcenter.likes.LikesServiceFactory;

@Path("/lcs")
@Produces("application/json")
public class LCSResource {
    private static final ADFLogger logger = ADFLogger.createADFLogger(LCSResource.class);
    @Context 
    private HttpServletRequest httpRequest;
    
    public LCSResource() {
        super();
    }
    
    //http://www.michaelwilliams.co.za/no-content-to-map-to-object-due-to-end-of-input/
    @POST
    @Path("/counts")
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    public Response getLCSData(LcsDO inputDO){
        Response res = null;
        //LcsDO inputDO = input.getValue();
        String serviceId = inputDO.getServiceId();
        String objectType = inputDO.getObjectType();
        String objectId = inputDO.getObjectId();
        
        Integer likesCount=0;
        Integer commentsCount = 0;

        List<Like> likes=null;
        List<Comment> comments = null;
        
        try{
            LcsDO outputDO = new LcsDO();
            outputDO.setServiceId(serviceId);
            outputDO.setObjectId(objectId);
            outputDO.setObjectType(objectType);
            
            
            likes=getLikes(serviceId,objectType,objectId);
            comments = getComments(serviceId,objectType,objectId);
            
            if(likes!=null)
                likesCount=likes.size();
            
            if(comments != null)
                commentsCount = comments.size();
            
            outputDO.setLikes(likesCount);
            outputDO.setComments(commentsCount);
            outputDO.setShares(getShareCount());
            res = Response.status(Response.Status.OK)
                                .entity(outputDO).type(MediaType.APPLICATION_JSON)
                                .build();
        }catch(Exception e){
            throw new BadRequestException(e.getMessage());
        }
        return res;    
    }
    
    @POST
    @Path("/like")
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    public Response like(){
        return null;    
    }
    
    @DELETE
    @Path("/like")
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    public Response unLike(){
        return null;    
    }
    
    @POST
    @Path("/comment")
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    public Response comment(){
        return null;    
    }
    
    @POST
    @Path("/share")
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    public Response share(){
        return null;    
    }
    
    
    private List<Like> getLikes(String serviceID,String objectType,String objectID) {
        
        List<Like> likes = null;        
        
        try{
            logger.info( "serviceId " + serviceID + " objectType " + objectType + " objectID " + objectID);            
            ActivityObject activityObject = createActivityObject(serviceID, objectType, objectID);
            LikesManager likesManager = LikesServiceFactory.getInstance().getLikesManager();
            likes = likesManager.getLikes(activityObject);
           
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return likes;
    }
    

    private List<Comment> getComments(String serviceID,String objectType,String objectID) {
        List<Comment> comments = null;        
        
        try{
            logger.info("serviceId " + serviceID + " objectType " + objectType + " objectID " + objectID);
            ActivityObject activityObject = createActivityObject(serviceID, objectType, objectID);
            CommentsManager commentsManager = CommentsServiceFactory.getInstance().getCommentsManager();
            comments = commentsManager.getComments(activityObject, CommentsManager.SortCriteria.CREATED_ON_ASC);

        }catch(Exception e){
            e.printStackTrace();
        }

        return comments;
    }    
    
    
    private ActivityObject createActivityObject(String serviceId, String objectType, String objectId)
    {
      ActivityObject obj = null;
      try {
        ActivityStreamingService as = ActivityStreamingServiceFactory.getInstance().getActivityStreamingService();
        ServiceObjectType serviceObjType = as.findObjectType(serviceId, objectType);
        obj = as.createObject(objectId, serviceObjType, objectId);
        obj.setServiceID(serviceId);
      } catch (ActivityException e) {
        logger.warning(e);
      }
      return obj;
    }
    
    private Integer getShareCount(){
        //TODO: return share count.
        return null;
    }
}
