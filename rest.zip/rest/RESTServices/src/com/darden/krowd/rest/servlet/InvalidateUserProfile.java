package com.darden.krowd.rest.servlet;

import java.io.IOException;

import java.io.PrintWriter;

import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.adf.share.logging.ADFLogger;

import oracle.webcenter.peopleconnections.profile.ProfileFactory;
import oracle.webcenter.peopleconnections.profile.UserProfileManager;
import oracle.webcenter.peopleconnections.profile.WCUserProfile;

public class InvalidateUserProfile extends HttpServlet {
    private static final ADFLogger logger = ADFLogger.createADFLogger(InvalidateUserProfile.class);
    private static final long serialVersionUID = -4354827561311018014L;

    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Enumeration<String> parameterNames = request.getParameterNames();
        String username = request.getUserPrincipal().getName();
        try{
            UserProfileManager profileManager = ProfileFactory.getProfileManager();
            WCUserProfile userProfile = profileManager.getProfileForUpdate(username);
            if(userProfile != null){
                logger.info("==== Trying to clear cache for User ===="+username);
                userProfile.invalidatePhotoCache();
                response.setStatus(HttpServletResponse.SC_OK);
                response.setContentType("application/json");
                PrintWriter out = response.getWriter();
                out.print("{\"status\" : \"OK\"}");
            }else{
                logger.warning("------- Unable to get User Profile for user ----"+username);
            }
        }catch(Exception e){
            logger.severe(e);
        }
        
    }
}
