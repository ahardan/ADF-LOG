package com.darden.krowd.rest.services;


import com.darden.krowd.common.CMSConstants;
import com.darden.krowd.common.KrowdUtility;
import com.darden.krowd.common.identity.LdapHelper;
import com.darden.krowd.rest.exceptions.BadRequestException;
import com.darden.krowd.rest.model.ReportInfo;

import java.text.Format;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import javax.servlet.http.HttpServletRequest;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import oracle.adf.share.logging.ADFLogger;

import oracle.security.idm.ComplexSearchFilter;
import oracle.security.idm.Identity;
import oracle.security.idm.RoleManager;
import oracle.security.idm.SearchResponse;
import oracle.security.idm.User;
import oracle.security.idm.UserProfile;

import oracle.webcenter.spaces.metadata.GSMetadata;

import org.apache.commons.lang.StringUtils;

import org.owasp.esapi.ESAPI;


@Path("/report")
@Produces("application/json")
public class ReportResource {    
    private static final ADFLogger logger = ADFLogger.createADFLogger(ReportResource.class);
    
    @Context private HttpServletRequest httpRequest;
    

    public ReportResource() {
        super();
    }

    private User getUserByEmplId(String emplId) throws Exception {
        if(emplId != null && StringUtils.isNotBlank(emplId)){
            HashMap<String,String> params = new HashMap<String,String>();
            params.put("Darden-Empl-ID",emplId);
            List<Identity> list = LdapHelper.getInstance().getIdentitiesWithAttributes(params, ComplexSearchFilter.TYPE_OR); 
            if(list != null && list.size() >0){
                User user = (User)list.get(0);
                return user;
            }else{
                return null;
            }         
        }else{
            return null;
        }
        
    }
    
    private ArrayList<String> getRoles(User user) throws Exception {
        RoleManager roleManager = LdapHelper.getInstance().getIdentityStore().getRoleManager();
        SearchResponse searchResponse = roleManager.getGrantedRoles(user.getPrincipal(), false);
        ArrayList<String> rolesList = new ArrayList<String>();
        while(searchResponse.hasNext()){
            Identity identity = searchResponse.next();
            String roleName = identity.getName();
            rolesList.add(roleName);          
        }
        return rolesList;
    }
    
    public String getGroup(User user) throws Exception {
        List<String> userRoles = getRoles(user);
            
            if (userRoles.contains("Portal - RSC Emp")){
                String businessUnit = (String)user.getUserProfile().getPropertyVal("Darden-Business-Unit");
                if (businessUnit.compareTo("YHUSA") == 0)
                    return "RSCY";
                else
                    return "RSC";
            }
            else if (userRoles.contains("Portal - RSC Emp – Canada")){
                return "CRSC";
            }
            else{
                UserProfile userProfile = user.getUserProfile();
                String businessUnit = (String)userProfile.getPropertyVal("Darden-Business-Unit");
                String area = (String)userProfile.getPropertyVal("Darden-Area");
                String region = (String)userProfile.getPropertyVal("Darden-Region");
                String office = (String)userProfile.getPropertyVal("physicalDeliveryOfficeName");
                String managerLevel = (String)userProfile.getPropertyVal("Darden-Manager-Level");
                
                return businessUnit + "|" + area + "|" + region + "|" + office + "|" + managerLevel;
            }
    }    
    
    
    @POST
    @Path("/report")
    public Response  reportActivity(ReportInfo reportInfo){
        try {
            reportInfo.process();
            //Map for forming content of the email
            Map<String, String> content = new LinkedHashMap<String, String>();
            
            content.put("Content Reported By", (reportInfo.getMyDisplayName() != null && !reportInfo.getMyDisplayName().trim().isEmpty()) ? reportInfo.getMyDisplayName():"Reporter's name not available");
            content.put("Reporter's Title",(reportInfo.getMyTitle() != null && !reportInfo.getMyTitle().trim().isEmpty()) ? reportInfo.getMyTitle():"Reporter's Title not available");
            content.put("Reporter's Brand",(reportInfo.getMyBrand() != null && !reportInfo.getMyBrand().trim().isEmpty()) ? reportInfo.getMyBrand():"Reporter's Brand not available");
            content.put("Reporter's Restaurant Location",(reportInfo.getMyLocation() != null && !reportInfo.getMyLocation().trim().isEmpty()) ? reportInfo.getMyLocation():"Reporter's Location not available");
            content.put("Reporter's Comments",(reportInfo.getMessage() != null && !reportInfo.getMessage().trim().isEmpty()) ? reportInfo.getMessage():"Reporter's Comments not available");
            
            content.put("Content Posted By",(reportInfo.getAuthorDisplayName() != null && !reportInfo.getAuthorDisplayName().trim().isEmpty()) ? reportInfo.getAuthorDisplayName():"Posted Content not available");
            content.put("Poster's Title",(reportInfo.getAuthorTitle() != null && !reportInfo.getAuthorTitle().trim().isEmpty()) ? reportInfo.getAuthorTitle():"Poster's Title not availale");
            content.put("Poster's Brand",(reportInfo.getAuthorBrand() != null && !reportInfo.getAuthorBrand().trim().isEmpty()) ? reportInfo.getAuthorBrand():"Poster's Brand not availale");
            content.put("Poster's Restaurant Location",(reportInfo.getAuthorLocation() != null && !reportInfo.getAuthorLocation().trim().isEmpty()) ? reportInfo.getAuthorLocation():"Poster's Location not available");

            Format formatter = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");
            
            if(reportInfo.getType().compareTo("ACTIVITY")==0){                
                content.put("Poster's Content", (reportInfo.getActivityElement().getDisplayDescription() != null && !reportInfo.getActivityElement().getDisplayDescription().trim().isEmpty()) ? reportInfo.getActivityElement().getDisplayDescription():"Poster's Content not available");
                content.put("Posted Date and Time", formatter.format(reportInfo.getActivityElement().getActivityTime()));
                Date date = new Date();
                String sDate = formatter.format(date);
                content.put("Reported Date and Time",sDate);
                content.put("Reported Activity ID", reportInfo.getActivityElement().getActivityID());
                
                String detail = reportInfo.getActivityElement().getDetail();
                if(detail != null)
                    content.put("Reported Activity Detail",detail);
                
                String detailUrl = reportInfo.getActivityElement().getDetailURL();
                if(detailUrl != null)
                    content.put("Reported Activity Detail URL",detailUrl);

                GSMetadata groupSpace = reportInfo.getGroupSpace();
                if(groupSpace != null){
                    content.put("Community", groupSpace.getDisplayName());
                }                
            }
          
         
            if(reportInfo.getType().compareTo("COMMENT")==0){
                content.put("Poster's Content", (reportInfo.getComment().getCommentText() != null && !reportInfo.getComment().getCommentText().trim().isEmpty()) ? reportInfo.getComment().getCommentText():"Poster's Content not available");
                content.put("Posted Date and Time", formatter.format(reportInfo.getComment().getCreationDate()));
                Date date = new Date();
                String sDate = formatter.format(date);
                content.put("Reported Date and Time",sDate);
                content.put("Reported Comment ID", reportInfo.getComment().getId());
                content.put("Reported Activity Detail URL", reportInfo.getReportURL());
            }
            
            content.put("Note", "Please login to KrowD before taking action");
            
            
            String isManagerEmailIdReq = KrowdUtility.getInstance().getProperties().getProperty("REPORT_CONTENTTO_MANAGER").trim();
            logger.info("isManagerEmailIdReq:::"+isManagerEmailIdReq);            
            String isRequired = "yes";
            String recipient =KrowdUtility.getInstance().getProperties().getProperty("REPORT_MAIL_RECIPIENT");
            String authorManagerEmailId=null;
            //if ((isManagerEmailIdReq.equalsIgnoreCase(isRequired)) && (isManagerEmailIdReq != null) && (isManagerEmailIdReq != ""))//commented
            if ((isManagerEmailIdReq.equalsIgnoreCase(isRequired)) && (isManagerEmailIdReq != null) && (!isManagerEmailIdReq.equalsIgnoreCase("")))//subh, CWE-597 Use of Wrong Operator in String Comparison
            {
                authorManagerEmailId = reportInfo.getAuthorManagerEmail();
            } else {
                logger.info("Recipient:::"+recipient);
            }
            
            String subject = "Inappropriate Content is Reported";
            String sender = KrowdUtility.getInstance().getProperties().getProperty("REPORT_MAIL_SENDER");            
            sendEmail(sender, recipient, authorManagerEmailId,content, subject);
            boolean ret=true;
            return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
        } catch (Exception e) {
            logger.severe(e);
            throw new BadRequestException(e);
        }        
    }
    
    private String createContent(Map content) {
        StringBuffer buf = new StringBuffer();
        buf.append("<table border=\"1\">");
        
        
            Iterator iterator = content.entrySet().iterator();
            while (iterator.hasNext()) {
            Map.Entry mapEntry = (Map.Entry) iterator.next();
                
                buf.append("<tr>");
                buf.append("<td><b>").append(mapEntry.getKey()).append("</b></td>");
                buf.append("<td>").append(mapEntry.getValue()).append("</td>");
                buf.append("</tr>"); 
                   System.out.println("The key is: " + mapEntry.getKey()
                           + ",value is :" + mapEntry.getValue());
            }

        buf.append("</table>");
        return buf.toString();
    } 
    
    private void sendEmail(String sender, String recipient,String recipientM, Map<String,String> content, String subject) throws NoSuchProviderException,
                                                  MessagingException {
            String host = KrowdUtility.getInstance().getProperties().getProperty("REPORT_SMTP_HOST");
            Properties props = new Properties();

            props.setProperty("mail.transport.protocol", "smtp");
            props.setProperty("mail.smtp.host", host);
            props.setProperty("mail.smtp.port", KrowdUtility.getInstance().getProperties().getProperty("REPORT_SMTP_PORT"));
            props.setProperty("mail.smtp.user", sender);
            props.setProperty("mail.debug", "true");
            props.setProperty("mail.disable", "false");
            props.setProperty("mail.verbose", "true");
            Session session = Session.getDefaultInstance(props);
            Transport transport = session.getTransport();
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(sender));
            message.setSubject(subject);            
            //message.addRecipients(javax.mail.Message.RecipientType.TO, InternetAddress.parse(recipient));//commented
            //subh, CWE - 93 Improper Neutralization of CRLF Sequences ('CRLF Injection')
            message.addRecipients(javax.mail.Message.RecipientType.TO, InternetAddress.parse(ESAPI.encoder().encodeForHTML(recipient)));
            //
            if(recipientM!=null && !recipientM.trim().isEmpty()){
                //message.addRecipients(javax.mail.Message.RecipientType.CC, InternetAddress.parse(recipientM));//commented
                //subh, CWE - 93 Improper Neutralization of CRLF Sequences ('CRLF Injection')
                message.addRecipients(javax.mail.Message.RecipientType.CC, InternetAddress.parse(ESAPI.encoder().encodeForHTML(recipientM)));
                //
            }
            //message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(ReportInappropriateContentBean));
            String contentToEmail = createContent(content);
            logger.info( "SMTP Clent method sendEmail() Mail Content:" + contentToEmail);
            System.out.println("Content for the email"+contentToEmail);
            message.setContent(contentToEmail, "text/html; charset=utf-8");
            transport.connect();
            transport.send(message);
            transport.close();
            logger.info( "SMTPClient method sendEmail() Completed Successfully.");
    }    
}
