package com.darden.krowd.rest.services;


//import com.darden.krowd.rest.config.CacheAnnotations.CacheMaxAge;
//import com.darden.krowd.rest.exceptions.BadRequestException;
//import com.darden.krowd.rest.model.MTask;
//import com.darden.krowd.rest.model.MTaskAction;
//import com.darden.krowd.rest.model.MTaskComment;
//import com.darden.krowd.rest.support.WorklistService;
//
//import com.sun.jersey.core.header.FormDataContentDisposition;
//import com.sun.jersey.multipart.FormDataParam;
//
//import java.io.ByteArrayInputStream;
//import java.io.IOException;
//import java.io.InputStream;
//
//import java.net.FileNameMap;
//import java.net.URLConnection;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.concurrent.TimeUnit;
//
//import javax.servlet.http.HttpServletRequest;
//
//import javax.ws.rs.Consumes;
//import javax.ws.rs.DefaultValue;
//import javax.ws.rs.GET;
//import javax.ws.rs.POST;
import javax.ws.rs.Path;
//import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
//import javax.ws.rs.QueryParam;
//import javax.ws.rs.core.Context;
//import javax.ws.rs.core.MediaType;
//import javax.ws.rs.core.Response;
//
//import oracle.adf.share.logging.ADFLogger;
//
//import oracle.bpel.services.workflow.StaleObjectException;
//import oracle.bpel.services.workflow.WorkflowException;
//
//import oracle.bpel.services.workflow.task.model.AttachmentType;
//import oracle.bpel.services.workflow.task.model.Task;
//
//import oracle.webcenter.bpel.config.BPELConnectionManagerRegistry;
//import oracle.webcenter.bpel.config.BPELConnectionUtil;
//import oracle.webcenter.bpel.config.ConfigurationException;
//import oracle.webcenter.jaxrs.framework.param.ItemsPerPageParam;
//import oracle.webcenter.jaxrs.framework.service.RestService;
//import oracle.webcenter.jaxrs.framework.uri.UriService;


@Path("/worklist")
@Produces("application/json")
public class WorklistResource {
//    @Context private HttpServletRequest httpRequest;    
//    private static final ADFLogger logger = ADFLogger.createADFLogger(WorklistResource.class);
//        
//    @RestService
//    protected UriService uriService;
//    
//    public WorklistResource() {
//        super();
//    }
//
//    @GET
//    @CacheMaxAge(time = 360, unit = TimeUnit.MINUTES)
//    @Path("/connections")
//    public List<String> getConnections(){        
//        try {
//            List<BPELConnectionUtil> mConnections = BPELConnectionManagerRegistry.getManager().getWorklistConnections();            
//            List<String> connections = new ArrayList<String>();
//            for(BPELConnectionUtil connection : mConnections){
//                connections.add(connection.getName());
//            }
//            return connections;
//        } catch (ConfigurationException e) {
//            throw new BadRequestException(e);
//        }
//    }
//    
//    private BPELConnectionUtil getConnection(String name){
//        List<BPELConnectionUtil> mConnections;
//        try {
//            mConnections = BPELConnectionManagerRegistry.getManager().getWorklistConnections();
//            for(BPELConnectionUtil connection : mConnections){
//                if(connection.getName().compareToIgnoreCase(name)==0)
//                    return connection;                
//            }
//            return null;
//        } catch (ConfigurationException e) {
//            logger.severe(e);            
//            return null;
//        }
//    }
//    
//    @GET
//    @Path("/{connection}/mtasks")
//    public Response getMTasks(@PathParam("connection")String connection,@DefaultValue("megroup") @QueryParam("filter") String filter,@DefaultValue("any") @QueryParam("state") String state){        
//        BPELConnectionUtil bpelConn = getConnection(connection);
//        if(bpelConn ==null){            
//            throw new BadRequestException("Cannot find BPEL Connection with name "+connection);
//        }else{
//            try {
//                WorklistService worklistService = new WorklistService(bpelConn);
//                List<Task> tasks = worklistService.getTasks(filter, state);                
//                return Response.status(Response.Status.OK).entity(WorklistService.toMTasks(tasks)).type("application/json").build();    
//            } catch (WorkflowException e) {
//                throw new BadRequestException("Cannot find query tasks for connection with name "+connection);
//            }            
//        }            
//    }
//
//    @GET
//    @Path("/{connection}/tasks")
//    public Response getTasks(@PathParam("connection")String connection,
//                             @DefaultValue("25") @QueryParam("itemsPerPage") ItemsPerPageParam itemsPerPage,
//                             @QueryParam("sortBy") String sortBy,
//                             @QueryParam("q") String queryString){        
//        BPELConnectionUtil bpelConn = getConnection(connection);
//        if(bpelConn ==null){            
//            throw new BadRequestException("Cannot find BPEL Connection with name "+connection);
//        }else{
//            WorklistService worklistService = new WorklistService(bpelConn);
//            List<Task> tasks;
//            try {
//                tasks =worklistService.queryTasks(itemsPerPage.intValue(),sortBy,queryString);
//                return Response.status(Response.Status.OK).entity(WorklistService.toMTasks(tasks)).type("application/json").build();    
//            } catch (WorkflowException e) {
//                logger.severe(e);
//                throw new BadRequestException(e);
//            }            
//        }            
//    }
//    
//    @GET
//    @Path("/{connection}/task/{tasknumber}")
//    public Response getTask(@PathParam("connection")String connection,@PathParam("tasknumber")String taskNumber){        
//        BPELConnectionUtil bpelConn = getConnection(connection);
//        if(bpelConn ==null){
//            throw new BadRequestException("Cannot find BPEL Connection with name "+connection);
//        }else{
//            WorklistService worklistService = new WorklistService(bpelConn);
//            Task task;
//            try {
//                task = worklistService.getTaskDetails(taskNumber);
//                return Response.status(Response.Status.OK).entity(new MTask(task)).type("application/json").build();    
//            } catch (WorkflowException e) {
//                logger.severe(e);
//                throw new BadRequestException(e);
//            }            
//        }                    
//    }
//    
//    @POST
//    @Path("/{connection}/task/{tasknumber}/process")
//    public Response processTask(@PathParam("connection")String connection,@PathParam("tasknumber")String taskNumber,MTaskAction outcome){        
//        BPELConnectionUtil bpelConn = getConnection(connection);
//        if(bpelConn ==null){
//            throw new BadRequestException("Cannot find BPEL Connection with name "+connection);
//        }else{
//            WorklistService worklistService = new WorklistService(bpelConn);
//            Task task;
//            try {
//                task = worklistService.getTaskDetails(taskNumber);
//                worklistService.processTask(taskNumber, outcome.getAction());
//                task = worklistService.getTaskDetails(taskNumber);
//                return Response.status(Response.Status.OK).entity(new MTask(task)).type("application/json").build();  
//            } catch (WorkflowException e) {
//                logger.severe(e);
//                throw new BadRequestException(e);
//            } catch (StaleObjectException e) {
//                logger.severe(e);
//                throw new BadRequestException(e);
//            }
//        }                    
//    }  
//    
//    @POST
//    @Path("/{connection}/task/{tasknumber}/comment")
//    public Response commentTask(@PathParam("connection")String connection,@PathParam("tasknumber")String taskNumber,MTaskComment comment){        
//        BPELConnectionUtil bpelConn = getConnection(connection);
//        if(bpelConn ==null){
//            throw new BadRequestException("Cannot find BPEL Connection with name "+connection);
//        }else{
//            WorklistService worklistService = new WorklistService(bpelConn);
//            Task task;
//            try {
//                task = worklistService.getTaskDetails(taskNumber);
//                worklistService.addComment(taskNumber, comment.getComment());
//                task = worklistService.getTaskDetails(taskNumber);
//                return Response.status(Response.Status.OK).entity(new MTask(task)).type("application/json").build();  
//            } catch (WorkflowException e) {
//                logger.severe(e);
//                throw new BadRequestException(e);
//            } catch (StaleObjectException e) {
//                logger.severe(e);
//                throw new BadRequestException(e);
//            }
//        }                    
//    }    
//    
//    @POST
//    @Consumes(MediaType.MULTIPART_FORM_DATA)
//    @Produces({MediaType.APPLICATION_JSON})    
//    @Path("/{connection}/task/{tasknumber}/upload")
//    public Response addAttachmentToTask(@PathParam("connection")String connection,
//                                        @PathParam("tasknumber")String taskNumber,
//                                        @FormDataParam("file") InputStream fileInputStream,
//                                        @FormDataParam("file") FormDataContentDisposition fileDetail){        
//        BPELConnectionUtil bpelConn = getConnection(connection);
//        if(bpelConn ==null){
//            throw new BadRequestException("Cannot find BPEL Connection with name "+connection);
//        }else{
//            WorklistService worklistService = new WorklistService(bpelConn);
//            Task task;
//            try {
//                task = worklistService.getTaskDetails(taskNumber);
//                
//                String fileName = fileDetail.getFileName();   
//                FileNameMap fileNameMap = URLConnection.getFileNameMap();
//                String mimeType = fileNameMap.getContentTypeFor(fileDetail.getFileName());                                    
//                worklistService.addAttachmentToTask(taskNumber, fileName,fileInputStream, mimeType, fileDetail.getFileName());
//                task = worklistService.getTaskDetails(taskNumber);
//                return Response.status(Response.Status.OK).entity(new MTask(task)).type("application/json").build();  
//            } catch (WorkflowException e) {
//                logger.severe(e);
//                throw new BadRequestException(e);
//            } catch (StaleObjectException e) {
//                logger.severe(e);
//                throw new BadRequestException(e);
//            } catch (IOException e) {
//                logger.severe(e);
//                throw new BadRequestException(e);                
//            }
//        }                    
//    } 
//    
//    @GET
//    @Path("/{connection}/task/{tasknumber}/attachment/{id}")
//    @Produces("*/*")
//    public Response getAttachmentForTask(@PathParam("connection")String connection,
//                                         @PathParam("tasknumber")String taskNumber,@PathParam("id")String attachmentId){
//             BPELConnectionUtil bpelConn = getConnection(connection);
//             if(bpelConn ==null){
//                 throw new BadRequestException("Cannot find BPEL Connection with name "+connection);
//             }else{
//                 WorklistService worklistService = new WorklistService(bpelConn);
//                 try {
//                     AttachmentType attType = worklistService.getAttachmentForTask(taskNumber, attachmentId);
//                     if(attType !=null){
//                         InputStream ips = attType.getInputStream();
//                         return Response.ok(ips).type(attType.getMimeType()).build();                    
//                     }else{
//                         throw new BadRequestException("Cannot find attachment for Id "+attachmentId);
//                     }
//                 } catch (WorkflowException e) {
//                     logger.severe(e);
//                     throw new BadRequestException(e);
//                 } 
//             }                    
//                                             
//    }

}
