package com.darden.krowd.rest.filter;

import com.sun.jersey.spi.container.ContainerRequest;
import com.sun.jersey.spi.container.ContainerRequestFilter;

import com.tangosol.net.CacheService;

import java.io.IOException;

import java.lang.annotation.Annotation;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.Provider;

import oracle.webcenter.content.integration.cache.Cache;
import oracle.webcenter.content.integration.cache.CacheFactory;

import oracle.webcenter.jaxrs.framework.annotation.ResourceInfo;


@Provider
public class ETagCacheRequestFilter implements ContainerRequestFilter {
 
  private static final String IF_NONE_MATCH = "If-None-Match";
  private static final String IF_MATCH = "If-Match";

    private CacheFactory cacheFactory;
    private Cache cache;    


    public ContainerRequest filter(ContainerRequest containerRequest) {
        return null;
    }
}
