package com.darden.krowd.rest.support;

import com.darden.krowd.rest.model.MTask;

import java.util.Comparator;

public class MTaskComparator implements Comparator<MTask> {

  @Override
  public int compare(MTask m1, MTask m2) {
    
    int p1 = m1.getPriority();
    int p2 = m2.getPriority();
    
    if (p1 > p2) {
      return +1;
    } else if (p1 < p2) {
      return -1;
    } else {
      return 0;
    }
  }
}