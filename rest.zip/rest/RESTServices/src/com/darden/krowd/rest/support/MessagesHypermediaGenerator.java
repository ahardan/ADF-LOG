package com.darden.krowd.rest.support;

import javax.servlet.http.HttpServletRequest;

import oracle.adf.share.logging.ADFLogger;

import oracle.webcenter.jaxrs.framework.model.LinkElement;
import com.darden.krowd.framework.PersonReference;
import oracle.webcenter.jaxrs.framework.uri.UriService;


public class MessagesHypermediaGenerator {
    private static final ADFLogger logger = ADFLogger.createADFLogger(MessagesHypermediaGenerator.class);
    
    
    public static PersonReference addLinks(UriService uriService, PersonReference person)
    {
      if (person == null) {
        return null;
      }

      if (person.getGuid() != null)
      {
        person.addLink(userIcon(uriService, person.getGuid()));
      }

      return person;
    }  
    
    public static LinkElement userIcon(UriService _uriService, String _strGuid)
    {
      LinkElement linkElement = new LinkElement();
      linkElement.setRel("urn:oracle:webcenter:people:icon");
      linkElement.setResourceType("urn:oracle:webcenter:people:person");
      linkElement.setType("image/png");
      linkElement.addCapability("urn:oracle:webcenter:read");

      String strURIPrefix = getBaseURI(_uriService.getRequest()) + "/webcenter";
      //String strURIPrefix = "https://krowdtst2.darden.com" + "/webcenter";
      oracle.webcenter.peopleconnections.profile.internal.view.webapp.ProfileELResolver.PhotoURIGenerator pug = new oracle.webcenter.peopleconnections.profile.internal.view.webapp.ProfileELResolver.PhotoURIGenerator(_strGuid, null);
      linkElement.setHref(strURIPrefix + pug.generatePhotoURI("SMALL"));
      linkElement.setTemplate(strURIPrefix + pug.generatePhotoURI("{size}"));
      return linkElement;
    }    
    
    public static String getBaseURI(HttpServletRequest _request)
    {
      return _request.getScheme() + "://" + _request.getServerName() + ":" + _request.getServerPort();
    }    
    
   
}
