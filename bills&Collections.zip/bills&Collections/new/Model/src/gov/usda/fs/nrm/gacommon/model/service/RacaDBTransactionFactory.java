package gov.usda.fs.nrm.gacommon.model.service;

import oracle.jbo.server.DBTransactionImpl2;
import oracle.jbo.server.DatabaseTransactionFactory;

public class RacaDBTransactionFactory  extends DatabaseTransactionFactory {
    public RacaDBTransactionFactory()
    {
        super();
    }
  /**
   * Return an instance of our custom InfraDBTransactionImpl class
   * instead of the default implementation.
   * 
   * @return An instance of our custom DBTransactionImpl implementation.
   */
  public DBTransactionImpl2 create() {
    return new RacaDBTransactionImpl();
  }
}