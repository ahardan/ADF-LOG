package gov.usda.fs.nrm.gacommon.model.exception.raca;

import java.util.ListResourceBundle;

public class RacaErrorMessages extends ListResourceBundle {

    public static final String GENERAL_ERROR_MESSAGE = "100100";   
    public static final String DB_CONSTRAINT_VIOLATION = "100101";  
    public static final String AGREEMENT_UNIQUE_CONSTRAINT_VIOLATION = "100102";  

    public RacaErrorMessages() {
    }
    
    private static final Object[][] sMessageStrings = new String[][] 
    {
      { GENERAL_ERROR_MESSAGE, "{0}" },
      { DB_CONSTRAINT_VIOLATION, "Database Constraint Exception: {0}" },
      { AGREEMENT_UNIQUE_CONSTRAINT_VIOLATION, "Agreement ID and Org must be unique" }
    };

    /**
     * Return String Identifiers and corresponding Messages in a two-dimensional array.
     *
     * @return Array of {key,Message} String arrays.
     */
    protected Object[][] getContents() 
    {
      return sMessageStrings;
    }
}
