package gov.usda.fs.nrm.gacommon.model.exception.raca;

import gov.usda.fs.nrm.gacommon.model.validation.raca.RacaValidation;

import java.io.File;
import java.io.FileInputStream;

import java.util.Properties;

import java.util.ResourceBundle;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.apache.log4j.*;

import org.xml.sax.InputSource;

public class ErrorMessageHandler {
    private static Logger log = LogManager.getLogger(ErrorMessageHandler.class);
    private Properties prop = new Properties();
    private String filePath;
    private static String FILE_NAME = "AppErrorMessages.xml";

    public ErrorMessageHandler() {
    }

    /**
     * searchFile
     * @param fileName
     * @return
     */
    public String searchFile(String fileName)
    {
        String ret;
        java.net.URL url = getClass().getClassLoader().getResource(fileName);
        if (url == null)
            ret = null;
        else
            ret =  url.getFile();
        
        log.debug("filePath: " + ret);
        return ret;
    }

    /**
     * loadResource
     */
    public void loadResource(){
        //ResourceBundle resources = ResourceBundle.getBundle(searchFile("gov.usda.fs.nrm.gacommon.model.exception.RacaErrorMessages"));
        //String fileName = "C:\\dev\\jdev\\jdev_10333\\work\\RACA\\Model\\classes\\gov\\usda\\fs\\iweb\\raca\\model\\exception\\RacaErrorMessages.class";
        //ResourceBundle resources = ResourceBundle.getBundle(fileName);
        //ResourceBundle resources = ResourceBundle.getBundle("gov.usda.fs.nrm.gacommon.model.exception.RacaErrorMessages.class");

         ResourceBundle resources = ResourceBundle.getBundle("RacaErrorMessages");
         
        //ResourceBundle resources = ResourceBundle.getBundle(searchFile("AppErrorMessagesP.properties"));
        log.debug("DB_CONSTRAINT_VIOLATION: " + resources.getString("DB_CONSTRAINT_VIOLATION"));      
    }

    /**
     * loadFile
     */
    public void loadFile(){
        //String fileName = "C:\\dev\\jdev\\jdev_10333\\work\\RACA\\Model\\classes\\gov\\usda\\fs\\iweb\\raca\\model\\exception\\AppErrorMessages.xml";
        //FileInputStream fis = new FileInputStream(fileName);
        try {
            java.net.URL url  = getClass().getClassLoader().getResource("AppErrorMessages.xml");
            //java.net.URL url  = getClass().getClassLoader().getResource("AppErrorMessagesP.properties");
            //FileInputStream fis = new FileInputStream(searchFile("AppErrorMessages.xml"));
            if (url != null){
                log.debug("url.getFile(): " + url.getFile()); 
                FileInputStream fis = new FileInputStream(url.getFile());
                //FileInputStream fis = new FileInputStream("gov.usda.fs.nrm.gacommon.model.exception.AppErrorMessagesP");
                getProp().loadFromXML(fis);
                getProp().list(System.out);
                log.debug("ORA-123: " + prop.getProperty("ORA-123"));
                //
                //log.debug()
                //RacaErrorMessages errorMsg = new RacaErrorMessages();
                
                //RacaErrorMessages.
                
                //log.debug("errorMsg.getString(\"DB_CONSTRAINT_VIOLATION\"): " + errorMsg.getString("DB_CONSTRAINT_VIOLATION"));
                //errorMsg.getString("DB_CONSTRAINT_VIOLATION");
                
            }
            else
                log.debug("File not found");   
        }
        catch(Exception e){
            log.debug(e.getMessage());
            System.out.println(e);
        }
    }

    /**
     * xpathFile
     */
    public void xpathFile(){
        XPathFactory  factory = XPathFactory.newInstance();
        XPath xPath = factory.newXPath();
        
        try {
            File xmlDocument = new File("C:/dev/jdev/jdev_10333/work/RACA/Model/src/AppErrorMessages.xml");
            //File xmlDocument = new File("C:\\dev\\jdev\\jdev_10333\\work\\RACA\\Model\\src\\catalog.xml");
            InputSource inputSource = new InputSource(new FileInputStream(xmlDocument));            

            String keyValue = "ORA-178";
            XPathExpression  xPathExpression= xPath.compile("/errorlist/entry");
            XPathExpression  xPathExpression2= xPath.compile("/errorlist/entry/@key");
            XPathExpression  xPathExpression3= xPath.compile("/errorlist/entry[@key='ORA-123']");
            XPathExpression  xPathExpression4= xPath.compile("/errorlist/entry[@key='ORA-178']/message");
            XPathExpression  xPathExpression5= xPath.compile("/errorlist/entry[@key='"+keyValue+"']/code");
            //XPathExpression  xPathExpression6=xPath.compile("/catalog/journal/article[@date='January-2004']/title");
             
            String msg = xPathExpression3.evaluate(inputSource);
            log.debug("msg: " + msg);     
            //String number = xPathExpression6.evaluate(inputSource);
            //log.debug("number: " + number);
            
            inputSource = new InputSource(new FileInputStream(xmlDocument));
            String newMsg = xPath.evaluate("/errorlist/entry[@key='"+keyValue+"']/message", inputSource);
            log.debug("newMsg: " + newMsg);       
        }
        catch(Exception e){
            log.debug("context",e);
            //e.printStackTrace();        
        }
    }

    /**
     * getErrorMsg
     * @param keyValue
     * @return
     */
    public String getErrorMsg(String keyValue){
        String ret = null;
        XPathFactory  factory = XPathFactory.newInstance();
        XPath xPath = factory.newXPath();        
        try {
            InputSource inputSource = new InputSource(new FileInputStream(getFilePath()));            
            XPathExpression  xPathExpression = xPath.compile("/errorlist/entry[@key='"+keyValue+"']/message");    
            String msg = xPathExpression.evaluate(inputSource);
            log.debug("msg: " + msg);  
            ret = msg;
        }
        catch(Exception e){
            log.debug("getErrorMsg",e);        
            //e.printStackTrace();
        }
        return ret;
    }

    /**
     * getErrorCode
     * @param keyValue
     * @return
     */
    public String getErrorCode(String keyValue){
        String ret = null;
        XPathFactory  factory = XPathFactory.newInstance();
        XPath xPath = factory.newXPath();        
        try {
            InputSource inputSource = new InputSource(new FileInputStream(getFilePath()));            
            XPathExpression  xPathExpression = xPath.compile("/errorlist/entry[@key='"+keyValue+"']/code");    
            String msg = xPathExpression.evaluate(inputSource);
            log.debug("msg: " + msg);  
            ret = msg;
        }
        catch(Exception e){
            log.debug("getErrorCode",e);
            //e.printStackTrace();
        }
        return ret;
    }
    
    /**
     * main
     * @param args
     * @throws Exception
     */
    public static void main(String args[]) throws Exception {
        ErrorMessageHandler msgHandler = new ErrorMessageHandler();
        //msgHandler.loadFile();
        //msgHandler.loadResource();
        //msgHandler.xpathFile();
        msgHandler.getErrorMsg("ORA-178");
        msgHandler.getErrorCode("ORA-178");
    }

    public void setProp(Properties prop) {
        this.prop = prop;
    }

    public Properties getProp() {
        return prop;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getFilePath() {   
        if (filePath == null){
            setFilePath(searchFile(FILE_NAME));
        }   
        return filePath;
    }
}
