package gov.usda.fs.iweb.raca.common.view.bean;

import gov.usda.fs.nrm.framework.view.utils.IWebViewUtils;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.RacaReqsViewRowImpl;
import gov.usda.fs.iweb.raca.common.view.utils.Utils;

import java.util.Hashtable;
import java.util.Iterator;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;
import oracle.jbo.ViewObject;
import oracle.jbo.server.ViewRowSetImpl;
import oracle.jbo.uicli.binding.JUCtrlValueBindingRef;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import oracle.adf.view.rich.component.rich.input.RichInputText;
import oracle.adf.view.rich.component.rich.data.RichTable;
import org.apache.myfaces.trinidad.component.core.input.CoreSelectBooleanCheckbox;
import org.apache.myfaces.trinidad.context.RequestContext;
import org.apache.myfaces.trinidad.event.LaunchEvent;
import org.apache.myfaces.trinidad.model.RowKeySet;

public class StatusDialogBean extends RacaBean {
    private static Logger log = LogManager.getLogger(StatusDialogBean.class);

    public String statusCmdId;
    public String dialogHeader;
    public String dialogFooter;
    public String dialogDate;
    public String dialogActorLabel;
    public String dialogActor;
    public String dialogEmailMsg;
    public String dialogEmailChkLabel;
    public String dialogEmailChkValue;
    public String dialogEmailAddress;    
    public Boolean dialogEmailChkEnabled;
    public Boolean dialogEmailChkReadOnly;
    private Hashtable dialogProp;
    private RichInputText comments;
    private RichInputText emailRecipients;
    private CoreSelectBooleanCheckbox emailCheckBox;
    private RichTable contacttable;
    public Boolean contacttableRendered;
    public Boolean renderEmailpromp;

    public StatusDialogBean() {

//        AdfFacesContext afContext = AdfFacesContext.getCurrentInstance();
//        String dialogH = afContext.getProcessScope().get("dialogHeader").toString();
//        if (log.isDebugEnabled()) {          
//            log.debug("StatusDialogBean().constructor:dialogH: " + dialogH);
//        }

    }

     /**
      * statusDialogLaunch
      * @param launchEvent
      */
     public void statusDialogLaunch(LaunchEvent launchEvent) {
    
         dialogProp = new Hashtable();   
         dialogProp.put("cmdSubmitted",new String[]{"Submit Request","Submit Request","","Submitted By","Send Email","unchecked","Collection Req","The request was submitted.",""});
         dialogProp.put("cmdRejected",new String[]{"Reject Request","Reject Request","","Rejected By","Send Email","checked","Collection Req","The request was rejected.",""});
         dialogProp.put("cmdRetrieved",new String[]{"Retrieve Request","Retrieve Request","","Retrieved By","Send Email","unchecked","Collection Req","The request was retrieved.",""});
         dialogProp.put("cmdPending",new String[]{"Request Pending","Request Pending","","Submitted By","Send Email","unchecked","Collection Req","The request was set to pending.",""});
         dialogProp.put("cmdActive",new String[]{"Activate Request","Activate Request","","Submitted By","Send Email","checked","Collection Req","The request was set to active.",""});
         dialogProp.put("cmdClosing",new String[]{"Request Closing","Request Closing","","Submitted By","Send Email","unchecked","Collection Req","The request was set to closing",""});
         dialogProp.put("cmdCustClosed",new String[]{"Customer Close Request","Customer Close Request","","Submitted By","Send Email","checked","Collection Req","The request was closed by customer",""});
         dialogProp.put("cmdClosed",   new String[]{"Close Request",          "Close Request","",         "Submitted By","Send Email","checked","Collection Req","The request was closed",""});
         dialogProp.put("cmdJCSend",new String[]{"Send Job Code Notification","Send","","Sent By","Send Email","checked","Job Code Notif","The Job Code Notification was sent.",""});
       
         dialogProp.put("cmdJumpToPending",new String[]{"Request Pending","Request Pending","","Submitted By","Send Email","unchecked","Collection Req","The request was set to pending.",""});
         dialogProp.put("cmdJumpToActive",new String[]{"Activate Request","Activate Request","","Submitted By","Send Email","unchecked","Collection Req","The request was set to active.",""});
       
         FacesContext context = FacesContext.getCurrentInstance();       
         setStatusCmdId(launchEvent.getComponent().getClientId(context));
             
         if (getStatusCmdId() != null){             
             // Default display values -- retrieve from Hashtable dialogProp
             String[] currentDialog = (String[]) dialogProp.get(getStatusCmdId());
             setDialogHeader(currentDialog[0]);                                  // Dialog Header   
             setDialogFooter(currentDialog[1]);                                  // Dialog Footer
             setDialogActorLabel(currentDialog[3]);                              // Actor Label
             setDialogEmailMsg(currentDialog[7]);                                // Email message for Dialog driven emails
              // set current date
              setDialogDate(Utils.getCurrentDateAsString());    
              
             String sReroutePrompt = currentDialog[2];                           // Prompt for Reroute field
             String sRerouteRendered = sReroutePrompt == null || "".equals(sReroutePrompt) ? "false" : "true";   // Indicates whether Reroute is displayed
             String sActorValue = "";                                                  // Current Actor
             setDialogEmailChkLabel(currentDialog[4]);                                 // Prompt for Checkbox
             setDialogEmailChkValue(currentDialog[5]);                                 // Value of Checkbox                                  
             
             // set value of check box
              if(currentDialog[5].equals("unchecked"))
                  setRenderEmailpromp(new Boolean("false"));
                 else
                   setRenderEmailpromp(new Boolean("true"));
                   
             if ("checked".equalsIgnoreCase(getDialogEmailChkValue())) 
                 setDialogEmailChkEnabled(new Boolean("true"));
             else
                 setDialogEmailChkEnabled(new Boolean("false"));

             // pre set field values
             setDialogEmailChkReadOnly(new Boolean("false"));
             if ("cmdRejected".equalsIgnoreCase(getStatusCmdId())){
                 setDialogEmailChkReadOnly(new Boolean("true"));
                 //setDialogEmailAddress(getRacaService().getEmailAddress("REVIEW"));
             }
             else if ("cmdClosed".equalsIgnoreCase(getStatusCmdId())||"cmdCustClosed".equalsIgnoreCase(getStatusCmdId()))  {
                 setDialogEmailChkReadOnly(new Boolean("true"));
                 // 5/2011 gpetrake DEF007002 added 'BA','PRC','RAC','GAT'
                // String[] emailList = new String[]{"REVIEW","BUDGET","PA","PRC","RAC","GAT"};
               //  setDialogEmailAddress(buildMulitEmailAddress(emailList));                
//                 getRacaService().getEmailAddress("REVIEW"));
             }   
              if("cmdActive".equalsIgnoreCase(getStatusCmdId()) || "cmdRejected".equalsIgnoreCase(getStatusCmdId()) || "cmdCustClosed".equalsIgnoreCase(getStatusCmdId()) || "cmdClosed".equalsIgnoreCase(getStatusCmdId()))
                setContacttableRendered(Boolean.TRUE);
             
             launchEvent.getDialogParameters().put("statusCmdId", getStatusCmdId()); 
             launchEvent.getDialogParameters().put("dialogHeader", getDialogHeader());    
             launchEvent.getDialogParameters().put("dialogFooter", getDialogFooter()); 
             launchEvent.getDialogParameters().put("dialogDate", getDialogDate()); 
             launchEvent.getDialogParameters().put("dialogActorLabel", getDialogActorLabel()); 
             launchEvent.getDialogParameters().put("dialogEmailMsg", getDialogEmailMsg()); 
             launchEvent.getDialogParameters().put("dialogEmailChkLabel", getDialogEmailChkLabel()); 
             launchEvent.getDialogParameters().put("dialogEmailChkEnabled", getDialogEmailChkEnabled()); 
             launchEvent.getDialogParameters().put("dialogEmailChkReadOnly", getDialogEmailChkReadOnly()); 
             launchEvent.getDialogParameters().put("dialogEmailAddress", getDialogEmailAddress()); 
             launchEvent.getDialogParameters().put("contacttableRendered", contacttableRendered);
             launchEvent.getDialogParameters().put("renderEmailpromp", getRenderEmailpromp());
         }
         
         if (log.isDebugEnabled()) {          
             log.debug("statusDialogLaunch:sCmdId: " + getStatusCmdId());
             log.debug("statusDialogLaunch:getEmailAddress(REVIEW): " + getRacaService().getEmailAddress("REVIEW"));
         }
     }

    /**
     * okReturnAction
     * @param actionEvent
     */
    /* public void okReturnAction(ActionEvent actionEvent) 
         
         {
             String RecipientsList = "";
             String Email = "";
             String racareqRowcn = "";
             Email = getSelectedUsers();
             log.debug((new StringBuilder()).append("start:okReturnAction:actionEvent ").append(actionEvent.getSource()).toString());
             AdfFacesContext afContext = AdfFacesContext.getCurrentInstance();
                     setStatusCmdId(afContext.getProcessScope().get("statusCmdId").toString());
             setDialogEmailMsg(afContext.getProcessScope().get("dialogEmailMsg").toString()); 
             boolean errFound = false;
             ViewObject view = getRacaService().findViewObject("RacaReqsView");
             RacaReqsViewRowImpl racaReqRow = (RacaReqsViewRowImpl)view.getCurrentRow();
             if(racaReqRow != null)
                 racareqRowcn = racaReqRow.getCn();
             IWebViewUtils.commitNoMessage();
             getRacaService().sync();
                 
             if (log.isDebugEnabled()) {          

                 log.debug("okReturnAction:comments: " + getComments().getValue());
                 log.debug("okReturnAction:getStatusCmdId: " + getStatusCmdId());
             } 
              String status = getRacaService().getRacaReqStatusCode();
             String email_recipients = (String)getEmailRecipients().getValue() != null ? (String)getEmailRecipients().getValue() : "";
             if(getEmailCheckBox().isSelected() && "".equals(Email) && "".equals(email_recipients))
             {
                 errFound = true;
                 String message = "Please select a contact or Enter Email address in the Primary Recipients, if contact is already selected please check whether email address is entered for the contact ";
                 IWebViewUtils.addMessage(FacesMessage.SEVERITY_ERROR, message, (String)null);
             } else
             if ("cmdSubmitted".equalsIgnoreCase(getStatusCmdId()))
             {          
                if (!getRacaService().isOnePayerYes ("GA-COOPERATOR"))
                {
                    errFound = true;
                    String message = "One cooperator must have payer equal to Yes. Press cancel and fix the data in Cooperators Tab before continuing.";
                    IWebViewUtils.addMessage(FacesMessage.SEVERITY_ERROR, message, (String) null);
                } else 
                {   
                    errFound = false;        
                    getRacaService().setRacaRequestStatus(null,"NEW","SUBMITTED",(String)getComments().getValue());
                }   
            }
             else if ("cmdRejected".equalsIgnoreCase(getStatusCmdId())){
                 getRacaService().setRacaRequestStatus(null,"SUBMITTED","REJECTED",(String)getComments().getValue());
             }
             else if ("cmdRetrieved".equalsIgnoreCase(getStatusCmdId())){
                 getRacaService().setRacaRequestStatus(null,"SUBMITTED","RETRIEVED",(String)getComments().getValue());
             }      
             else if ("cmdPending".equalsIgnoreCase(getStatusCmdId())){
               if ("NEW".equals(status))
               {
                 getRacaService().setRacaRequestStatus(null,"NEW","SUBMITTED",(String)getComments().getValue());                
                 getRacaService().setRacaRequestStatus(null,"SUBMITTED","RETRIEVED",(String)getComments().getValue());
               }
                 getRacaService().setRacaRequestStatus(null,"RETRIEVED","PENDING",(String)getComments().getValue());
             }
             else if ("cmdActive".equalsIgnoreCase(getStatusCmdId())){
                 //check Decision radio button        
              if (!getRacaService().isOnePayerYes ("GA-COOPERATOR"))
                 {
                     errFound = true;
                     String message = "One cooperator must have payer equal to Yes. Press cancel and fix the data in Cooperators Tab before continuing.";
                     IWebViewUtils.addMessage(FacesMessage.SEVERITY_ERROR, message, (String) null);
                                     }
                 else 
                 {  errFound = false;
                    //check that Collection Type is not blank
                     if ("NEW".equals(status))
                     {
                       getRacaService().setRacaRequestStatus(null,"NEW","SUBMITTED",(String)getComments().getValue());
                       getRacaService().setRacaRequestStatus(null,"SUBMITTED","RETRIEVED",(String)getComments().getValue());
                       getRacaService().setRacaRequestStatus(null,"RETRIEVED","PENDING",(String)getComments().getValue());
                     }
                     getRacaService().setRacaRequestStatus(null,"PENDING","ACTIVE",(String)getComments().getValue());
                 }
             }

             else if ("cmdClosing".equalsIgnoreCase(getStatusCmdId())){
                 getRacaService().setRacaAgmtStatus(null,"ACTIVE","CLOSING",(String)getComments().getValue());
             }   

             else if ("cmdCustClosed".equalsIgnoreCase(getStatusCmdId()) || "cmdClosed".equalsIgnoreCase(getStatusCmdId())) {

                 if (getRacaService().isCloseoutPending())
                 {
                     errFound = true;
                     String message = "Unresolved Agreement Closure Pending. Press cancel and enter Resolved Date before continuing.";
                     IWebViewUtils.addMessage(FacesMessage.SEVERITY_ERROR, message, (String) null);
                 }
                 else 
                 {   
                  errFound = false;
                     if ("cmdCustClosed".equalsIgnoreCase(getStatusCmdId())) {
                        getRacaService().setRacaAgmtStatus(null,"CLOSING","CUSTOMER CLOSED",(String)getComments().getValue());
                     }   
                 else // assume cmdClosed".equalsIgnoreCase(getStatusCmdId()))
                     {
                  getRacaService().setRacaAgmtStatus(null,"CLOSING","CLOSED",(String)getComments().getValue());
        }
                 }
             }    
             else if ("cmdJCSend".equalsIgnoreCase(getStatusCmdId())){
                 getRacaService().setJobCodeNotifStatus(null,"NEW","SENT",(String)getComments().getValue());

             }
            else 
                 log.debug("Command Button not found:getStatusCmdId: " + getStatusCmdId());
                    if(!errFound)
                           {
                               log.debug((new StringBuilder()).append("getEmailRecipients: ").append(getEmailRecipients().getValue()).toString());
                               log.debug((new StringBuilder()).append("getEmailCheckBox: ").append(getEmailCheckBox().isSelected()).toString());
                               if("".equals(email_recipients) && !"".equals(Email))
                                   RecipientsList = Email;
                               else
                               if(!"".equals(email_recipients) && "".equals(Email))
                                   RecipientsList = email_recipients.toUpperCase();
                               else
                                   RecipientsList = email_recipients.toUpperCase().concat((new StringBuilder()).append(",").append(Email).toString());
                               if(getEmailCheckBox().isSelected() && (!"".equals(email_recipients) || !Email.equals("")))
                                      if ("cmdClosing".equalsIgnoreCase(getStatusCmdId())|| "cmdCustClosed".equalsIgnoreCase(getStatusCmdId())
                      || "cmdClosed".equalsIgnoreCase(getStatusCmdId())){
                       // Added Standard Closed Message 
                      if ("cmdClosed".equalsIgnoreCase(getStatusCmdId())) {
                        String closedMsg = "RACA has completed all closeout steps for this agreement. At this time, all financial activity is complete and RACA has placed the Collections tab in Closed status." + 
                                          System.getProperty("line.separator") + " The FS-6500-243 Closeout Request/Notification form is attached to the agreement in I-Web for your review. This agreement may now be closed with the cooperator and placed in G&A Closed status";
                          setDialogEmailMsg(closedMsg);                                     
                      }                                     
                      else if ("cmdCustClosed".equalsIgnoreCase(getStatusCmdId())) {
                        String closedMsg = "RACA has reviewed this agreement and determined that all customer service related objectives have been met.  At this time, there are no unbilled costs or open receivables and collections equal expenditures." +
                                             System.getProperty("line.separator") + "  RACA has placed the Collections tab in Customer Closed status. The FS-6500-243 Closeout Request/Notification form is attached to the agreement in I-Web for your review.  This agreement may now be closed with the cooperator and placed in G&A Closed status in I-Web.";
                        setDialogEmailMsg(closedMsg);
                      }
                       getRacaService().sendRacaAgmtEmail("I-Web@iweb.fs.usda.gov", (String)getEmailRecipients().getValue(), 
                                                         "RACA Notification", getDialogEmailMsg(), (String)getComments().getValue());
                   }
                   else if ("cmdJCSend".equalsIgnoreCase(getStatusCmdId())){
                       String jobCodeNotifMsg = "The job code(s) for this agreement have been established and spending is authorized.";
                       setDialogEmailMsg(jobCodeNotifMsg);
                       getRacaService().sendRacaReqEmail("I-Web@iweb.fs.usda.gov", (String)getEmailRecipients().getValue(), 
                                                         "RACA Notification", getDialogEmailMsg(), (String)getComments().getValue()); 
                   }
                   else{
                       getRacaService().sendRacaReqEmail("I-Web@iweb.fs.usda.gov", (String)getEmailRecipients().getValue(), 
                                                         "RACA Notification", getDialogEmailMsg(), (String)getComments().getValue());                
                   }
               }

               IWebViewUtils.commitNoMessage();
               getRacaService().sync();
               AdfFacesContext.getCurrentInstance().returnFromDialog(Boolean.TRUE, null);
            }*/
         
         
    public void okReturnAction(ActionEvent actionEvent)
        {
            String RecipientsList = "";
            String Email = "";
            String racareqRowcn = "";
            Email = getSelectedUsers();
            log.debug((new StringBuilder()).append("start:okReturnAction:actionEvent ").append(actionEvent.getSource()).toString());
            RequestContext afContext = RequestContext.getCurrentInstance();
            setStatusCmdId(afContext.getProcessScope().get("statusCmdId").toString());
            setDialogEmailMsg(afContext.getProcessScope().get("dialogEmailMsg").toString());
            boolean errFound = false;
            ViewObject view = getRacaService().findViewObject("RacaReqsView");
            RacaReqsViewRowImpl racaReqRow = (RacaReqsViewRowImpl)view.getCurrentRow();
            if(racaReqRow != null)
                racareqRowcn = racaReqRow.getCn();
            IWebViewUtils.commitNoMessage();
            getRacaService().sync();
            if(log.isDebugEnabled())
            {
                log.debug((new StringBuilder()).append("okReturnAction:comments: ").append(getComments().getValue()).toString());
                log.debug((new StringBuilder()).append("okReturnAction:getStatusCmdId: ").append(getStatusCmdId()).toString());
            }
            log.debug("BEFORE THE STATUS CODE"+getRacaService().toString());
            String status = getRacaService().getRacaReqStatusCode();
            log.debug("After THE STATUS CODE"+getRacaService().toString());
            String email_recipients = (String)getEmailRecipients().getValue() != null ? (String)getEmailRecipients().getValue() : "";
            if(getEmailCheckBox().isSelected() && "".equals(Email) && "".equals(email_recipients))
            {
                errFound = true;
                String message = "Please select a contact or Enter Email address in the Primary Recipients, if contact is already selected please check whether email address is entered for the contact ";
                IWebViewUtils.addMessage(FacesMessage.SEVERITY_ERROR, message, (String)null);
            } else
            if("cmdSubmitted".equalsIgnoreCase(getStatusCmdId()))
            {
               String FedIdType = getRacaService().getFedIdType();
               String ProgrmResponsibilityType = getRacaService().getProgrmResponsibilityType();               
                if(!getRacaService().isOnePayerYes("GA-COOPERATOR"))
                {
                    errFound = true;
                    String message = "One cooperator must have payer equal to Yes. Press cancel and fix the data in Cooperators Tab before continuing.";
                    IWebViewUtils.addMessage(FacesMessage.SEVERITY_ERROR, message, (String)null);
                } 
                else if ((FedIdType != null && "IA".equals(FedIdType)) &&                    
                         (ProgrmResponsibilityType != null && "INCOMING FUNDING AGREEMENT".equals(ProgrmResponsibilityType))){
                        if (getRacaService().getCooperatorAgreementNumber() == null){
                            errFound = true;
                            String message = "Cooperator Number must be entered. Press cancel and fix the data before continuing.";
                            IWebViewUtils.addMessage(FacesMessage.SEVERITY_ERROR, message, (String)null);                            
                        }
                        else if (getRacaService().getRacaReqObligatingDocNo() == null){
                            errFound = true;
                            String message = "Missing OF Obligating Doc No. Press cancel and fix the data before continuing.";
                            IWebViewUtils.addMessage(FacesMessage.SEVERITY_ERROR, message, (String)null);                                                        
                        }
                        else{
                            errFound = false;
                            getRacaService().setRacaRequestStatus(null, "NEW", "SUBMITTED", (String)getComments().getValue());
                        }                                            
                }
                else{
                    errFound = false;
                    getRacaService().setRacaRequestStatus(null, "NEW", "SUBMITTED", (String)getComments().getValue());
                }
            } else
            if("cmdRejected".equalsIgnoreCase(getStatusCmdId()))
                getRacaService().setRacaRequestStatus(null, "SUBMITTED", "REJECTED", (String)getComments().getValue());
            else
            if("cmdRetrieved".equalsIgnoreCase(getStatusCmdId()))
                getRacaService().setRacaRequestStatus(null, "SUBMITTED", "RETRIEVED", (String)getComments().getValue());
            else
            if("cmdPending".equalsIgnoreCase(getStatusCmdId()))
            {
                if("NEW".equals(status))
                {
                    getRacaService().setRacaRequestStatus(null, "NEW", "SUBMITTED", (String)getComments().getValue());
                    getRacaService().setRacaRequestStatus(null, "SUBMITTED", "RETRIEVED", (String)getComments().getValue());
                }
                getRacaService().setRacaRequestStatus(null, "RETRIEVED", "PENDING", (String)getComments().getValue());
            } else
            if("cmdActive".equalsIgnoreCase(getStatusCmdId()))
            {
                if(!getRacaService().isOnePayerYes("GA-COOPERATOR"))
                {
                    errFound = true;
                    String message = "One cooperator must have payer equal to Yes. Press cancel and fix the data in Cooperators Tab before continuing.";
                    IWebViewUtils.addMessage(FacesMessage.SEVERITY_ERROR, message, (String)null);
                } else
                {
                    errFound = false;
                    if("NEW".equals(status))
                    {
                        getRacaService().setRacaRequestStatus(null, "NEW", "SUBMITTED", (String)getComments().getValue());
                        getRacaService().setRacaRequestStatus(null, "SUBMITTED", "RETRIEVED", (String)getComments().getValue());
                        getRacaService().setRacaRequestStatus(null, "RETRIEVED", "PENDING", (String)getComments().getValue());
                    }
                    getRacaService().setRacaRequestStatus(null, "PENDING", "ACTIVE", (String)getComments().getValue());
                }
            } else
            if("cmdClosing".equalsIgnoreCase(getStatusCmdId()))
                getRacaService().setRacaAgmtStatus(null, "ACTIVE", "CLOSING", (String)getComments().getValue());
            else
            if("cmdCustClosed".equalsIgnoreCase(getStatusCmdId()) || "cmdClosed".equalsIgnoreCase(getStatusCmdId()))
            {
                if(getRacaService().isCloseoutPending())
                {
                    errFound = true;
                    String message = "Unresolved Agreement Closure Pending. Press cancel and enter Resolved Date before continuing.";
                    IWebViewUtils.addMessage(FacesMessage.SEVERITY_ERROR, message, (String)null);
                } else
                {
                    errFound = false;
                    if("cmdCustClosed".equalsIgnoreCase(getStatusCmdId()))
                        getRacaService().setRacaAgmtStatus(null, "CLOSING", "CUSTOMER CLOSED", (String)getComments().getValue());
                    else
                        getRacaService().setRacaAgmtStatus(null, "CLOSING", "CLOSED", (String)getComments().getValue());
                }
            } else
            if("cmdJCSend".equalsIgnoreCase(getStatusCmdId()))
                getRacaService().setJobCodeNotifStatus(null, "NEW", "SENT", (String)getComments().getValue());
            else
                log.debug((new StringBuilder()).append("Command Button not found:getStatusCmdId: ").append(getStatusCmdId()).toString());
            if(!errFound)
            {
                log.debug((new StringBuilder()).append("getEmailRecipients: ").append(getEmailRecipients().getValue()).toString());
                log.debug((new StringBuilder()).append("getEmailCheckBox: ").append(getEmailCheckBox().isSelected()).toString());
                if("".equals(email_recipients) && !"".equals(Email))
                    RecipientsList = Email;
                else
                if(!"".equals(email_recipients) && "".equals(Email))
                    RecipientsList = email_recipients.toUpperCase();
                else
                    RecipientsList = email_recipients.toUpperCase().concat((new StringBuilder()).append(",").append(Email).toString());
                if(getEmailCheckBox().isSelected() && (!"".equals(email_recipients) || !Email.equals("")))
                    if("cmdClosing".equalsIgnoreCase(getStatusCmdId()) || "cmdCustClosed".equalsIgnoreCase(getStatusCmdId()) || "cmdClosed".equalsIgnoreCase(getStatusCmdId()))
                    {
                        if("cmdClosed".equalsIgnoreCase(getStatusCmdId()))
                        {
                            String closedMsg = (new StringBuilder()).append("RACA has completed all closeout steps for this agreement. At this time, all financial activity is complete and RACA has placed the Collections tab in Closed status.").append(System.getProperty("line.separator")).append(" The FS-6500-243 Closeout Request/Notification form is attached to the agreement in I-Web for your review. This agreement may now be closed with the cooperator and placed in G&A Closed status").toString();
                            setDialogEmailMsg(closedMsg);
                        } else
                        if("cmdCustClosed".equalsIgnoreCase(getStatusCmdId()))
                        {
                            String closedMsg = (new StringBuilder()).append("RACA has reviewed this agreement and determined that all customer service related objectives have been met.  At this time, there are no unbilled costs or open receivables and collections equal expenditures.").append(System.getProperty("line.separator")).append("  RACA has placed the Collections tab in Customer Closed status. The FS-6500-243 Closeout Request/Notification form is attached to the agreement in I-Web for your review.  This agreement may now be closed with the cooperator and placed in G&A Closed status in I-Web.").toString();
                            setDialogEmailMsg(closedMsg);
                        }
                        getRacaService().sendRacaAgmtEmail("I-Web@iweb.fs.usda.gov", RecipientsList, "RACA Notification", getDialogEmailMsg(), (String)getComments().getValue(), getStatusCmdId());
                    } else
                    if("cmdJCSend".equalsIgnoreCase(getStatusCmdId()))
                    {
                        String jobCodeNotifMsg = "The job code(s) for this agreement have been established and spending is authorized.";
                        setDialogEmailMsg(jobCodeNotifMsg);
                        getRacaService().sendRacaReqEmail("I-Web@iweb.fs.usda.gov", email_recipients, "RACA Notification", getDialogEmailMsg(), (String)getComments().getValue(), getStatusCmdId(), racareqRowcn);
                    } else
                    {
                        getRacaService().sendRacaReqEmail("I-Web@iweb.fs.usda.gov", RecipientsList, "RACA Notification", getDialogEmailMsg(), (String)getComments().getValue(), getStatusCmdId(), racareqRowcn);
                    }
                RequestContext.getCurrentInstance().returnFromDialog(Boolean.TRUE, null);
            }
        }

        
    

    /**
     * Build an email address list comma delimited. Trim comma after last character
     */
        public String buildMulitEmailAddress(String[] list) {
            StringBuilder sbEmailAddress = new StringBuilder();
            String sAddress;
            
            for (int i = 0; i < list.length; i++)
            { 
                sAddress = getRacaService().getEmailAddress(list[i]);            
                if (sAddress != null) {
                 sbEmailAddress.append(sAddress).append(",");
                }
            }  
            if (sbEmailAddress.length() > 1) {
               // return email address trim trailing comma(,)
              return sbEmailAddress.substring(0,sbEmailAddress.length()-1);
            }
            else return null;
                     
        }

    /**
     * cancelReturnAction
     * @param actionEvent
     */
    public void cancelReturnAction(ActionEvent actionEvent) {
        if (log.isDebugEnabled()) {          
            log.debug("cancelReturnAction:ActionEvent.getPhaseId(): " + actionEvent.getPhaseId());
        }
        RequestContext.getCurrentInstance().returnFromDialog(null, null);
    }

    public void setStatusCmdId(String statusCmdId) {
        this.statusCmdId = statusCmdId;
    }

    public String getStatusCmdId() {
        return statusCmdId;
    }

    public void setDialogHeader(String dialogHeader) {
        this.dialogHeader = dialogHeader;
    }

    public String getDialogHeader() {
        return dialogHeader;
    }

    public void setDialogFooter(String dialogFooter) {
        this.dialogFooter = dialogFooter;
    }

    public String getDialogFooter() {
        return dialogFooter;
    }

    public void setComments(RichInputText comments) {
        this.comments = comments;
    }

    public RichInputText getComments() {
        return comments;
    }

    public void setDialogDate(String dialogDate) {
        this.dialogDate = dialogDate;
    }

    public String getDialogDate() {
        return dialogDate;
    }

    public void setEmailRecipients(RichInputText emailRecipients) {
        this.emailRecipients = emailRecipients;
    }

    public RichInputText getEmailRecipients() {
        return emailRecipients;
    }

    public void setDialogActor(String dialogActor) {
        this.dialogActor = dialogActor;
    }

    public String getDialogActor() {
        return dialogActor;
    }

    public void setDialogActorLabel(String dialogActorLabel) {
        this.dialogActorLabel = dialogActorLabel;
    }

    public String getDialogActorLabel() {
        return dialogActorLabel;
    }

    public void setDialogEmailMsg(String dialogEmailMsg) {
        this.dialogEmailMsg = dialogEmailMsg;
    }

    public String getDialogEmailMsg() {
        return dialogEmailMsg;
    }

    public void setEmailCheckBox(CoreSelectBooleanCheckbox emailCheckBox) {
        this.emailCheckBox = emailCheckBox;
    }

    public CoreSelectBooleanCheckbox getEmailCheckBox() {
        return emailCheckBox;
    }

    public void setDialogEmailChkLabel(String dialogEmailChkLabel) {
        this.dialogEmailChkLabel = dialogEmailChkLabel;
    }

    public String getDialogEmailChkLabel() {
        return dialogEmailChkLabel;
    }

    public void setDialogEmailChkValue(String dialogEmailChkValue) {
        this.dialogEmailChkValue = dialogEmailChkValue;
    }

    public String getDialogEmailChkValue() {
        return dialogEmailChkValue;
    }

    public void setDialogEmailChkEnabled(Boolean dialogEmailChkEnabled) {
        this.dialogEmailChkEnabled = dialogEmailChkEnabled;
    }

    public Boolean getDialogEmailChkEnabled() {
        return dialogEmailChkEnabled;
    }

    public void setDialogEmailChkReadOnly(Boolean dialogEmailChkReadOnly) {
        this.dialogEmailChkReadOnly = dialogEmailChkReadOnly;
    }

    public Boolean getDialogEmailChkReadOnly() {
        return dialogEmailChkReadOnly;
    }

    public void setDialogEmailAddress(String dialogEmailAddress) {
        this.dialogEmailAddress = dialogEmailAddress;
    }

    public String getDialogEmailAddress() {
        return dialogEmailAddress;
    }
    
    public void setContacttable(RichTable contacttable)
      {
          this.contacttable = contacttable;
      }

      public RichTable getContacttable()
      {
          return contacttable;
      }
      
    public void setContacttableRendered(Boolean contacttableRendered)
        {
            this.contacttableRendered = contacttableRendered;
        }

        public Boolean getContacttableRendered()
        {
            return contacttableRendered;
        }

    public void setRenderEmailpromp(Boolean renderEmailpromp)
       {
           this.renderEmailpromp = renderEmailpromp;
       }

       public Boolean getRenderEmailpromp()
       {
           return renderEmailpromp;
       }   
      
    private String getSelectedUsers()
        {
            String Email = "";
            if(contacttable != null)
            {
               
                //RowKeySet  state = contacttable.getSelectionState();
                RowKeySet  state = contacttable.getSelectedRowKeys();
                if(state != null)
                {
                   // Iterator selection = state.getKeySet().iterator();
                    Iterator selection = state.iterator();
                    if(selection != null)
                        while(selection.hasNext()) 
                        {
                            contacttable.setRowKey(selection.next());
                            JUCtrlValueBindingRef binding = (JUCtrlValueBindingRef)contacttable.getRowData();
                            Row row = binding.getRow();
                            if(row != null)
                            {
                                System.out.println((new StringBuilder()).append("=======").append(row.getAttribute("ContCn")).toString());
                                String contcn = (String)row.getAttribute("ContCn");
                                if(row.getAttribute("AddressesView") != null)
                                {
                                    ViewRowSetImpl addview = (ViewRowSetImpl)row.getAttribute("AddressesView");
                                    RowSetIterator Rsi = addview.getRowSetIterator();
                                    Row ValidGAemail =null;  //added
                                   // if(Rsi.first() != null)
                                    while(Rsi.hasNext())
                                    {
                                       ValidGAemail=Rsi.next();
                                        String Row_Email = "";
                                        if((String)ValidGAemail.getAttribute("ElectronicAddress") != null && "GA".equals((String)ValidGAemail.getAttribute("ProgramArea")))
                                           {
                                            Row_Email = (String)ValidGAemail.getAttribute("ElectronicAddress");
                                            System.out.print((new StringBuilder()).append("Email added ").append(Row_Email).toString());
                                            Email = (new StringBuilder()).append(Email).append(Row_Email.toUpperCase()).append(",").toString();
                                            System.out.print(Email);
                                         }
                                    }
                                }
                            }
                        }
                }
            }
            if(Email.length() > 1)
                Email = Email.substring(0, Email.length() - 1);
            return Email;
        }

}
