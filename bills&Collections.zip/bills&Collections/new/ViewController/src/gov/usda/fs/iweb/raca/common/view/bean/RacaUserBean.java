package gov.usda.fs.iweb.raca.common.view.bean;

import gov.usda.fs.nrm.framework.utils.JSFUtils;
import gov.usda.fs.nrm.framework.view.UserBean;


import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import org.apache.log4j.*;

public class RacaUserBean extends RacaBean {
    private static Logger log = LogManager.getLogger(RacaUserBean.class);
    private boolean roleRacaAsc;
    private boolean roleGaSpec; 
    private boolean roleGaPgmApp; 
    private boolean roleAllValid; 
    private boolean roleGaTech;
    private boolean roleGaHelpDesk;  // 6/15/15 Duk added
    private boolean II_GA_Budget;
    private boolean II_GA_PGM_App;
    private boolean II_GA_PGM_Tech;
    private boolean II_GA_ACC_App;
    private boolean II_GA_ACC_Tech;
    private boolean roleGAValid;

    /**
     * RacaUserBean Constructor
     */
    public RacaUserBean() {        
        setSessionVariables();
        processRoles();
    }

    /**
     * processRoles
     */
    public void processRoles(){
        /* 4/10/15 Duk modified
        UserBean userBean = (UserBean) findBean("userBean");
        log.debug("Roles : " + userBean.getRoles()); 
        log.debug("II_RACA_ASC : " + userBean.isInRole("II_RACA_ASC"));
        log.debug("II_GA_SPEC : " + userBean.isInRole("II_GA_SPEC"));
        log.debug("II_GA_PGM_APP : " + userBean.isInRole("II_GA_PGM_APP"));   
        setRoleRacaAsc(userBean.isInRole("II_RACA_ASC"));
        setRoleGaSpec(userBean.isInRole("II_GA_SPEC"));
        setRoleGaPgmApp(userBean.isInRole("II_GA_PGM_APP"));
        if ( isRoleGaSpec() || isRoleGaPgmApp() || isRoleRacaAsc() ){
           setRoleAllValid(true);
        }          
        log.debug("roleAllValid : " + isRoleAllValid()); 
        */
         UserBean userBean = (UserBean) findBean("userBean");
         log.debug("Roles : " + userBean.getRoles()); 
         log.debug("II_RACA_ASC : " + userBean.isInRole("II_RACA_ASC"));
         log.debug("II_GA_SPEC : " + userBean.isInRole("II_GA_SPEC"));
         log.debug("II_GA_TECH : " + userBean.isInRole("II_GA_TECH")); 
         log.debug("II_GA_HELPDESK : " + userBean.isInRole("II_GA_HELPDESK"));
         setRoleRacaAsc(userBean.isInRole("II_RACA_ASC"));
         setRoleGaSpec(userBean.isInRole("II_GA_SPEC"));
         setRoleGaTech(userBean.isInRole("II_GA_TECH"));
         setRoleGAHelpDesk(userBean.isInRole("II_GA_HELPDESK"));
         setII_GA_ACC_Tech(userBean.isInRole("II_GA_ACC_TECH"));
         setII_GA_ACC_App(userBean.isInRole("II_GA_ACC_APP"));
         setII_GA_PGM_Tech(userBean.isInRole("II_GA_PGM_TECH"));
         setII_GA_PGM_App(userBean.isInRole("II_GA_PGM_APP"));
         setII_GA_Budget(userBean.isInRole("II_GA_BUDGET"));
         
        if ( isRoleRacaAsc() || isRoleGaSpec() || isRoleGaTech()){
           setRoleAllValid(true);
        } else {
            setRoleAllValid(false);
        }  
        boolean valid_role;
        valid_role=((userBean.isInRole("II_GA_HELPDESK")) || (userBean.isInRole("II_RACA_ASC")) || (userBean.isInRole("II_GA_SPEC")) || (userBean.isInRole("II_GA_TECH"))) ;
        if( !((isII_GA_ACC_Tech() ||isII_GA_ACC_App() ||isII_GA_PGM_Tech() || isII_GA_PGM_App() ||isII_GA_Budget())  && !valid_role) )
            setRoleGAValid(false);
        else
           setRoleGAValid(true);
         log.debug("roleAllValid : " + isRoleAllValid());  
         
         if(userBean.isInRole("II_GA_HELPDESK")){
             setRoleRacaAsc(true);
             setRoleAllValid(true);
         }
    }

    /**
     * setSessionVariables
     */
    public void setSessionVariables() {
    
        String reportServerName = null;
        reportServerName = (String)JSFUtils.getFromSession("reportServerName");
        if (reportServerName == null){
            // set the report server name
            reportServerName = getRacaService().getReportServerName();
            JSFUtils.storeOnSession("reportServerName",reportServerName);               
        } 
        log.debug("setSessionVariables:reportServerName: " + reportServerName);
    }
    
    public void setRoleGaSpec(boolean roleGaSpec) {
        this.roleGaSpec = roleGaSpec;
    }

    public boolean isRoleGaSpec() {
        return roleGaSpec;
    }

    public void setRoleRacaAsc(boolean roleRacaAsc) {
        this.roleRacaAsc = roleRacaAsc;
    }

    public boolean isRoleRacaAsc() {
        return roleRacaAsc;
    }

    public void setRoleGAHelpDesk(boolean roleGaHelpDesk) {
        this.roleGaHelpDesk = roleGaHelpDesk;
    }

    public boolean isRoleGAHelpDesk() {
        return roleGaHelpDesk;
    }
    
    /**
     * rolesActionListener
     * @param actionEvent
     */
    public void rolesActionListener(ActionEvent actionEvent) {
        resetRoles();
        FacesContext context = FacesContext.getCurrentInstance();       
        String cmdId = actionEvent.getComponent().getClientId(context);
        log.debug("cmdId: " + cmdId);
        if ("formPad:cmdII_RACA_ASC".equalsIgnoreCase(cmdId)){
            setRoleRacaAsc(true);
        }
        else if ("formPad:cmdII_GA_PGM_APP".equalsIgnoreCase(cmdId)){
            setRoleGaPgmApp(false);
        }
        else if ("formPad:cmdII_GA_SPEC".equalsIgnoreCase(cmdId)){
            setRoleGaSpec(true);
        }        
        else if ("formPad:cmdII_GA_TECH".equalsIgnoreCase(cmdId)){
            setRoleGaTech(true);
        }
        else if ("formPad:cmdRACA_ASC_GA_SPEC".equalsIgnoreCase(cmdId)){
            setRoleRacaAsc(true);
            setRoleGaSpec(true);
        }
        else if ("formPad:cmdRACA_GA_PGM_Tech".equalsIgnoreCase(cmdId)){
            setII_GA_ACC_Tech(true);
            setII_GA_PGM_Tech(true);
            setRoleGAValid(true);
        }
        if ( isRoleRacaAsc() || isRoleGaSpec() || isRoleGaTech()){
           setRoleAllValid(true);
        } else {
            setRoleAllValid(false);
        }
        log.debug("toString(): " + toString());
    }
    // 4/10/15 Duk modified
    public void resetRoles(){
        setRoleRacaAsc(false);
        setRoleGaSpec(false);   
        setRoleGaTech(false); 
        setRoleGaPgmApp(false); 
        setRoleGAHelpDesk(false);
    }

    public String toString(){
        StringBuffer sb = new StringBuffer();
        sb.append("RacaUserBean[");
        sb.append("roleRacaAsc: "+roleRacaAsc);
        sb.append(", roleGaSpec:"+roleGaSpec);     
        sb.append(", roleGaPgmApp:"+roleGaPgmApp); 
        sb.append(", roleGaTech:"+roleGaTech); 
        sb.append("]");
        return sb.toString();        
    }

    public void setRoleGaPgmApp(boolean roleGaPgmApp) {
        this.roleGaPgmApp = roleGaPgmApp;
    }

    public boolean isRoleGaPgmApp() {
        return roleGaPgmApp;
    }
    // 4/10/15 Duk added
    public void setRoleGaTech(boolean roleGaTech) {
        this.roleGaTech = roleGaTech;
    }   
    
    public boolean isRoleGaTech() {
        return roleGaTech;
    }    
    //
    public void setRoleAllValid(boolean roleAllValid) {
        this.roleAllValid = roleAllValid;
    }

    public boolean isRoleAllValid() {
        return roleAllValid;
    }

    public void setII_GA_Budget(boolean iI_GA_Budget) {
        this.II_GA_Budget = iI_GA_Budget;
    }

    public boolean isII_GA_Budget() {
        return II_GA_Budget;
    }

    public void setII_GA_PGM_App(boolean iI_GA_PGM_App) {
        this.II_GA_PGM_App = iI_GA_PGM_App;
    }

    public boolean isII_GA_PGM_App() {
        return II_GA_PGM_App;
    }

    public void setII_GA_PGM_Tech(boolean iI_GA_PGM_Tech) {
        this.II_GA_PGM_Tech = iI_GA_PGM_Tech;
    }

    public boolean isII_GA_PGM_Tech() {
        return II_GA_PGM_Tech;
    }

    public void setII_GA_ACC_App(boolean iI_GA_ACC_App) {
        this.II_GA_ACC_App = iI_GA_ACC_App;
    }

    public boolean isII_GA_ACC_App() {
        return II_GA_ACC_App;
    }

    public void setII_GA_ACC_Tech(boolean iI_GA_ACC_Tech) {
        this.II_GA_ACC_Tech = iI_GA_ACC_Tech;
    }

    public boolean isII_GA_ACC_Tech() {
        return II_GA_ACC_Tech;
    }

    public void setRoleGAValid(boolean roleGAValid) {
        this.roleGAValid = roleGAValid;
    }

    public boolean isRoleGAValid() {
        return roleGAValid;
    }
}
