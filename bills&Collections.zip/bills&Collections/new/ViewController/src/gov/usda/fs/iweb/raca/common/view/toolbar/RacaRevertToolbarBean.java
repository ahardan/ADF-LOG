package gov.usda.fs.iweb.raca.common.view.toolbar;

import gov.usda.fs.nrm.framework.view.toolbar.RevertToolBarBean;

import java.io.Serializable;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;


public class RacaRevertToolbarBean extends RevertToolBarBean implements Serializable {

    private static Logger log = LogManager.getLogger(RacaRevertToolbarBean.class);
    @SuppressWarnings("compatibility:7691961728417831897")
    private static final long serialVersionUID = 1L;
    private Map validationMap = new HashMap();

    public RacaRevertToolbarBean() {
        super();
    }

    public String revert() {
        super.revert();

        return null;
    }

    public Boolean getRendered() {
        return super.getRendered();
    }

    public Boolean getDisabled() {
        return super.getDisabled();
    }

    
}
