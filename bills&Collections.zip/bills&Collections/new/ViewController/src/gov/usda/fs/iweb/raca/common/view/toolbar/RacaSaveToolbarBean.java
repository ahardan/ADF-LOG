package gov.usda.fs.iweb.raca.common.view.toolbar;

import gov.usda.fs.nrm.framework.view.toolbar.SaveToolBarBean;
import gov.usda.fs.nrm.framework.view.utils.IWebViewUtils;

import gov.usda.fs.nrm.gacommon.model.service.GACommonServiceImpl;

import java.io.Serializable;

import javax.faces.application.FacesMessage;

import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;

import oracle.jbo.JboException;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class RacaSaveToolbarBean extends SaveToolBarBean implements Serializable{
    private static Logger log = LogManager.getLogger(RacaSaveToolbarBean.class);
    @SuppressWarnings("compatibility:-1878953106124874038")
    private static final long serialVersionUID = 1L;    
    
    private Boolean disabled;    
    
    public RacaSaveToolbarBean() {
        super();
    }

    public void actionListener(javax.faces.event.ActionEvent p1) {
            commit(true);
        }
    
    
//    public Boolean disabled() {
//        Boolean retVal = false;
//        
//        NAMPBean nampBean = ViewUtil.getNampBean();
//        
//        if ( nampBean != null )
//            retVal = nampBean.isPageReadOnly();
//        
//        return retVal;
//
//    }    
    
    public boolean commit(boolean showMessage)
        {
           boolean success = true;
           int commitCount = 0;
           try
           {
//              NampAppBase am = ViewUtil.getNampAppModule();
              GACommonServiceImpl am = (GACommonServiceImpl) IWebViewUtils.getApplicationModule("GACommonService");
              if (am == null)
              {
                 String message = "Application Module null in call to commit. Transaction not commited!";
                 throw new JboException(message);
              }
              else if (am.getTransaction().isDirty())
              {
                 commitCount = 1;
                 log.debug("I'm Commmiting!");
                 am.getTransaction().commit();
                 // Put here for benefits SubmProjBenefitsCalculatedView ExternalFundingLeveraged attributes to refresh 
               //  am.refreshRaca("Save");           
                 if (showMessage)
                 {
                    String message = "The changes have been saved successfully.";
                    IWebViewUtils.addMessage(FacesMessage.SEVERITY_INFO, message, (String) null);
                 }
              }
              else
              {
                 log.debug("I'm Commmiting, But I'm not dirty!");
                 if (showMessage)
                 {
                    String message = "There were no changes to save.";
                    IWebViewUtils.addMessage(FacesMessage.SEVERITY_INFO, message, (String) null);
                 }
              }

           }
           catch (JboException e)
           {
               e.printStackTrace();
                              
              // 10/12/09 Duk added to try to commit again due to locked by other user error message
              if (commitCount == 1)
              {
                 try
                 {
                     GACommonServiceImpl am = (GACommonServiceImpl) IWebViewUtils.getApplicationModule("GACommonService");
                    log.debug("I'm Commmiting again!");
                    am.getTransaction().commit();
                    if (showMessage)
                    {
                       String message = "The changes have been saved successfully.";
                       IWebViewUtils.addMessage(FacesMessage.SEVERITY_INFO, message, (String) null);
                    }
                 }
                 catch (JboException e1)
                 {
                    log.warn("Commit Exception", e1);
                    success = false;
                
                    BindingContext bctx = BindingContext.getCurrent();
                       ((DCBindingContainer)bctx.getCurrentBindingsEntry()).reportException(e1);
                    
                 }
              }
              else
              {
                 log.warn("Commit Exception", e);
                 success = false;
                 IWebViewUtils.addMessage(FacesMessage.SEVERITY_INFO, e.getMessage(), (String) null);
                 //log.debug(e.getMessage());
              }
           }
           finally
           {
              //setLogDateCT();
           }

           return success;
        }
}
