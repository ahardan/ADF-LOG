package gov.usda.fs.iweb.raca.common.view.controller;

import gov.usda.fs.iweb.raca.common.view.utils.OnPageLoadBackingBeanBase;
import gov.usda.fs.nrm.framework.binding.IWebInitialBindingContainer;
import gov.usda.fs.nrm.framework.utils.ADFUtils;
import gov.usda.fs.nrm.framework.utils.JSFUtils;
import gov.usda.fs.nrm.framework.view.utils.IWebViewUtils;
import gov.usda.fs.nrm.framework.view.IWebBaseBackingBean;
import gov.usda.fs.nrm.framework.view.toolbar.ReturnBean;
import gov.usda.fs.iweb.raca.common.view.utils.Utils;

import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.RacaAgmtViewRowImpl;
import  gov.usda.fs.iweb.raca.view.collections.bean.CollectionReqBean;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCIteratorBinding;

import oracle.binding.BindingContainer;

import oracle.jbo.Row;
import oracle.jbo.ViewCriteria;
import oracle.jbo.ViewCriteriaRow;
import oracle.jbo.ViewObject;

import org.apache.log4j.*;

import gov.usda.fs.nrm.framework.view.toolbar.ReturnBean;

public class FilterPageController extends OnPageLoadBackingBeanBase  {

    private static Logger log = LogManager.getLogger(FilterPageController.class);
    private BindingContainer bc = null;
    
    public FilterPageController() {
    }

    /**
     * onPageLoad
     */
    public void onPageLoad() {
      // Base class evaluates #{adfFacesContext.postback} for us
        if (isPostback() == false) {
            log.debug("onPageLoad");
            getRequestVariables();
            //setSessionVariables();
        }  else {  // 4/4/15 Duk added
         //
//         String fp7 = IWebViewUtils.getIWebRequestParameters().getFp7();  
//         if (fp7 != null && fp7.length() > 0) {
//             setReturnDisabled(true);
//         }
        }
        /* 4/20/15 Duk This is for release 1 but commented out for testing release 2
         if (isNewGARequest()) {
             setReturnDisabled(true);
         }   
         */
    }
    
    private boolean isNewGARequest() {
        boolean result = false;
        String fp8 = IWebViewUtils.getIWebRequestParameters().getFp8();  
        
        if (fp8 != null) {
            result = fp8.indexOf(".do") > 0 ? false: true;
        }        
        
        return result;
    }
    

    /**
     * onPagePreRender
     */
    public void onPagePreRender() {
      // Base class evaluates #{adfFacesContext.postback} for us
//       String feaCn = (String) JSFUtils.resolveExpression("#{bindings.Cn.inputValue}");
//       addFeaturesUrlParam(feaCn); 
        log.debug("onPagePreRender");
      }  

    /**
     * getRequestVariables
     */
    public void getRequestVariables() {        
        String fp1 = IWebViewUtils.getIWebRequestParameters().getFp1();
        String fp2 = IWebViewUtils.getIWebRequestParameters().getFp2();
        String fp3 = IWebViewUtils.getIWebRequestParameters().getFp3();
        String fp4 = IWebViewUtils.getIWebRequestParameters().getFp4();
        String fp5 = IWebViewUtils.getIWebRequestParameters().getFp5();        
        //String fp11 = JSFUtils.resolveExpressionAsString("#{param.fp11}");
       
        if (log.isDebugEnabled()) {          
            log.debug("getRequestVariables:fp1: " + fp1);
            log.debug("getRequestVariables:fp2: " + fp2);
            log.debug("getRequestVariables:fp3: " + fp3);
            log.debug("getRequestVariables:fp4: " + fp4);
            log.debug("getRequestVariables:fp5: " + fp5);
            log.debug("getRequestVariables:fp8: " + IWebViewUtils.getIWebRequestParameters().getFp8());
        }        

        
        if ("CREATE_AI".equalsIgnoreCase(fp3)){
            // create new AI
             getRacaService().createRacaAgmt(fp5);
             
//             getRacaService().getTransaction().rollback();
//             //ViewObject vo = getRacaService().findViewObject("RacaAgmtViewIterator");
//             DCIteratorBinding iterator = ADFUtils.findIterator("RacaAgmtViewIterator");            
//             ViewObject vo = iterator.getViewObject();
//             Row row = vo.createRow();
//             vo.insertRow(row);
        }
        else if ("EDIT_AI".equalsIgnoreCase(fp3)){
            // edit AI, add or edit collection requests
            if (!isNullOrEmpty(fp1)){
                getRacaService().setRacaAgmtCurrentRowByCn(fp1);                
            }
            // edit AI SPECIAL_USE_AUTHORIZATION collection request
            if (!isNullOrEmpty(fp5) && fp5.equalsIgnoreCase("SUDS")){
                getRacaService().setRacaAgmtBlankRow(fp5);              
            } 
            // 4/4/15 Duk added for new G&A
//            String fp7 = IWebViewUtils.getIWebRequestParameters().getFp7();  
//            if (fp7 != null && fp7.length() > 0) {
//                setReturnDisabled(true);
//            }
//            if (isNewGARequest()) {
//                setReturnDisabled(true);
//            }
        }
        else if (!isNullOrEmpty(fp4) && fp4.startsWith("RELOAD")){
            // refresh contact and cooperator screens
            getRacaService().executeViewQuery("ContactsLinksView");
            getRacaService().executeViewQuery("CooperatorsLinksView");
            getRacaService().sync();
        }
                  
        // remove fp1 variables from the session
        IWebViewUtils.getIWebRequestParameters().remove("fp1");
        IWebViewUtils.getIWebRequestParameters().remove("fp2");
        IWebViewUtils.getIWebRequestParameters().remove("fp3");
        IWebViewUtils.getIWebRequestParameters().remove("fp4");
        IWebViewUtils.getIWebRequestParameters().remove("fp5");
    }
    // 4/4/15 Duk added for new G&A
    public void setReturnDisabled(boolean flag) {
        ReturnBean returnBean = (ReturnBean)JSFUtils.getManagedBeanValue("returnBean");
        returnBean.setDisabled(Boolean.valueOf(flag));
    }

//    /**
//     * setSessionVariables
//     */
//    public void setSessionVariables() {
//    
//        String reportServerName = null;
//        reportServerName = (String)JSFUtils.getFromSession("reportServerName");
//        if (reportServerName == null){
//            // set the report server name
//            reportServerName = getRacaService().getReportServerName();
//            JSFUtils.storeOnSession("reportServerName",reportServerName);               
//        } 
//        log.debug("setSessionVariables:reportServerName: " + reportServerName);
//    }


//    public void getRequestVariablesOld() {
//
//        String local_cn = IWebBaseBackingBean.getIWebRequestParameters().getFp1();
//        String local_refresh = IWebBaseBackingBean.getIWebRequestParameters().getFp4();
//        BindingContext bindingCtx = ADFUtils.getDCBindingContainer().getBindingContext();              
//        if ("RELOAD".equals(local_refresh)) {   
//            String feaCn;
//            // get the Cn from a session variable
//            feaCn = (String)JSFUtils.getFromSession("feaCnKeyStr");
//            DCIteratorBinding iterator = ADFUtils.findIterator("FeaturesViewIterator");            
//            ViewObject vo = iterator.getViewObject();
//            System.out.println("CurrentCn =" + feaCn);        
//            ViewCriteria vc = vo.createViewCriteria();
//            ViewCriteriaRow vcRow = vc.createViewCriteriaRow();     
//            vcRow.setAttribute("Cn", "= '" + feaCn + "'");
//            vc.addElement(vcRow);
//            vo.applyViewCriteria(vc);
//            vo.executeQuery();
//            refreshBindingContainer(bindingCtx.findBindingContainer("featuresPageDef"));
//        }
//        else if (local_cn != null) {
//           // Scott used viewCriteria. Maybe I don't need to remove the where clause             
//            DCIteratorBinding iterator1 = ADFUtils.findIterator("FeaturesViewIterator");            
//            ViewObject vo1 = iterator1.getViewObject();
//            ViewCriteria vc1 = vo1.createViewCriteria();
//            ViewCriteriaRow vcRow1 = vc1.createViewCriteriaRow();           
//            vcRow1.setAttribute("Cn", "= '" + local_cn + "'");            
//            vc1.addElement(vcRow1);
//            vo1.applyViewCriteria(vc1);
//            vo1.executeQuery();
//            refreshBindingContainer(bindingCtx.findBindingContainer("featuresPageDef"));
//        }        
//    }    

    
    protected void refreshBindingContainer(DCBindingContainer bc)
    {
       if (bc instanceof IWebInitialBindingContainer)      
       {
          ((IWebInitialBindingContainer)bc).resetIteratorRefreshOption();
       }
    }
}