package gov.usda.fs.iweb.raca.common.view.toolbar;


import gov.usda.fs.nrm.framework.view.toolbar.ReturnBean;

import java.io.Serializable;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class RacaReturnToolbarBean extends ReturnBean implements Serializable{

    private static Logger log = LogManager.getLogger(RacaReturnToolbarBean.class);
    @SuppressWarnings("compatibility:7691961728417831897")
    private static final long serialVersionUID = 1L;
    private Map validationMap = new HashMap();

    public RacaReturnToolbarBean() {
        super();
    }

    public String checkReturn() {
        return super.checkReturn();
    }    
    
}
