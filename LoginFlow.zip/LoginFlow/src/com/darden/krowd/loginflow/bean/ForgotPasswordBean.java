package com.darden.krowd.loginflow.bean;


import com.darden.krowd.common.KrowdUtility;
import com.darden.krowd.common.LoginPortalException;
import com.darden.krowd.common.PortalConstants;
import com.darden.krowd.common.StringsRepoUtil;
import com.darden.krowd.common.exception.KrowdPortalMailException;
import com.darden.krowd.common.exception.PasswordPolicyException;
import com.darden.krowd.common.identity.LdapHelper;
import com.darden.krowd.common.util.ADUtil;
import com.darden.krowd.common.util.MailUtil;
import com.darden.krowd.loginflow.constants.LoginConstants;
import com.darden.krowd.loginflow.util.DatabaseUtil;

import java.io.Serializable;

import java.text.MessageFormat;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import javax.mail.SendFailedException;

import javax.naming.NamingException;
import javax.naming.OperationNotSupportedException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.view.rich.context.AdfFacesContext;

import oracle.security.idm.User;

import org.apache.commons.lang.RandomStringUtils;


/**
 * @author
 * @version
 * @description
 */
public class ForgotPasswordBean implements Serializable {
    
    @SuppressWarnings("compatibility:5471234058569236921")
    private static final long serialVersionUID = -4161748224307426484L;
    private static final String CLASS_NAME = ForgotPasswordBean.CLASS_NAME;

    transient ADFLogger krowdLogger = ADFLogger.createADFLogger(ForgotPasswordBean.class);
    transient Properties properties = KrowdUtility.getInstance().getProperties();
    transient ADUtil adUtil = new ADUtil();
    transient DatabaseUtil databaseUtil = DatabaseUtil.getInstance();
    transient StringsRepoUtil repoUtil = StringsRepoUtil.getInstance();
    
    private Locale locale = FacesContext.getCurrentInstance().getViewRoot().getLocale();
    private String currentLocale = null;
    
    private String userName = null;
    private String newPassword = null;
    private String oldPassword = null;
    private String confirmPassword = null;
    private String securityQuestion1 = null;
    private String securityQuestion2 = null;
    private String securityQuestion3 = null;
    private String securityAnswer1 = null;
    private String securityAnswer2 = null;
    private String securityAnswer3 = null;
    private String forgotPwdErrorMsg = null;
    private String secQAerrorMsg = null;
    private String resetPwdErrorMsg = null;
    private String errorMessage = null;
    private String successMessage = null;
    private String userEmail = null;
    
    private List<SelectItem> securityList1 = new ArrayList<SelectItem>();
    private List<SelectItem> securityList2 = new ArrayList<SelectItem>();
    private List<SelectItem> securityList3 = new ArrayList<SelectItem>();
    private List generatedQuestions = new ArrayList();
    private List securityQuestions = new ArrayList();
    
    private HashMap securityQuestionMap = new HashMap();
    
    private Boolean resetEmailLinkVisible = false;
    private boolean errorMsgRender = false;
    private boolean successsMessageRender = false;
    private int count = 0;
    
    transient ADFContext adfCtx = ADFContext.getCurrent();
    Map appScope = adfCtx.getSessionScope();
    
    private boolean disabledLogicActivated;
    public ForgotPasswordBean() {
        super();
        krowdLogger.info("Locale is :"+locale);
        if(locale != null){
            if(locale.toString().contains("es"))
                this.currentLocale = "es";
            else
                this.currentLocale = "en";
        }else{
            this.currentLocale = "en";
        }
        krowdLogger.info("Current Locale is :"+ this.currentLocale);
    }

    /**
     * @return String
     * @description This method is used to validate the user whether RSC or NonRSC from Active Directory for the username
     */
    public String validUsername() {
        final String METHOD_NAME = "validUsername";
        userName = userName.trim();
        appScope.put("LoginUsername", userName);
        forgotPwdErrorMsg = "";
        krowdLogger.info(CLASS_NAME, METHOD_NAME,
                         " Calling isDardenBusinessUnitRL with username : " + userName + " DARDEN_BUSINESS_UNIT : " +
                         PortalConstants.DARDEN_BUSINESS_UNIT);
        boolean checkRLUser = adUtil.isDardenBusinessUnitRL(userName, PortalConstants.DARDEN_BUSINESS_UNIT);
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " Returning isDardenBusinessUnitRL method with checkRLUser : " + checkRLUser);

        if (!checkRLUser) {
            if (adUtil.validUsername(userName) &&
                !(adUtil.getSamAccountName(userName, properties.getProperty(PortalConstants.SAMACCOUNTNAME)) != null)) {

                try {
                    if (!databaseUtil.getUserActivationStatus(userName)) {
                        krowdLogger.info(CLASS_NAME, METHOD_NAME, "User " + userName + " account is not activated");
                        forgotPwdErrorMsg =
                                repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_ACCOUNT_NOT_ACTIVATED).toString();
                        return null;
                    }
                    String returnValue = adUtil.getUserRole(userName);
                    krowdLogger.info("Role for the Username " + userName + " is : " + returnValue);
                    if (returnValue.equalsIgnoreCase(properties.getProperty(PortalConstants.LOGIN_RSC))) {
                        userName = "";
                        krowdLogger.info(CLASS_NAME, METHOD_NAME, "User " + userName + " is RSC");
                        return properties.getProperty(PortalConstants.LOGIN_REDIRECT_RSC);
                    } else {

                        returnValue = adUtil.getUserAttribute(userName, properties.getProperty(PortalConstants.USERACCOUNTCONTROL));
                        int expiredPasswordValue = 0x800000;
                        // Added the null check if the return value is null
                        int longReturnValue = (null != returnValue && !returnValue.isEmpty())? Integer.parseInt(returnValue):0;

                        if ((longReturnValue & expiredPasswordValue) == expiredPasswordValue) {
                            krowdLogger.info(CLASS_NAME, METHOD_NAME, "User " + userName + " password expired");
                            return properties.getProperty(PortalConstants.LOGIN_REDIRECT_EXPIREDPASSWORD);
                        } else {

                            try {
                                databaseUtil.getUserSecurityQuestions(userName);
                            } catch (NullPointerException e) {
                                krowdLogger.severe(PortalConstants.KROWD_EXCEPTIONS_NULLPOINTEREXCEPTION, e);
                                new LoginPortalException(krowdLogger, "NeedHelpWithLoginBean.validUsername()", e);
                                forgotPwdErrorMsg =
                                        repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_ACCOUNT_NOT_ACTIVATED).toString();
                                return null;
                            } finally { //oracle.jbo.client.Configuration.releaseRootApplicationModule(amObj, true);
                            }
                            krowdLogger.info(CLASS_NAME, METHOD_NAME, " Redirecting to Security Question Answers page");
                            generateSecurityQuestions();
                            showPasswordResetLink();
                            return properties.getProperty(PortalConstants.LOGIN_REDIRECT_FORGOTPASSWORD);
                        }
                    }
                } catch (NullPointerException e) {
                    new LoginPortalException(krowdLogger, "NeedHelpWithLoginBean.validUsername()", e);
                    krowdLogger.severe(PortalConstants.KROWD_EXCEPTIONS_NULLPOINTEREXCEPTION, e);
                }
            }

            else {
                krowdLogger.info(CLASS_NAME, METHOD_NAME, "User " + userName + " in alias name flow");
                String tempUserName=userName;
                krowdLogger.info(CLASS_NAME, METHOD_NAME, "tempUserName " + userName + " in alias name flow");
                userName = adUtil.getSamAccountName(userName, properties.getProperty(PortalConstants.SAMACCOUNTNAME));
                try {
                    if (!databaseUtil.getUserActivationStatus(userName)) {
                        krowdLogger.info(CLASS_NAME, METHOD_NAME, "User " + userName + " account is not activated");
                        forgotPwdErrorMsg =
                                repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_ACCOUNT_NOT_ACTIVATED).toString();
                        return null;
                    }

                    String returnValue = null;

                    returnValue = adUtil.getUserRole(userName);
                    krowdLogger.info("Role for the Username " + userName + " is : " + returnValue);
                    if (returnValue.equalsIgnoreCase(properties.getProperty(PortalConstants.LOGIN_RSC))) {
                        userName = "";
                        krowdLogger.info(CLASS_NAME, METHOD_NAME, "User " + userName + " is RSC");
                        return properties.getProperty(PortalConstants.LOGIN_RSC);
                    } else {
                        // Getting the value of disabled Logic flag from DB, if not null assigned to disabledLogicFlag variable
                        String disabledLogicFlag = properties.getProperty("DISABLED_LOGIC_ACTIVATION_FLAG");
                        this.setDisabledLogicActivated((disabledLogicFlag != null) ? Boolean.parseBoolean(disabledLogicFlag) : true);
                        
                        if (this.isDisabledLogicActivated()) {
                            if (!adUtil.isUserDisabledInAD(userName)) {
                                returnValue =
                                        adUtil.getUserAttribute(userName, properties.getProperty(PortalConstants.USERACCOUNTCONTROL));
                                int expiredPasswordValue = 0x800000;
                                // Added the null check if the return value is null
                                int longReturnValue = (null != returnValue && !returnValue.isEmpty())? Integer.parseInt(returnValue):0;
                               

                                if ((longReturnValue & expiredPasswordValue) == expiredPasswordValue) {
                                    krowdLogger.info(CLASS_NAME, METHOD_NAME, "User " + userName + " password expired");
                                    return properties.getProperty(PortalConstants.LOGIN_REDIRECT_EXPIREDPASSWORD);
                                } else {

                                    try {
                                        databaseUtil.getUserSecurityQuestions(userName);
                                    } catch (NullPointerException e) {
                                        krowdLogger.severe(PortalConstants.KROWD_EXCEPTIONS_NULLPOINTEREXCEPTION, e);
                                        new LoginPortalException(krowdLogger, "NeedHelpWithLoginBean.validUsername()", e);
                                        forgotPwdErrorMsg =
                                                repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_ACCOUNT_NOT_ACTIVATED).toString();
                                        return null;
                                    } finally {
                                    }
                                    krowdLogger.info(CLASS_NAME, METHOD_NAME, " Redirecting to Security Question Answers page");
                                    generateSecurityQuestions();
                                    showPasswordResetLink();
                                    krowdLogger.info(CLASS_NAME, METHOD_NAME, "Setting temp user name to username  " + tempUserName + " in alias name flow");
                                    userName=tempUserName;
                                    return properties.getProperty(PortalConstants.LOGIN_REDIRECT_FORGOTPASSWORD);
                                }
                            } else {
                                // if user is disabled, a user friendly message will be shown from DB
                                krowdLogger.info(CLASS_NAME, METHOD_NAME, LoginConstants.LOGIN_LOG_DISABLED_USER);
                                forgotPwdErrorMsg =
                                        repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_DISABLED_USER).toString();
                                krowdLogger.info(CLASS_NAME, METHOD_NAME, "Message for Disabled user is :" + forgotPwdErrorMsg);
                            }
                        } else {
                            returnValue = adUtil.getUserAttribute(userName, properties.getProperty(PortalConstants.USERACCOUNTCONTROL));
                            int expiredPasswordValue = 0x800000;
                            int longReturnValue = (null != returnValue && !returnValue.isEmpty())? Integer.parseInt(returnValue):0;

                            if ((longReturnValue & expiredPasswordValue) == expiredPasswordValue) {
                                krowdLogger.info(CLASS_NAME, METHOD_NAME, "User " + userName + " password expired");
                                return properties.getProperty(PortalConstants.LOGIN_REDIRECT_EXPIREDPASSWORD);
                            } else {

                                try {
                                    databaseUtil.getUserSecurityQuestions(userName);
                                } catch (NullPointerException e) {
                                    krowdLogger.severe(PortalConstants.KROWD_EXCEPTIONS_NULLPOINTEREXCEPTION, e);
                                    new LoginPortalException(krowdLogger, "NeedHelpWithLoginBean.validUsername()", e);
                                    forgotPwdErrorMsg =
                                            repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_ACCOUNT_NOT_ACTIVATED).toString();
                                    return null;
                                } finally {
                                }
                                krowdLogger.info(CLASS_NAME, METHOD_NAME, " Redirecting to Security Question Answers page");
                                generateSecurityQuestions();
                                showPasswordResetLink();
                                return properties.getProperty(PortalConstants.LOGIN_REDIRECT_FORGOTPASSWORD);
                            }
                        }
                    }
                } catch (Exception e) {
                    new LoginPortalException(krowdLogger, "NeedHelpWithLoginBean.validUsername()", e);
                    krowdLogger.severe(PortalConstants.KROWD_EXCEPTIONS_NULLPOINTEREXCEPTION, e);

                }
               
            }
         
            forgotPwdErrorMsg = repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_INVALID_USERNAME).toString();
            return null;
        } else {
            return properties.getProperty(PortalConstants.RL_RESTRICTED);
        }
    }


    /**
     * @return List
     * @description
     */
    public List generateSecurityQuestions() {
        final String METHOD_NAME = "generateSecurityQuestions";
        generatedQuestions.clear();
        try {
            krowdLogger.info(CLASS_NAME, METHOD_NAME, " Calling generatePasscode method with userName : " + userName);
            securityQuestions = databaseUtil.getUserSecurityQuestions(userName);

        } catch (NullPointerException e) {
            krowdLogger.severe(CLASS_NAME, METHOD_NAME, e.getMessage());
        } finally {
        }
        for (int i = 0; i < securityQuestions.size(); i++) {
            krowdLogger.info(CLASS_NAME, METHOD_NAME,
                             " Security questions fetched from DB for userName : " + userName + " are : " + securityQuestions.get(i));
            krowdLogger.info(CLASS_NAME, METHOD_NAME,
                             " ***********" + repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_SECURITY_QUESTION +
                                                                                                    securityQuestions.get(i)));
            generatedQuestions.add(repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_SECURITY_QUESTION +
                                                                                         securityQuestions.get(i)));

        }

        securityQuestionMap.put(properties.getProperty(PortalConstants.LOGIN_SECURITYQUSETION1), "");
        securityQuestionMap.put(properties.getProperty(PortalConstants.LOGIN_SECURITYQUSETION2), "");
        securityQuestionMap.put(properties.getProperty(PortalConstants.LOGIN_SECURITYQUSETION3), "");

        return generatedQuestions;
    }

    /**
     * @param securityList
     * @param securityMap
     * @param securityQuestion
     * @description This method is used to Populate 8 security questions in a list of type SelectItem
     */
    public void populateSecurityQuestion(List<SelectItem> securityList, HashMap securityMap, String securityQuestion) {
        securityList.clear();

        for (int secQuestionIterator = 0; secQuestionIterator < generatedQuestions.size(); secQuestionIterator++) {

            if (securityMap.containsValue(Integer.toString(secQuestionIterator + 1)) &&
                !Integer.toString(secQuestionIterator + 1).equals(securityMap.get(securityQuestion).toString())) {
                continue;
            } else {
                securityList.add(new SelectItem(Integer.toString(secQuestionIterator + 1),
                                                generatedQuestions.get(secQuestionIterator).toString()));

            }
        }
    }


    /**
     * @return void
     * @description This method is used to verify whether Email exists in the database for a user
     */
    public void showPasswordResetLink() {
        final String METHOD_NAME = "showPasswordResetLink";
        try {
            String email = null;
            krowdLogger.info(CLASS_NAME, METHOD_NAME, "Username is " + userName);
            email = databaseUtil.getUserPersonalEmail(userName);
            if (null == email) {
                resetEmailLinkVisible = false;
            } else {
                resetEmailLinkVisible = true;
            }
            krowdLogger.info(CLASS_NAME, METHOD_NAME, "Email Visible link : " + resetEmailLinkVisible);
        } catch (Exception e) {
            krowdLogger.severe(CLASS_NAME, METHOD_NAME, e.getMessage());
        }
    }

    /**
     * @return String
     * @description This method is used to validate the user details against the Active Directory attributes
     */
    public String validateUserSecAnswers() {
        final String METHOD_NAME = "validateUserSecAnswers";
        krowdLogger.info(CLASS_NAME, METHOD_NAME, "Username is : " + userName);
        String returnValue = null;
        String aliasuserName = null;
        userName = (String)appScope.get("LoginUsername");
        if (null == userName || userName.isEmpty()) {
            userName = ADFContext.getCurrent().getSecurityContext().getUserName();
            krowdLogger.info(CLASS_NAME, METHOD_NAME, LoginConstants.LOGIN_LOG_TNC_USER2 + userName);
        }

        String aliasAttribute = adUtil.getUserAttribute(userName, PortalConstants.ALIAS_ATTRIBUTE);
        String tempUserName =  adUtil.getSamAccountName(userName,PortalConstants.SAMACCOUNTNAME);
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " Temp username is " + tempUserName);
        
        if(tempUserName != null && !tempUserName.isEmpty()){
            userName = (tempUserName != null)? tempUserName.trim() : tempUserName;
            aliasAttribute = adUtil.getUserAttribute(userName, PortalConstants.ALIAS_ATTRIBUTE);
            krowdLogger.info(CLASS_NAME, METHOD_NAME, " aliasuserName inside temp block is " + aliasAttribute);
            krowdLogger.info(CLASS_NAME, METHOD_NAME, " username inside temp block is " + userName);
        }
            
        aliasuserName = (null != aliasAttribute) ? aliasAttribute.trim():aliasuserName;
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " aliasuserName is " + aliasuserName);
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " username is " + userName);
        
        FacesContext vFacesContext = FacesContext.getCurrentInstance();
        ExternalContext vExternalContext = vFacesContext.getExternalContext();
        HttpServletResponse vResponse = (HttpServletResponse)vExternalContext.getResponse();
        if (null != aliasAttribute) {
            Cookie vNewCookie = new Cookie("KROWD_ACTIVATED_USER", aliasuserName);
            vNewCookie.setDomain(".darden.com");
            vNewCookie.setPath("/");
            vResponse.addCookie(vNewCookie);
        } else {
            Cookie vNewCookie = new Cookie("KROWD_ACTIVATED_USER", userName);
            vNewCookie.setDomain(".darden.com");
            vNewCookie.setPath("/");
            vResponse.addCookie(vNewCookie);

        }
        try {

            String securityQn1 = null;
            String securityQn2 = null;
            String securityQn3 = null;

            if (securityQuestion1 == null) {
                securityQn1 = "";
                securityQn2 = securityQuestions.get(Integer.parseInt(securityQuestion2) - 1).toString();
                securityQn3 = securityQuestions.get(Integer.parseInt(securityQuestion3) - 1).toString();
            } else if (securityQuestion2 == null) {
                securityQn2 = "";
                securityQn1 = securityQuestions.get(Integer.parseInt(securityQuestion1) - 1).toString();
                securityQn3 = securityQuestions.get(Integer.parseInt(securityQuestion3) - 1).toString();
            } else if (securityQuestion3 == null) {

                securityQn3 = "";
                securityQn1 = securityQuestions.get(Integer.parseInt(securityQuestion1) - 1).toString();
                securityQn2 = securityQuestions.get(Integer.parseInt(securityQuestion2) - 1).toString();

            } else {

                securityQn1 = securityQuestions.get(Integer.parseInt(securityQuestion1) - 1).toString();
                securityQn2 = securityQuestions.get(Integer.parseInt(securityQuestion2) - 1).toString();
                securityQn3 = securityQuestions.get(Integer.parseInt(securityQuestion3) - 1).toString();
            }
            krowdLogger.info(CLASS_NAME, METHOD_NAME,
                             " Calling validateUserSecAnswers method with userName :" + userName + " securityQn1 : " + securityQn1 +
                             "securityAnswer1 : " + securityAnswer1 + "securityQn2 : " + securityQn2 + "securityAnswer2 : " +
                             securityAnswer2 + "securityQn3 : " + securityQn3 + "securityAnswer3 : " + securityAnswer3);
            returnValue =
                    databaseUtil.validateUserSecAnswers(userName, securityQn1, securityAnswer1, securityQn2, securityAnswer2, securityQn3,
                                                        securityAnswer3);
            krowdLogger.info(CLASS_NAME, METHOD_NAME, " Returning from validateUserSecAnswers method with returnValue : " + returnValue + " and resetEmailLinkVisible : " + resetEmailLinkVisible);
            if (returnValue.equalsIgnoreCase(properties.getProperty(PortalConstants.LOGIN_NOTACTIVATED))) {
                secQAerrorMsg =
                        repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_ACCOUNT_NOT_ACTIVATED).toString();
            } else if (returnValue.equalsIgnoreCase(properties.getProperty(PortalConstants.LOGIN_NOTANSWERED))) {
                secQAerrorMsg = repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_LEAST_SECURITY).toString();
            } else if (returnValue.equalsIgnoreCase(properties.getProperty(PortalConstants.LOGIN_SUCCESS))) {
                return properties.getProperty(PortalConstants.LOGIN_FORGOTPASSWORD_SCCREEN);
            } else if ((returnValue.equalsIgnoreCase(properties.getProperty(PortalConstants.LOGIN_FAILURE))) &&
                       resetEmailLinkVisible.compareTo(false) == 0) {
                if (count < 2) {
                    secQAerrorMsg =
                            repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_INVALID_CREDENTIALS).toString();
                    count++;
                } else {
                    count++;
                    secQAerrorMsg =
                            repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_ACCOUNT_LOCK_INCORRECT_SECURITY_ANSWERS).toString();
                }
            } else if ((returnValue.equalsIgnoreCase(properties.getProperty(PortalConstants.LOGIN_FAILURE))) &&
                       resetEmailLinkVisible.compareTo(true) == 0) {
                if (count < 2) {
                    secQAerrorMsg =
                            repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_INVALID_CREDENTIALS).toString();
                    count++;
                } else {
                    count++;
                    secQAerrorMsg =
                            repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_RESET_PASSWORD_LINK).toString();
                }
            }
        } catch (NullPointerException nullPointerException) {
            new LoginPortalException(krowdLogger, "ForgotPasswordBean.validateUserSecAnswers()", nullPointerException);
            return null;
        } catch (Exception exception) {
            new LoginPortalException(krowdLogger, "ForgotPasswordBean.validateUserSecAnswers()", exception);
            return null;
        }
        return null;
    }

    /**
     * @return String
     * @description This method is used to reset password
     */
    public String resetPassword() {
        final String METHOD_NAME = "resetPassword";
        try {
            userName = (String)appScope.get("LoginUsername");
            if (null == userName || userName.isEmpty()) {
                userName = ADFContext.getCurrent().getSecurityContext().getUserName();
                krowdLogger.info(CLASS_NAME, METHOD_NAME, LoginConstants.LOGIN_LOG_TNC_USER2 + userName);
            }
            
            if (validatePassword()) {
                String returnValue = null;
                String waterMarkUsername = repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_WATERMARK_USERNAME).toString();
                if (null == userName || userName.isEmpty() || waterMarkUsername.equalsIgnoreCase(userName)) {
                    userName = (String)AdfFacesContext.getCurrentInstance().getPageFlowScope().get("userName");
                    krowdLogger.info(CLASS_NAME,METHOD_NAME, " Username fetched from Passcode Verification page : " + userName);
                }
                krowdLogger.info(CLASS_NAME, METHOD_NAME,
                                 " Calling doResetPassword method with userName : " + userName + " confirmPassword : " + confirmPassword);
                
                String aliasAttribute = adUtil.getUserAttribute(userName, PortalConstants.ALIAS_ATTRIBUTE);
                String tempUserName =  adUtil.getSamAccountName(userName,PortalConstants.SAMACCOUNTNAME);
                krowdLogger.info(CLASS_NAME, METHOD_NAME, " Temp username is " + tempUserName);
                
                if(tempUserName != null && !tempUserName.isEmpty()){
                    userName = (tempUserName != null)? tempUserName.trim() : tempUserName;
                    aliasAttribute = adUtil.getUserAttribute(userName, PortalConstants.ALIAS_ATTRIBUTE);
                    krowdLogger.info(CLASS_NAME, METHOD_NAME, " aliasuserName inside temp block is " + aliasAttribute);
                    krowdLogger.info(CLASS_NAME, METHOD_NAME, " username inside temp block is " + userName);
                }
                returnValue = adUtil.doResetPassword(userName, confirmPassword);
                krowdLogger.info(CLASS_NAME, METHOD_NAME, " Returning from doResetPassword method with returnValue :" + returnValue);
                if (returnValue.equalsIgnoreCase(properties.getProperty(PortalConstants.LOGIN_SUCCESS))) {
                    return properties.getProperty(PortalConstants.LOGIN_FORGOT_PASSWORD_MSG);
                }else{
                    resetPwdErrorMsg = repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_PASSWORD_EXCEPTION_MESSAGE).toString();
                    return properties.getProperty(PortalConstants.LOGIN_FAILURE);
                }
            }
        }catch(OperationNotSupportedException e){
            krowdLogger.severe("Password reset Failed", e);
            return properties.getProperty(PortalConstants.LOGIN_FORGOT_PASSWORD_MSG);
        } catch (Exception e) {
            krowdLogger.severe(CLASS_NAME, METHOD_NAME, e.getMessage());
            return properties.getProperty(PortalConstants.LOGIN_FORGOT_PASSWORD_MSG);
        }
        return "failure";
    }

    /**
     * @return boolean
     * @description This method is used to validate the complexity of the password entered.
     */
    public boolean validatePassword() {
        resetPwdErrorMsg = "";
        if (null != newPassword && null != confirmPassword) {
            if (!newPassword.equals(confirmPassword)) {
                resetPwdErrorMsg =
                        repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_PASSWORD_DO_NOT_MATCH).toString();
                newPassword = null;
                confirmPassword = null;
                return false;
            } else if (newPassword.length() < 6 && newPassword.length() > 17) {
                resetPwdErrorMsg =
                        repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_PASSWORD_NOTINRANGE).toString();
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    /**
     * @return String
     * Method to generate and store the password reset code
     */
    public String processPasscode() {
        final String METHOD_NAME = "processPasscode";
        krowdLogger.info(CLASS_NAME, METHOD_NAME, "Entering the method");
        try {
            boolean status = false;
            boolean checkMailSent = false;
            krowdLogger.info(CLASS_NAME, METHOD_NAME, " userName is : " + userName);
            userName = (String)appScope.get("LoginUsername");
            if (null == userName || userName.isEmpty()) {
                userName = ADFContext.getCurrent().getSecurityContext().getUserName();
                krowdLogger.info(CLASS_NAME, METHOD_NAME, LoginConstants.LOGIN_LOG_TNC_USER2 + userName);
                
            }
            
            //Password Verification Code is generated as a 6 digit alphanumeric value
            String sysGenOTP = "aaaaaa";
            char[] alphaNumberList =
                new char[] { 'b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'q', 'r', 's', 't', 'v', 'w', 'x', 'y', 'z', 'B',
                             'C', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'X', 'Y', 'Z', '0', '1',
                             '2', '3', '4', '5', '6', '7', '8', '9' };
            sysGenOTP = RandomStringUtils.random(6, 0, 51, true, true, alphaNumberList);
            while (!(sysGenOTP.matches(".*\\d+.*"))) {
                sysGenOTP = RandomStringUtils.random(6, 0, 51, true, true, alphaNumberList);
            }

            //save the password verification code to database
            if (null != sysGenOTP && !sysGenOTP.isEmpty()) {
                krowdLogger.info(CLASS_NAME, METHOD_NAME,
                                 "Calling generatePasscode method with username : " + userName + " and passcode : " + sysGenOTP);
                String tempUserName =  adUtil.getSamAccountName(userName,PortalConstants.SAMACCOUNTNAME);
                krowdLogger.info(CLASS_NAME, METHOD_NAME, "processPasscode Temp username is " + tempUserName);
                if(tempUserName != null && !tempUserName.isEmpty()){
                    tempUserName = (tempUserName != null)? tempUserName.trim() : tempUserName;
                    krowdLogger.info(CLASS_NAME, METHOD_NAME, "processPasscode username inside temp block is " + userName);
                    status = databaseUtil.generatePasscode(tempUserName, sysGenOTP);
                }
                else{
                    status = databaseUtil.generatePasscode(userName, sysGenOTP);
                }
               
                krowdLogger.info(CLASS_NAME, METHOD_NAME,
                                 "Returning from generatePasscode method with status : " + status + " for Username : " + userName);
            }
            if (status) {
                krowdLogger.info(CLASS_NAME, METHOD_NAME, "OTP is successfully saved in database for the user " + userName);
                // Call isEmailSent method to send the passcode through Email
                checkMailSent = isEmailSent(userName, sysGenOTP);
            }
            if (!checkMailSent || !status) {
                krowdLogger.info(CLASS_NAME, METHOD_NAME, "Error while generating or sending the passcode");
                errorMessage = "passcodeVerifyMsg";
                errorMsgRender = true;
                successsMessageRender = false;
                krowdLogger.info(CLASS_NAME, METHOD_NAME, "errorMessage : " + errorMessage);
                return errorMessage;
            }
        } catch (Exception ex) {
            // Add error logggers here
            krowdLogger.severe(CLASS_NAME, METHOD_NAME, ex.getMessage());
            errorMessage = "passcodeVerifyMsg";
            errorMsgRender = true;
            successsMessageRender = false;
            krowdLogger.info(CLASS_NAME, METHOD_NAME, "errorMessage : " + errorMessage);
            return errorMessage;
        }
        successMessage = "passcodeVerifyMsg";
        successsMessageRender = true;
        errorMsgRender = false;
        krowdLogger.info(CLASS_NAME, METHOD_NAME, "Exiting the method with message: " + successMessage);
        return successMessage;
    }

    /**
     * @param userName
     * @param sysGenOTP
     * @return boolean
     * Method to send password reset code through Email
     */
    public boolean isEmailSent(String userName, String sysGenOTP) {
        final String METHOD_NAME = "sendPasscodeEmail";
        krowdLogger.info(CLASS_NAME, METHOD_NAME, "Entering the method with Username : " + userName + " and Passcode :" + sysGenOTP);
        try {
            // Sender name is stored as a constant in DB
            String mailSender = properties.getProperty(PortalConstants.MAIL_SENDER_NAME).toString();
            //Receiver email is to be fetched from database\
            String mailRecipient = null;
            krowdLogger.info(CLASS_NAME, METHOD_NAME, "Calling getUserPersonalEmail method with usename: " + userName);
            String tempUserName =  adUtil.getSamAccountName(userName,PortalConstants.SAMACCOUNTNAME);
            krowdLogger.info(CLASS_NAME, METHOD_NAME, " Temp username is " + tempUserName);
            if(tempUserName != null && !tempUserName.isEmpty()){
                userName = (tempUserName != null)? tempUserName.trim() : tempUserName;
                krowdLogger.info(CLASS_NAME, METHOD_NAME, " username inside temp block is " + userName);
            }
            mailRecipient = databaseUtil.getUserPersonalEmail(userName);
            krowdLogger.info(CLASS_NAME, METHOD_NAME,
                             "Returning from retrieveCurrentEmail method with usename: " + userName + " and mailRecipient: " +
                             mailRecipient);
            try {
                // Checking whether the recipient mail address is valid
                String domainName[] = mailRecipient.split("@");
                //Look up the MX records to find whether the domain has a valid mail server
                doLookup(domainName[1]);
            } catch (Exception e) {
                krowdLogger.severe(CLASS_NAME, METHOD_NAME,
                                   "Invalid email address " + mailRecipient + " for " + userName + e.getMessage());
                return false;
            }
            //Mail subject is stored as a constant in DB
            String mailSubject = properties.getProperty(PortalConstants.MAIL_SUBJECT).toString();
            //Email body is stored in db
            String emailTemplate = properties.getProperty(PortalConstants.EMAIL_BODY).toString();

            //Get the display name of the user from AD
            User user = LdapHelper.getInstance().getUser(userName);
            oracle.security.idm.UserProfile currentUserProfile = user.getUserProfile();
            String displayName = null;
            if ((String)currentUserProfile.getPropertyVal("displayName") != null) {
                displayName = (String)currentUserProfile.getPropertyVal("displayName");
            } else if ((String)currentUserProfile.getPropertyVal("cn") != null) {
                displayName = (String)currentUserProfile.getPropertyVal("cn");
            } else if ((String)currentUserProfile.getPropertyVal("name") != null) {
                displayName = (String)currentUserProfile.getPropertyVal("name");
            }
            //get mailLink from DB
            HttpServletRequest requestObj = (HttpServletRequest)FacesContext.getCurrentInstance().getExternalContext().getRequest();
            String mailLink =
                requestObj.getScheme().concat("://").concat(requestObj.getServerName()).concat(properties.getProperty(PortalConstants.MAIL_LINK).toString());

            // Drafting the Email
            MessageFormat format = new MessageFormat("");
            String[] emailDetails = new String[3];
            emailDetails[0] = displayName;
            emailDetails[1] = mailLink;
            emailDetails[2] = sysGenOTP;
            String emailBody = format.format(emailTemplate, emailDetails);
            krowdLogger.info("Email Content is :" + emailBody);
            krowdLogger.info("Mail Sender name :" + mailSender + "\t" + "Mail recipient :" + mailRecipient + "\t" + "Mail Subject :" +
                             mailSubject + "\t" + "Mail body" + emailBody);
            try {
                MailUtil mailUtil = new MailUtil();
                krowdLogger.info(CLASS_NAME, METHOD_NAME, "Sending Email....." + " for user: " + userName);

                mailUtil.sendMail(mailSender, mailRecipient, mailSubject, emailBody, null);
            } catch (KrowdPortalMailException e) {
                krowdLogger.severe(CLASS_NAME, METHOD_NAME,
                                   "Exception while sending the OTP email for user: " + userName + e.getMessage());
                return false;
            } catch (SendFailedException e) {
                krowdLogger.severe(CLASS_NAME, METHOD_NAME,
                                   "Exception while sending the OTP email for user: Invalid email address" + userName + e.getMessage());
                return false;
            }
        } catch (Exception e) {
            krowdLogger.severe(CLASS_NAME, METHOD_NAME, e.getMessage());
            return false;
        }
        return true;
    }

    /**
     * @return count of mail servers
     * @description This method is used to retrieve the count of mails servers available for a mail domain
     */
    private int doLookup(String hostName) throws NamingException {
        Hashtable env = new Hashtable();
        env.put("java.naming.factory.initial", "com.sun.jndi.dns.DnsContextFactory");
        DirContext ictx = new InitialDirContext(env);
        Attributes attrs = ictx.getAttributes(hostName, new String[] { "MX" });
        Attribute attr = attrs.get("MX");
        krowdLogger.info("The attribute returned is :" + attr);
        if (null == attr)
            return (0);
        krowdLogger.info("Number of mail servers available for " + hostName + ":" + attr.size());
        return (attr.size());
    }

    /**
     * @return email
     * @description This method is used to retrieve current email of the user from database
     */
    public String getUserEmail() {
        final String METHOD_NAME = "getUserEmail";
        try {
            krowdLogger.info(CLASS_NAME, METHOD_NAME, "Username is " + userName);
            String tempUserName =  adUtil.getSamAccountName(userName,PortalConstants.SAMACCOUNTNAME);
            krowdLogger.info(CLASS_NAME, METHOD_NAME, " Temp username is " + tempUserName);
            
            if(tempUserName != null && !tempUserName.isEmpty()){
                userName = (tempUserName != null)? tempUserName.trim() : tempUserName;
                krowdLogger.info(CLASS_NAME, METHOD_NAME, " getting user email for " + userName);
            }
            userEmail = databaseUtil.getUserPersonalEmail(userName);
            if (null == userEmail) {
                userEmail = "";
            } else {
                //Asterisk out the email except the first two characters.
                String strPart1 = userEmail.substring(0, userEmail.indexOf('@'));
                String strPart2 = userEmail.substring(userEmail.indexOf('@'));
                String strPart3 = strPart1.substring(0, 2);
                String strPart4 = userEmail.substring(2, strPart1.length());
                String strPart5 = strPart4.replaceAll(".", "*");
                userEmail = strPart3.concat(strPart5).concat(strPart2);
                krowdLogger.info(CLASS_NAME, METHOD_NAME, "Asterisked Email Id :" + userEmail);
            }
//            MessageFormat format = new MessageFormat("");
//            String msgTemplate = repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.EMAIL_SENT_MESSAGE).toString();
//            String[] msgDetails = new String[1];
//            msgDetails[0] = userEmail;
//            emailMsg = format.format(msgTemplate, msgDetails);
//            //to convert the message from english to spanish and vice versa
//            AdfFacesContext.getCurrentInstance().getPageFlowScope().put("emailMsg", emailMsg);
        } catch (Exception e) {
            krowdLogger.severe(CLASS_NAME, METHOD_NAME, e.getMessage());
        }
        krowdLogger.info(CLASS_NAME, METHOD_NAME, "Asterisked Email Id for the username " + userName + " is " + userEmail);
        return userEmail;
    }

    /**
     * @return String
     * @description This method is used to change the password by checking the old password
     */
    public String changePassword() {
        final String METHOD_NAME = "changePassword";
        resetPwdErrorMsg = "";
        userName = (String)appScope.get("LoginUsername");
        if (null == userName || userName.isEmpty()) {
            userName = ADFContext.getCurrent().getSecurityContext().getUserName();
            krowdLogger.info(CLASS_NAME, METHOD_NAME, LoginConstants.LOGIN_LOG_TNC_USER2 + userName);
            
        }
        
        if (validatePassword()) {
            String returnValue = "";

            try {
                returnValue = adUtil.doChangePassword(userName, oldPassword, newPassword);
            } catch (PasswordPolicyException e) {
                resetPwdErrorMsg =
                        repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_PASSWORD_POLICY_MESSAGE).toString();
                new LoginPortalException(krowdLogger, "ExpiredPasswordBean.changePassword()", e);
                return null;
            }
            if (returnValue.equalsIgnoreCase(properties.getProperty(PortalConstants.LOGIN_SUCCESS))) {
                userName = "";
                return properties.getProperty(LoginConstants.LOGIN_REDIRECT_EXPIREDPASSWORD_MSG);
            } else {
                resetPwdErrorMsg =
                        repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_PASSWORD_EXCEPTION_MESSAGE).toString();
                return null;
            }
        }
        return null;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserName() {
        return userName;
    }

    public void setForgotPwdErrorMsg(String forgotPwdErrorMsg) {
        this.forgotPwdErrorMsg = forgotPwdErrorMsg;
    }

    public String getForgotPwdErrorMsg() {
        return forgotPwdErrorMsg;
    }

    public void setGeneratedQuestions(List generatedQuestions) {
        this.generatedQuestions = generatedQuestions;
    }

    public List getGeneratedQuestions() {
        return generatedQuestions;
    }

    public void setSecurityQuestions(List securityQuestions) {
        this.securityQuestions = securityQuestions;
    }

    public List generatePasscode() {
        return securityQuestions;
    }


    /**
     * @param securityQuestion1
     * @description Setter method of the securityQuestion1 field
     */
    public void setSecurityQuestion1(String securityQuestion1) {

        securityQuestionMap.put(properties.getProperty(PortalConstants.LOGIN_SECURITYQUSETION1), securityQuestion1);
        if (null != securityQuestion1 && securityQuestion1.equalsIgnoreCase("")) {
            securityQuestion1 = null;
        }
        this.securityQuestion1 = securityQuestion1;
    }

    /**
     * @return String
     * @description Getter method of the securityQuestion1 field
     */
    public String getSecurityQuestion1() {
        return securityQuestion1;
    }

    /**
     * @param securityQuestion2
     * @description Setter method of the securityQuestion2 field
     */
    public void setSecurityQuestion2(String securityQuestion2) {

        securityQuestionMap.put(properties.getProperty(PortalConstants.LOGIN_SECURITYQUSETION2), securityQuestion2);
        if (null != securityQuestion2 && securityQuestion2.equalsIgnoreCase("")) {
            securityQuestion2 = null;
        }
        this.securityQuestion2 = securityQuestion2;
    }

    /**
     * @return String
     * @description Getter method of the securityQuestion2 field
     */
    public String getSecurityQuestion2() {
        return securityQuestion2;
    }

    /**
     * @param securityQuestion3
     * @description Setter method of the securityQuestion3 field
     */
    public void setSecurityQuestion3(String securityQuestion3) {

        securityQuestionMap.put(properties.getProperty(PortalConstants.LOGIN_SECURITYQUSETION3), securityQuestion3);
        if (null != securityQuestion3 && securityQuestion3.equalsIgnoreCase("")) {
            securityQuestion3 = null;
        }
        this.securityQuestion3 = securityQuestion3;
    }

    /**
     * @return String
     * @description Getter method of the securityQuestion3 field
     */
    public String getSecurityQuestion3() {
        return securityQuestion3;
    }

    /**
     * @param securityList1
     * @description Setter method of the securityList1 field
     */
    public void setSecurityList1(List<SelectItem> securityList1) {
        this.securityList1 = securityList1;
    }

    /**
     * @return List
     * @description Getter method of the securityList1 field
     */
    public List<SelectItem> getSecurityList1() {
        populateSecurityQuestion(securityList1, securityQuestionMap, properties.getProperty(PortalConstants.LOGIN_SECURITYQUSETION1));
        return securityList1;
    }

    /**
     * @param securityList2
     * @description Setter method of the securityList2 field
     */
    public void setSecurityList2(List<SelectItem> securityList2) {
        this.securityList2 = securityList2;
    }

    /**
     * @return List
     * @description Getter method of the securityList2 field
     */
    public List<SelectItem> getSecurityList2() {
        populateSecurityQuestion(securityList2, securityQuestionMap, properties.getProperty(PortalConstants.LOGIN_SECURITYQUSETION2));
        return securityList2;
    }

    /**
     * @param securityList3
     * @description Setter method of the securityList3 field
     */
    public void setSecurityList3(List<SelectItem> securityList3) {
        this.securityList3 = securityList3;
    }

    /**
     * @return List
     * @description Getter method of the securityList3 field
     */
    public List<SelectItem> getSecurityList3() {
        populateSecurityQuestion(securityList3, securityQuestionMap, properties.getProperty(PortalConstants.LOGIN_SECURITYQUSETION3));
        return securityList3;
    }

    /**
     * @param securityAnswer1
     * @description Setter method of the securityAnswer1 field
     */
    public void setSecurityAnswer1(String securityAnswer1) {
        if (null != securityAnswer1 &&
            (securityAnswer1.equalsIgnoreCase("") || securityAnswer1.equals(repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_WATERMARK_ANSWER).toString()))) {
            securityAnswer1 = null;
        }
        this.securityAnswer1 = securityAnswer1;
    }

    /**
     * @return String
     * @description Getter method of the securityAnswer1 field
     */
    public String getSecurityAnswer1() {
        return securityAnswer1;
    }

    /**
     * @param securityAnswer2
     * @description  Setter method of the securityAnswer2 field
     */
    public void setSecurityAnswer2(String securityAnswer2) {
        if (null != securityAnswer2 &&
            (securityAnswer2.equalsIgnoreCase("") || securityAnswer2.equals(repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_WATERMARK_ANSWER).toString()))) {
            securityAnswer2 = null;
        }
        this.securityAnswer2 = securityAnswer2;
    }

    /**
     * @return String
     * @description Getter method of the securityAnswer2 field
     */
    public String getSecurityAnswer2() {
        return securityAnswer2;
    }

    /**
     * @param securityAnswer3
     * @description Setter method of the securityAnswer3 field
     */
    public void setSecurityAnswer3(String securityAnswer3) {
        if (null != securityAnswer3 &&
            (securityAnswer3.equalsIgnoreCase("") || securityAnswer3.equals(repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_WATERMARK_ANSWER).toString()))) {
            securityAnswer3 = null;
        }
        this.securityAnswer3 = securityAnswer3;
    }

    /**
     * @return String
     * @description Getter method of the securityAnswer3 field
     */
    public String getSecurityAnswer3() {
        return securityAnswer3;
    }

    public void setSecQAerrorMsg(String secQAerrorMsg) {
        this.secQAerrorMsg = secQAerrorMsg;
    }

    public String getSecQAerrorMsg() {
        return secQAerrorMsg;
    }

    public void setResetEmailLinkVisible(Boolean resetEmailLinkVisible) {
        this.resetEmailLinkVisible = resetEmailLinkVisible;
    }

    public Boolean getResetEmailLinkVisible() {
        return resetEmailLinkVisible;
    }


    public void setResetPwdErrorMsg(String resetPwdErrorMsg) {
        this.resetPwdErrorMsg = resetPwdErrorMsg;
    }

    public String getResetPwdErrorMsg() {
        return resetPwdErrorMsg;
    }

    public void setErrorMsgRender(boolean errorMsgRender) {
        this.errorMsgRender = errorMsgRender;
    }

    public boolean isErrorMsgRender() {
        return errorMsgRender;
    }

    public void setSuccesssMessageRender(boolean successsMessageRender) {
        this.successsMessageRender = successsMessageRender;
    }

    public boolean isSuccesssMessageRender() {
        return successsMessageRender;
    }

    public void setOldPassword(String oldPassword) {
        this.oldPassword = oldPassword;
    }

    public String getOldPassword() {
        return oldPassword;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }

    public String getNewPassword() {
        return newPassword;
    }

    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }

    public String getConfirmPassword() {
        return confirmPassword;
    }

    /**
     * @return
     * @description
     */
    public String redirectToForgotUsername() {
        // Add event code here...
        final String METHOD_NAME = "redirectToForgotUsername";
        String forgotUserURL = null;
        krowdLogger.info(CLASS_NAME, METHOD_NAME, "Entering redirectToForgotUsername");
        try {
            //get forgotPwdURL from DB
            HttpServletRequest requestObj = (HttpServletRequest)FacesContext.getCurrentInstance().getExternalContext().getRequest();
            forgotUserURL =
                    requestObj.getScheme().concat("://").concat(requestObj.getServerName()).concat(properties.getProperty(PortalConstants.LOGIN_FORGOT_USER_LINK).toString());
            FacesContext.getCurrentInstance().getExternalContext().redirect(forgotUserURL);
        } catch (Exception e) {
            krowdLogger.severe(CLASS_NAME, METHOD_NAME, e.getMessage());
        }
        krowdLogger.info(CLASS_NAME, METHOD_NAME, "forgotUserURL : " + forgotUserURL);
        return forgotUserURL;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getCount() {
        return count;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public void setDisabledLogicActivated(boolean disabledLogicActivated) {
        this.disabledLogicActivated = disabledLogicActivated;
    }

    public boolean isDisabledLogicActivated() {
        return disabledLogicActivated;
    }

    public String redirectToSecurityAnswers() {
            krowdLogger.info(CLASS_NAME, "redirectToSecurityAnswers", "Entering redirectToSecurityAnswers from expire passoword flow");
        
        try {
            databaseUtil.getUserSecurityQuestions(userName);
        } catch (NullPointerException e) {
            krowdLogger.severe(PortalConstants.KROWD_EXCEPTIONS_NULLPOINTEREXCEPTION, e);
            new LoginPortalException(krowdLogger, "NeedHelpWithLoginBean.validUsername()", e);
            forgotPwdErrorMsg =
                    repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_ACCOUNT_NOT_ACTIVATED).toString();
            return null;
        } finally { //oracle.jbo.client.Configuration.releaseRootApplicationModule(amObj, true);
        }
        krowdLogger.info(CLASS_NAME, "redirectToSecurityAnswers", " Redirecting to Security Question Answers from expire passoword page");
        generateSecurityQuestions();
        showPasswordResetLink();
        return "expsecurityQA";
        }

    /**
     * @param actionEvent
     * @description This method will reset the Questions and Answers field on Forgot password Sec QA fragment on click on Back
     */
    public void clearSecQA(ActionEvent actionEvent) {
        actionEvent = null;
        // Add event code here...
        this.securityAnswer1 = null;
        this.securityAnswer2 = null;
        this.securityQuestion1 = null;
        this.securityQuestion2 = null;
        this.secQAerrorMsg = null;
    }

    public void setCurrentLocale(String currentLocale) {
        this.currentLocale = currentLocale;
    }

    public String getCurrentLocale() {
        return currentLocale;
    }
}
