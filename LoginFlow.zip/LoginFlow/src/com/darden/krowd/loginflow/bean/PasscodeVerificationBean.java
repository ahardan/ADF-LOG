package com.darden.krowd.loginflow.bean;


import com.darden.krowd.common.KrowdUtility;
import com.darden.krowd.common.PortalConstants;
import com.darden.krowd.common.StringsRepoUtil;
import com.darden.krowd.loginflow.constants.LoginConstants;
import com.darden.krowd.common.util.ADUtil;
import com.darden.krowd.loginflow.util.DatabaseUtil;

import java.io.Serializable;

import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import javax.faces.context.FacesContext;

import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.view.rich.context.AdfFacesContext;

/**
 * @author
 * @version
 * @description
 */
public class PasscodeVerificationBean implements Serializable {

    @SuppressWarnings("compatibility:-4995508902486645754")
    private static final long serialVersionUID = 9001300761513997706L;

    private static final String CLASS_NAME = PasscodeVerificationBean.CLASS_NAME;
    transient Properties properties = KrowdUtility.getInstance().getProperties();
    transient ADFLogger krowdLogger = ADFLogger.createADFLogger(PasscodeVerificationBean.class);
    transient ADUtil adUtil = new ADUtil();
    transient DatabaseUtil databaseUtil = DatabaseUtil.getInstance();
    transient StringsRepoUtil repoUtil = StringsRepoUtil.getInstance();
    
    private Locale locale = FacesContext.getCurrentInstance().getViewRoot().getLocale();
    private String currentLocale = null;
    
    private String userName = null;
    private String otpPassword = null;
    private String validationMessage = null;
    private boolean validationMessageRender = false;

    transient ADFContext adfCtx = ADFContext.getCurrent();
    Map appScope = adfCtx.getSessionScope();

    public PasscodeVerificationBean() {
        super();
        krowdLogger.info("Locale is :"+locale);
        if(locale != null){
            if(locale.toString().contains("es"))
                this.currentLocale = "es";
            else
                this.currentLocale = "en";
        }else{
            this.currentLocale = "en";
        }
        krowdLogger.info("Current Locale is :"+ this.currentLocale);
    }

    /**
     * @return String
     * @description This method is used to validate username and OTP
     */
    public String processUsernamePasscode() {
        final String METHOD_NAME = "processUsernamePasscode";
        krowdLogger.info(CLASS_NAME, METHOD_NAME, "Username " + userName);
        appScope.put("LoginUsername", userName);
        validationMessage = "";
        validationMessageRender = true;
        boolean isOtpValid = false;
        String returnValue = null;
        try {
            if (null != userName && !userName.isEmpty() && null != otpPassword && !otpPassword.isEmpty()) {
                if (validUsername()) {
                    isOtpValid = validatePasscode();
                    if (!isOtpValid) {
                        validationMessage =
                                repoUtil.getStrings().get(this.currentLocale.toString()).get(PortalConstants.LOGIN_OTP_VERIFICATION_FAILURE).toString();

                    } else {
                        returnValue = LoginConstants.LOGIN_REDIRECT_SETPWD;
                        validationMessageRender = false;
                        AdfFacesContext.getCurrentInstance().getPageFlowScope().put("userName", userName);
                    }
                } else {
                    validationMessage =
                            repoUtil.getStrings().get(this.currentLocale.toString()).get(PortalConstants.LOGIN_INVALID_USERNAME).toString();
                }
            } else {
                validationMessage =
                        repoUtil.getStrings().get(this.currentLocale.toString()).get(PortalConstants.LOGIN_ENTER_OTP_DETAILS).toString();
            }
        } catch (Exception exception) {
            krowdLogger.severe(CLASS_NAME, METHOD_NAME, exception.getMessage());

        }
        krowdLogger.info(CLASS_NAME, METHOD_NAME, "UserName " + userName + " with status" + returnValue);
        return returnValue;
    }

    /**
     * @return boolean
     * @description This method is used to validate the user from Active Directory for the username
     */
    public boolean validUsername() {
        final String METHOD_NAME = "validUsername";
        krowdLogger.info(CLASS_NAME, METHOD_NAME, "Username " + userName);
        userName = (userName != null && userName != "") ? userName.trim() : userName;
        appScope.put("UserName", userName);
        try {
            boolean checkRLUser = adUtil.isDardenBusinessUnitRL(userName, PortalConstants.DARDEN_BUSINESS_UNIT);
            krowdLogger.info(CLASS_NAME, METHOD_NAME, "checkRLUser " + checkRLUser);
            if (!checkRLUser) {
                if (adUtil.validUsername(userName) &&
                    !(adUtil.getSamAccountName(userName, properties.getProperty(PortalConstants.SAMACCOUNTNAME)) != null)) {
                    if (!databaseUtil.getUserActivationStatus(userName)) {
                        krowdLogger.info(CLASS_NAME, METHOD_NAME, "User " + userName + " account is not activated");
                         return false;
                    }

                    String returnValue = null;

                    returnValue = adUtil.getUserRole(userName);
                    if (returnValue.equalsIgnoreCase(properties.getProperty(PortalConstants.LOGIN_RSC))) {
                        userName = "";
                        krowdLogger.info(CLASS_NAME, METHOD_NAME, "User " + userName + " is RSC");
                        return false;
                    } else {

                        returnValue = adUtil.getUserAttribute(userName, properties.getProperty(PortalConstants.USERACCOUNTCONTROL));
                        int expiredPasswordValue = 0x800000;
                        // Added the null check if the return value is null
                        int longReturnValue = (null != returnValue && !returnValue.isEmpty())? Integer.parseInt(returnValue):0;

                        if ((longReturnValue & expiredPasswordValue) == expiredPasswordValue) {
                            krowdLogger.info(CLASS_NAME, METHOD_NAME, "User " + userName + " password expired");
                            return false;
                        }
                    }
                } else {
                    userName = adUtil.getSamAccountName(userName, properties.getProperty(PortalConstants.SAMACCOUNTNAME));
                    if (!databaseUtil.getUserActivationStatus(userName)) {
                        //                        validationMessage =
                        //                                resourceAdapter.get(PortalConstants.LOGIN_ACCOUNT_NOT_ACTIVATED).toString();
                        krowdLogger.info(CLASS_NAME, METHOD_NAME, "User " + userName + " account is not activated");
                         return false;
                    }

                    String returnValue = null;

                    returnValue = adUtil.getUserRole(userName);
                    if (returnValue.equalsIgnoreCase(properties.getProperty(PortalConstants.LOGIN_RSC))) {
                        userName = "";
                        krowdLogger.info(CLASS_NAME, METHOD_NAME, "User " + userName + " is RSC");
                        return false;
                    } else {

                        returnValue = adUtil.getUserAttribute(userName, properties.getProperty(PortalConstants.USERACCOUNTCONTROL));
                        int expiredPasswordValue = 0x800000;
                        // Added the null check if the return value is null
                        int longReturnValue = (null != returnValue && !returnValue.isEmpty())? Integer.parseInt(returnValue):0;

                        if ((longReturnValue & expiredPasswordValue) == expiredPasswordValue) {
                            krowdLogger.info(CLASS_NAME, METHOD_NAME, "User " + userName + " password expired");
                            return false;
                        }
                    }
                }
            } else {
                krowdLogger.info(CLASS_NAME, METHOD_NAME, "User" + userName + " is a RL user");
                return false;
            }
        } catch (Exception e) {
            krowdLogger.severe(CLASS_NAME, METHOD_NAME, e.getMessage());
            return false;
        }
        krowdLogger.info(CLASS_NAME, METHOD_NAME, "User " + userName + " is valid");
        return true;
    }

    /**
     * @return String
     * @description This method is used to validate the user entered OTP details against the Active Directory attributes
     */
    public boolean validatePasscode() {
        final String METHOD_NAME = "validatePasscode";
        krowdLogger.info(CLASS_NAME, METHOD_NAME, "Username  " + userName);
        boolean isValidOTPassword;
        isValidOTPassword = false;
        try {
            String tempUserName =  adUtil.getSamAccountName(userName,PortalConstants.SAMACCOUNTNAME);
            krowdLogger.info(CLASS_NAME, METHOD_NAME, " Temp username is " + tempUserName);
            if(tempUserName != null && !tempUserName.isEmpty()){
                userName = (tempUserName != null)? tempUserName.trim() : tempUserName;
                krowdLogger.info(CLASS_NAME, METHOD_NAME, " validatePasscode for user name inside temp block is " + tempUserName);
                isValidOTPassword = databaseUtil.validateUserPasscode(tempUserName, otpPassword);
            }else{
                krowdLogger.info(CLASS_NAME, METHOD_NAME, " validatePasscode for user name" + userName);
                isValidOTPassword = databaseUtil.validateUserPasscode(userName, otpPassword);
                krowdLogger.info(CLASS_NAME, METHOD_NAME, "validatePasscode checking alias name: " + (String) appScope.get("LoginUsername"));
                tempUserName =  adUtil.getSamAccountName((String) appScope.get("LoginUsername"),PortalConstants.SAMACCOUNTNAME);
                if(!isValidOTPassword && tempUserName != null && !tempUserName.isEmpty()){
                    userName=(String) appScope.get("LoginUsername");
                }
                
            }
           
        } catch (Exception exception) {
            krowdLogger.severe(CLASS_NAME, METHOD_NAME, exception.getMessage());
            validationMessageRender = true;
        }
        krowdLogger.info(CLASS_NAME, METHOD_NAME, "Validation message " + validationMessage);
        return isValidOTPassword;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserName() {
        return userName;
    }

    public void setOtpPassword(String otpPassword) {
        this.otpPassword = otpPassword;
    }

    public String getOtpPassword() {
        return otpPassword;
    }

    public void setValidationMessage(String validationMessage) {
        this.validationMessage = validationMessage;
    }

    public String getValidationMessage() {
        return validationMessage;
    }

    public void setValidationMessageRender(boolean validationMessageRender) {
        this.validationMessageRender = validationMessageRender;
    }

    public boolean isValidationMessageRender() {
        return validationMessageRender;
    }

    public void setCurrentLocale(String currentLocale) {
        this.currentLocale = currentLocale;
    }

    public String getCurrentLocale() {
        return currentLocale;
    }
}
