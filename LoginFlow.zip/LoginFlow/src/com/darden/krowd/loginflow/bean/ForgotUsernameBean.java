package com.darden.krowd.loginflow.bean;


import com.darden.krowd.common.KrowdUtility;
import com.darden.krowd.common.LoginPortalException;
import com.darden.krowd.common.PortalConstants;
import com.darden.krowd.common.StringsRepoUtil;
import com.darden.krowd.common.util.ADUtil;
import com.darden.krowd.loginflow.constants.LoginConstants;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;

import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;


/**
 * @author
 * @version
 * @description
 */
public class ForgotUsernameBean implements Serializable {
    
    @SuppressWarnings("compatibility:1881742442856490102")
    private static final long serialVersionUID = -6777111423655387776L;
    private static final String CLASS_NAME = ForgotUsernameBean.CLASS_NAME;

    transient ADFLogger krowdLogger = ADFLogger.createADFLogger(ForgotUsernameBean.class); 
    transient ADUtil adUtil = new ADUtil();
    transient Properties properties = KrowdUtility.getInstance().getProperties();
    transient StringsRepoUtil repoUtil = StringsRepoUtil.getInstance();
    
    private Locale locale = FacesContext.getCurrentInstance().getViewRoot().getLocale();
    private String currentLocale = null;
    
    private String forgotUsrErrorMsg = null;
    private String forgotUsrRMErrorMsg = null;
    private String posId = null;
    private String restaurantNumber = null;
    private String initials = null;
    private String userName = null;
    
    //RM related variables
    private String rmRestaurantNumber = null;
    private String last4DigitEmpId = null;
    
    private List<SelectItem> listOfDaysTM = new ArrayList<SelectItem>();
    private List<SelectItem> listOfDaysRM = new ArrayList<SelectItem>();

    
    private String selectedDayTM = null;
    private String selectedMonthTM = null;
    private String selectedDayRM = null;
    private String selectedMonthRM = null;
    
    transient ADFContext adfCtx = ADFContext.getCurrent();
    Map appScope = adfCtx.getSessionScope();
    
    private boolean disabledLogicActivated;

    public ForgotUsernameBean() {
        super();
        krowdLogger.info("Locale is :"+locale);
        if(locale != null){
            if(locale.toString().contains("es"))
                this.currentLocale = "es";
            else
                this.currentLocale = "en";
        }else{
            this.currentLocale = "en";
        }
        krowdLogger.info("Current Locale is :"+ this.currentLocale);
        populateDateOfBirthDropDowns();
    }

    /**
     * @return String
     * @description This method is used to validate the given details and to fetch username of a team member from Active Directory
     */
    public String validateUserDetailsTM() {
        final String METHOD_NAME = "validateUserDetailsTM";
        String birthdate = null;
        boolean checkRLUser = false;
        forgotUsrErrorMsg = "";
        String userNameDisabled = null;
        if (null != selectedDayTM && null != selectedMonthTM && !selectedMonthTM.isEmpty() && !selectedDayTM.isEmpty()) {
            birthdate = selectedDayTM.concat(selectedMonthTM);
            krowdLogger.info(CLASS_NAME, METHOD_NAME,
                             " Calling validateUserDetails with initials : " + initials + " tempDate : " + birthdate +
                             " restaurantNumber : " + restaurantNumber + " posId : " + posId);
            try{
                userName = adUtil.validateUserDetails(initials, birthdate, restaurantNumber, posId);
            }catch(LoginPortalException e){                
                krowdLogger.severe(e);
                userName = null;
            }
            appScope.put("LoginUsername", userName);
            krowdLogger.info(CLASS_NAME, METHOD_NAME, " Returning from validateUserDetails with userName : " + userName);
        }
        userNameDisabled = userName;
        String aliasAttribute = adUtil.getUserAttribute(userName, PortalConstants.ALIAS_ATTRIBUTE);
        userName = null != aliasAttribute ? aliasAttribute.trim() : userName;

        if (null != userName && !userName.isEmpty()) {
            initials = "";
            selectedDayTM = "";
            selectedMonthTM = "";
            restaurantNumber = "";
            posId = "";
            checkRLUser = adUtil.isDardenBusinessUnitRL(userName, PortalConstants.DARDEN_BUSINESS_UNIT);
            krowdLogger.info(CLASS_NAME, METHOD_NAME, "checkRLUser : " + checkRLUser);
            if(checkRLUser){
                return properties.getProperty(PortalConstants.RL_RESTRICTED);
            }else{
                // Getting the value of disabled Logic flag from DB, if not null assigned to disabledLogicFlag variable
                String disabledLogicFlag = properties.getProperty("DISABLED_LOGIC_ACTIVATION_FLAG");
                this.setDisabledLogicActivated((disabledLogicFlag != null) ? Boolean.parseBoolean(disabledLogicFlag) : true);
                
                if (this.isDisabledLogicActivated()) {
                    if (!adUtil.isUserDisabledInAD(userNameDisabled)) {
                        return properties.getProperty(PortalConstants.LOGIN_FORGOT_USERNAME_SUCCESS);
                    } else {
                        // if user is disabled, a user friendly message will be shown from DB
                        krowdLogger.info(CLASS_NAME, METHOD_NAME, LoginConstants.LOGIN_LOG_DISABLED_USER);
                        forgotUsrErrorMsg =
                                repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_DISABLED_USER).toString();
                        krowdLogger.info(CLASS_NAME, METHOD_NAME, "Message for Disabled user is :" + forgotUsrErrorMsg);
                        return properties.getProperty(PortalConstants.LOGIN_FAILURE);
                    }
                } else {
                    return properties.getProperty(PortalConstants.LOGIN_FORGOT_USERNAME_SUCCESS);
                }
            }
        } else {
            forgotUsrErrorMsg =
                    repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_USERNAME_INVALID_COMBINATION).toString();
            return properties.getProperty(PortalConstants.LOGIN_FAILURE);
        }
    }

    /**
     * @return String
     * @description This method is used to validate the given details and to fetch username of a restaurant manager from Active Directory
     */
    public String validateUserDetailsRM() {
        final String METHOD_NAME = "validateUserDetailsRM";
        forgotUsrRMErrorMsg = "";
        String birthdate = null;
        boolean checkRLUser = false;
        
        if (null != selectedDayRM && null != selectedMonthRM && !selectedMonthRM.isEmpty() && !selectedDayRM.isEmpty()) {
            birthdate = selectedDayRM.concat(selectedMonthRM);
            krowdLogger.info("Birthdate for Restaurant Manager user is :" + birthdate);
            krowdLogger.info(CLASS_NAME, METHOD_NAME,
                             " Calling validateUserDetails with tempDate : " + birthdate + " restaurantNumber : " + rmRestaurantNumber +
                             " last4DigitEmpId : " + last4DigitEmpId);
            try{
                userName = adUtil.validateUserDetails(birthdate, rmRestaurantNumber, last4DigitEmpId);
            }catch(LoginPortalException e){                
                krowdLogger.severe(e);
                userName = null;
            }            
            appScope.put("LoginUsername", userName);
            krowdLogger.info(CLASS_NAME, METHOD_NAME, " Returning from validateUserDetails with userName : " + userName);
        }

        if (null != userName && !userName.isEmpty()) {
            checkRLUser = adUtil.isDardenBusinessUnitRL(userName, PortalConstants.DARDEN_BUSINESS_UNIT);
            if (checkRLUser)
                return properties.getProperty(PortalConstants.RL_RESTRICTED);
            else {
                krowdLogger.info(CLASS_NAME, METHOD_NAME, " Calling getUserRole method with userName : " + userName);
                String userRole = adUtil.getUserRole(userName);
                krowdLogger.info(CLASS_NAME, METHOD_NAME, " Returning from getUserRole method with userRole : " + userRole);
                if (userRole.equalsIgnoreCase(properties.getProperty(PortalConstants.LOGIN_RM))) {
                    selectedDayRM = "";
                    selectedMonthRM = "";
                    rmRestaurantNumber = "";
                    last4DigitEmpId = "";
                    return properties.getProperty(PortalConstants.LOGIN_FORGOT_USERNAME_SUCCESS);
                } else if (userRole.equalsIgnoreCase(properties.getProperty(PortalConstants.LOGIN_TM))) {
                    forgotUsrRMErrorMsg =
                            repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_TEAM_MEMBER).toString();
                    return properties.getProperty(PortalConstants.LOGIN_FAILURE);
                } else if (userRole.equalsIgnoreCase(properties.getProperty(PortalConstants.LOGIN_RSC))) {
                    forgotUsrRMErrorMsg =
                            repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_RSC_MEMBERS).toString();
                    return properties.getProperty(PortalConstants.LOGIN_FAILURE);
                }
            }
            return null;
        } else {
            forgotUsrRMErrorMsg =
                    repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_USERNAME_INVALID_COMBINATION).toString();
            return properties.getProperty(PortalConstants.LOGIN_FAILURE);
        }

    }

    public void setForgotUsrErrorMsg(String forgotUsrErrorMsg) {
        this.forgotUsrErrorMsg = forgotUsrErrorMsg;
    }

    public String getForgotUsrErrorMsg() {
        return forgotUsrErrorMsg;
    }

    public void setPosId(String posId) {
        this.posId = posId;
    }

    public String getPosId() {
        return posId;
    }

    public void setRestaurantNumber(String restaurantNumber) {
        this.restaurantNumber = restaurantNumber;
    }

    public String getRestaurantNumber() {
        return restaurantNumber;
    }

    public void setInitials(String initials) {
        this.initials = initials;
    }

    public String getInitials() {
        return initials;
    }

    public void setLast4DigitEmpId(String last4DigitEmpId) {
        this.last4DigitEmpId = last4DigitEmpId;
    }

    public String getLast4DigitEmpId() {
        return last4DigitEmpId;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserName() {
        return userName;
    }

    public void setRmRestaurantNumber(String rmRestaurantNumber) {
        this.rmRestaurantNumber = rmRestaurantNumber;
    }

    public String getRmRestaurantNumber() {
        return rmRestaurantNumber;
    }

    public void setListOfDaysTM(List<SelectItem> listOfDaysTM) {
        this.listOfDaysTM = listOfDaysTM;
    }

    public List<SelectItem> getListOfDaysTM() {
        return listOfDaysTM;
    }

    public void setListOfDaysRM(List<SelectItem> listOfDaysRM) {
        this.listOfDaysRM = listOfDaysRM;
    }

    public List<SelectItem> getListOfDaysRM() {
        return listOfDaysRM;
    }


    public void setSelectedDayTM(String selectedDayTM) {
        this.selectedDayTM = selectedDayTM;
    }

    public String getSelectedDayTM() {
        return selectedDayTM;
    }

    public void setSelectedMonthTM(String selectedMonthTM) {
        this.selectedMonthTM = selectedMonthTM;
    }

    public String getSelectedMonthTM() {
        return selectedMonthTM;
    }

    public void setSelectedDayRM(String selectedDayRM) {
        this.selectedDayRM = selectedDayRM;
    }

    public String getSelectedDayRM() {
        return selectedDayRM;
    }

    public void setSelectedMonthRM(String selectedMonthRM) {
        this.selectedMonthRM = selectedMonthRM;
    }

    public String getSelectedMonthRM() {
        return selectedMonthRM;
    }

    public void daysValueChangeTM(ValueChangeEvent valueChangeEvent) {
        // Add event code here...
        selectedDayTM = String.valueOf(valueChangeEvent.getNewValue());
        krowdLogger.info("Selected day for Team Member is : "+selectedDayTM);
    }

    public void monthValueChangeTM(ValueChangeEvent valueChangeEvent) {
        // Add event code here...
        selectedMonthTM = String.valueOf(valueChangeEvent.getNewValue());
        krowdLogger.info("Selected Month for Team Member is : "+selectedMonthTM);
    }

    public void daysValueChangeRM(ValueChangeEvent valueChangeEvent) {
        // Add event code here...
        selectedDayRM = String.valueOf(valueChangeEvent.getNewValue());
        krowdLogger.info("Selected day Restaurant Manager is : "+selectedDayRM);
    }

    public void monthValueChangeRM(ValueChangeEvent valueChangeEvent) {
        // Add event code here...
        selectedMonthRM = String.valueOf(valueChangeEvent.getNewValue());
        krowdLogger.info("Selected Month Restaurant Manager is : "+selectedMonthRM);
    }
    
    private void populateDateOfBirthDropDowns() {
        listOfDaysTM.clear();
        listOfDaysRM.clear();
        
        //adding 31 days in Days List for Team Members and Restaurant Managers
        for (int dayVar = 1; dayVar <= LoginConstants.LOGIN_NO_OF_DAYS; dayVar++) {
            listOfDaysTM.add(new SelectItem(String.format(properties.getProperty(LoginConstants.LOGIN_DUALDIGIT_FORMAT), dayVar)));
            listOfDaysRM.add(new SelectItem(String.format(properties.getProperty(LoginConstants.LOGIN_DUALDIGIT_FORMAT), dayVar)));
        }
    }

    public void setForgotUsrRMErrorMsg(String forgotUsrRMErrorMsg) {
        this.forgotUsrRMErrorMsg = forgotUsrRMErrorMsg;
    }

    public String getForgotUsrRMErrorMsg() {
        return forgotUsrRMErrorMsg;
    }

    public void setDisabledLogicActivated(boolean disabledLogicActivated) {
        this.disabledLogicActivated = disabledLogicActivated;
    }

    public boolean isDisabledLogicActivated() {
        return disabledLogicActivated;
    }

    public void setCurrentLocale(String currentLocale) {
        this.currentLocale = currentLocale;
    }

    public String getCurrentLocale() {
        return currentLocale;
    }
}
