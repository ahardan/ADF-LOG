package com.darden.krowd.loginflow.bean;


import com.darden.krowd.RIDCCommon.ridc.CMSHelper;
import com.darden.krowd.common.CMSConstants;
import com.darden.krowd.common.KrowdUtility;
import com.darden.krowd.common.LoginPortalException;
import com.darden.krowd.common.PortalConstants;
import com.darden.krowd.common.StringsRepoUtil;
import com.darden.krowd.common.util.ADUtil;
import com.darden.krowd.loginflow.constants.LoginConstants;
import com.darden.krowd.loginflow.util.DatabaseUtil;

import java.io.IOException;
import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;

import javax.naming.NamingException;

import javax.naming.OperationNotSupportedException;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;

import oracle.security.idm.IMException;
import oracle.security.jps.JpsException;

import oracle.webcenter.peopleconnections.connections.internal.model.ConnectionsInternalUtils;
import oracle.webcenter.peopleconnections.profile.ProfileException;
import oracle.webcenter.peopleconnections.profile.internal.model.ProfileInternalUtils;
import oracle.webcenter.peopleconnections.profile.internal.model.ProfileSyncManagerImpl;
import oracle.webcenter.peopleconnections.profile.repository.jpa.WcPeopleConnProfilePhoto;


/**
 * @author
 * @version
 * @description
 */

public class ActivationBean implements Serializable {
    @SuppressWarnings("compatibility:-2274586695613848847")
    private static final long serialVersionUID = 7938060726982373701L;
    private static final String CLASS_NAME = ActivationBean.CLASS_NAME;

    transient ADFLogger krowdLogger = ADFLogger.createADFLogger(ActivationBean.class);
    transient StringsRepoUtil repoUtil = StringsRepoUtil.getInstance();
    transient ADUtil adUtil = new ADUtil();

    transient Properties properties = KrowdUtility.getInstance().getProperties();
    transient DatabaseUtil databaseUtil = DatabaseUtil.getInstance();
    transient Map sessionScope = ADFContext.getCurrent().getSessionScope();

    private Locale locale = FacesContext.getCurrentInstance().getViewRoot().getLocale();
    private String currentLocale = null;

    private boolean visibleAlreadyActivated;
    private boolean status = false;
    private boolean tNcStatus = true;

    private int answerCount = 0;

    private String message = null;
    private String userName = null;
    private String initials = null;
    //private String birthDate = null;
    private String restaurantNumber = null;
    private String posId = null;
    private String emailId = null;
    private String confirmEmailId = null;
    private String termsAndConditionsUserName = null;
    private String chkTermAgmt = null;
    private String secQAerrorMsg = null;
    private String resetPwdErrorMsg = null;
    private String securityQuestion1 = null;
    private String securityQuestion2 = null;
    private String securityQuestion3 = null;
    private String securityAnswer1 = null;
    private String securityAnswer2 = null;
    private String securityAnswer3 = null;
    private String password = null;
    private String confirmPassword = null;
    private String loginPageURL = null;

    private HashMap mapSec = new HashMap();
    private List generateQuestions = new ArrayList();

    private List<SelectItem> securityList1 = new ArrayList<SelectItem>();
    private List<SelectItem> securityList2 = new ArrayList<SelectItem>();
    private List<SelectItem> securityList3 = new ArrayList<SelectItem>();
    private List<SelectItem> listOfDays = new ArrayList<SelectItem>();

    private String selectedDay = null;
    private String selectedMonth = null;

    transient ADFContext adfCtx = ADFContext.getCurrent();
    Map appScope = adfCtx.getSessionScope();
    
    private boolean disabledLogicActivated;

    public ActivationBean() {
        super();
        krowdLogger.info("Locale is :"+locale);
        if(locale != null){
            if(locale.toString().contains("es"))
                this.currentLocale = "es";
            else
                this.currentLocale = "en";
        }else{
            this.currentLocale = "en";
        }
        krowdLogger.info("Current Locale is :"+ this.currentLocale);
        generateSecurityQuestions();
        populateDateOfBirthDropDowns();
    }
    
    public String getTwoFactorLiveStatus(){
        krowdLogger.info("Inside 2factor code method ");

        String _2FactorLive = (String) properties.get("KROWD_2FACTOR_LIVE");
        String _2FactorConcept = (String) properties.get("KROWD_2FACTOR_CONCEPT");
        String attrDardenBusinessUnitValue = adUtil.getUserAttribute(userName, "distinguishedName");
        krowdLogger.info("Darden Business UnitValue "+ attrDardenBusinessUnitValue);       
        krowdLogger.info("2 Factor Concpet DB Property "+ _2FactorConcept);       
        krowdLogger.info("2 Factor Concpet LIVE Property "+ _2FactorLive);       

        //String dardenBusinessUnit = (String)(user.getUserProfile().getPropertyVal("Darden-Business-Unit"));

        krowdLogger.info("2Factor Property Value :"+_2FactorLive);
        if(_2FactorLive != null && _2FactorLive.equalsIgnoreCase("true") && attrDardenBusinessUnitValue.contains(_2FactorConcept)){
            krowdLogger.info("Inside If condition:");
            return "2FactorFlow";
        }else{
            krowdLogger.info("Inside else condition ");
            return "securityQA";
        }
        //return (_2FactorLive != null && _2FactorLive.equalsIgnoreCase("true"))? "2FactorFlow" : "securityQA";
    }
    
    public String getTwoFactorActivaitonFlow(){
        krowdLogger.info("Inside 2factor code method ");

        String _2FactorLive = (String) properties.get("KROWD_2FACTOR_LIVE");
        
        krowdLogger.info("2Factor Property Value :"+_2FactorLive);

        if(_2FactorLive != null && _2FactorLive.equalsIgnoreCase("true")){
            krowdLogger.info("Inside If condition:");

            return "changePassword2Factorflow";
        }else{
            krowdLogger.info("Inside else condition ");

            return "changePassword";
        }
        //return (_2FactorLive != null && _2FactorLive.equalsIgnoreCase("true"))? "2FactorFlow" : "securityQA";
    }

    /**
     * @return String
     * @throws JpsException
     * @throws IMException
     * @throws IOException
     * @description This method is used to validate the user details against AD and check whether the user is activated.
     */
    public String activateProfile() throws JpsException, IMException, IOException {
        final String METHOD_NAME = LoginConstants.LOGIN_METHOD_ACTIVATE_PROFILE;
        message = "";
        try {
            userName = validateUser();
            appScope.put("LoginUsername", userName);
            krowdLogger.info("username is *********** " + userName);
            
            if (userName.isEmpty() && !LoginConstants.LOGIN_CONSTANT_INVALID_RLUSER.equalsIgnoreCase(userName)) {
                krowdLogger.info(CLASS_NAME, METHOD_NAME, LoginConstants.LOGIN_LOG_INVALID_USERNAME);
                message =
                        repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_USERNAME_INVALID_COMBINATION).toString();
                visibleAlreadyActivated = true;
            } else if (LoginConstants.LOGIN_CONSTANT_INVALID_RLUSER.equalsIgnoreCase(userName)) {
                krowdLogger.info(CLASS_NAME, METHOD_NAME, LoginConstants.LOGIN_LOG_RL_USER);
                initials = null;
                selectedDay = "";
                selectedMonth = "";
                restaurantNumber = null;
                posId = null;
                emailId = null;
                confirmEmailId = null;
                return properties.getProperty(PortalConstants.RL_RESTRICTED);
            } else {
                if (!LoginConstants.LOGIN_CONSTANT_INVALID_RLUSER.equalsIgnoreCase(userName)) {
                    if (databaseUtil.getUserActivationStatus(userName)) {
                        krowdLogger.info(CLASS_NAME, METHOD_NAME, LoginConstants.LOGIN_LOG_ACTIVATED_USER);
                        message = repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_ALREADY_ACTIVATED).toString();
                        visibleAlreadyActivated = true;
                    } else {
                        if (emailId.equalsIgnoreCase(confirmEmailId)) {
                            initials = null;
                            selectedDay = "";
                            selectedMonth = "";
                            restaurantNumber = null;
                            posId = null;
                            
                            // Getting the value of disabled Logic flag from DB, if not null assigned to disabledLogicFlag variable
                            String disabledLogicFlag = properties.getProperty("DISABLED_LOGIC_ACTIVATION_FLAG");
                            this.setDisabledLogicActivated((disabledLogicFlag != null) ? Boolean.parseBoolean(disabledLogicFlag) : true);
                            
                            // checking if user is disable in AD. If not disabled, the user will be redirected to TNC page. 
                            if (this.isDisabledLogicActivated()) {
                                if (!adUtil.isUserDisabledInAD(userName)) {
                                    krowdLogger.info(CLASS_NAME, METHOD_NAME,
                                                     LoginConstants.LOGIN_LOG_TNC_REDIRECT + userName + LoginConstants.LOGIN_LOG_EMAILID +
                                                     emailId + LoginConstants.LOGIN_LOG_CONFIRM_EMAILID + confirmEmailId);
                                    return properties.getProperty(PortalConstants.LOGIN_TERM_AGREEMENT);
                                } else {
                                    // if user is disabled, a user friendly message will be shown from DB
                                    krowdLogger.info(CLASS_NAME, METHOD_NAME, LoginConstants.LOGIN_LOG_DISABLED_USER);
                                    message =
                                            repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_DISABLED_USER).toString();
                                    krowdLogger.info(CLASS_NAME, METHOD_NAME, "Message for Disabled user is :" + message);
                                    visibleAlreadyActivated = true;
                                }
                            } else {
                                krowdLogger.info(CLASS_NAME, METHOD_NAME,
                                                 LoginConstants.LOGIN_LOG_TNC_REDIRECT + userName + LoginConstants.LOGIN_LOG_EMAILID +
                                                 emailId + LoginConstants.LOGIN_LOG_CONFIRM_EMAILID + confirmEmailId);
                                return properties.getProperty(PortalConstants.LOGIN_TERM_AGREEMENT);
                            }
                        }
                    }
                }
            }
        } catch(LoginPortalException e){
            LoginPortalException.REASON reason = e.getReasonCode();
            if(reason!=null && reason.compareTo(LoginPortalException.REASON.DOB_MISMATCH) == 0){
                message =  (String)repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_USERNAME_INVALID_COMBINATION).toString();
                visibleAlreadyActivated = true;                  
            }else{
                krowdLogger.severe(e);
            }
        }
        catch (Exception e) {
            krowdLogger.severe(CLASS_NAME, METHOD_NAME, e.getMessage());
        }
        return null;
    }

    /**
     * @return String
     * @description This method validates user details against AD attributes
     */
    public String validateUser() throws LoginPortalException{
        final String METHOD_NAME = LoginConstants.LOGIN_METHOD_VALIDATE_USER;
        String birthdate = null;
        boolean checkRLUser = false;
        try {
            if(null != selectedDay && null !=selectedMonth && !selectedMonth.isEmpty() && !selectedDay.isEmpty()){
                birthdate = selectedDay.concat(selectedMonth);
                krowdLogger.info(CLASS_NAME, METHOD_NAME, LoginConstants.LOGIN_LOG_VAL_USER1 + initials + LoginConstants.LOGIN_LOG_VAL_USER2 + birthdate + 
                                                          LoginConstants.LOGIN_LOG_VAL_USER3 + restaurantNumber + LoginConstants.LOGIN_LOG_VAL_USER4 + posId);
                
                userName = adUtil.validateUserDetails(initials, birthdate, restaurantNumber, posId);
                krowdLogger.info(CLASS_NAME, METHOD_NAME, LoginConstants.LOGIN_LOG_VAL_USER5 + userName);
            }
            if (null != userName && !userName.isEmpty()) {
                krowdLogger.info(CLASS_NAME, METHOD_NAME,
                                 LoginConstants.LOGIN_LOG_VAL_USER6 + userName + LoginConstants.LOGIN_LOG_VAL_USER7 +
                                 PortalConstants.DARDEN_BUSINESS_UNIT);
                checkRLUser = adUtil.isDardenBusinessUnitRL(userName, PortalConstants.DARDEN_BUSINESS_UNIT);
                krowdLogger.info(CLASS_NAME, METHOD_NAME, LoginConstants.LOGIN_LOG_VAL_USER8 + checkRLUser);
                if (checkRLUser)
                    userName = LoginConstants.LOGIN_CONSTANT_INVALID_RLUSER;
            }
        } catch(LoginPortalException e){
            throw e;
        }catch (NullPointerException npe) {
            krowdLogger.severe(CLASS_NAME, METHOD_NAME, npe.getMessage());
        } catch (Exception e) {
            krowdLogger.severe(CLASS_NAME, METHOD_NAME, e.getMessage());
        }
        krowdLogger.info(CLASS_NAME, METHOD_NAME, LoginConstants.LOGIN_LOG_VAL_USER9 + userName);
        return userName;
    }

    /**
     * @return String
     * @description This method gets the user's Alias name from AD.
     */
    public String getTermsAndConditionsUserName() {
        final String METHOD_NAME = LoginConstants.LOGIN_METHOD_GET_TNC_USERNAME;
        krowdLogger.info(CLASS_NAME, METHOD_NAME, LoginConstants.LOGIN_LOG_TNC_USER1 + userName);
        try {
            userName = (String) appScope.get("LoginUsername");
            if (null == userName || userName.isEmpty()) {
                userName = ADFContext.getCurrent().getSecurityContext().getUserName();
                krowdLogger.info(CLASS_NAME, METHOD_NAME, LoginConstants.LOGIN_LOG_TNC_USER2 + userName);
                //Checking whether the user is anonymous
                krowdLogger.info(CLASS_NAME, METHOD_NAME,
                                 "Evaluate Condition : " + properties.getProperty(PortalConstants.LOGIN_ANONYMOUS).equalsIgnoreCase(userName.trim()));
                if (properties.getProperty(PortalConstants.LOGIN_ANONYMOUS).equalsIgnoreCase(userName.trim())) {
                    try {
                        krowdLogger.info(CLASS_NAME, METHOD_NAME, "Redirecting to SiteMinder page since the user is anonymous");
                        FacesContext.getCurrentInstance().getExternalContext().redirect("https://krowddev2.darden.com");
                    } catch (IOException e) {
                        krowdLogger.severe(CLASS_NAME, METHOD_NAME, "Error while redirecting to SiteMinder page", e.getMessage());
                    }
                }
            }
            String aliasAttribute = adUtil.getUserAttribute(userName, PortalConstants.ALIAS_ATTRIBUTE);
            krowdLogger.info(CLASS_NAME, METHOD_NAME,
                             LoginConstants.LOGIN_LOG_TNC_USER3 + userName + LoginConstants.LOGIN_LOG_TNC_USER6 + aliasAttribute);

            if (null == aliasAttribute || aliasAttribute.isEmpty()) {
                termsAndConditionsUserName = userName;
                krowdLogger.info(CLASS_NAME, METHOD_NAME,
                                 LoginConstants.LOGIN_LOG_TNC_USER4 + termsAndConditionsUserName + LoginConstants.LOGIN_LOG_TNC_USER5);
            } else {
                termsAndConditionsUserName = aliasAttribute.trim();
            }
            krowdLogger.info(CLASS_NAME, METHOD_NAME, LoginConstants.LOGIN_LOG_TNC_USER7 + termsAndConditionsUserName);

            HttpServletResponse vResponse = (HttpServletResponse)FacesContext.getCurrentInstance().getExternalContext().getResponse();
            Cookie vNewCookie = null;
            if (null != aliasAttribute) {
                vNewCookie = new Cookie(LoginConstants.LOGIN_CONSTANT_KROWD_ACTIVATED_USER, termsAndConditionsUserName);
                krowdLogger.info(LoginConstants.LOGIN_LOG_TNC_USER8 + vNewCookie.getValue());
            } else {
                vNewCookie = new Cookie(LoginConstants.LOGIN_CONSTANT_KROWD_ACTIVATED_USER, userName);
                krowdLogger.info(LoginConstants.LOGIN_LOG_TNC_USER9 + vNewCookie.getValue());
            }
            vNewCookie.setDomain(LoginConstants.LOGIN_CONSTANT_DARDEN_COM);
            vNewCookie.setPath(LoginConstants.LOGIN_CONSTANT_BACKSLASH);
            vResponse.addCookie(vNewCookie);
        } catch (Exception e) {
            krowdLogger.info(CLASS_NAME, METHOD_NAME, e.getMessage());
        }
        krowdLogger.info(CLASS_NAME, METHOD_NAME, LoginConstants.LOGIN_LOG_TNC_USER7 + termsAndConditionsUserName);
        return termsAndConditionsUserName;
    }

    /**
     * @return String
     * @description returns TermsAndConditions datasource to content presenter task flow.
     */
    public String getTermsAndConditions() {
        CMSHelper cmsHelper = new CMSHelper();
        String queryString = CMSConstants.CMS_TERMS_COND_QUERY;
        String datasource = cmsHelper.getdatsourceSingleNode(queryString);
        krowdLogger.info(LoginConstants.LOGIN_LOG_GET_TNC + datasource);
        if (0 != cmsHelper.getDataFileCount(datasource)) {
            this.tNcStatus = false;
        } else {
            this.tNcStatus = true;
        }
        return datasource;
    }

    /**
     * @return List
     * @description This method is used to generate 8 security questions.
     */
    public List generateSecurityQuestions() {
        generateQuestions.clear();
        krowdLogger.info("this.currentLocale" + this.locale + " :currentLocale is" + this.currentLocale);
        krowdLogger.info("PortalConstants.LOGIN_TOTAL_QUESTION_NO"+ repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_TOTAL_QUESTION_NO));
        for (int secQuestionIterator = 0;
             secQuestionIterator < Integer.parseInt(repoUtil.getStrings().get(currentLocale).get(PortalConstants.LOGIN_TOTAL_QUESTION_NO).toString());
             secQuestionIterator++) {
            generateQuestions.add(repoUtil.getStrings().get(currentLocale).get(PortalConstants.LOGIN_SECURITY_QUESTION +
                                                                                        (secQuestionIterator + 1)));
        }
        mapSec.put(properties.getProperty(PortalConstants.LOGIN_SECURITYQUSETION1), "");
        mapSec.put(properties.getProperty(PortalConstants.LOGIN_SECURITYQUSETION2), "");
        mapSec.put(properties.getProperty(PortalConstants.LOGIN_SECURITYQUSETION3), "");
        return generateQuestions;
    }

    /**
     * @param securityList
     * @param securityMap
     * @param securityQuestion
     * @description This method is used to populate 8 security questions in a list of type SelectItem
     */
    public void populateSecurityQuestion(List<SelectItem> securityList, HashMap securityMap, String securityQuestion) {
        securityList.clear();
        for (int secQuestionIterator = 0; secQuestionIterator < generateQuestions.size(); secQuestionIterator++) {
            if (securityMap.containsValue(Integer.toString(secQuestionIterator + 1)) &&
                !Integer.toString(secQuestionIterator + 1).equals(securityMap.get(securityQuestion).toString())) {
                continue;
            } else {
                securityList.add(new SelectItem(Integer.toString(secQuestionIterator + 1),
                                                generateQuestions.get(secQuestionIterator).toString()));
            }
        }
    }

    /**
     * @return boolean
     * @description This method is used to validate security answers.
     */
    public boolean validateSecurityAnswer() {
        secQAerrorMsg = "";
        try {
            if (securityQuestion1.equals(securityQuestion2) || securityQuestion2.equals(securityQuestion3) ||
                securityQuestion1.equals(securityQuestion3)) {
                secQAerrorMsg =
                        repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_SAME_SECURITYQUESTION).toString();
                return true;
            } else {
                if ((securityAnswer1 == null) || (securityAnswer2 == null) || (securityAnswer3 == null)) {
                    secQAerrorMsg =
                            repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_UNANSWERED_SECURITYQUESTION).toString();
                    return true;
                } else {
                    return false;
                }
            }
        } catch (NullPointerException e) {
            secQAerrorMsg =
                    repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_SELECT_SECURITYQUESTION).toString();
            new LoginPortalException(krowdLogger, "ActivateProfileSecQABean.validateSecurityAnswer()", e);
            return true;
        }
    }


    /**
     * @return String
     * @throws JpsException
     * @throws IMException
     * @description This method is used to save the security questions and the respective answers
     */
    public String saveUserSecurityQA() throws JpsException, IMException {
        final String METHOD_NAME = "saveUserSecurityQA";
        byte[] picByte;
        try {
            String userRole = adUtil.getUserRole(userName);
            if( ! userRole.equalsIgnoreCase(properties.getProperty(PortalConstants.LOGIN_TM)))
            {
            long t = new Date().getTime();
            krowdLogger.info(CLASS_NAME, METHOD_NAME, " get Photo  Start " + (new Date().getTime() -t));
            picByte = adUtil.getUserADPhoto(ADFContext.getCurrent().getSecurityContext().getUserName(), "jpegPhoto");
            krowdLogger.info(CLASS_NAME, METHOD_NAME, " get Photo  end and ProfileSync Start " + (new Date().getTime() -t));
            syncNewProfile();
            krowdLogger.info(CLASS_NAME, METHOD_NAME, "  ProfileSync end and upload photo start " + (new Date().getTime() -t));
            photoUpload(picByte);
            krowdLogger.info(CLASS_NAME, METHOD_NAME, " upload photo end " + (new Date().getTime() -t));
            }
        } catch (NamingException e) {
            krowdLogger.severe(CLASS_NAME, METHOD_NAME, e.getMessage());
        } catch (Exception e) {
            krowdLogger.severe(CLASS_NAME, METHOD_NAME, e.getMessage());
        }
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " Calling validateSecurityAnswer method");
        boolean returnValue = validateSecurityAnswer();
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " Returning from validateSecurityAnswer method with returnValue : " + returnValue);
        boolean status = false;
        HttpServletResponse vResponse = (HttpServletResponse)FacesContext.getCurrentInstance().getExternalContext().getResponse();

        if (ADFContext.getCurrent().getSecurityContext().isAuthenticated()) {
            Cookie vNewCookie = null;
            vNewCookie = new Cookie("ActivateUser", "1");
            vNewCookie.setDomain(LoginConstants.LOGIN_CONSTANT_DARDEN_COM);
            vNewCookie.setPath(LoginConstants.LOGIN_CONSTANT_BACKSLASH);
            vResponse.addCookie(vNewCookie);
        }

        if (!returnValue) {
            userName = (String)appScope.get("LoginUsername");
            if (null == userName || userName.isEmpty()) {
                userName = ADFContext.getCurrent().getSecurityContext().getUserName();
                krowdLogger.info(CLASS_NAME, METHOD_NAME, "Security Question userName from Security Context" + userName);
                if (properties.getProperty(PortalConstants.LOGIN_ANONYMOUS).equalsIgnoreCase(userName.trim())) {
                    try {
                        FacesContext.getCurrentInstance().getExternalContext().redirect(properties.getProperty(PortalConstants.LOGINPAGE_URL));
                        krowdLogger.info(CLASS_NAME, METHOD_NAME, "Redirecting to SiteMinder page since the user is anonymous");
                    } catch (IOException e) {
                        krowdLogger.severe(CLASS_NAME, METHOD_NAME, "Error while redirecting to SiteMinder page", e.getMessage());
                    }
                }
            }
            String aliasAttribute = adUtil.getUserAttribute(userName, PortalConstants.ALIAS_ATTRIBUTE);
            Cookie vNewCookie = null;

            if ((null == aliasAttribute) || ("".equals(aliasAttribute.trim()))) {
                vNewCookie = new Cookie(LoginConstants.LOGIN_CONSTANT_KROWD_ACTIVATED_USER, userName);
                krowdLogger.info("cookie if in sec ques" + vNewCookie.getValue());
            } else {
                vNewCookie = new Cookie(LoginConstants.LOGIN_CONSTANT_KROWD_ACTIVATED_USER, aliasAttribute.trim());
                krowdLogger.info("cookie else in sec ques  " + vNewCookie.getValue());
            }
            vNewCookie.setDomain(LoginConstants.LOGIN_CONSTANT_DARDEN_COM);
            vNewCookie.setPath(LoginConstants.LOGIN_CONSTANT_BACKSLASH);
            vResponse.addCookie(vNewCookie);
            try {
                krowdLogger.info(CLASS_NAME, METHOD_NAME,
                                 " Calling saveUserInformation method with userName : " + userName + " emailId : " + emailId);
                if (databaseUtil.saveUserInformation(userName, emailId)) {
                    krowdLogger.info(CLASS_NAME, METHOD_NAME,
                                     " Calling saveUserSecurityQA method with userName : " + userName + " securityQuestion1 : " +
                                     securityQuestion1 + " securityAnswer1 : " + securityAnswer1 + " securityQuestion2 : " +
                                     securityQuestion2 + " securityAnswer2 : " + securityAnswer2 + " securityQuestion3 : " +
                                     securityQuestion3 + " securityAnswer3 : " + securityAnswer3);
                    status =
                            databaseUtil.saveUserSecurityQA(userName, securityQuestion1, securityAnswer1, securityQuestion2, securityAnswer2,
                                                            securityQuestion3, securityAnswer3);
                    krowdLogger.info(CLASS_NAME, METHOD_NAME, " Returning from saveUserSecurityQA method with status : " + status);
                }
            } catch (Exception e) {
                secQAerrorMsg =
                        repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_SELECT_SECURITYQUESTION).toString();
                new LoginPortalException(krowdLogger, "ActivateProfileSecQABean.saveUserSecurityQA()", e);
            }
            krowdLogger.info("Status : " + status);
            if (status) {
                String userRole = adUtil.getUserRole(userName);
                krowdLogger.info("User Role : " + userRole);
                if ((userRole.equalsIgnoreCase(properties.getProperty(PortalConstants.LOGIN_RSC)) ||
                     userRole.equalsIgnoreCase(properties.getProperty(PortalConstants.LOGIN_RM)))) {
                    krowdLogger.info(CLASS_NAME, METHOD_NAME, "Inside if");
                    krowdLogger.info(CLASS_NAME, METHOD_NAME, " Calling activateProfile method with userName : " + userName);
                    databaseUtil.activateProfile(userName);
                    return properties.getProperty(PortalConstants.LOGIN_ACTIVATE_ACCOUNT_SUCCESS);
                } else {
                    krowdLogger.info("Inside else");
                    return properties.getProperty(PortalConstants.LOGIN_PASSWORD_SCREEN);
                }
            } else {
                return properties.getProperty(PortalConstants.LOGIN_PASSWORD_SCREEN);
            }

        } else {
            return null;
        }
    }


    /**
     * @return String
     * @description
     */
    public String syncNewProfile() {
        new ProfileSyncManagerImpl().syncProfile(ADFContext.getCurrent().getSecurityContext().getUserName());
        try {
            krowdLogger.info(ConnectionsInternalUtils.userNameToGuid(ADFContext.getCurrent().getSecurityContext().getUserName()));
        } catch (ProfileException e) {
            krowdLogger.info(e);
        }
        return "";
    }

    /**
     * @param picByte
     * @return String
     * @description
     */
    public String photoUpload(byte[] picByte) {
        krowdLogger.info(" Inside photoUpload Method ");
        String photoUid = null;
        WcPeopleConnProfilePhoto entity = null;
        krowdLogger.info(" The value of argument picByte :" + String.valueOf(picByte.length));

        EntityManager em = ProfileInternalUtils.getEntityManagerFactory().createEntityManager();
        em.getTransaction().begin();
        Query query = em.createNamedQuery("WcPeopleConnProfilePhoto.findByUserAndSize");
        try {
            query.setParameter("user",
                               ConnectionsInternalUtils.userNameToGuid(ADFContext.getCurrent().getSecurityContext().getUserName()));
            query.setParameter("photosize", oracle.webcenter.peopleconnections.profile.WCUserProfile.PhotoSize.ORIGINAL.name());
            entity = (WcPeopleConnProfilePhoto)query.getSingleResult();
            photoUid = entity.getId();
            if (entity == null) {
                photoUid = UUID.randomUUID().toString();
                entity =
                        new WcPeopleConnProfilePhoto(photoUid, oracle.webcenter.peopleconnections.profile.WCUserProfile.PhotoSize.ORIGINAL.name(),
                                                     ConnectionsInternalUtils.userNameToGuid(ADFContext.getCurrent().getSecurityContext().getUserName()));
            }
            entity.setImageData(picByte);
            em.persist(entity);
            em.getTransaction().commit();
        } catch (ProfileException e) {
            krowdLogger.info(e);
        } catch (NoResultException ex) {
            krowdLogger.severe(ex);
        } finally {
            em.close();
        }
        return "";
    }

    /**
     * @param valueChangeEvent
     * @description This method will increment/decrement the answercount based on the Answer1 Input
     */
    public void changeValue(ValueChangeEvent valueChangeEvent) {
        securityAnswer1 = (String)valueChangeEvent.getNewValue();
        krowdLogger.info("SECURITY ANSWER1 : " + securityAnswer1 +"\n SECURITY QUESTION1 : " + securityQuestion1 +"\n OLD VALUE : " + valueChangeEvent.getOldValue());
        
        if (null == securityAnswer1 || securityAnswer1.equalsIgnoreCase("")) {
            if (answerCount > 0 && null != (String)valueChangeEvent.getOldValue()) {
                answerCount = (securityQuestion1 != null || !securityQuestion1.equalsIgnoreCase("")) ? answerCount - 1 : answerCount;
                krowdLogger.info("SECURITY ANSWER1 --> Answer count post decrement : " + answerCount);
            }
        } else if (securityQuestion1 != null && !securityQuestion1.equalsIgnoreCase("")) {
            if (securityAnswer1 != null && !securityAnswer1.equalsIgnoreCase("")) {
                String oldanswer1 = (String)valueChangeEvent.getOldValue();
                answerCount = (null == oldanswer1 || oldanswer1.equalsIgnoreCase("")) ? answerCount + 1 : answerCount;
                krowdLogger.info("SECURITY ANSWER1 --> Answer count post increment : " + answerCount);
            }
            int answerCountFromProperties = Integer.parseInt(properties.getProperty(PortalConstants.LOGIN_ANSWERED_COUNT));
            answerCount = (answerCount >= answerCountFromProperties) ? answerCountFromProperties : answerCount;
        }
    }

    /**
     * @param valueChangeEvent
     * @description This method will increment/decrement the answercount based on the Answer2 Input
     */
    public void changeValue1(ValueChangeEvent valueChangeEvent) {
        securityAnswer2 = (String)valueChangeEvent.getNewValue();
        krowdLogger.info("SECURITY ANSWER2 : " + securityAnswer2 +"\n SECURITY QUESTION2 : " + securityQuestion2 +"\n OLD VALUE : " + valueChangeEvent.getOldValue());
        
        if (null == securityAnswer2 || securityAnswer2.equalsIgnoreCase("")) {
            if (answerCount > 0 && null != (String)valueChangeEvent.getOldValue()) {
                answerCount = (securityQuestion2 != null || !securityQuestion2.equalsIgnoreCase("")) ? answerCount - 1 : answerCount;
                krowdLogger.info("SECURITY ANSWER2 --> Answer count post decrement : " + answerCount);
            }
        } else if (securityQuestion2 != null && !securityQuestion2.equalsIgnoreCase("")) {
            if (securityAnswer2 != null && !securityAnswer2.equalsIgnoreCase("")) {
                String oldanswer2 = (String)valueChangeEvent.getOldValue();
                answerCount = (null == oldanswer2 || oldanswer2.equalsIgnoreCase("")) ? answerCount + 1 : answerCount;
                krowdLogger.info("SECURITY ANSWER2 --> Answer count post increment : " + answerCount);
            }
            int answerCountFromProperties = Integer.parseInt(properties.getProperty(PortalConstants.LOGIN_ANSWERED_COUNT));
            answerCount = (answerCount >= answerCountFromProperties) ? answerCountFromProperties : answerCount;
        }
    }

    /**
     * @param valueChangeEvent
     * @description This method will increment/decrement the answercount based on the Answer3 Input
     */
    public void changeValue2(ValueChangeEvent valueChangeEvent) {
        securityAnswer3 = (String)valueChangeEvent.getNewValue();
        krowdLogger.info("SECURITY ANSWER3 : " + securityAnswer3 +"\n SECURITY QUESTION3 : " + securityQuestion3 +"\n OLD VALUE : " + valueChangeEvent.getOldValue());
        
        if (null == securityAnswer3 || securityAnswer3.equalsIgnoreCase("")) {
            if (answerCount > 0 && null != (String)valueChangeEvent.getOldValue()) {
                answerCount = (securityQuestion3 != null || !securityQuestion3.equalsIgnoreCase("")) ? answerCount - 1 : answerCount;
                krowdLogger.info("SECURITY ANSWER3 --> Answer count post decrement : " + answerCount);
            }
        } else if (securityQuestion3 != null && !securityQuestion3.equalsIgnoreCase("")) {
            if (securityAnswer3 != null && !securityAnswer3.equalsIgnoreCase("")) {
                String oldanswer3 = (String)valueChangeEvent.getOldValue();
                answerCount = (null == oldanswer3 || oldanswer3.equalsIgnoreCase("")) ? answerCount + 1 : answerCount;
                krowdLogger.info("SECURITY ANSWER3 --> Answer count post increment : " + answerCount);
            }
            int answerCountFromProperties = Integer.parseInt(properties.getProperty(PortalConstants.LOGIN_ANSWERED_COUNT));
            answerCount = (answerCount >= answerCountFromProperties) ? answerCountFromProperties : answerCount;
        }
    }

    /**
     * @param valueChangeEvent
     * @description This method will set the new selected value to question2
     */
    public void twoqueschange(ValueChangeEvent valueChangeEvent) {
        securityQuestion2 = (String)valueChangeEvent.getNewValue();
    }

    /**
     * @param valueChangeEvent
     * @description This method will set the new selected value to question1
     */
    public void onequeschange(ValueChangeEvent valueChangeEvent) {
        securityQuestion1 = (String)valueChangeEvent.getNewValue();
    }

    /**
     * @param valueChangeEvent
     * @description This method will set the new selected value to question3
     */
    public void threequeschange(ValueChangeEvent valueChangeEvent) {
        securityQuestion3 = (String)valueChangeEvent.getNewValue();
    }
    
    /**
     * @return String
     * @description This method is used to set the password during activate account in the 2 factor flow
     */
    public String changePassword2Factorflow() {
        final String METHOD_NAME = "changePassword";
        try {
            userName = (String) appScope.get("LoginUsername");
            if (null == userName || userName.isEmpty()) {
                userName = ADFContext.getCurrent().getSecurityContext().getUserName();
                krowdLogger.info(CLASS_NAME, METHOD_NAME, LoginConstants.LOGIN_LOG_TNC_USER2 + userName);
            }
            if (validatePassword()) {
                String returnValue = null;
                krowdLogger.info(CLASS_NAME, METHOD_NAME,
                                 "Calling doResetPassword method with username : " + userName + " and password : " + password);
                returnValue = adUtil.doResetPassword(userName, password);
                krowdLogger.info(CLASS_NAME, METHOD_NAME, "Returning from doResetPassword method with returnValue : " + returnValue);
                if (returnValue.equalsIgnoreCase(properties.getProperty(PortalConstants.LOGIN_SUCCESS))) {
                    krowdLogger.info(CLASS_NAME, METHOD_NAME, "Calling activateProfile method with username : " + userName);
                    databaseUtil.saveUserInformation(userName, emailId);
                    databaseUtil.activateProfile(userName);
                    return properties.getProperty(PortalConstants.LOGIN_ACTIVATE_ACCOUNT_SUCCESS);
                } else {
                    resetPwdErrorMsg =
                            repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_PASSWORD_EXCEPTION_MESSAGE).toString();
                    return properties.getProperty(PortalConstants.LOGIN_FAILURE);
                }
            }
        } catch(OperationNotSupportedException e){
            krowdLogger.severe("Password change Failure", e);
            resetPwdErrorMsg = repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_PASSWORD_OPERATION_FAILED).toString();
        } catch (Exception e) {
            krowdLogger.info(CLASS_NAME, METHOD_NAME, e.getMessage());
        }
        return properties.getProperty(PortalConstants.LOGIN_FAILURE);
    }

    /**
     * @return String
     * @description This method is used to set the password during activate account.
     */
    public String changePassword() {
        final String METHOD_NAME = "changePassword";
        try {
            userName = (String) appScope.get("LoginUsername");
            if (null == userName || userName.isEmpty()) {
                userName = ADFContext.getCurrent().getSecurityContext().getUserName();
                krowdLogger.info(CLASS_NAME, METHOD_NAME, LoginConstants.LOGIN_LOG_TNC_USER2 + userName);
            }
            if (validatePassword()) {
                String returnValue = null;
                krowdLogger.info(CLASS_NAME, METHOD_NAME,
                                 "Calling doResetPassword method with username : " + userName + " and password : " + password);
                returnValue = adUtil.doResetPassword(userName, password);
                krowdLogger.info(CLASS_NAME, METHOD_NAME, "Returning from doResetPassword method with returnValue : " + returnValue);
                if (returnValue.equalsIgnoreCase(properties.getProperty(PortalConstants.LOGIN_SUCCESS))) {
                    krowdLogger.info(CLASS_NAME, METHOD_NAME, "Calling activateProfile method with username : " + userName);
                    databaseUtil.activateProfile(userName);
                    return properties.getProperty(PortalConstants.LOGIN_ACTIVATE_ACCOUNT_SUCCESS);
                } else {
                    resetPwdErrorMsg =
                            repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_PASSWORD_EXCEPTION_MESSAGE).toString();
                    return properties.getProperty(PortalConstants.LOGIN_FAILURE);
                }
            }
        } catch(OperationNotSupportedException e){
            krowdLogger.severe("Failed to change Password", e);
            resetPwdErrorMsg = repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_PASSWORD_OPERATION_FAILED).toString();
        }  catch (Exception e) {
            krowdLogger.info(CLASS_NAME, METHOD_NAME, e.getMessage());
        }
        return properties.getProperty(PortalConstants.LOGIN_FAILURE);
    }

    /**
     * @return boolean
     * @description This method is used to validate the complexity of the password entered.
     */
    private boolean validatePassword() {
        if (null != password && null != confirmPassword) {
            if (!password.equals(confirmPassword)) {
                resetPwdErrorMsg =
                        repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_PASSWORD_DO_NOT_MATCH).toString();
                password = null;
                confirmPassword = null;
                return false;
            } else if (password.length() < 6 && password.length() > 17) {
                resetPwdErrorMsg =
                        repoUtil.getStrings().get(this.currentLocale).get(PortalConstants.LOGIN_PASSWORD_NOTINRANGE).toString();
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    public void setVisibleAlreadyActivated(boolean visibleAlreadyActivated) {
        this.visibleAlreadyActivated = visibleAlreadyActivated;
    }

    public boolean isVisibleAlreadyActivated() {
        return visibleAlreadyActivated;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserName() {
        return userName;
    }

    public void setInitials(String initials) {
        this.initials = initials;
    }

    public String getInitials() {
        return initials;
    }

/*     public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public String getBirthDate() {
        return birthDate;
    } */

    public void setRestaurantNumber(String restaurantNumber) {
        this.restaurantNumber = restaurantNumber;
    }

    public String getRestaurantNumber() {
        return restaurantNumber;
    }

    public void setPosId(String posId) {
        this.posId = posId;
    }

    public String getPosId() {
        return posId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setConfirmEmailId(String confirmEmailId) {
        this.confirmEmailId = confirmEmailId;
    }

    public String getConfirmEmailId() {
        return confirmEmailId;
    }

    public void setTermsAndConditionsUserName(String termsAndConditionsUserName) {
        this.termsAndConditionsUserName = termsAndConditionsUserName;
    }

    public void setSecQAerrorMsg(String secQAerrorMsg) {
        this.secQAerrorMsg = secQAerrorMsg;
    }

    public String getSecQAerrorMsg() {
        return secQAerrorMsg;
    }

    /**
     * @param securityQuestion1
     * @description Setter method for securityQuestion1 field
     */
    public void setSecurityQuestion1(String securityQuestion1) {

        mapSec.put(properties.getProperty(PortalConstants.LOGIN_SECURITYQUSETION1), securityQuestion1);
        if (null != securityQuestion1 && securityQuestion1.equalsIgnoreCase("")) {
            securityQuestion1 = null;
        }
        this.securityQuestion1 = securityQuestion1;

    }

    public String getSecurityQuestion1() {
        return securityQuestion1;
    }

    /**
     * @param securityQuestion2
     * @description Setter method for securityQuestion2 field
     */
    public void setSecurityQuestion2(String securityQuestion2) {

        mapSec.put(properties.getProperty(PortalConstants.LOGIN_SECURITYQUSETION2), securityQuestion2);
        if (null != securityQuestion2 && securityQuestion2.equalsIgnoreCase("")) {
            securityQuestion2 = null;
        }
        this.securityQuestion2 = securityQuestion2;
    }

    public String getSecurityQuestion2() {
        return securityQuestion2;
    }

    /**
     * @param securityQuestion3
     * @description Setter method for securityQuestion3 field
     */
    public void setSecurityQuestion3(String securityQuestion3) {

        mapSec.put(properties.getProperty(PortalConstants.LOGIN_SECURITYQUSETION3), securityQuestion3);
        if (null != securityQuestion3 && securityQuestion3.equalsIgnoreCase("")) {
            securityQuestion3 = null;
        }
        this.securityQuestion3 = securityQuestion3;
    }

    public String getSecurityQuestion3() {
        return securityQuestion3;
    }

    public void setSecurityAnswer1(String securityAnswer1) {
        this.securityAnswer1 = securityAnswer1;
    }

    public String getSecurityAnswer1() {
        return securityAnswer1;
    }

    public void setSecurityAnswer2(String securityAnswer2) {
        this.securityAnswer2 = securityAnswer2;
    }

    public String getSecurityAnswer2() {
        return securityAnswer2;
    }

    public void setSecurityAnswer3(String securityAnswer3) {
        this.securityAnswer3 = securityAnswer3;
    }

    public String getSecurityAnswer3() {
        return securityAnswer3;
    }

    public void setSecurityList1(List<SelectItem> securityList1) {
        this.securityList1 = securityList1;
    }

    /**
     * @return List
     * @description Getter method for securityList1 field
     */
    public List<SelectItem> getSecurityList1() {

        populateSecurityQuestion(securityList1, mapSec, properties.getProperty(PortalConstants.LOGIN_SECURITYQUSETION1));
        return securityList1;
    }

    public void setSecurityList2(List<SelectItem> securityList2) {
        this.securityList2 = securityList2;
    }

    /**
     * @return List
     * @description Getter method for securityList2 field
     */
    public List<SelectItem> getSecurityList2() {

        populateSecurityQuestion(securityList2, mapSec, properties.getProperty(PortalConstants.LOGIN_SECURITYQUSETION2));
        return securityList2;
    }

    public void setSecurityList3(List<SelectItem> securityList3) {
        this.securityList3 = securityList3;
    }

    /**
     * @return List
     * @description Getter method for securityList3 field
     */
    public List<SelectItem> getSecurityList3() {

        populateSecurityQuestion(securityList3, mapSec, properties.getProperty(PortalConstants.LOGIN_SECURITYQUSETION3));
        return securityList3;
    }


    public void setAnswerCount(int answerCount) {
        this.answerCount = answerCount;
    }

    public int getAnswerCount() {
        return answerCount;
    }


    public void setPassword(String password) {
        this.password = password;
    }

    public String getPassword() {
        return password;
    }

    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }

    public String getConfirmPassword() {
        return confirmPassword;
    }

    public void setResetPwdErrorMsg(String resetPwdErrorMsg) {
        this.resetPwdErrorMsg = resetPwdErrorMsg;
    }

    public String getResetPwdErrorMsg() {
        return resetPwdErrorMsg;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public boolean isStatus() {
        return status;
    }

    public void setChkTermAgmt(String chkTermAgmt) {
        this.chkTermAgmt = chkTermAgmt;
    }

    public String getChkTermAgmt() {
        return chkTermAgmt;
    }


    /**
     * @return String
     * @description
     */
    public String redirectToForgotPwd() {
        // Add event code here...
        final String METHOD_NAME = "redirectToForgotPwd";
        String forgotPwdURL = null;
        krowdLogger.info(CLASS_NAME, METHOD_NAME, "Entering redirectToForgotPwd");
        try {
            //get forgotPwdURL from DB
            HttpServletRequest requestObj = (HttpServletRequest)FacesContext.getCurrentInstance().getExternalContext().getRequest();
            forgotPwdURL =
                    requestObj.getScheme().concat("://").concat(requestObj.getServerName()).concat(properties.getProperty(PortalConstants.LOGIN_FORGOT_PWD_LINK).toString());
            FacesContext.getCurrentInstance().getExternalContext().redirect(forgotPwdURL);
        } catch (Exception e) {
            krowdLogger.severe(CLASS_NAME, METHOD_NAME, e.getMessage());
        }
        krowdLogger.info(CLASS_NAME, METHOD_NAME, "forgotPwdURL : " + forgotPwdURL);
        return forgotPwdURL;
    }

    public void setTNcStatus(boolean tNcStatus) {
        this.tNcStatus = tNcStatus;
    }

    public boolean isTNcStatus() {
        return tNcStatus;
    }

    public void setLoginPageURL(String loginPageURL) {
        this.loginPageURL = loginPageURL;
    }

    public String getLoginPageURL() {
        loginPageURL = properties.getProperty(PortalConstants.LOGINPAGE_URL);
        return loginPageURL;
    }

    /**
     * @param actionEvent
     * @description This method is called to redirect to SM login page.
     */
    public void redirectToLoginPage(ActionEvent actionEvent) {
        final String METHOD_NAME = "redirectToLoginPage";
        actionEvent = null;
        appScope.put("LoginUsername", null);
        ExternalContext ectx = FacesContext.getCurrentInstance().getExternalContext();
        HttpServletResponse response = (HttpServletResponse)ectx.getResponse();
        Cookie killCookie = new Cookie("KROWD_ACTIVATED_USER", null);
        killCookie.setMaxAge(0);
        killCookie.setPath("/");
        Cookie redirectCookie = new Cookie("RedirectHomePage", "1");
        redirectCookie.setDomain(".darden.com");
        redirectCookie.setPath("/");
        response.addCookie(killCookie);
        response.addCookie(redirectCookie);
        krowdLogger.info(CLASS_NAME,METHOD_NAME, "Cookie value : " + killCookie.getValue());
        krowdLogger.info(CLASS_NAME, METHOD_NAME, "Login Page URL is: " + properties.getProperty(PortalConstants.LOGINPAGE_URL));
        try {
            // added the faces context redirection logic in place of Http response logic
           //ectx.redirect(properties.getProperty(PortalConstants.LOGINPAGE_URL));
            String krowdPortalName = (properties.get("KROWD_CURRENT_PORTAL_NAME") != null)?(String)properties.get("KROWD_CURRENT_PORTAL_NAME"):"Krowd";
            String logoutURL = (String)properties.getProperty(PortalConstants.LOGINPAGE_URL)+"/webcenter/portal/"+krowdPortalName+"/logoutServlet";
            krowdLogger.info("logoutURL in login control bean" +logoutURL);
            ectx.redirect(logoutURL);
        } catch (IOException e) {
            krowdLogger.severe(CLASS_NAME, METHOD_NAME, e.getMessage());
        }
    }

    public void cancelLoginFlow(ActionEvent actionEvent) {
        final String METHOD_NAME = "cancelLoginFlow";
        actionEvent=null;

        appScope.put("LoginUsername", null);
        ExternalContext ectx = FacesContext.getCurrentInstance().getExternalContext();
        clearActivatedKrowdUserCookie((HttpServletRequest)ectx.getRequest(), (HttpServletResponse)ectx.getResponse());
        try {
            ectx.redirect(properties.getProperty(PortalConstants.LOGINPAGE_URL));
        } catch (IOException e) {
            krowdLogger.severe(CLASS_NAME, METHOD_NAME, e.getMessage());
        }
    }

    public void clearActivatedKrowdUserCookie(HttpServletRequest request, HttpServletResponse response) {
        Cookie[] persistentCookies = request.getCookies();
        for (int iCount = 0; iCount < persistentCookies.length; iCount++) {
            if ((persistentCookies[iCount].getName().equalsIgnoreCase("KROWD_ACTIVATED_USER"))) {
                persistentCookies[iCount].setDomain(".darden.com");
                persistentCookies[iCount].setPath("/");
                persistentCookies[iCount].setMaxAge(0);
                response.addCookie(persistentCookies[iCount]);
            }
        }

    }
    /* public void deleteUserInformation(ActionEvent actionEvent) {
        // Add event code here...
        final String METHOD_NAME = "deleteUserInformation";
        boolean isUserDeleted = false;
        actionEvent = null;
        FacesContext fctx = FacesContext.getCurrentInstance();
        try {
            krowdLogger.info(CLASS_NAME, METHOD_NAME, "Calling deleteUserInformation method with username : " + userName);
            isUserDeleted = databaseUtil.deleteUserInformation(userName);
            krowdLogger.info(CLASS_NAME, METHOD_NAME, "Returning from deleteUserInformation method with status : " + isUserDeleted);
            //Invalidating the session for the user
            ((HttpSession)fctx.getExternalContext().getSession(false)).invalidate();
            //Redirect the user to SiteMinder page
            krowdLogger.info(CLASS_NAME, METHOD_NAME, "Login Page URL is: " + properties.getProperty(PortalConstants.LOGINPAGE_URL));
            fctx.getExternalContext().redirect(properties.getProperty(PortalConstants.LOGINPAGE_URL));
            return;
        } catch (Exception e) {
            krowdLogger.severe(CLASS_NAME, METHOD_NAME, e.getMessage());
        }
    } */

    public void setListOfDays(List<SelectItem> listOfDays) {
        this.listOfDays = listOfDays;
    }

    public List<SelectItem> getListOfDays() {
        return listOfDays;
    }

    public void daysValueChange(ValueChangeEvent valueChangeEvent) {
        // Add event code here...
        selectedDay = String.valueOf(valueChangeEvent.getNewValue());
        krowdLogger.info("Selected day is : "+selectedDay);
    }

    public void setSelectedDay(String selectedDay) {
        this.selectedDay = selectedDay;
    }

    public String getSelectedDay() {
        return selectedDay;
    }

    public void monthValueChange(ValueChangeEvent valueChangeEvent) {
        // Add event code here...
        selectedMonth = String.valueOf(valueChangeEvent.getNewValue());
        krowdLogger.info("Selected Month is : "+selectedMonth);
    }
    
    private void populateDateOfBirthDropDowns() {
        listOfDays.clear();
        
        //adding 31 days in Days List
        for (int dayVar = 1; dayVar <= LoginConstants.LOGIN_NO_OF_DAYS; dayVar++) {
            listOfDays.add(new SelectItem(String.format(String.format(properties.getProperty(LoginConstants.LOGIN_DUALDIGIT_FORMAT),dayVar))));
        }
    }

    public void setDisabledLogicActivated(boolean disabledLogicActivated) {
        this.disabledLogicActivated = disabledLogicActivated;
    }

    public boolean isDisabledLogicActivated() {
        return disabledLogicActivated;
    }

    public void setSelectedMonth(String selectedMonth) {
        this.selectedMonth = selectedMonth;
    }

    public String getSelectedMonth() {
        return selectedMonth;
    }

    public void setCurrentLocale(String currentLocale) {
        this.currentLocale = currentLocale;
    }

    public String getCurrentLocale() {
        return currentLocale;
    }
}
