package com.darden.krowd.loginflow.util;


import com.darden.krowd.common.exception.KrowdPortalException;
import com.darden.krowd.common.model.applicationModule.loginflow.common.LoginFlowAM;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.share.logging.ADFLogger;


/**
 * @author
 * @version
 * @description
 */

public class DatabaseUtil implements Serializable {

    @SuppressWarnings("compatibility:4021514572983204742")
    private static final long serialVersionUID = 3017378622110694240L;
    private static final String CLASS_NAME = DatabaseUtil.CLASS_NAME;
    private static DatabaseUtil databaseUtil;
    transient ADFLogger krowdLogger = ADFLogger.createADFLogger(DatabaseUtil.class);

    private DatabaseUtil() {
    }

    public static DatabaseUtil getInstance() {
        if (null == databaseUtil)
            databaseUtil = new DatabaseUtil();
        return databaseUtil;
    }

    /**
     * @param userName
     * @return boolean
     * @description This method is used to get the value of UserAckStatus field from Database
     */
    public boolean getUserActivationStatus(String userName) {
        final String METHOD_NAME = "getUserActivationStatus";
        boolean returnValue = false;
        krowdLogger.info(CLASS_NAME, METHOD_NAME, "Username is : " + userName);
        returnValue = this.getLoginAppModuleObj().isUserAcknowledged(userName);
        krowdLogger.info(CLASS_NAME, METHOD_NAME, "User is acknowledged ? : " + returnValue);
        return returnValue;
    }

    /**
     * @param userName
     * @param securityQuestion1
     * @param securityAnswer1
     * @param securityQuestion2
     * @param securityAnswer2
     * @param securityQuestion3
     * @param securityAnswer3
     * @return String
     * @throws KrowdPortalException
     * @description This method is used to save the security question and the corresponding security answers in the table
     */
    public boolean saveUserSecurityQA(String userName, String securityQuestion1, String securityAnswer1, String securityQuestion2,
                                      String securityAnswer2, String securityQuestion3, String securityAnswer3) {
        final String METHOD_NAME = "saveUserSecurityQA";
        boolean returnValue = false;
        krowdLogger.info(CLASS_NAME, METHOD_NAME,
                         "Username : " + userName + " securityQuestion1 : " + securityQuestion1 + " securityAnswer1 : " + securityAnswer1 +
                         " securityQuestion2 : " + securityQuestion2 + " securityAnswer2 : " + securityAnswer2 + " securityQuestion3 : " +
                         securityQuestion3 + " securityAnswer3 : " + securityAnswer3);
        returnValue = this.getLoginAppModuleObj().saveUserSecurityQA(userName, securityQuestion1, securityAnswer1, securityQuestion2, securityAnswer2, securityQuestion3,
                                                   securityAnswer3);
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " Security Question Answers saved ? " + returnValue);
        return returnValue;
    }

    /**
     * @param userName
     * @return String
     * @description This method is used to activate profile for the particular username
     */
    public boolean activateProfile(String userName) {
        final String METHOD_NAME = "activateProfile";
        boolean returnValue = false;
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " Username is : " + userName);
        returnValue = this.getLoginAppModuleObj().activateProfile(userName);
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " Account is activated ? " + returnValue);
        return returnValue;
    }

    /**
     * @param userName
     * @return boolean
     * @description This method is used to save the user details in UserProfile table
     */
    public boolean saveUserInformation(String userName, String emailId) {
        final String METHOD_NAME = "saveUserInformation";
        boolean returnValue = false;
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " Username is : " + userName + " emailId : " + emailId);
        returnValue = this.getLoginAppModuleObj().saveUserInformation(userName, emailId);
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " User details saved ? " + returnValue);
        return returnValue;
    }

    /**
     * @param userName
     * @param securityQuestion1
     * @param securityAnswer1
     * @param securityQuestion2
     * @param securityAnswer2
     * @param securityQuestion3
     * @param securityAnswer3
     * @return String
     * @description This method is used to validate the security answers already entered by the user in WcpSecurityUsrSecurityAnswers table
     */
    public String validateUserSecAnswers(String userName, String securityQuestion1, String securityAnswer1, String securityQuestion2,
                                         String securityAnswer2, String securityQuestion3, String securityAnswer3) {
        final String METHOD_NAME = "validateUserSecAnswers";
        String returnValue = null;
        krowdLogger.info(CLASS_NAME, METHOD_NAME,
                         "Username : " + userName + " securityQuestion1 : " + securityQuestion1 + " securityAnswer1 : " + securityAnswer1 +
                         " securityQuestion2 : " + securityQuestion2 + " securityAnswer2 : " + securityAnswer2 + " securityQuestion3 : " +
                         securityQuestion3 + " securityAnswer3 : " + securityAnswer3);
        returnValue = this.getLoginAppModuleObj().validateUserSecAnswers(userName, securityQuestion1, securityAnswer1, securityQuestion2, securityAnswer2,
                                                       securityQuestion3, securityAnswer3);
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " Validated User details ? " + returnValue);
        return returnValue;
    }

    /**
     * @param userName
     * @param otpPassword
     * @return boolean
     * @description This method is used to validate the OTPResetcode entered by the user in OTP table
     */
    public boolean validateUserPasscode(String userName, String otpPassword) {
        final String METHOD_NAME = "validateUserPasscode";
        boolean returnValue = false;
        
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " Username is : " + userName + " otpPassword : " + otpPassword);
        returnValue = this.getLoginAppModuleObj().validateUserPasscode(userName, otpPassword);
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " Validated Passcode details ? " + returnValue);
        return returnValue;
    }

    /**
     * @param userName
     * @param sysGenOTP
     * @return boolean
     * @description This method is used to save the encrypted OTP into OTP_TEMP table
     */
    public boolean generatePasscode(String userName, String sysGenOTP) {
        final String METHOD_NAME = "generatePasscode";
        boolean returnValue = false;
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " Username is : " + userName + " sysGenOTP : " + sysGenOTP);
        returnValue = this.getLoginAppModuleObj().generatePasscode(userName, sysGenOTP);
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " Saved Passcode details ? " + returnValue);
        return returnValue;
    }

    /**
     * @param userName
     * @return List
     * @description This method is used to fetch the list of security questions for the user
     */
    public List getUserSecurityQuestions(String userName) {
        final String METHOD_NAME = "getUserSecurityQuestions";
        List secQnsList = new ArrayList();
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " Username is : " + userName);
        secQnsList = this.getLoginAppModuleObj().getUserSecurityQuestions(userName);
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " List of  Security Questions : " + secQnsList);
        return secQnsList;
    }

    /**
     * @param userName
     * @return String
     * @description This method is used to save the encrypted OTP into OTP_TEMP table
     */
    public String getUserPersonalEmail(String userName) {
        final String METHOD_NAME = "getUserPersonalEmail";
        String email = null;
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " Username is : " + userName);
        email = this.getLoginAppModuleObj().getCurrentEmail(userName);
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " Email retrieved : " + email);
        return email;
    }
    
    /**
     * @return LoginFlowAM
     * @description This method is used to return Login App Module Object
     */
    private LoginFlowAM getLoginAppModuleObj(){
        final String METHOD_NAME = "getLoginAppModuleObj";
        try {
            DCDataControl dc = BindingContext.getCurrent().findDataControl("LoginFlowAMDataControl");
            dc = (null != dc) ? dc : BindingContext.getCurrent().getDefaultDataControl();
            return (LoginFlowAM)dc.getApplicationModule();
        } catch (Exception e) {
            krowdLogger.severe(CLASS_NAME, METHOD_NAME, e.getMessage());
            return null;
        }
    }
    
    /**
     * @param userName
     * @return String
     * @description This method is used to save the encrypted OTP into OTP_TEMP table
     */
    /* public boolean deleteUserInformation(String userName) {
        final String METHOD_NAME = "deleteUserInformation";
        boolean status = false;
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " Username is : " + userName);
        try {
            DCDataControl dc = BindingContext.getCurrent().findDataControl("LoginFlowAMDataControl");
            if (null == dc) {
                dc = BindingContext.getCurrent().getDefaultDataControl();
            }
            LoginFlowAM loginFlowAM = (LoginFlowAM)dc.getApplicationModule();
            status = loginFlowAM.deleteUserInformation(userName);
        } catch (Exception e) {
            krowdLogger.severe(CLASS_NAME, METHOD_NAME, e.getMessage());
        }
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " Email retrieved : " + status);
        return status;
    } */
}
