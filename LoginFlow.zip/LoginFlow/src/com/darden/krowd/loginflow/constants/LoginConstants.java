package com.darden.krowd.loginflow.constants;

public class LoginConstants {
    public LoginConstants() {
        super();
    }
    
    //subh, CWE-259: Use of Hard-coded Password
    enum Level {
        LOGIN_REDIRECT_EXPIREDPASSWORD_MSG,
        changePwd
    }
    //
    public static final String LOGIN_METHOD_ACTIVATE_PROFILE = "activateProfile";
    public static final String LOGIN_METHOD_VALIDATE_USER = "validateUser";
    public static final String LOGIN_METHOD_GET_TNC_USERNAME = "getTermsAndConditionsUserName";
    
    public static final String LOGIN_CONSTANT_INVALID_RLUSER = "RL_INVALIDUSER";
    public static final String LOGIN_CONSTANT_KROWD_ACTIVATED_USER = "KROWD_ACTIVATED_USER";
    public static final String LOGIN_CONSTANT_DARDEN_COM = ".darden.com";
    public static final String LOGIN_CONSTANT_BACKSLASH = "/";
    
    public static final String LOGIN_LOG_INVALID_USERNAME = "Username Invalid Combination";
    public static final String LOGIN_LOG_RL_USER = "RL User";
    public static final String LOGIN_LOG_ACTIVATED_USER = "User is already activated";
    public static final String LOGIN_LOG_DISABLED_USER = "User is disabled in AD";
    public static final String LOGIN_LOG_TNC_REDIRECT = "Redirecting to Terms and Conditions with username : ";
    public static final String LOGIN_LOG_EMAILID = " emailId : ";
    public static final String LOGIN_LOG_CONFIRM_EMAILID = " confirmEmailId : ";
    public static final String LOGIN_LOG_VAL_USER1 = "Calling validateUserDetails method with : 1. Initials : ";
    public static final String LOGIN_LOG_VAL_USER2 = " 2. DOB : ";
    public static final String LOGIN_LOG_VAL_USER3 = " 3. Restaurant Number : ";
    public static final String LOGIN_LOG_VAL_USER4 = " 4. POS Id : ";
    public static final String LOGIN_LOG_VAL_USER5 = " Returning from validateUserDetails method with username : ";
    public static final String LOGIN_LOG_VAL_USER6 = " Calling isDardenBusinessUnitRL method with : Username : ";
    public static final String LOGIN_LOG_VAL_USER7 = " User Attribute : ";
    public static final String LOGIN_LOG_VAL_USER8 = " Returning from isDardenBusinessUnitRL method with checkRLUser : ";
    public static final String LOGIN_LOG_VAL_USER9 = " Username from AD : ";
    public static final String LOGIN_LOG_TNC_USER1 = " Username is: " ;
    public static final String LOGIN_LOG_TNC_USER2 = " Username from Security Context: " ;
    public static final String LOGIN_LOG_TNC_USER3 = " Alias name for the username ";
    public static final String LOGIN_LOG_TNC_USER4 = " termsAndConditionsUserName is ";
    public static final String LOGIN_LOG_TNC_USER5 = " if Alias name is null";
    public static final String LOGIN_LOG_TNC_USER6 = " is ";
    public static final String LOGIN_LOG_TNC_USER7 = " termsAndConditions UserName: ";
    public static final String LOGIN_LOG_TNC_USER8 = " cookie if ";
    public static final String LOGIN_LOG_TNC_USER9 = " cookie else ";
    public static final String LOGIN_LOG_GET_TNC = " The datasource formed is :";
    public static final String LOGIN_LOG_SET_BTNTXT1 = " Calling getUserRole method with userName : ";
    public static final String LOGIN_LOG_SET_BTNTXT2 = " Returning with getUserRole method with userRole : ";
    public static final String LOGIN_LOG_SET_BTNTXT3 = " Button Text Set : ";
    
    public static final String LOGIN_REDIRECT_SETPWD = Level.changePwd.name();
    public static final String LOGIN_REDIRECT_EXPIREDPASSWORD_MSG = Level.LOGIN_REDIRECT_EXPIREDPASSWORD_MSG.name();
    
    public static final String LOGIN_DUALDIGIT_FORMAT = "LOGIN_DUALDIGIT_FORMAT"; //%02d%
    public static final String LOGIN_START_YEAR = "LOGIN_START_YEAR"; //1910
    public static final String LOGIN_END_YEAR = "LOGIN_END_YEAR"; //2005
    public static final String LOGIN_TEST_YEAR = "LOGIN_TEST_YEAR"; //9999
    
    public static final Integer LOGIN_NO_OF_DAYS = 31;
    
    
    
}
