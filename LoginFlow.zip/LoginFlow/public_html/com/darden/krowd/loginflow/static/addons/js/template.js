var menuJson;
function checkEmail(event) {
    var sEmailOne = $('.emailFieldOne > input').val();
    var sEmailTwo = $('.emailFieldTwo > input').val();
    var saveButton = event.getSource();
    var lang = saveButton.getProperty("Lang");
    lang = lang.toLowerCase();
    if ((lang == null) || (lang.indexOf("es") == -1)) {
      lang = "en";
    }
    else {
      lang = "es";
    }
// Checking If email feild 1 is empty
    if (!validateEmail(sEmailOne)) {

      if (lang == 'en')
        $('.emailFieldOneError').html('Please enter valid Personal Email');
      if (lang == 'es')
        $('.emailFieldOneError').html('Por favor, introduzca la direccion de correo electronico volida');
      event.cancel();
    }


// Checking If email feild 2 is empty
    else if (!validateEmail(sEmailTwo)) {
      if (lang == 'en')
        $('.emailFieldTwoError').html('Please enter valid Personal Email');
      if (lang == 'es')
        $('.emailFieldTwoError').html('Por favor ingrese vÃ¡lida de correo electrÃ³nico personal');
      event.cancel();

    }

// Compare two feilds
    else if (!compareFeilds(sEmailOne, sEmailTwo)) {
      if (lang == 'en')
        $('.emailFieldTwoError').html('Your email does not match');
      if (lang == 'es')
        $('.emailFieldTwoError').html('Tu direcciÃ³n de correo electrÃ³nico no coincide');
      event.cancel();

    }
    else {
      $('.emailFieldOneError').html('');
      $('.emailFieldTwoError').html('');
    }
  }


// Function that validates email address through a regular expression.
  function validateEmail(sEmail) {
    var filter = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
    var sites = ["@bahamabreeze.com", "@capitalgrille.com", "@darden.com", "@eddiev.com", "@longhornsteakhouse.com", "@olivegarden.com", "@olivegardencanada.com", "@seasons52.com", "@yardhouse.com"];
    // Defect 5512 - Changing the email format to lowercase before validating with regular expression and restricted email formats.
    var email_to_lowercase = sEmail.toLowerCase();
    if (filter.test(email_to_lowercase)) {
      for (var count = 0; sites.length > count; count++) {
        if (email_to_lowercase.indexOf(sites[count]) >= 1) {
          return false;
        }
      }
      return true;
    }
    else {
      return false;
    }
  }


//Function to compare two feilds
  function compareFeilds(feild1, feild2) {

    if (feild1.toLowerCase() == feild2.toLowerCase()) {
      return true;
    }
    else {
      return false;
    }
  }

//Function to compare two feilds
  function clearError() {
    $('.emailFieldOneError').html('');
    $('.emailFieldTwoError').html('');
  }


//Function to compare two feilds
  function clearEmails(event) {
    $('.emailFieldOne > input').val('');
    $('.emailFieldTwo > input').val('');
    $('.emailFieldOneError').html('');
    $('.emailFieldTwoError').html('');
    event.cancel();
  }


// Change password end


//Change Password - START

  function showChangePassword(event) {
    var source = event.getSource();
    var popup = AdfPage.PAGE.findComponent("pt1:resetPop1");
    var hints = {};
    popup.show(hints);
  }

  function closePopup(event) {
    var popup = AdfPage.PAGE.findComponent("pt1:resetPop1");
    popup.hide();
    $('.oldPassword > input').val('');
    $('.newPassword > input').val('');
    $('.confirmPassword > input').val('');
  }

//Change Password - END
/** Login Flow JS Functions **/
    function validation(styleclass) {
        return function (evt) {
            var inputValue = $('.' + styleclass + ' > input').val();
            //console.log(inputValue);
        }
    }

    function adf$noValueText$intialize(event) {
        var component = event.getSource();
        component.visitChildren(adf$noValueText$replaceEmptyWithText, null, false);
    }

    function adf$noValueText$onFocus(event) {
        adf$noValueText$replaceTextWithEmpty(event.getSource());
    }

    function adf$noValueText$onBlur(event) {
        adf$noValueText$replaceEmptyWithText(event.getSource());
    }

    function adf$noValueText$replaceTextWithEmpty(component) {
        var noValueText = component.getProperty("noValueText");
        if (typeof noValueText != 'undefined') {
            var domNode = document.getElementById(component.getClientId() + "::content");
            if (domNode.value == component.getProperty("noValueText")) {
                domNode.value = "";
            }
        }
    }

    function adf$noValueText$replaceEmptyWithText(component) {
        var noValueText = component.getProperty("noValueText");
        if (typeof noValueText != 'undefined') {
            var domNode = document.getElementById(component.getClientId() + "::content");
            if (domNode.value == "") {
                domNode.value = component.getProperty("noValueText");
            }
        }
    }

    //clear error messages in find and activation
    function clearActivationError() {
        $('.loginInitialsError').html('');
        $('.loginRestNumberError').html('');
        $('.loginPOSIdError').html('');
        $('.loginDateFmtError').html('');
    }

    //clear error messages in Forgot Username
    function clearDate() {
        $('.loginDateFmtError1').html('');
    }

    function activateProfileValidate(event) {
        var saveButton = event.getSource();
        var lang = saveButton.getProperty("Lang");
        lang = lang.toLowerCase();
        if ((lang == null) || (lang.indexOf("es") ==  - 1)) {
            lang = "en";
        }
        else {
            lang = "es";
        }

        var sLoginInitials = $('.loginInitials > input').val();
        var ActPrfle_dob_day = $('.actPrfle_dob_day >select option:selected').val();
        var ActPrfle_dob_month = $('.actPrfle_dob_month >select option:selected').val();
        var sLoginRestNumber = $('.loginRestNumber > input').val();
        var sLoginPOSId = $('.loginPOSId > input').val();

        var initFilter = /^[A-z]{2}$/;
        var restFilter = /^[0-9]{4}$/;
        var posIdFilter = /^[0-9]{1,9}$/;
        if (!regexValidation(sLoginInitials, initFilter)) {
            if (lang == 'en')
                $('.loginInitialsError').html('Please enter your first and last initials.(Ex:AA)');
            if (lang == 'es')
                $('.loginInitialsError').html('Por favor ingrese sus iniciales del nombre y apellido.(Ex:AA)');
            event.cancel();
        }

        if (ActPrfle_dob_day == 0 || ActPrfle_dob_month == 0) {
            if (lang == 'en')
                $('.loginDateFmtError').html('Please select your date of birth : MM/DD');
            if (lang == 'es')
                $('.loginDateFmtError').html('Por favor seleccione su fecha de nacimiento: MM/DD');
            event.cancel();
        }
        else {
            $('.loginDateFmtError').html('');
        }

        if (!regexValidation(sLoginRestNumber, restFilter)) {
            if (lang == 'en')
                $('.loginRestNumberError').html('Don’t remember? <br/> Refer to your timecard, paycheck or ask your manager for assistance.');
            if (lang == 'es')
                $('.loginRestNumberError').html('No te acuerdas? <br/> Consulte la tarjeta de tiempo, cheque o pregunte a su administrador de ayuda.');
            event.cancel();
        }

        if (!regexValidation(sLoginPOSId, posIdFilter)) {
            if (lang == 'en')
                $('.loginPOSIdError').html('Enter your clock in number. <br/> Forgot POS ID? <br/> Ask Manager for assistance. <br/> New Employee? <br/> Allow 24 hours after POS ID assignment to activate your account in Krowd.');
            if (lang == 'es')
                $('.loginPOSIdError').html('Escriba su reloj en número. <br/> ¿Olvidó ID POS? <br/> Pregunta Manager para asistencia. <br/> ¿Nuevo empleado? <br/> Deje transcurrir 24 horas después de la asignación POS ID para activar su cuenta en Krowd.');
            event.cancel();
        }

        checkEmail(event);
        if(event.isCanceled()) {
     if (lang == 'en')
      $('.bottom-error').html('Please check if all your data is valid');
    if (lang == 'es')
      $('.bottom-error').html('Por favor, compruebe si todos sus datos son v�lidos');
}
    }

    function numberValidation(styleclass, length, errorclass, enMsg, esMsg) {
        return function (evt) {
         $('.bottom-error').html('');
            var regex = '^[0-9]{' + length + '}$';
            if (!(regexCommonValidation(evt, styleclass, regex, errorclass, enMsg, esMsg))) {
                evt.cancel();
            }
        }
    }

    function posValidation(styleclass, errorclass, enMsg, esMsg) {
        return function (evt) {
         $('.bottom-error').html('');
            var regex = '^[0-9]{1,9}$';
            if (!(regexCommonValidation(evt, styleclass, regex, errorclass, enMsg, esMsg))) {
                evt.cancel();
            }
        }
    }

    function charValidation(styleclass, length, errorclass, enMsg, esMsg) {
        return function (evt) {
         $('.bottom-error').html('');
            var regex = '^[A-z]{' + length + '}$';
            if (!(regexCommonValidation(evt, styleclass, regex, errorclass, enMsg, esMsg))) {
                evt.cancel();
            }
        }
    }

    function emailValidation(styleclass, errorclass, enMsg, esMsg) {
        return function (evt) {
         $('.bottom-error').html('');
            var regex = '^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$';
            if (!(regexCommonValidation(evt, styleclass, regex, errorclass, enMsg, esMsg))) {
                evt.cancel();
            }
        }
    }

    function mixedInputValidate(styleclass, length, errorclass, enMsg, esMsg) {
        return function (evt) {
            var regex = '^[0-9a-z��������������A-Z ]{1,' + length + '}$';
            if (!(regexCommonValidation(evt, styleclass, regex, errorclass, enMsg, esMsg))) {
                evt.cancel();
            }
        }
    }

    function passwordValidation(styleclass, errorclass, enMsg, esMsg) {
        return function (evt) {
            var regex = '^[0-9a-z��������������A-Z ]{7,16}$';
            if (!(regexCommonValidation(evt, styleclass, regex, errorclass, enMsg, esMsg))) {
                evt.cancel();
            }
        }
    }

    function regexCommonValidation(evt, styleclass, regex, errorclass, enMsg, esMsg) {
        var inputId = '.' + styleclass + ' > input';
        var inputValue = $(inputId).val();
        var saveButton = evt.getSource();
        var lang = saveButton.getProperty("Lang");

        lang = lang.toLowerCase();
        if ((lang == null) || (lang.indexOf("es") ==  - 1)) {
            lang = "en";
        }
        else {
            lang = "es";
        }
        if (!regexValidation(inputValue, regex)) {
            //console.log("inside if");
            if (lang == 'en')
                $('.' + errorclass).html(enMsg);
            if (lang == 'es')
                $('.' + errorclass).html(esMsg);
            return false;
        }
        else {
            //Hide/remove the message   
            $('.' + errorclass).html('');
        }
    }

    function regexValidation(inputValue, regex) {
        var Regex = new RegExp(regex);
        return Regex.test(inputValue);
    }

    function userNameValidate(event) {
        var saveButton = event.getSource();
        var lang = saveButton.getProperty("Lang");
        lang = lang.toLowerCase();
        if ((lang == null) || (lang.indexOf("es") ==  - 1)) {
            lang = "en";
        }
        else {
            lang = "es";
        }

        var sLoginName = $('.loginForgotPassName > input').val();
        var regex = '^[0-9a-z��������������A-Z ]{7,16}$';
        if (!regexValidation(sLoginName, regex)) {
            if (lang == 'en')
                $('.loginForgotPassNameError').html('Please enter your username.');
            if (lang == 'es')
                $('.loginForgotPassNameError').html('Por favor ingrese su nombre de usuario.');
            event.cancel();
        }
    }

    function setPasswordValidate(event) {
        var saveButton = event.getSource();
        var lang = saveButton.getProperty("Lang");
        lang = lang.toLowerCase();
        if ((lang == null) || (lang.indexOf("es") ==  - 1)) {
            lang = "en";
        }
        else {
            lang = "es";
        }
        var sLoginName = $('.loginUserName > input').val();
        var regex = '^[0-9a-z��������������A-Z ]{7,16}$';
        if (!regexValidation(sLoginName, regex)) {
            if (lang == 'en')
                $('.loginUserNameError').html('Please enter the username.');
            if (lang == 'es')
                $('.loginUserNameError').html('Por favor ingrese su nombre de usuario.');
            event.cancel();
        }
        checkLoginPassword(event);
    }

    function forgotPasswordValidate(event) {
        var saveButton = event.getSource();
        var lang = saveButton.getProperty("Lang");
        lang = lang.toLowerCase();
        if ((lang == null) || (lang.indexOf("es") ==  - 1)) {
            lang = "en";
        }
        else {
            lang = "es";
        }
        var sLoginName = $('.loginForgotPassName > input').val();
        sLoginName = (sLoginName != 'Username') ? sLoginName : '';
        var regex = '^[0-9a-z��������������A-Z]{1,64}$';
        if (!regexValidation(sLoginName, regex)) {
            if (lang == 'en')
                $('.loginForgotPassNameError').html('Please enter your username');
            if (lang == 'es')
                $('.loginForgotPassNameError').html('Por favor ingrese su nombre de usuario.');
            event.cancel();
        }
    }

    function checkLoginPassword(event) {
        var sLoginNewPass = $('.loginNewPass > input').val();
        var sLoginConfirmPass = $('.loginConfirmPass > input').val();
        var regex = '^[0-9a-z��������������A-Z ]{7,16}$';
        var saveButton = event.getSource();
        var lang = saveButton.getProperty("Lang");
        lang = lang.toLowerCase();
        if ((lang == null) || (lang.indexOf("es") ==  - 1)) {
            lang = "en";
        }
        else {
            lang = "es";
        }
        // Checking If password field 1 is empty
        if (!regexValidation(sLoginNewPass, regex)) {

            if (lang == 'en')
                $('.loginNewPassError').html('Please enter a new password.');
            if (lang == 'es')
                $('.loginNewPassError').html('Por favor introduzca una nueva contraseña.');
            event.cancel();
        }

        // Checking If password field 2 is empty
        else if (!regexValidation(sLoginConfirmPass, regex)) {
            if (lang == 'en')
                $('.loginConfirmPassError').html('Please enter to confirm password.');
            if (lang == 'es')
                $('.loginConfirmPassError').html('Por favor introduzca la contraseña para confirmar.');
            event.cancel();

        }

        // Compare two feilds
        else if (!compareFeilds(sLoginNewPass, sLoginNewPass)) {
            if (lang == 'en')
                $('.loginConfirmPassError').html('Your password does not match.');
            if (lang == 'es')
                $('.loginConfirmPassError').html('Tu contraseña no coincide.');
            event.cancel();

        }
        else {
            $('.loginNewPassError').html('');
            $('.loginConfirmPassError').html('');
        }
    }

    function validateUserDetails(event) {
        var saveButton = event.getSource();
        var lang = saveButton.getProperty("Lang");
        lang = lang.toLowerCase();
        if ((lang == null) || (lang.indexOf("es") ==  - 1)) {
            lang = "en";
        }
        else {
            lang = "es";
        }

        var sLoginInitials = $('.loginInitials > input').val();
        var sLoginRestNumber = $('.loginRestNumber > input').val();
        var sLoginPOSId = $('.loginPOSId > input').val();
        var ActPrfle_dob_day = $('.actPrfle_dob_day >select option:selected').val();
        var ActPrfle_dob_month = $('.actPrfle_dob_month >select option:selected').val();

        var initFilter = /^[A-z]{2}$/;
        var restFilter = /^[0-9]{4}$/;
        var posIdFilter = /^[0-9]{1,9}$/;

        if (!regexValidation(sLoginInitials, initFilter)) {
            if (lang == 'en')
                $('.loginInitialsError').html('Please enter your first and last initials.(Ex:AA)');
            if (lang == 'es')
                $('.loginInitialsError').html('Por favor ingrese sus iniciales del nombre y apellido.(Ex:AA)');
            event.cancel();
        }

        if (ActPrfle_dob_day == 0 || ActPrfle_dob_month == 0) {
            if (lang == 'en')
                $('.loginDateFmtError').html('Please select your date of birth : MM/DD');
            if (lang == 'es')
                $('.loginDateFmtError').html('Por favor seleccione su fecha de nacimiento: MM/DD');
            event.cancel();
        }
        else {
            $('.loginDateFmtError').html('');
        }

        if (!regexValidation(sLoginRestNumber, restFilter)) {
            if (lang == 'en')
                $('.loginRestNumberError').html('Don’t remember? <br/> Refer to your timecard,.paycheck or ask your manager for assistance.');
            if (lang == 'es')
                $('.loginRestNumberError').html('No te acuerdas? <br/> Consulte la tarjeta de tiempo, cheque o pregunte a su administrador de ayuda.');
            event.cancel();
        }

        if (!regexValidation(sLoginPOSId, posIdFilter)) {
            if (lang == 'en')
                $('.loginPOSIdError').html('Enter your clock in number. <br/> Forgot POS ID? <br/> Ask Manager for assistance. <br/> New Employee? <br/> Allow 24 hours after POS ID assignment to activate your account in Krowd');
            if (lang == 'es')
                $('.loginPOSIdError').html('Escriba su reloj en número. <br/> ¿Olvidó ID POS? <br/> Pregunta Manager para asistencia. <br/> ¿Nuevo empleado? <br/> Deje transcurrir 24 horas después de la asignación POS ID para activar su cuenta en Krowd');
            event.cancel();
        }
    }

    function validateRMDetails(event) {
        var saveButton = event.getSource();
        var lang = saveButton.getProperty("Lang");
        lang = lang.toLowerCase();
        if ((lang == null) || (lang.indexOf("es") ==  - 1)) {
            lang = "en";
        }
        else {
            lang = "es";
        }

        var sLoginRestNumber = $('.loginRestNumber > input').val();
        var sEmployeeId = $('.loginEmplId > input').val();
        var ActPrfle_dob_day = $('.actPrfle_dob_dayRM >select option:selected').val();
        var ActPrfle_dob_month = $('.actPrfle_dob_monthRM >select option:selected').val();

        var restFilter = /^[0-9]{4}$/;

        if (!regexValidation(sLoginRestNumber, restFilter)) {
            if (lang == 'en')
                $('.loginRestNumberError').html('Don’t remember? <br/> Refer to your timecard, paycheck or ask your manager for assistance.');
            if (lang == 'es')
                $('.loginRestNumberError').html('No te acuerdas? <br/> Consulte la tarjeta de tiempo, cheque o pregunte a su administrador de ayuda.');
            event.cancel();
        }

        if (!regexValidation(sEmployeeId, restFilter)) {
            if (lang == 'en')
                $('.loginEmplIdError').html('Please enter last 4 digits of your Employee ID.');
            if (lang == 'es')
                $('.loginEmplIdError').html('Por favor, introduzca últimos 4 dígitos de su ID de empleado.');
            event.cancel();
        }

        if (ActPrfle_dob_day == 0 || ActPrfle_dob_month == 0) {
            if (lang == 'en')
                $('.loginDateFmtError1').html('Please select your date of birth : MM/DD');
            if (lang == 'es')
                $('.loginDateFmtError1').html('Por favor seleccione su fecha de nacimiento: MM/DD');
            event.cancel();
        }
        else {
            $('.loginDateFmtError1').html('');
        }
    }
    
    function mobValidateTMDetails(event) {
        var saveButton = event.getSource();
        var lang = saveButton.getProperty("Lang");
        lang = lang.toLowerCase();
        if ((lang == null) || (lang.indexOf("es") ==  - 1)) {
            lang = "en";
        }
        else {
            lang = "es";
        }

        var sLoginInitials = $('.mobloginInitials > input').val();
        var sLoginRestNumber = $('.mobloginRestNumber > input').val();
        var sLoginPOSId = $('.mobloginPOSId > input').val();
        var ActPrfle_dob_day = $('.mobActPrfle_dob_dayTM >select option:selected').val();
        var ActPrfle_dob_month = $('.mobActPrfle_dob_monthTM >select option:selected').val();

        var initFilter = /^[A-z]{2}$/;
        var restFilter = /^[0-9]{4}$/;
        var posIdFilter = /^[0-9]{1,9}$/;

        if (!regexValidation(sLoginInitials, initFilter)) {
            if (lang == 'en')
                $('.mobloginInitialsError').html('Please enter your first and last initials.(Ex:AA)');
            if (lang == 'es')
                $('.mobloginInitialsError').html('Por favor ingrese sus iniciales del nombre y apellido.(Ex:AA)');
            event.cancel();
        }

        if (ActPrfle_dob_day == 0 || ActPrfle_dob_month == 0) {
            if (lang == 'en')
                $('.mobloginDateFmtError').html('Please select your date of birth : MM/DD');
            if (lang == 'es')
                $('.mobloginDateFmtError').html('Por favor seleccione su fecha de nacimiento: MM/DD');
            event.cancel();
        }
        else {
            $('.mobloginDateFmtError').html('');
        }

        if (!regexValidation(sLoginRestNumber, restFilter)) {
            if (lang == 'en')
                $('.mobloginRestNumberError').html('Don’t remember? <br/> Refer to your timecard, paycheck or ask your manager for assistance.');
            if (lang == 'es')
                $('.mobloginRestNumberError').html('No te acuerdas? <br/> Consulte la tarjeta de tiempo, cheque o pregunte a su administrador de ayuda.');
            event.cancel();
        }

        if (!regexValidation(sLoginPOSId, posIdFilter)) {
            if (lang == 'en')
                $('.mobloginPOSIdError').html('Enter your clock in number. <br/> Forgot POS ID? <br/> Ask Manager for assistance. <br/> New Employee? <br/> Allow 24 hours after POS ID assignment to activate your account in Krowd.');
            if (lang == 'es')
                $('.mobloginPOSIdError').html('Escriba su reloj en número. <br/> ¿Olvidó ID POS? <br/> Pregunta Manager para asistencia. <br/> ¿Nuevo empleado? <br/> Deje transcurrir 24 horas después de la asignación POS ID para activar su cuenta en Krowd.');
            event.cancel();
        }
    }

    function mobValidateRMDetails(event) {
        var saveButton = event.getSource();
        var lang = saveButton.getProperty("Lang");
        lang = lang.toLowerCase();
        if ((lang == null) || (lang.indexOf("es") ==  - 1)) {
            lang = "en";
        }
        else {
            lang = "es";
        }

        var sLoginRestNumber = $('.mobloginRestNumberRM > input').val();
        var sEmployeeId = $('.mobloginEmplId > input').val();
        var ActPrfle_dob_day = $('.mobActPrfle_dob_dayRM >select option:selected').val();
        var ActPrfle_dob_month = $('.mobActPrfle_dob_monthRM >select option:selected').val();

        var restFilter = /^[0-9]{4}$/;

        if (!regexValidation(sLoginRestNumber, restFilter)) {
            if (lang == 'en')
                $('.mobloginRestNumberRMError').html('Don’t remember? <br/> Refer to your timecard, paycheck or ask your manager for assistance.');
            if (lang == 'es')
                $('.mobloginRestNumberRMError').html('No te acuerdas? <br/> Consulte la tarjeta de tiempo, cheque o pregunte a su administrador de ayuda.');
            event.cancel();
        }

        if (!regexValidation(sEmployeeId, restFilter)) {
            if (lang == 'en')
                $('.mobloginEmplIdError').html('Please enter last 4 digits of your Employee ID.');
            if (lang == 'es')
                $('.mobloginEmplIdError').html('Por favor, introduzca últimos 4 dígitos de su ID de empleado.');
            event.cancel();
        }

        if (ActPrfle_dob_day == 0 || ActPrfle_dob_month == 0) {
            if (lang == 'en')
                $('.mobloginDateFmtError1').html('Please select your date of birth : MM/DD');
            if (lang == 'es')
                $('.mobloginDateFmtError1').html('Por favor seleccione su fecha de nacimiento: MM/DD');
            event.cancel();
        }
        else {
            $('.mobloginDateFmtError1').html('');
        }
    }

    function validatePwdSecQA(event) {

        var saveButton = event.getSource();
        var lang = saveButton.getProperty("Lang");
        var regex = '^[0-9a-z��������������A-Z ]{1,45}$';
        lang = lang.toLowerCase();
        if ((lang == null) || (lang.indexOf("es") ==  - 1)) {
            lang = "en";
        }
        else {
            lang = "es";
        }

        var sSecQA1 = $('.loginSecA1 > input').val();
        var sSecQA2 = $('.loginSecA2 > input').val();
        var sSecQ1 = $('.secQ1 > select option:selected').val();
        var sSecQ2 = $('.secQ2 > select option:selected').val();

        if (((sSecQA1 == null || sSecQA1 == '') || (sSecQA2 == null || sSecQA2 == '')) || (sSecQ1 == 0 || sSecQ1 == '') || (sSecQ2 == 0 || sSecQ2 == '')) {
            if (lang == 'en')
                $('.all-error').html('Please answer atleast 2 Security Questions.');
            if (lang == 'es')
                $('.all-error').html('Por favor respuesta al menos 2 cuestiones de seguridad.');
            event.cancel();
        }
        else if (!regexSecQValidation(lang, 'loginSecA1', regex, 'loginSecA1Error', 'Please answer the first security question without special characters', 'Por favor, responder a la segunda pregunta de seguridad y sin caracteres especiales')) {
            event.cancel();
        }
        else if (!regexSecQValidation(lang, 'loginSecA2', regex, 'loginSecA2Error', 'Please answer the second security question without special characters', 'Por favor, responder a la segunda pregunta de seguridad y sin caracteres especiales')) {
            event.cancel();
        }
        else {
            $('.loginSecA1Error').html('');
            $('.loginSecA2Error').html('');
        }
    }

function regexSecQValidation(lang,styleclass,regex,errorclass,enMsg, esMsg){
    var inputId = '.' + styleclass + ' > input';
    var inputValue = $(inputId).val();
 
    
    lang = lang.toLowerCase();
    if ((lang == null) || (lang.indexOf("es") ==  - 1)) {
      lang = "en";
    }
    else {
      lang = "es";
    }
    if (!regexValidation(inputValue, regex)) {
   
      if (lang == 'en')
        $('.' + errorclass).html(enMsg);
      if (lang == 'es')
        $('.' + errorclass).html(esMsg);
      return false;
    }
    else {
      //Hide/remove the message   
      $('.' + errorclass).html('');
  
       return true;
    }
}

function validateSecQA(event) {

  var saveButton = event.getSource();
  var lang = saveButton.getProperty("Lang");
  var regex = '^[0-9a-z��������������A-Z ]{1,45}$';
  lang = lang.toLowerCase();
  if ((lang == null) || (lang.indexOf("es") ==  - 1)) {
    lang = "en";
  }
  else {
    lang = "es";
  }

  var sSecQA1 = $('.loginSecA1 > input').val();
  var sSecQA2 = $('.loginSecA2 > input').val();
  var sSecQA3 = $('.loginSecA3 > input').val();

  if ((sSecQA1 == null || sSecQA1 == '') || (sSecQA2 == null || sSecQA2 == '') || (sSecQA3 == null || sSecQA3 == '')) {
    if (lang == 'en')
      $('.all-error').html('Please answer all the Security Questions');
    if (lang == 'es')
      $('.all-error').html('Por favor conteste todas las preguntas de seguridad');
    event.cancel();
  }
  else if( ! regexSecQValidation(lang,'loginSecA1',regex,'loginSecA1Error','Please answer the first security question without special characters','Por favor, responder a la segunda pregunta de seguridad y sin caracteres especiales')) {
    event.cancel(); 
 }
 
 else if( ! regexSecQValidation(lang,'loginSecA2',regex,'loginSecA2Error','Please answer the second security question without special characters','Por favor, responder a la segunda pregunta de seguridad y sin caracteres especiales')){
      event.cancel();  
  }
 else  if( ! regexSecQValidation(lang,'loginSecA3',regex,'loginSecA3Error','Please answer the third security question without special characters','Por favor, responder a la tercera pregunta de seguridad y sin caracteres especiales')){
     event.cancel();    
   }
else{
     $('.loginSecA1Error').html('');
     $('.loginSecA2Error').html('');
     $('.loginSecA3Error').html('');
  }
}
    function passcodeValidate(event) {
        var saveButton = event.getSource();
        var lang = saveButton.getProperty("Lang");
        lang = lang.toLowerCase();
        if ((lang == null) || (lang.indexOf("es") ==  - 1)) {
            lang = "en";
        }
        else {
            lang = "es";
        }

        var sUsername = $('.loginPassVerifyName > input').val();
        sUsername = (sUsername != 'Username') ? sUsername : '';
        var sPassCode = $('.loginOtpPass > input').val();
        sPassCode = (sPassCode != 'Passcode') ? sPassCode : '';

        var regexFilter = '^[0-9a-z��������������A-Z]{1,64}$';

        if (!regexValidation(sUsername, regexFilter)) {
            if (lang == 'en')
                $('.loginPassVerifyNameError').html('Please enter your username.');
            if (lang == 'es')
                $('.loginPassVerifyNameError').html('Por favor ingrese su nombre de usuario.');
            event.cancel();
        }

        if (!regexValidation(sPassCode, regexFilter)) {
            if (lang == 'en')
                $('.loginOtpPassError').html('Please enter your password reset code.');
            if (lang == 'es')
                $('.loginOtpPassError').html('Introduzca su código de restablecimiento de contraseña.');
            event.cancel();
        }
    }

    //To set tab name for Loginflow
    function setLoginFlowTitle(event) {
        var url = window.location.search;//Getting url search data . example ?value=...
        //var language = event.getSource().getProperty("language");
        ////Getting undefind value on page load so used below js code to get lang value.
        var language = document.documentElement.lang;
        if ( - 1 != url.indexOf("&value=Activate")) {
            if (language == 'en')
                $(document).prop('title', "Activate Profile");
            if (language == 'es')
                $(document).prop('title', "Activar Perfil");
        }
        else if ( - 1 != url.indexOf("&value=ForgotPwd")) {
            if (language == 'en')
                $(document).prop('title', "Forgot Password");
            if (language == 'es')
                $(document).prop('title', "Se te olvidó tu contraseña");
        }
        else if ( - 1 != url.indexOf("&value=ForgotUser")) {
            if (language == 'en')
                $(document).prop('title', "Forgot Username");
            if (language == 'es')
                $(document).prop('title', "¿Olvidó nombre de usuario");
        }
        else if ( - 1 != url.indexOf("&value=PasscodeVerify")) {
            if (language == 'en')
                $(document).prop('title', "Passcode Verification");
            if (language == 'es')
                $(document).prop('title', "Código de acceso Verificación");
        }
        event.cancel();
    }

    function selectDateDDYY() {
     $('.bottom-error').html('');
        var ActPrfle_dob_day = $('.actPrfle_dob_day >select option:selected').val();
        var ActPrfle_dob_year = $('.actPrfle_dob_year >select option:selected').val();
        if (ActPrfle_dob_day != 0 && ActPrfle_dob_year != 0) {
            $('.loginDateFmtError').html('');
        }
    }

    function selectDateDDMM() {
     $('.bottom-error').html('');
        var ActPrfle_dob_day = $('.actPrfle_dob_day >select option:selected').val();
        var ActPrfle_dob_month = $('.actPrfle_dob_month >select option:selected').val();
        if (ActPrfle_dob_day != 0 && ActPrfle_dob_month != 0) {
            $('.loginDateFmtError').html('');
        }
    }

    function selectDateDDMMRM() {
        var ActPrfle_dob_day = $('.actPrfle_dob_dayRM >select option:selected').val();
        var ActPrfle_dob_month = $('.actPrfle_dob_monthRM >select option:selected').val();
        if (ActPrfle_dob_day != 0 && ActPrfle_dob_month != 0) {
            $('.loginDateFmtError1').html('');
        }
    }
    
    function selectMobDateDDMM() {
        var ActPrfle_dob_day = $('.mobActPrfle_dob_dayTM >select option:selected').val();
        var ActPrfle_dob_month = $('.mobActPrfle_dob_monthTM >select option:selected').val();
        if (ActPrfle_dob_day != 0 && ActPrfle_dob_month != 0) {
            $('.mobloginDateFmtError').html('');
        }
    }
    
    function selectMobDateDDMMRM() {
        var ActPrfle_dob_day = $('.mobActPrfle_dob_dayRM >select option:selected').val();
        var ActPrfle_dob_month = $('.mobActPrfle_dob_monthRM >select option:selected').val();
        if (ActPrfle_dob_day != 0 && ActPrfle_dob_month != 0) {
            $('.mobloginDateFmtError1').html('');
        }
    }
    
    function confirmInput(inputStyleClass, iconStyleclass, activeClassName, inactiveClassname) {
        return function (evt) {
            if (!(confirmInputValidation(evt, inputStyleClass, iconStyleclass, activeClassName, inactiveClassname))) {
                evt.cancel();
            }
        }
    }

    function confirmInputValidation(evt, inputStyleClass, iconStyleclass, activeClassName, inactiveClassname) {
        var inputId = '.' + inputStyleClass + ' > input';
        var inputValue = $(inputId).val();

        if (inputValue == null || inputValue == '') {
            $('.' + iconStyleclass).removeClass(activeClassName);
            $('.' + iconStyleclass).addClass(inactiveClassname);
        }else {
            $('.' + iconStyleclass).removeClass(inactiveClassname);
            $('.' + iconStyleclass).addClass(activeClassName);
        }
        return false;
    }
    
    function clearSecQAFgtPwd(event) {
        var activeClassName = 'inputtickmarktext-login';
        var inactiveClassName = 'inputtickmarkInactive-login';
        $('.secQ1 >select option:first').prop('selected', true);
        $('.secQ2 >select option:first').prop('selected', true);
        $('.loginSecA1 > input').val('');
        $('.loginSecA2 > input').val('');
        $('.queicon1').removeClass(activeClassName);
        $('.queicon1').addClass(inactiveClassName);
        $('.queicon2').removeClass(activeClassName);
        $('.queicon2').addClass(inactiveClassName);
        $('.all-error').html('');
    }
    
    
    function validateTnC(event) {
        var saveButton = event.getSource();
        var lang = saveButton.getProperty("Lang");
        lang = lang.toLowerCase();
        if ((lang == null) || (lang.indexOf("es") ==  - 1)) {
            lang = "en";
        }
        else {
            lang = "es";
        }
        var atLeastOneIsChecked = $('.checkTnC :checkbox:checked').length > 0;
        if (!atLeastOneIsChecked) {
            if (lang == 'en')
                $('.tnc-error').html('Please read and accept the terms and conditions.');
            if (lang == 'es')
                $('.tnc-error').html('Por favor, lea y acepte los términos y condiciones.');
            $('.checkTnC :checkbox:first').focus();
            event.cancel();
        }
        else {
            $('.tnc-error').html('');
        }
    }
  
    /** End of Login Flow JS Functions **/
  
  function noOfQuesAnswered(inputclass, selectclass, numberclass){
    var selectStyleValue = $('.'+ selectclass +' >select option:selected').val();
    var inputStyleValue = $('.'+ inputclass +' > input').val();
    var numberStyleValue = $('.'+ numberclass).text();
    console.log('Count is:'+ inputStyleValue +'old value');
      return function (evt) {
        if (!(noOfQuesValidation(evt, inputclass, selectclass, numberclass))) {
            evt.cancel();
        }
    }
  }
  
  function noOfQuesValidation(evt, inputStyleClass, selectStyleclass, numberStyleclass ){
    var selectStyleValue = $('.'+ selectStyleclass +' >select option:selected').val();
    var inputStyleValue = $('.'+ inputStyleClass +' > input').val();
    var numberStyleValue = $('.'+ numberStyleclass).text();
    console.log('Count is:'+ numberStyleValue +'old value');
    if(selectStyleValue != 0 ){
        if(inputStyleValue.length == 0){
            $('.'+ numberStyleclass).html(parseInt(numberStyleValue) - parseInt(1));
        }else if(inputStyleValue.length != null){
            $('.'+ numberStyleclass).html(parseInt(numberStyleValue) + parseInt(1));
        }
    }
  
  }
  
  function pageLoad(event){
    console.log('LOGIN PAGE HEIGHT'+$('.loginPage').height());
    console.log('WINDOW HEIGHT'+$(window).height());
    
    if ($('.loginPage').height()<$(window).height()){
        $('.footer_wrapper').addClass("fixed");
    }else{
        $('.footer_wrapper').removeClass("fixed");
    }
    event.cancel();
  }
/** End of Login Flow JS Functions **/
//End