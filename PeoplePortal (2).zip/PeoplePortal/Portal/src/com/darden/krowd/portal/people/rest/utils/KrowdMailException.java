package  com.darden.krowd.portal.people.rest.utils;

import oracle.adf.share.logging.ADFLogger;

public class KrowdMailException extends KrowdException {
    public KrowdMailException(ADFLogger adfLogger, String string,
                                    String string1) {
        super(adfLogger, string, string1);
    }

    public KrowdMailException(ADFLogger adfLogger, String string,
                                    Throwable throwable) {
        super(adfLogger, string, throwable);
    }

    public KrowdMailException() {
        super();
    }
}
