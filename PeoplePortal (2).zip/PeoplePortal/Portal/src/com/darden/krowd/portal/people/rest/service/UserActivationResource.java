package com.darden.krowd.portal.people.rest.service;


import com.darden.krowd.common.KrowdUtility;

import com.darden.krowd.common.PortalConstants;

import com.darden.krowd.common.identity.LdapHelper;
import com.darden.krowd.common.model.applicationModule.loginflow.LoginFlowAMImpl;
import com.darden.krowd.common.model.applicationModule.loginflow.common.LoginFlowAM;

import com.darden.krowd.common.util.MailUtil;

import com.darden.krowd.portal.people.rest.base.LoginBaseClass;

import com.darden.krowd.portal.people.rest.constants.LoginConstants;
import com.darden.krowd.portal.people.rest.model.ActivationRequest;
import com.darden.krowd.portal.people.rest.model.UserPassword;
import com.darden.krowd.portal.people.rest.utils.Base62Code;

import java.security.SecureRandom;

import java.text.MessageFormat;

import java.util.Base64;
import java.util.Base64.Encoder;
import java.util.Properties;

import javax.mail.SendFailedException;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import oracle.adf.model.BindingContext;
import oracle.adf.model.DataControlFrame;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;

import oracle.security.idm.User;

import org.apache.commons.lang.RandomStringUtils;


@Path("/activate")
@Produces("application/json")
public class UserActivationResource extends LoginBaseClass{
    private static final String CLASS_NAME = UserActivationResource.class.getName();
    private static final ADFLogger krowdLogger = ADFLogger.createADFLogger(UserActivationResource.class);    
    private static String PAGE_DEF = "com_darden_krowd_portal_RestPageDef";  
    private static String DATACONTROL = "LoginFlowAMDataControl";
    private String emailIDfromAD= null ;
    Properties properties = KrowdUtility.getInstance().getProperties();

    public UserActivationResource() {
        super();
    }

    /**
     * Sends Password Reset code to the user's email ID.
     */
    @POST
    @Path("/sendPasscodeEmail/{samAccountName}")
    public Response sendTemporaryPasscode(@PathParam("samAccountName") String  samAccountName){        
        Boolean ret = this.sendTemporaryPasscodeIntern(samAccountName);         
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }

    /**
     * Resets user's account in Krowd
     */
    @POST
    @Path("/resetUserAccount/{samAccountName}")
 public Response resetUserAccount(@PathParam("samAccountName") String  samAccountName){
        Boolean ret = this.resetUserAccountIntern(samAccountName);
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }


    @POST
    @Path("/acceptTerms/{contentId}")
    public Response acceptTermsAndActivate(@PathParam("contentId")
        String contentId) {
        String userId = ADFContext.getCurrent().getSecurityContext().getUserName();
        this.acceptTermsAndActivate(userId,contentId);
        return Response.ok().build();
    }
    
    
    
    
    
    
    
    @POST
    @Path("/activate")
    public Response activationService(@DefaultValue("en") @QueryParam("lang") String lang,
                                      ActivationRequest activationRequest) {
        final String METHOD_NAME = LoginConstants.LOGIN_METHOD_ACTIVATE_PROFILE;
        krowdLogger.info(" ***********" + METHOD_NAME + "***************");
        krowdLogger.info(" ***********" + METHOD_NAME + "***************"+activationRequest+"***"+activationRequest.getSelectedDay()+activationRequest.getSelectedMonth()+activationRequest.getInitials());
        String message = "";
        boolean disabledLogicActivated;
        String userName = validateUser(activationRequest);
        String emailIdFromAD = adUtil.getUserAttribute(userName,"mail");
        setEmailIDfromAD(emailIdFromAD);
        boolean isOk = false;
        if (userName.isEmpty() || LoginConstants.LOGIN_CONSTANT_INVALID_RLUSER.equalsIgnoreCase(userName)) {
            message = repoUtil.getStrings()
                              .get(lang)
                              .get(LoginConstants.LOGIN_USERNAME_INVALID_COMBINATION)
                              .toString();
            return Response.status(Response.Status.BAD_REQUEST)
                           .type(MediaType.APPLICATION_JSON)
                           .build(); //throw new BadRequestException(message);
        } else {
            if (!LoginConstants.LOGIN_CONSTANT_INVALID_RLUSER.equalsIgnoreCase(userName)) {
                if (databaseUtil.getUserActivationStatus(userName)) {
                    message = repoUtil.getStrings()
                                      .get(lang)
                                      .get(LoginConstants.LOGIN_ALREADY_ACTIVATED)
                                      .toString();
                    return Response.status(Response.Status.BAD_REQUEST)
                                   .type(MediaType.APPLICATION_JSON)
                                   .build(); //throw new BadRequestException(message);
                } else {
                    krowdLogger.info("***********In else for getuseractivation");
                    krowdLogger.info("***********confirmEmailId" + emailIdFromAD);
                    emailIdFromAD = adUtil.getUserAttribute(userName, "mail");
                    if (null != emailIdFromAD || !emailIdFromAD.isEmpty()) {
                        String disabledLogicFlag = properties.getProperty("DISABLED_LOGIC_ACTIVATION_FLAG");
                        disabledLogicActivated =
                            (disabledLogicFlag != null) ? Boolean.parseBoolean(disabledLogicFlag) : true;
                        krowdLogger.info(" ***********disabledLogicFlag is not null" + disabledLogicFlag);
                        if (disabledLogicActivated) {
                            if (!adUtil.isUserDisabledInAD(userName)) {


                                krowdLogger.info("before return forgetPasswordbean.processPasscodeActivation()forgetPasswordbean");
                                isOk = processPasscodeActivation(krowdLogger, CLASS_NAME, lang, userName);
                                if (isOk)
                                    return Response.ok()
                                                   .type(MediaType.APPLICATION_JSON)
                                                   .build();
                            } else {
                                // if user is disabled, a user friendly message will be shown from DB
                                krowdLogger.info(CLASS_NAME, METHOD_NAME, LoginConstants.LOGIN_LOG_DISABLED_USER);
                                message = repoUtil.getStrings()
                                                  .get(lang)
                                                  .get(LoginConstants.LOGIN_DISABLED_USER)
                                                  .toString();
                                krowdLogger.info(CLASS_NAME, METHOD_NAME, "Message for Disabled user is :" + message);
                                return Response.status(Response.Status.BAD_REQUEST)
                                               .type(MediaType.APPLICATION_JSON)
                                               .build(); //throw new BadRequestException(message);
                            }
                        } else {

                            krowdLogger.info("&&&&&&&&&&&&&&&&&&&&&&&&&&&processPasscodeActivation :");
                            isOk = processPasscodeActivation(krowdLogger, CLASS_NAME, lang, userName);
                            if (isOk)
                                return Response.ok()
                                               .type(MediaType.APPLICATION_JSON)
                                               .build();

                        }
                    } else {
                        krowdLogger.info("The Email address is not in the file");
                        message = "The Email address is not in the file ";
                        return Response.status(Response.Status.BAD_REQUEST)
                                       .type(MediaType.APPLICATION_JSON)
                                       .build(); //throw new BadRequestException(message);
                    }
                }
            }
        }
        if (isOk) {
            return Response.ok()
                           .type(MediaType.APPLICATION_JSON)
                           .build();
        } else {
            return Response.serverError().build();
        }
    }









    @POST
    @Path("/active/{sday}/{smonth}/{init}/{resnum}/{postid}")
    public Response activeService(@DefaultValue("en") @QueryParam("lang") String lang,
                                      @PathParam("sday") String sday ,@PathParam("smonth") String smonth ,@PathParam("init") String init ,@PathParam("resnum") String resnum ,@PathParam("postid") String postid ) {
        final String METHOD_NAME = LoginConstants.LOGIN_METHOD_ACTIVATE_PROFILE;
                                                                                                                              
        krowdLogger.info(" ***********" + METHOD_NAME + "***************"); 
        krowdLogger.info(" ***********" + METHOD_NAME + "***************"+sday+ "***"+smonth+"***"+init+ "***"+resnum+ "***"+postid);
        ActivationRequest activationreques = new ActivationRequest();
        activationreques.setInitials(init);
        activationreques.setSelectedDay(sday);
        activationreques.setSelectedMonth(smonth);
        activationreques.setRestaurantNumber(resnum);
        activationreques.setPosId(postid);
        
        String message = "";
        boolean disabledLogicActivated;
        String userName = validateUser(activationreques);
        String emailIdFromAD = adUtil.getUserAttribute(userName,"mail");
        setEmailIDfromAD(emailIdFromAD);
        boolean isOk = false;
        if (userName.isEmpty() || LoginConstants.LOGIN_CONSTANT_INVALID_RLUSER.equalsIgnoreCase(userName)) {
            message = repoUtil.getStrings()
                              .get(lang)
                              .get(LoginConstants.LOGIN_USERNAME_INVALID_COMBINATION)
                              .toString();
            return Response.status(Response.Status.BAD_REQUEST)
                           .type(MediaType.APPLICATION_JSON)
                           .build(); //throw new BadRequestException(message);
        } else {
            if (!LoginConstants.LOGIN_CONSTANT_INVALID_RLUSER.equalsIgnoreCase(userName)) {
                if (databaseUtil.getUserActivationStatus(userName)) {
                    message = repoUtil.getStrings()
                                      .get(lang)
                                      .get(LoginConstants.LOGIN_ALREADY_ACTIVATED)
                                      .toString();
                    return Response.status(Response.Status.BAD_REQUEST)
                                   .type(MediaType.APPLICATION_JSON)
                                   .build(); //throw new BadRequestException(message);
                } else {
                    krowdLogger.info("***********In else for getuseractivation");
                    krowdLogger.info("***********confirmEmailId" + emailIdFromAD);
                    emailIdFromAD = adUtil.getUserAttribute(userName, "mail");
                    if (null != emailIdFromAD || !emailIdFromAD.isEmpty()) {
                        String disabledLogicFlag = properties.getProperty("DISABLED_LOGIC_ACTIVATION_FLAG");
                        disabledLogicActivated =
                            (disabledLogicFlag != null) ? Boolean.parseBoolean(disabledLogicFlag) : true;
                        krowdLogger.info(" ***********disabledLogicFlag is not null" + disabledLogicFlag);
                        if (disabledLogicActivated) {
                            if (!adUtil.isUserDisabledInAD(userName)) {


                                krowdLogger.info("before return forgetPasswordbean.processPasscodeActivation()forgetPasswordbean");
                                isOk = processPasscodeActivation(krowdLogger, CLASS_NAME, lang, userName);
                                if (isOk)
                                    return Response.ok()
                                                   .type(MediaType.APPLICATION_JSON)
                                                   .build();
                            } else {
                                // if user is disabled, a user friendly message will be shown from DB
                                krowdLogger.info(CLASS_NAME, METHOD_NAME, LoginConstants.LOGIN_LOG_DISABLED_USER);
                                message = repoUtil.getStrings()
                                                  .get(lang)
                                                  .get(LoginConstants.LOGIN_DISABLED_USER)
                                                  .toString();
                                krowdLogger.info(CLASS_NAME, METHOD_NAME, "Message for Disabled user is :" + message);
                                return Response.status(Response.Status.BAD_REQUEST)
                                               .type(MediaType.APPLICATION_JSON)
                                               .build(); //throw new BadRequestException(message);
                            }
                        } else {

                            krowdLogger.info("&&&&&&&&&&&&&&&&&&&&&&&&&&&processPasscodeActivation :");
                            isOk = processPasscodeActivation(krowdLogger, CLASS_NAME, lang, userName);
                            if (isOk)
                                return Response.ok()
                                               .type(MediaType.APPLICATION_JSON)
                                               .build();

                        }
                    } else {
                        krowdLogger.info("The Email address is not in the file");
                        message = "The Email address is not in the file ";
                        return Response.status(Response.Status.BAD_REQUEST)
                                       .type(MediaType.APPLICATION_JSON)
                                       .build(); //throw new BadRequestException(message);
                    }
                }
            }
        }
        if (isOk) {
            return Response.ok()
                           .type(MediaType.APPLICATION_JSON)
                           .build();
        } else {
            return Response.serverError().build();
        }
    }
















    /**
     * @return String
     * @description This method is used to validate username and OTP
     */
    @GET
    @Path("/checkPasscode/{userOpt}")
    
    public Response checkPasscodeActivation(@DefaultValue("en") @QueryParam("lang") String lang,
                                          @PathParam("userOpt")  String userOpt) {
        String optendOpt = Base62Code.decodeToString(userOpt);
        String[] parts = Base62Code.decodeToString(optendOpt).split(",");
        String userId = parts[1];
        String optPassword = parts[2];
        final String METHOD_NAME = "checkUsernamePasscode";
        krowdLogger.info(CLASS_NAME, METHOD_NAME, "Username " + userId);
        return validateOtp(krowdLogger, CLASS_NAME, lang, userId, optPassword);
    }


    /**
     * @return String
     * @description This method is used to set the password during activate account in the 2 factor flow
     */

    @POST
    @Path("/changepassword")
    
    public Response changePassword(@DefaultValue("en") @QueryParam("lang") String lang, UserPassword userPassword) {
        final String METHOD_NAME = "changePassword";
        try {
            String resetPwdErrorMsg = null;
            if (null == userPassword.getUserName() || userPassword.getUserName().isEmpty()) {
                return Response.status(Response.Status.BAD_REQUEST)
                               .type(MediaType.APPLICATION_JSON)
                               .build(); //throw new BadRequestException("check username");
            }
            if (validatePassword(userPassword)) {
                String returnValue = null;
                krowdLogger.info(CLASS_NAME, METHOD_NAME,
                            "Calling doResetPassword method with userPassword.getUserName() : " +
                            userPassword.getUserName() + " anduserPassword.getPassword() : " +
                            userPassword.getPassword());
                returnValue = adUtil.doResetPassword(userPassword.getUserName(), userPassword.getPassword());
                krowdLogger.info(CLASS_NAME, METHOD_NAME,
                            "Returning from doResetPassword method with returnValue : " + returnValue);
                if (returnValue.equalsIgnoreCase(properties.getProperty(LoginConstants.LOGIN_SUCCESS))) {
                    krowdLogger.info(CLASS_NAME, METHOD_NAME,
                                "Calling activateProfile method with userPassword.getUserName() : " +
                                userPassword.getUserName());
                    String emailIdFromDb = databaseUtil.getUserPersonalEmail(userPassword.getUserName());
                    databaseUtil.saveUserInformation(userPassword.getUserName(), emailIdFromDb);
                    databaseUtil.activateProfile(userPassword.getUserName());
                    return Response.ok()
                                   .type(MediaType.APPLICATION_JSON)
                                   .build();
                } else {
                    resetPwdErrorMsg = repoUtil.getStrings()
                                               .get(lang)
                                               .get(LoginConstants.LOGIN_PASSWORD_EXCEPTION_MESSAGE)
                                               .toString();
                    return Response.status(Response.Status.BAD_REQUEST)
                                   .type(MediaType.APPLICATION_JSON)
                                   .build(); //throw new BadRequestException(resetPwdErrorMsg);
                }
            }
        } catch (Exception e) {
            krowdLogger.severe("Password change Failure", e);
            return Response.status(Response.Status.BAD_REQUEST)
                           .type(MediaType.APPLICATION_JSON)
                           .build(); //throw new BadRequestException(repoUtil.getStrings()
            //                                                  .get(lang)
            //                                                  .get(PortalConstants.LOGIN_PASSWORD_OPERATION_FAILED)
            //                                                  .toString());
        }
        return Response.status(Response.Status.BAD_REQUEST)
                       .type(MediaType.APPLICATION_JSON)
                       .build();
    }


    /**
     * @return boolean
     * @description This method is used to validate the complexity of theuserPassword.getPassword() entered.
     */
    private boolean validatePassword(UserPassword userPassword) {
        if (null != userPassword.getPassword() && null != userPassword.getConfirmPassword()) {
            if (!userPassword.getPassword().equals(userPassword.getConfirmPassword())) {
                return false;
            } else if (userPassword.getPassword().length() < 6 && userPassword.getPassword().length() > 17) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    //Added for activation process
    private String validateUser(ActivationRequest activationRequest) {
        final String METHOD_NAME = LoginConstants.LOGIN_METHOD_VALIDATE_USER;
        String birthdate = null;
        boolean checkRLUser = false;
        String userName = null;
        krowdLogger.info(CLASS_NAME, METHOD_NAME,"getSelectedDay"+activationRequest.getSelectedDay() +activationRequest.getSelectedMonth());
        try {
            if (null != activationRequest.getSelectedDay() && null != activationRequest.getSelectedMonth() &&
                !activationRequest.getSelectedMonth().isEmpty() && !activationRequest.getSelectedDay().isEmpty()) {
                birthdate = activationRequest.getSelectedDay().concat(activationRequest.getSelectedMonth());
                userName =
                    adUtil.validateUserDetails(activationRequest.getInitials(), birthdate,
                                               activationRequest.getRestaurantNumber(), activationRequest.getPosId());
                krowdLogger.info(CLASS_NAME, METHOD_NAME,"userName :-"+userName);

            }
            if (null != userName && !userName.isEmpty()) {
                checkRLUser = adUtil.isDardenBusinessUnitRL(userName, LoginConstants.DARDEN_BUSINESS_UNIT);

                if (checkRLUser)
                    userName = LoginConstants.LOGIN_CONSTANT_INVALID_RLUSER;
            }
        } catch (Exception e) {
            krowdLogger.severe(CLASS_NAME, METHOD_NAME, e.getMessage());
        }
        krowdLogger.info(CLASS_NAME, METHOD_NAME, LoginConstants.LOGIN_LOG_VAL_USER9 + userName);
        return userName;
    }

    public void setEmailIDfromAD(String emailIDfromAD) {
        this.emailIDfromAD = emailIDfromAD;
    }

    public String getEmailIDfromAD() {
        return emailIDfromAD;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    /**  Function - This method is used to send one time passcode(OTP) to the user with registered Email Id in Krowd.
     *   Implementation - Get the EmailId of the user from WCP_USER_PROFILE table.
     *   Generate Temporary passcode and store in DB.
     *   Send an email to registered Email Id.
     */

    public boolean sendTemporaryPasscodeIntern(String samAccountName) {
        final String METHOD_NAME = "sendTemporaryPasscode";
        String mailRecipient = "";
        try {
            // Sender name is stored as a constant in DB
            String mailSender =
                properties.getProperty(PortalConstants.MAIL_SENDER_NAME).toString();

            // Get user's email ID from WCP_USER_PROFILE table
            mailRecipient = this.getUserPersonalEmail(samAccountName);

            krowdLogger.info(CLASS_NAME, METHOD_NAME,
                             "Returning from retrieveCurrentEmail method with usename: " +
                             samAccountName + " and mailRecipient: " +
                             mailRecipient);
            // Generate temporary passcode
            String sysGenOTP = generatePasscode(samAccountName);
            if (sysGenOTP != null && (!sysGenOTP.equalsIgnoreCase(""))) {
                this.sendPasscodeEmail(sysGenOTP, mailSender, mailRecipient,samAccountName );
            }
            return true;
            
        } catch (Exception e) {
         String message = e.getMessage();
         krowdLogger.severe(CLASS_NAME, METHOD_NAME,
                               "Invalid email address " + mailRecipient +
                               " for " + samAccountName + e.getMessage());
            return false;
        }
    }
    
    /** Function - This method is used to reset user's account given thier samAccountName.
     *  Implementation - Updates the ACK_STATUS of WCP_USER_PROFILE table to  value 0
     *  with upper(samAccountName) as key.
     */
    public boolean resetUserAccountIntern(String samAccountName){
        final String METHOD_NAME = "generatePasscode";
        boolean returnValue = false;
        LoginFlowAMImpl loginAm = (LoginFlowAMImpl)this.getLoginAM();
        returnValue = loginAm.resetUserAccount(samAccountName);
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " resetUserAccount " + returnValue);
        return returnValue;
    }
    

    
    
    public void acceptTermsAndActivate(String samAccountName,String contentId){
        final String METHOD_NAME = "acceptTermsAndActivate";
        this.getLoginAM().activateProfile(samAccountName);
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " acceptTermsAndActivate ");
    }    
       
    
    
    /**Generate temporary passcode. Note - the existing passcode code is reused.  
    */
    private String generatePasscode(String samAccountName){ 
    String sysGenOTP = "aaaaaa";
    char[] alphaNumberList =
        new char[] { 'b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'q', 'r', 's', 't', 'v', 'w', 'x', 'y', 'z', 'B',
                     'C', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'X', 'Y', 'Z', '0', '1',
                     '2', '3', '4', '5', '6', '7', '8', '9' };
    /*sysGenOTP = RandomStringUtils.random(6, 0, 51, true, true, alphaNumberList);
    while (!(sysGenOTP.matches(".*\\d+.*"))) {
        sysGenOTP = RandomStringUtils.random(6, 0, 51, true, true, alphaNumberList);
    }*/ //commented
    
        //subh, CWE - 331 Insufficient Entropy
        SecureRandom random = new SecureRandom();
        byte bytes[] = new byte[4]; //to keep 6 characters length after encoding
        random.nextBytes(bytes);
        Encoder encoder = Base64.getUrlEncoder().withoutPadding();
        sysGenOTP = encoder.encodeToString(bytes);
        
        String regexAlphaNumeric = "^[a-zA-Z0-9]+$";// to ensure generated OTP is alphanumeric
        while (!(sysGenOTP.matches(".*\\d+.*")) || !(sysGenOTP.matches(regexAlphaNumeric))) 
        {
            random.nextBytes(bytes);
            sysGenOTP=Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
        }
        //

       boolean status = this.generatePasscode(samAccountName, sysGenOTP);
       if(status)
           return sysGenOTP;
       else
           return null;
    }
    
    
    
    
    
    /**Send  Passcode to user through Email. Note - the existing passcode code is reused. 
    */
    private void sendPasscodeEmail(String sysGenOTP,String mailSender, String mailRecipient, String samAccountName ) throws Exception,
                                                              SendFailedException {
    final String METHOD_NAME = "sendPasscodeEmail";
    //Mail subject is stored as a constant in DB
    String mailSubject = properties.getProperty(PortalConstants.MAIL_SUBJECT).toString();
    //Email body is stored in db
    String emailTemplate = properties.getProperty(PortalConstants.EMAIL_BODY).toString();

    //Get the display name of the user from AD
    User user = LdapHelper.getInstance().getUser(samAccountName);
    oracle.security.idm.UserProfile currentUserProfile = user.getUserProfile();
    
    String displayName = user.getName();
    
    //get mailLink from DB
    //     HttpServletRequest requestObj = (HttpServletRequest)ADFContext.getCurrent().getRequest();
    
    //    requestObj.getScheme().concat("://").concat(requestObj.getServerName()).concat(properties.getProperty(PortalConstants.MAIL_LINK).toString());
     String mailLink =    ("http://krowddev1.darden.com/").concat(properties.getProperty(PortalConstants.MAIL_LINK).toString());
    // Drafting the Email
    MessageFormat format = new MessageFormat("");
    String[] emailDetails = new String[3];
    emailDetails[0] = displayName;
    emailDetails[1] = mailLink;
    emailDetails[2] = sysGenOTP;
    String emailBody = format.format(emailTemplate, emailDetails);
    krowdLogger.info("Email Content is :" + emailBody);
    krowdLogger.info("Mail Sender name :" + mailSender + "\t" + "Mail recipient :" + mailRecipient + "\t" + "Mail Subject :" +
                     mailSubject + "\t" + "Mail body" + emailBody);
    
        MailUtil mailUtil = new MailUtil();
        krowdLogger.info(CLASS_NAME, METHOD_NAME, "Sending Email....." + " for user: " + samAccountName);

    
         mailUtil.sendMail(mailSender, mailRecipient, mailSubject, emailBody, null);
    
    }
    
    
    private String getUserPersonalEmail(String userName) {
        final String METHOD_NAME = "getUserPersonalEmail";
        String email = null;
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " Username is : " + userName);
        email = this.getLoginAM().getCurrentEmail(userName);
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " Email retrieved : " + email);
        return email;
    }
    
    
    private boolean generatePasscode(String userName, String sysGenOTP) {
        final String METHOD_NAME = "generatePasscode";
        boolean returnValue = false;
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " Username is : " + userName + " sysGenOTP : " + sysGenOTP);
        returnValue = this.getLoginAM().generatePasscode(userName, sysGenOTP);
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " Saved Passcode details ? " + returnValue);
        return returnValue;
    }
    
    
    private LoginFlowAM getLoginAM(){
        BindingContext bindingContext = BindingContext.getCurrent();
        LoginFlowAM am =null;
        DCDataControl dc = null; 
        if(bindingContext !=null){
            String dcFrameName = bindingContext.getCurrentDataControlFrame();
            DataControlFrame dcframe = dcFrameName == null? null : bindingContext.findDataControlFrame(dcFrameName);
            
            dc = dcframe == null ? null : dcframe.findDataControl(DATACONTROL);        
            dc = dc == null ? bindingContext.findDataControl(DATACONTROL) : dc;
            DCBindingContainer amxs = bindingContext.findBindingContainer(PAGE_DEF);
            if(dc == null){
               DCBindingContainer amx = bindingContext.findBindingContainer(PAGE_DEF);
                dc = amx.findDataControl(DATACONTROL); 
                am = (LoginFlowAM)dc.getDataProvider();
            }else{
                am = (LoginFlowAM)dc.getDataProvider();
            }
        }
        return am;
    }    
    
}
