package  com.darden.krowd.portal.people.rest.utils;



import oracle.adf.share.logging.ADFLogger;


/**
 * @author Archana K.S(Archana_S08@infosys.com), Infosys Portal Team
 * @version 1.0
 * @description This class is used for Exception Handling
 */
public class KrowdException extends Exception
{
    public KrowdException()
    {
        super();
    }

    // Constructor used for system defined Exceptions

    public KrowdException(ADFLogger logger, String exceptionType,
            Throwable ex)
    {
        super("This system exception " + ex.getMessage());
        
        if(logger != null)
            logger.severe(exceptionType,ex);
    }

    // Constructor used for user defined Exceptions

    public KrowdException(ADFLogger logger, String exceptionType,
            String exceptionMessage)
    {
        super(exceptionMessage);
        
        if(logger != null)
            logger.severe(exceptionType, exceptionMessage);
        
    }
}
