package com.darden.krowd.portal.people.rest.model;

import java.io.Serializable;

public class ActivationRequest implements Serializable  {
    private String selectedDay;
    private String selectedMonth;
    private String initials = null;
    private String restaurantNumber = null;
    private String posId = null;


    public void setInitials(String initials) {
        this.initials = initials;
    }

    public String getInitials() {
        return initials;
    }

    public void setRestaurantNumber(String restaurantNumber) {
        this.restaurantNumber = restaurantNumber;
    }

    public String getRestaurantNumber() {
        return restaurantNumber;
    }

    public void setPosId(String posId) {
        this.posId = posId;
    }

    public String getPosId() {
        return posId;
    }

    public void setSelectedDay(String selectedDay) {
        this.selectedDay = selectedDay;
    }

    public String getSelectedDay() {
        return selectedDay;
    }

    public void setSelectedMonth(String selectedMonth) {
        this.selectedMonth = selectedMonth;
    }

    public String getSelectedMonth() {
        return selectedMonth;
    }
}
