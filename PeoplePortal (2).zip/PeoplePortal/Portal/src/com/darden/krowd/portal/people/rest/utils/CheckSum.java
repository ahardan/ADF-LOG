package  com.darden.krowd.portal.people.rest.utils;


public class CheckSum {
	private static final String CHECKSUMALPHABET = "1234567890ABCDEFGHJKLMNPQRSTUVWXYZ";

	private CheckSum() {
		super();
	}

	private static String getChecksumAlphabet() {
		return CHECKSUMALPHABET;
	}

	/**
	 * Generates a 3-character checksum for the given a string
	 *
	 * @return
	 */
	public static String getCheckSum(String origString) {
		char[] serialCharacters = (origString).toCharArray();
		int characterValue = 0;
		for (char serialCharacter : serialCharacters) {
			characterValue += serialCharacter;
		}
		if (characterValue > getChecksumAlphabet().length()) {
			characterValue = characterValue % getChecksumAlphabet().length();
		}

		StringBuilder result = new StringBuilder();
		result.append(getChecksumAlphabet().toCharArray()[characterValue]);
		return result.toString();
	}

	public static String getCheckSumGivenAlphabet(String origString, String alphabet) {
		char[] serialCharacters = (origString).toCharArray();
		int characterValue = 0;
		for (char serialCharacter : serialCharacters) {
			characterValue += serialCharacter;
		}
		if (characterValue > alphabet.length()) {
			characterValue = characterValue % alphabet.length();
		}

		StringBuilder result = new StringBuilder();
		result.append(alphabet.toCharArray()[characterValue]);
		return result.toString();
	}

	public static boolean isCheckSumValid(String origString, String checkSum) {
		boolean checkSumFlag = false;
		String fChekSum = getCheckSum(origString);
		if (fChekSum.equals(checkSum)) {
			checkSumFlag = true;
		}
		return checkSumFlag;

	}

	public static boolean isCheckSumValidGivenAlphabet(String origString, String checkSum, String alphabet) {
		boolean checkSumFlag = false;
		String fChekSum = getCheckSumGivenAlphabet(origString, alphabet);
		if (fChekSum.equals(checkSum)) {
			checkSumFlag = true;
		}
		return checkSumFlag;
	}

}
