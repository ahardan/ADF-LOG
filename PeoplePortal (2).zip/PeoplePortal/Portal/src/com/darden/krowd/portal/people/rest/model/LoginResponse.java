package com.darden.krowd.portal.people.rest.model;

public class LoginResponse {
    String smsession;
    
    
    public LoginResponse() {
        super();
    }
}
