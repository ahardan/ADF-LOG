package com.darden.krowd.login.model;

public class LoginRequest {
    String username; 
    String password;
    String smType;
    String smRealmOid;
    String smGUID;
    String smAuthReason;
    String smAgentName;
    String smTarget;

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPassword() {
        return password;
    }

    public void setSmType(String smType) {
        this.smType = smType;
    }

    public String getSmType() {
        return smType;
    }

    public void setSmRealmOid(String smRealmOid) {
        this.smRealmOid = smRealmOid;
    }

    public String getSmRealmOid() {
        return smRealmOid;
    }

    public void setSmGUID(String smGUID) {
        this.smGUID = smGUID;
    }

    public String getSmGUID() {
        return smGUID;
    }

    public void setSmAuthReason(String smAuthReason) {
        this.smAuthReason = smAuthReason;
    }

    public String getSmAuthReason() {
        return smAuthReason;
    }

    public void setSmAgentName(String smAgentName) {
        this.smAgentName = smAgentName;
    }

    public String getSmAgentName() {
        return smAgentName;
    }

    public void setSmTarget(String smTarget) {
        this.smTarget = smTarget;
    }

    public String getSmTarget() {
        return smTarget;
    }

    public LoginRequest() {
        super();
    }
}
