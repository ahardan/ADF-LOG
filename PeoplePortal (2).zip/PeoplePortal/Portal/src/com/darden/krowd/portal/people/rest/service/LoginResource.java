package com.darden.krowd.portal.people.rest.service;


import com.darden.krowd.common.KrowdUtility;

import com.darden.krowd.common.PortalConstants;

import com.darden.krowd.common.identity.LdapHelper;
import com.darden.krowd.common.model.applicationModule.loginflow.LoginFlowAMImpl;
import com.darden.krowd.common.model.applicationModule.loginflow.common.LoginFlowAM;

import com.darden.krowd.common.util.MailUtil;

import java.security.SecureRandom;

import java.text.MessageFormat;

import java.util.Base64;
import java.util.Base64.Encoder;
import java.util.Properties;

import javax.mail.SendFailedException;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import oracle.adf.model.BindingContext;
import oracle.adf.model.DataControlFrame;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;

import oracle.security.idm.User;

import org.apache.commons.lang.RandomStringUtils;


@Path("/login")
@Produces("application/json")
public class LoginResource {
    private static final String CLASS_NAME = UserActivationResource.class.getName();
    private static final ADFLogger krowdLogger = ADFLogger.createADFLogger(UserActivationResource.class);    
    private static String PAGE_DEF = "com_darden_krowd_portal_RestPageDef";  
    private static String DATACONTROL = "LoginFlowAMDataControl";
    
    Properties properties = KrowdUtility.getInstance().getProperties();

    public LoginResource() {
        super();
    }

    /**
     * Sends Password Reset code to the user's email ID.
     */
    @POST
    @Path("/sendPasscodeEmail/{samAccountName}")
    public Response sendTemporaryPasscode(@PathParam("samAccountName") String  samAccountName){        
        Boolean ret = this.sendTemporaryPasscodeIntern(samAccountName);         
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }

    /**
     * Resets user's account in Krowd
     */
    @POST
    @Path("/resetUserAccount/{samAccountName}")
 public Response resetUserAccount(@PathParam("samAccountName") String  samAccountName){
        Boolean ret = this.resetUserAccountIntern(samAccountName);
        return Response.ok(ret).type(MediaType.APPLICATION_JSON).build();
    }


    @POST
    @Path("/acceptTerms/{contentId}")
    public Response acceptTermsAndActivate(@PathParam("contentId")
        String contentId) {
        String userId = ADFContext.getCurrent().getSecurityContext().getUserName();
        this.acceptTermsAndActivate(userId,contentId);
        return Response.ok().build();
    }
    
    /**  Function - This method is used to send one time passcode(OTP) to the user with registered Email Id in Krowd.
     *   Implementation - Get the EmailId of the user from WCP_USER_PROFILE table.
     *   Generate Temporary passcode and store in DB.
     *   Send an email to registered Email Id.
     */

    public boolean sendTemporaryPasscodeIntern(String samAccountName) {
        final String METHOD_NAME = "sendTemporaryPasscode";
        String mailRecipient = "";
        try {
            // Sender name is stored as a constant in DB
            String mailSender =
                properties.getProperty(PortalConstants.MAIL_SENDER_NAME).toString();

            // Get user's email ID from WCP_USER_PROFILE table
            mailRecipient = this.getUserPersonalEmail(samAccountName);

            krowdLogger.info(CLASS_NAME, METHOD_NAME,
                             "Returning from retrieveCurrentEmail method with usename: " +
                             samAccountName + " and mailRecipient: " +
                             mailRecipient);
            // Generate temporary passcode
            String sysGenOTP = generatePasscode(samAccountName);
            if (sysGenOTP != null && (!sysGenOTP.equalsIgnoreCase(""))) {
                this.sendPasscodeEmail(sysGenOTP, mailSender, mailRecipient,samAccountName );
            }
            return true;
            
        } catch (Exception e) {
         String message = e.getMessage();
         krowdLogger.severe(CLASS_NAME, METHOD_NAME,
                               "Invalid email address " + mailRecipient +
                               " for " + samAccountName + e.getMessage());
            return false;
        }
    }
    
    /** Function - This method is used to reset user's account given thier samAccountName.
     *  Implementation - Updates the ACK_STATUS of WCP_USER_PROFILE table to  value 0
     *  with upper(samAccountName) as key.
     */
    public boolean resetUserAccountIntern(String samAccountName){
        final String METHOD_NAME = "generatePasscode";
        boolean returnValue = false;
        LoginFlowAMImpl loginAm = (LoginFlowAMImpl)this.getLoginAM();
        returnValue = loginAm.resetUserAccount(samAccountName);
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " resetUserAccount " + returnValue);
        return returnValue;
    }
    

    
    
    public void acceptTermsAndActivate(String samAccountName,String contentId){
        final String METHOD_NAME = "acceptTermsAndActivate";
        this.getLoginAM().activateProfile(samAccountName);
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " acceptTermsAndActivate ");
    }    
       
    
    
    /**Generate temporary passcode. Note - the existing passcode code is reused.  
    */
    private String generatePasscode(String samAccountName){ 
    String sysGenOTP = "aaaaaa";
    char[] alphaNumberList =
        new char[] { 'b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'q', 'r', 's', 't', 'v', 'w', 'x', 'y', 'z', 'B',
                     'C', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'X', 'Y', 'Z', '0', '1',
                     '2', '3', '4', '5', '6', '7', '8', '9' };
    /*sysGenOTP = RandomStringUtils.random(6, 0, 51, true, true, alphaNumberList);
    while (!(sysGenOTP.matches(".*\\d+.*"))) {
        sysGenOTP = RandomStringUtils.random(6, 0, 51, true, true, alphaNumberList);
    }*/ //commented
    
        //subh, CWE - 331 Insufficient Entropy
        SecureRandom random = new SecureRandom();
        byte bytes[] = new byte[4]; //to keep 6 characters length after encoding
        random.nextBytes(bytes);
        Encoder encoder = Base64.getUrlEncoder().withoutPadding();
        sysGenOTP = encoder.encodeToString(bytes);
        
        String regexAlphaNumeric = "^[a-zA-Z0-9]+$";// to ensure generated OTP is alphanumeric
        while (!(sysGenOTP.matches(".*\\d+.*")) || !(sysGenOTP.matches(regexAlphaNumeric))) 
        {
            random.nextBytes(bytes);
            sysGenOTP=Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
        }
        //

       boolean status = this.generatePasscode(samAccountName, sysGenOTP);
       if(status)
           return sysGenOTP;
       else
           return null;
    }
    
    
    
    
    
    /**Send  Passcode to user through Email. Note - the existing passcode code is reused. 
    */
    private void sendPasscodeEmail(String sysGenOTP,String mailSender, String mailRecipient, String samAccountName ) throws Exception,
                                                              SendFailedException {
    final String METHOD_NAME = "sendPasscodeEmail";
    //Mail subject is stored as a constant in DB
    String mailSubject = properties.getProperty(PortalConstants.MAIL_SUBJECT).toString();
    //Email body is stored in db
    String emailTemplate = properties.getProperty(PortalConstants.EMAIL_BODY).toString();

    //Get the display name of the user from AD
    User user = LdapHelper.getInstance().getUser(samAccountName);
    oracle.security.idm.UserProfile currentUserProfile = user.getUserProfile();
    
    String displayName = user.getName();
    
    //get mailLink from DB
    //     HttpServletRequest requestObj = (HttpServletRequest)ADFContext.getCurrent().getRequest();
    
    //    requestObj.getScheme().concat("://").concat(requestObj.getServerName()).concat(properties.getProperty(PortalConstants.MAIL_LINK).toString());
     String mailLink =    ("http://krowddev1.darden.com/").concat(properties.getProperty(PortalConstants.MAIL_LINK).toString());
    // Drafting the Email
    MessageFormat format = new MessageFormat("");
    String[] emailDetails = new String[3];
    emailDetails[0] = displayName;
    emailDetails[1] = mailLink;
    emailDetails[2] = sysGenOTP;
    String emailBody = format.format(emailTemplate, emailDetails);
    krowdLogger.info("Email Content is :" + emailBody);
    krowdLogger.info("Mail Sender name :" + mailSender + "\t" + "Mail recipient :" + mailRecipient + "\t" + "Mail Subject :" +
                     mailSubject + "\t" + "Mail body" + emailBody);
    
        MailUtil mailUtil = new MailUtil();
        krowdLogger.info(CLASS_NAME, METHOD_NAME, "Sending Email....." + " for user: " + samAccountName);

    
         mailUtil.sendMail(mailSender, mailRecipient, mailSubject, emailBody, null);
    
    }
    
    
    private String getUserPersonalEmail(String userName) {
        final String METHOD_NAME = "getUserPersonalEmail";
        String email = null;
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " Username is : " + userName);
        email = this.getLoginAM().getCurrentEmail(userName);
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " Email retrieved : " + email);
        return email;
    }
    
    
    private boolean generatePasscode(String userName, String sysGenOTP) {
        final String METHOD_NAME = "generatePasscode";
        boolean returnValue = false;
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " Username is : " + userName + " sysGenOTP : " + sysGenOTP);
        returnValue = this.getLoginAM().generatePasscode(userName, sysGenOTP);
        krowdLogger.info(CLASS_NAME, METHOD_NAME, " Saved Passcode details ? " + returnValue);
        return returnValue;
    }
    
    
    private LoginFlowAM getLoginAM(){
        BindingContext bindingContext = BindingContext.getCurrent();
        LoginFlowAM am =null;
        DCDataControl dc = null; 
        if(bindingContext !=null){
            String dcFrameName = bindingContext.getCurrentDataControlFrame();
            DataControlFrame dcframe = dcFrameName == null? null : bindingContext.findDataControlFrame(dcFrameName);
            
            dc = dcframe == null ? null : dcframe.findDataControl(DATACONTROL);        
            dc = dc == null ? bindingContext.findDataControl(DATACONTROL) : dc;
            DCBindingContainer amxs = bindingContext.findBindingContainer(PAGE_DEF);
            if(dc == null){
               DCBindingContainer amx = bindingContext.findBindingContainer(PAGE_DEF);
                dc = amx.findDataControl(DATACONTROL); 
                am = (LoginFlowAM)dc.getDataProvider();
            }else{
                am = (LoginFlowAM)dc.getDataProvider();
            }
        }
        return am;
    }    
    
}
