package com.darden.krowd.portal.people.rest.model;


public class UserPassCode {
    private String userName;
    private String otpPassword;

    public UserPassCode() {
        super();
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserName() {
        return userName;
    }

    public void setOtpPassword(String otpPassword) {
        this.otpPassword = otpPassword;
    }

    public String getOtpPassword() {
        return otpPassword;
    }
}
