package com.darden.krowd.portal.people.rest.service;

//import com.darden.krowd.rest.exceptions.BadRequestException;
import com.darden.krowd.portal.people.rest.base.LoginBaseClass;
import com.darden.krowd.portal.people.rest.constants.LoginConstants;
import com.darden.krowd.portal.people.rest.model.ActivationRequest;
import com.darden.krowd.portal.people.rest.model.UserPassCode;
import com.darden.krowd.portal.people.rest.model.UserPassword;
import com.darden.krowd.portal.people.rest.utils.Base62Code;

import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import oracle.adf.share.logging.ADFLogger;
//import javax.ws.rs.BadRequestException;


@Path("/loginservices/activation")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class ActivationResource extends LoginBaseClass {
    private static final ADFLogger logger = ADFLogger.createADFLogger(ActivationResource.class);
    private static final String CLASS_NAME = ActivationResource.CLASS_NAME;
    private String emailIDfromAD = null;

    public ActivationResource() {
        super();
    }


    @POST
    @Path("/activate")
    public Response activationService(@DefaultValue("en") @QueryParam("lang") String lang,
                                      ActivationRequest activationRequest) {
        final String METHOD_NAME = LoginConstants.LOGIN_METHOD_ACTIVATE_PROFILE;
        logger.info(" ***********" + METHOD_NAME + "***************");
        String message = "";
        boolean disabledLogicActivated;
        String userName = validateUser(activationRequest);
        String emailIdFromAD = adUtil.getUserAttribute(userName, "mail");
        setEmailIDfromAD(emailIdFromAD);
        boolean isOk = false;
        if (userName.isEmpty() || LoginConstants.LOGIN_CONSTANT_INVALID_RLUSER.equalsIgnoreCase(userName)) {
            message = repoUtil.getStrings()
                              .get(lang)
                              .get(LoginConstants.LOGIN_USERNAME_INVALID_COMBINATION)
                              .toString();
            return Response.status(Response.Status.BAD_REQUEST)
                           .type(MediaType.APPLICATION_JSON)
                           .build(); //throw new BadRequestException(message);
        } else {
            if (!LoginConstants.LOGIN_CONSTANT_INVALID_RLUSER.equalsIgnoreCase(userName)) {
                if (databaseUtil.getUserActivationStatus(userName)) {
                    message = repoUtil.getStrings()
                                      .get(lang)
                                      .get(LoginConstants.LOGIN_ALREADY_ACTIVATED)
                                      .toString();
                    return Response.status(Response.Status.BAD_REQUEST)
                                   .type(MediaType.APPLICATION_JSON)
                                   .build(); //throw new BadRequestException(message);
                } else {
                    logger.info("***********In else for getuseractivation");
                    logger.info("***********confirmEmailId" + emailIdFromAD);
                    emailIdFromAD = adUtil.getUserAttribute(userName, "mail");
                    if (null != emailIdFromAD || !emailIdFromAD.isEmpty()) {
                        String disabledLogicFlag = properties.getProperty("DISABLED_LOGIC_ACTIVATION_FLAG");
                        disabledLogicActivated =
                            (disabledLogicFlag != null) ? Boolean.parseBoolean(disabledLogicFlag) : true;
                        logger.info(" ***********disabledLogicFlag is not null" + disabledLogicFlag);
                        if (disabledLogicActivated) {
                            if (!adUtil.isUserDisabledInAD(userName)) {


                                logger.info("before return forgetPasswordbean.processPasscodeActivation()forgetPasswordbean");
                                isOk = processPasscodeActivation(logger, CLASS_NAME, lang, userName);
                                if (isOk)
                                    return Response.ok()
                                                   .type(MediaType.APPLICATION_JSON)
                                                   .build();
                            } else {
                                // if user is disabled, a user friendly message will be shown from DB
                                logger.info(CLASS_NAME, METHOD_NAME, LoginConstants.LOGIN_LOG_DISABLED_USER);
                                message = repoUtil.getStrings()
                                                  .get(lang)
                                                  .get(LoginConstants.LOGIN_DISABLED_USER)
                                                  .toString();
                                logger.info(CLASS_NAME, METHOD_NAME, "Message for Disabled user is :" + message);
                                return Response.status(Response.Status.BAD_REQUEST)
                                               .type(MediaType.APPLICATION_JSON)
                                               .build(); //throw new BadRequestException(message);
                            }
                        } else {

                            logger.info("&&&&&&&&&&&&&&&&&&&&&&&&&&&processPasscodeActivation :");
                            isOk = processPasscodeActivation(logger, CLASS_NAME, lang, userName);
                            if (isOk)
                                return Response.ok()
                                               .type(MediaType.APPLICATION_JSON)
                                               .build();

                        }
                    } else {
                        logger.info("The Email address is not in the file");
                        message = "The Email address is not in the file ";
                        return Response.status(Response.Status.BAD_REQUEST)
                                       .type(MediaType.APPLICATION_JSON)
                                       .build(); //throw new BadRequestException(message);
                    }
                }
            }
        }
        if (isOk) {
            return Response.ok()
                           .type(MediaType.APPLICATION_JSON)
                           .build();
        } else {
            return Response.serverError().build();
        }
    }

    /**
     * @return String
     * @description This method is used to validate username and OTP
     */
    @GET
    @Path("/checkPasscode")

    public Response checkPasscodeActivation(@DefaultValue("en") @QueryParam("lang") String lang, String userOpt) {
        String optendOpt = Base62Code.decodeToString(userOpt);
        String[] parts = Base62Code.decodeToString(optendOpt).split(",");
        String userId = parts[1];
        String optPassword = parts[2];
        final String METHOD_NAME = "checkUsernamePasscode";
        logger.info(CLASS_NAME, METHOD_NAME, "Username " + userId);
        return validateOtp(logger, CLASS_NAME, lang, userId, optPassword);
    }


    /**
     * @return String
     * @description This method is used to set the password during activate account in the 2 factor flow
     */

    @POST
    @Path("/changepassword")

    public Response changePassword(@DefaultValue("en") @QueryParam("lang") String lang, UserPassword userPassword) {
        final String METHOD_NAME = "changePassword";
        try {
            String resetPwdErrorMsg = null;
            if (null == userPassword.getUserName() || userPassword.getUserName().isEmpty()) {
                return Response.status(Response.Status.BAD_REQUEST)
                               .type(MediaType.APPLICATION_JSON)
                               .build(); //throw new BadRequestException("check username");
            }
            if (validatePassword(userPassword)) {
                String returnValue = null;
                logger.info(CLASS_NAME, METHOD_NAME,
                            "Calling doResetPassword method with userPassword.getUserName() : " +
                            userPassword.getUserName() + " anduserPassword.getPassword() : " +
                            userPassword.getPassword());
                returnValue = adUtil.doResetPassword(userPassword.getUserName(), userPassword.getPassword());
                logger.info(CLASS_NAME, METHOD_NAME,
                            "Returning from doResetPassword method with returnValue : " + returnValue);
                if (returnValue.equalsIgnoreCase(properties.getProperty(LoginConstants.LOGIN_SUCCESS))) {
                    logger.info(CLASS_NAME, METHOD_NAME,
                                "Calling activateProfile method with userPassword.getUserName() : " +
                                userPassword.getUserName());
                    String emailIdFromDb = databaseUtil.getUserPersonalEmail(userPassword.getUserName());
                    databaseUtil.saveUserInformation(userPassword.getUserName(), emailIdFromDb);
                    databaseUtil.activateProfile(userPassword.getUserName());
                    return Response.ok()
                                   .type(MediaType.APPLICATION_JSON)
                                   .build();
                } else {
                    resetPwdErrorMsg = repoUtil.getStrings()
                                               .get(lang)
                                               .get(LoginConstants.LOGIN_PASSWORD_EXCEPTION_MESSAGE)
                                               .toString();
                    return Response.status(Response.Status.BAD_REQUEST)
                                   .type(MediaType.APPLICATION_JSON)
                                   .build(); //throw new BadRequestException(resetPwdErrorMsg);
                }
            }
        } catch (Exception e) {
            logger.severe("Password change Failure", e);
            return Response.status(Response.Status.BAD_REQUEST)
                           .type(MediaType.APPLICATION_JSON)
                           .build(); //throw new BadRequestException(repoUtil.getStrings()
            //                                                  .get(lang)
            //                                                  .get(PortalConstants.LOGIN_PASSWORD_OPERATION_FAILED)
            //                                                  .toString());
        }
        return Response.status(Response.Status.BAD_REQUEST)
                       .type(MediaType.APPLICATION_JSON)
                       .build();
    }


    /**
     * @return boolean
     * @description This method is used to validate the complexity of theuserPassword.getPassword() entered.
     */
    private boolean validatePassword(UserPassword userPassword) {
        if (null != userPassword.getPassword() && null != userPassword.getConfirmPassword()) {
            if (!userPassword.getPassword().equals(userPassword.getConfirmPassword())) {
                return false;
            } else if (userPassword.getPassword().length() < 6 && userPassword.getPassword().length() > 17) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    //Added for activation process
    private String validateUser(ActivationRequest activationRequest) {
        final String METHOD_NAME = LoginConstants.LOGIN_METHOD_VALIDATE_USER;
        String birthdate = null;
        boolean checkRLUser = false;
        String userName = null;
        try {
            if (null != activationRequest.getSelectedDay() && null != activationRequest.getSelectedMonth() &&
                !activationRequest.getSelectedMonth().isEmpty() && !activationRequest.getSelectedDay().isEmpty()) {
                birthdate = activationRequest.getSelectedDay().concat(activationRequest.getSelectedMonth());
                userName =
                    adUtil.validateUserDetails(activationRequest.getInitials(), birthdate,
                                               activationRequest.getRestaurantNumber(), activationRequest.getPosId());
            }
            if (null != userName && !userName.isEmpty()) {
                checkRLUser = adUtil.isDardenBusinessUnitRL(userName, LoginConstants.DARDEN_BUSINESS_UNIT);

                if (checkRLUser)
                    userName = LoginConstants.LOGIN_CONSTANT_INVALID_RLUSER;
            }
        } catch (Exception e) {
            logger.severe(CLASS_NAME, METHOD_NAME, e.getMessage());
        }
        logger.info(CLASS_NAME, METHOD_NAME, LoginConstants.LOGIN_LOG_VAL_USER9 + userName);
        return userName;
    }

    public void setEmailIDfromAD(String emailIDfromAD) {
        this.emailIDfromAD = emailIDfromAD;
    }

    public String getEmailIDfromAD() {
        return emailIDfromAD;
    }
}
