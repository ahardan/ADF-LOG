package com.darden.krowd.portal.people.rest.service;

import  com.darden.krowd.portal.people.rest.base.LoginBaseClass;
import  com.darden.krowd.portal.people.rest.constants.LoginConstants;

import com.darden.krowd.portal.people.rest.base.LoginBaseClass;

import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import oracle.adf.share.logging.ADFLogger;

@Path("/loginservices/forgetpassword")
@Produces("application/json")
public class ForgetPasswordResource extends LoginBaseClass {
    private static final ADFLogger logger = ADFLogger.createADFLogger(ForgetPasswordResource.class);
    private static final String CLASS_NAME = ForgetPasswordResource.CLASS_NAME;

    public ForgetPasswordResource() {
        super();
    }


    /**
     * @return String
     * @description This method is used to validate the user whether RSC or NonRSC from Active Directory for the username
     */
    @GET
    @Path("/validate/{userName}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response validUsername(@DefaultValue("en") @QueryParam("lang") String lang,
                                  @PathParam("userName") String userName) {
        final String METHOD_NAME = "validUsername";
        userName = userName.trim();
        boolean disabledLogicActivated;
        String mailRecipient =
            ((databaseUtil.getUserPersonalEmail(userName) == null ||
              databaseUtil.getUserPersonalEmail(userName).isEmpty()) ? adUtil.getUserAttribute(userName, "mail") :
             databaseUtil.getUserPersonalEmail(userName));
        logger.info(CLASS_NAME, METHOD_NAME,
                    " mailRecipient for  username : " + userName + " email: " + mailRecipient + "AD email" +
                    adUtil.getUserAttribute(userName, "mail") + "DB email" +
                    databaseUtil.getUserPersonalEmail(userName));

        logger.info(CLASS_NAME, METHOD_NAME,
                    " Calling isDardenBusinessUnitRL with username : " + userName + " DARDEN_BUSINESS_UNIT : " +
                    LoginConstants.DARDEN_BUSINESS_UNIT);
        boolean checkRLUser = adUtil.isDardenBusinessUnitRL(userName, LoginConstants.DARDEN_BUSINESS_UNIT);
        logger.info(CLASS_NAME, METHOD_NAME,
                    " Returning isDardenBusinessUnitRL method with checkRLUser : " + checkRLUser);

        if (!checkRLUser) {
            if (adUtil.validUsername(userName) &&
                !(adUtil.getSamAccountName(userName, properties.getProperty(LoginConstants.SAMACCOUNTNAME)) != null)) {

                try {
                    if (!databaseUtil.getUserActivationStatus(userName)) {
                        logger.info(CLASS_NAME, METHOD_NAME, "User " + userName + " account is not activated");
                        
                        return Response.status(Response.Status.BAD_REQUEST)
                                       .type(MediaType.APPLICATION_JSON)
                                       .build(); //throw new BadRequestException(forgotPwdErrorMsg);
                    }

                    if (null == mailRecipient || mailRecipient.isEmpty()) {
                        logger.severe(CLASS_NAME, METHOD_NAME, "User " + userName + " Email Not Found ");
                   
                        return Response.status(Response.Status.BAD_REQUEST)
                                       .type(MediaType.APPLICATION_JSON)
                                       .build(); //throw new BadRequestException(forgotPwdErrorMsg);
                    }

                    String returnValue = adUtil.getUserRole(userName);
                    logger.info("Role for the Username " + userName + " is : " + returnValue);
                    if (returnValue.equalsIgnoreCase(properties.getProperty(LoginConstants.LOGIN_RSC))) {
                        userName = "";
                        logger.info(CLASS_NAME, METHOD_NAME, "User " + userName + " is RSC");
                        //                           return properties.getProperty(LoginConstants.LOGIN_REDIRECT_RSC);
                        return Response.status(Response.Status.BAD_REQUEST)
                                       .type(MediaType.APPLICATION_JSON)
                                       .build(); //throw new BadRequestException(properties.getProperty(LoginConstants.LOGIN_REDIRECT_RSC) + "");
                    } else {

                        returnValue =
                            adUtil.getUserAttribute(userName,
                                                    properties.getProperty(LoginConstants.USERACCOUNTCONTROL));
                        int expiredPasswordValue = 0x800000;
                        // Added the null check if the return value is null
                        int longReturnValue =
                            (null != returnValue && !returnValue.isEmpty()) ? Integer.parseInt(returnValue) : 0;

                        if ((longReturnValue & expiredPasswordValue) == expiredPasswordValue) {
                            logger.info(CLASS_NAME, METHOD_NAME, "User " + userName + " password expired");
                            //                               return properties.getProperty(LoginConstants.LOGIN_REDIRECT_EXPIREDPASSWORD);
                            return Response.status(Response.Status.BAD_REQUEST)
                                           .type(MediaType.APPLICATION_JSON)
                                           .build(); //throw new BadRequestException("User " + userName + " password expired");
                        } else {

                            try {
                                // databaseUtil.getUserSecurityQuestions(userName);
                            } catch (NullPointerException e) {
                                logger.severe(LoginConstants.KROWD_EXCEPTIONS_NULLPOINTEREXCEPTION, e);
                                // new LoginPortalException(logger, "NeedHelpWithLoginBean.validUsername()", e);
                               
                                return Response.status(Response.Status.BAD_REQUEST)
                                               .type(MediaType.APPLICATION_JSON)
                                               .build(); //throw new BadRequestException(forgotPwdErrorMsg);
                            } finally { //oracle.jbo.client.Configuration.releaseRootApplicationModule(amObj, true);
                            }
                            logger.info(CLASS_NAME, METHOD_NAME, " Redirecting to Security Question Answers page");
                            // generateSecurityQuestions();
                            //                               showPasswordResetLink();
                            processPasscodeActivation(logger, CLASS_NAME, lang, userName);
                            //                               return properties.getProperty(LoginConstants.LOGIN_REDIRECT_FORGOTPASSWORD);
                            return Response.ok()
                                           .type(MediaType.APPLICATION_JSON)
                                           .build();
                        }
                    }
                } catch (NullPointerException e) {
                    // new LoginPortalException(logger, "NeedHelpWithLoginBean.validUsername()", e);
                    logger.severe(LoginConstants.KROWD_EXCEPTIONS_NULLPOINTEREXCEPTION, e);
                    return Response.status(Response.Status.BAD_REQUEST)
                                   .type(MediaType.APPLICATION_JSON)
                                   .build(); //throw new BadRequestException(e.getMessage());
                }
            }

            else {
                logger.info(CLASS_NAME, METHOD_NAME, "User " + userName + " in alias name flow");
                String tempUserName = userName;
                logger.info(CLASS_NAME, METHOD_NAME, "tempUserName " + userName + " in alias name flow");
                userName = adUtil.getSamAccountName(userName, properties.getProperty(LoginConstants.SAMACCOUNTNAME));
                try {
                    if (!databaseUtil.getUserActivationStatus(userName)) {
                        logger.info(CLASS_NAME, METHOD_NAME, "User " + userName + " account is not activated");
                     
                        return Response.status(Response.Status.BAD_REQUEST)
                                       .type(MediaType.APPLICATION_JSON)
                                       .build(); //throw new BadRequestException(forgotPwdErrorMsg);
                    }

                    String returnValue = null;

                    returnValue = adUtil.getUserRole(userName);
                    logger.info("Role for the Username " + userName + " is : " + returnValue);
                    if (returnValue.equalsIgnoreCase(properties.getProperty(LoginConstants.LOGIN_RSC))) {
                        userName = "";
                        logger.info(CLASS_NAME, METHOD_NAME, "User " + userName + " is RSC");
                        //                           return properties.getProperty(LoginConstants.LOGIN_RSC);
                        return Response.status(Response.Status.BAD_REQUEST)
                                       .type(MediaType.APPLICATION_JSON)
                                       .build(); //throw new BadRequestException("User " + userName + " is RSC");
                    } else {
                        // Getting the value of disabled Logic flag from DB, if not null assigned to disabledLogicFlag variable

                        String disabledLogicFlag = properties.getProperty("DISABLED_LOGIC_ACTIVATION_FLAG");
                        disabledLogicActivated =
                            (disabledLogicFlag != null) ? Boolean.parseBoolean(disabledLogicFlag) : true;

                        if (disabledLogicActivated) {
                            if (!adUtil.isUserDisabledInAD(userName)) {
                                returnValue =
                                    adUtil.getUserAttribute(userName,
                                                            properties.getProperty(LoginConstants.USERACCOUNTCONTROL));
                                int expiredPasswordValue = 0x800000;
                                // Added the null check if the return value is null
                                int longReturnValue =
                                    (null != returnValue && !returnValue.isEmpty()) ? Integer.parseInt(returnValue) : 0;


                                if ((longReturnValue & expiredPasswordValue) == expiredPasswordValue) {
                                    logger.info(CLASS_NAME, METHOD_NAME, "User " + userName + " password expired");
                                    //                                    return properties.getProperty(LoginConstants.LOGIN_REDIRECT_EXPIREDPASSWORD);
                                    return Response.status(Response.Status.BAD_REQUEST)
                                                   .type(MediaType.APPLICATION_JSON)
                                                   .build(); //throw new BadRequestException("User " + userName + " password expired");
                                } else {

                                    try {
                                        //  databaseUtil.getUserSecurityQuestions(userName);
                                    } catch (NullPointerException e) {
                                        logger.severe(LoginConstants.KROWD_EXCEPTIONS_NULLPOINTEREXCEPTION, e);
                                        // new LoginPortalException(logger, "NeedHelpWithLoginBean.validUsername()", e);
                                       
                                        return Response.status(Response.Status.BAD_REQUEST)
                                                       .type(MediaType.APPLICATION_JSON)
                                                       .build(); //throw new BadRequestException(e.getMessage());
                                    } finally {
                                    }
                                    logger.info(CLASS_NAME, METHOD_NAME,
                                                " Redirecting to Security Question Answers page");
                                    //generateSecurityQuestions();
                                    //                                    showPasswordResetLink();
                                    logger.info(CLASS_NAME, METHOD_NAME,
                                                "Setting temp user name to username  " + tempUserName +
                                                " in alias name flow");
                                    userName = tempUserName;
                                    processPasscodeActivation(logger, CLASS_NAME, lang, userName);
                                    //                                    return properties.getProperty(LoginConstants.LOGIN_REDIRECT_FORGOTPASSWORD);
                                    return Response.ok()
                                                   .type(MediaType.APPLICATION_JSON)
                                                   .build();
                                }
                            } else {
                                // if user is disabled, a user friendly message will be shown from DB
                                logger.info(CLASS_NAME, METHOD_NAME, LoginConstants.LOGIN_LOG_DISABLED_USER);
                             
                        
                                return Response.status(Response.Status.BAD_REQUEST)
                                               .type(MediaType.APPLICATION_JSON)
                                               .build(); //throw new BadRequestException(forgotPwdErrorMsg);
                            }
                        } else {
                            returnValue =
                                adUtil.getUserAttribute(userName,
                                                        properties.getProperty(LoginConstants.USERACCOUNTCONTROL));
                            int expiredPasswordValue = 0x800000;
                            int longReturnValue =
                                (null != returnValue && !returnValue.isEmpty()) ? Integer.parseInt(returnValue) : 0;

                            if ((longReturnValue & expiredPasswordValue) == expiredPasswordValue) {
                                logger.info(CLASS_NAME, METHOD_NAME, "User " + userName + " password expired");
                                return Response.status(Response.Status.BAD_REQUEST)
                                               .type(MediaType.APPLICATION_JSON)
                                               .build(); //throw new BadRequestException("User " + userName + " password expired");

                            } else {

                                try {
                                    //  databaseUtil.getUserSecurityQuestions(userName);
                                } catch (NullPointerException e) {
                                    logger.severe(LoginConstants.KROWD_EXCEPTIONS_NULLPOINTEREXCEPTION, e);
                                    // new LoginPortalException(logger, "NeedHelpWithLoginBean.validUsername()", e);
                                 
                                    return Response.status(Response.Status.BAD_REQUEST)
                                                   .type(MediaType.APPLICATION_JSON)
                                                   .build(); //throw new BadRequestException(forgotPwdErrorMsg);
                                } finally {
                                }
                                logger.info(CLASS_NAME, METHOD_NAME, " Redirecting to Security Question Answers page");
                                // generateSecurityQuestions();
                                //                                showPasswordResetLink();
                                processPasscodeActivation(logger, CLASS_NAME, lang, userName);
                                //                                return properties.getProperty(LoginConstants.LOGIN_REDIRECT_FORGOTPASSWORD);
                                return Response.ok()
                                               .type(MediaType.APPLICATION_JSON)
                                               .build();
                            }
                        }
                    }
                } catch (Exception e) {
                    // new LoginPortalException(logger, "NeedHelpWithLoginBean.validUsername()", e);
                    logger.severe(LoginConstants.KROWD_EXCEPTIONS_NULLPOINTEREXCEPTION, e);
                    return Response.status(Response.Status.BAD_REQUEST)
                                   .type(MediaType.APPLICATION_JSON)
                                   .build(); //throw new BadRequestException(e.getMessage());
                }

            }

            //            forgotPwdErrorMsg = repoUtil.getStrings()
            //                                        .get(lang)
            //                                        .get(LoginConstants.LOGIN_INVALID_USERNAME)
            //                                        .toString();
            //            return Response.serverError().build();
        } else {
            //               return properties.getProperty(LoginConstants.RL_RESTRICTED);
            return Response.status(Response.Status.BAD_REQUEST)
                           .type(MediaType.APPLICATION_JSON)
                           .build();
        }
    }


}
