package com.darden.krowd.portal.people.rest.service;

import com.darden.krowd.common.PortalConstants;
import com.darden.krowd.portal.people.rest.base.LoginBaseClass;
import com.darden.krowd.portal.people.rest.model.UserPassCode;
import com.darden.krowd.portal.people.rest.utils.Base62Code;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import oracle.adf.share.logging.ADFLogger;

@Path("/loginservices/passcode")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class PassCodeVerificationResource extends LoginBaseClass {
    transient ADFLogger krowdLogger = ADFLogger.createADFLogger(PassCodeVerificationResource.class);
    private static final String CLASS_NAME = PassCodeVerificationResource.CLASS_NAME;
    private String validationMessage = null;
    private boolean tNcStatus = true;
    private String chkTermAgmt = null;

    public PassCodeVerificationResource() {
        super();

    }

    @POST
    @Path("/processUsernamePasscode")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    /**
     * @return String
     * @description This method is used to validate username and OTP
     */
    public Response processUsernamePasscode( String userOpt) {
        String optendOpt = Base62Code.decodeToString(userOpt);
        String[] parts = Base62Code.decodeToString(optendOpt).split(",");
        String userId = parts[1];
        String optPassword = parts[2];
        final String METHOD_NAME = "processUsernamePasscode";
        krowdLogger.info(CLASS_NAME, METHOD_NAME, "Username " +userId);
        validationMessage = "";

        boolean isOtpValid = false;
        String returnValue = null;
        try {
            if (null != userId&& !userId.isEmpty() && null != optPassword && !optPassword.isEmpty()) {
                if (validUsername(userId)) {
                    isOtpValid = validatePasscode(userId, optPassword );
                    if (!isOtpValid) {
                        //                        validationMessage = repoUtil.getStrings()
                        //                                                    .get(this.currentLocale.toString())
                        //                                                    .get(PortalConstants.LOGIN_OTP_VERIFICATION_FAILURE)
                        //                                                    .toString();
                        return Response.status(Response.Status.BAD_REQUEST)
                                       .type(MediaType.APPLICATION_JSON)
                                       .build();

                    } else {
                        return Response.ok()
                                       .type(MediaType.APPLICATION_JSON)
                                       .build();

                        //                        returnValue = LoginConstants.LOGIN_REDIRECT_SETPWD;
                        //                        validationMessageRender = false;
                        //                        AdfFacesContext.getCurrentInstance()
                        //                                       .getPageFlowScope()
                        //                                       .put("userName", userName);
                    }
                } else {
                    //                    validationMessage = repoUtil.getStrings()
                    //                                                .get(this.currentLocale.toString())
                    //                                                .get(PortalConstants.LOGIN_INVALID_USERNAME)
                    //                                                .toString();
                    return Response.status(Response.Status.BAD_REQUEST)
                                   .type(MediaType.APPLICATION_JSON)
                                   .build();
                }
            } else {
                return Response.status(Response.Status.BAD_REQUEST)
                               .type(MediaType.APPLICATION_JSON)
                               .build();
            }
        } catch (Exception exception) {
            krowdLogger.severe(CLASS_NAME, METHOD_NAME, exception.getMessage());

        }
        krowdLogger.info(CLASS_NAME, METHOD_NAME, "UserName " + userId);
        return Response.status(Response.Status.BAD_REQUEST)
                       .type(MediaType.APPLICATION_JSON)
                       .build();
    }


    /**
     * @return boolean
     * @description This method is used to validate the user from Active Directory for the username
     */
    public boolean validUsername(String userName) {
        final String METHOD_NAME = "validUsername";
        krowdLogger.info(CLASS_NAME, METHOD_NAME, "Username " + userName);
        userName = (userName != null && userName != "") ? userName.trim() : userName;
        try {
            boolean checkRLUser = adUtil.isDardenBusinessUnitRL(userName, PortalConstants.DARDEN_BUSINESS_UNIT);
            krowdLogger.info(CLASS_NAME, METHOD_NAME, "checkRLUser " + checkRLUser);
            if (!checkRLUser) {
                if (adUtil.validUsername(userName) &&
                    !(adUtil.getSamAccountName(userName, properties.getProperty(PortalConstants.SAMACCOUNTNAME)) !=
                      null)) {
                    if (!databaseUtil.getUserActivationStatus(userName)) {
                        krowdLogger.info(CLASS_NAME, METHOD_NAME, "User " + userName + " account is not activated");
                        return false;
                    }

                    String returnValue = null;

                    returnValue = adUtil.getUserRole(userName);
                    if (returnValue.equalsIgnoreCase(properties.getProperty(PortalConstants.LOGIN_RSC))) {
                        userName = "";
                        krowdLogger.info(CLASS_NAME, METHOD_NAME, "User " + userName + " is RSC");
                        return false;
                    } else {

                        returnValue =
                            adUtil.getUserAttribute(userName,
                                                    properties.getProperty(PortalConstants.USERACCOUNTCONTROL));
                        int expiredPasswordValue = 0x800000;
                        // Added the null check if the return value is null
                        int longReturnValue =
                            (null != returnValue && !returnValue.isEmpty()) ? Integer.parseInt(returnValue) : 0;

                        if ((longReturnValue & expiredPasswordValue) == expiredPasswordValue) {
                            krowdLogger.info(CLASS_NAME, METHOD_NAME, "User " + userName + " password expired");
                            return false;
                        }
                    }
                } else {
                    userName =
                        adUtil.getSamAccountName(userName, properties.getProperty(PortalConstants.SAMACCOUNTNAME));
                    if (!databaseUtil.getUserActivationStatus(userName)) {
                        //                        validationMessage =
                        //                                resourceAdapter.get(PortalConstants.LOGIN_ACCOUNT_NOT_ACTIVATED).toString();
                        krowdLogger.info(CLASS_NAME, METHOD_NAME, "User " + userName + " account is not activated");
                        return false;
                    }

                    String returnValue = null;

                    returnValue = adUtil.getUserRole(userName);
                    if (returnValue.equalsIgnoreCase(properties.getProperty(PortalConstants.LOGIN_RSC))) {
                        userName = "";
                        krowdLogger.info(CLASS_NAME, METHOD_NAME, "User " + userName + " is RSC");
                        return false;
                    } else {

                        returnValue =
                            adUtil.getUserAttribute(userName,
                                                    properties.getProperty(PortalConstants.USERACCOUNTCONTROL));
                        int expiredPasswordValue = 0x800000;
                        // Added the null check if the return value is null
                        int longReturnValue =
                            (null != returnValue && !returnValue.isEmpty()) ? Integer.parseInt(returnValue) : 0;

                        if ((longReturnValue & expiredPasswordValue) == expiredPasswordValue) {
                            krowdLogger.info(CLASS_NAME, METHOD_NAME, "User " + userName + " password expired");
                            return false;
                        }
                    }
                }
            } else {
                krowdLogger.info(CLASS_NAME, METHOD_NAME, "User" + userName + " is a RL user");
                return false;
            }
        } catch (Exception e) {
            krowdLogger.severe(CLASS_NAME, METHOD_NAME, e.getMessage());
            return false;
        }
        krowdLogger.info(CLASS_NAME, METHOD_NAME, "User " + userName + " is valid");
        return true;
    }

    /**
     * @return String
     * @description This method is used to validate the user entered OTP details against the Active Directory attributes
     */
    public boolean validatePasscode(String userName, String passCode) {
        final String METHOD_NAME = "validatePasscode";
        krowdLogger.info(CLASS_NAME, METHOD_NAME, "Username  " + userName);
        boolean isValidOTPassword;
        isValidOTPassword = false;

        try {
            String tempUserName = adUtil.getSamAccountName(userName, PortalConstants.SAMACCOUNTNAME);
            krowdLogger.info(CLASS_NAME, METHOD_NAME, " Temp username is " + tempUserName);
            if (tempUserName != null && !tempUserName.isEmpty()) {
                userName = (tempUserName != null) ? tempUserName.trim() : tempUserName;
                krowdLogger.info(CLASS_NAME, METHOD_NAME,
                                 " validatePasscode for user name inside temp block is " + tempUserName);
                isValidOTPassword = databaseUtil.validateUserPasscode(tempUserName, passCode);
            } else {
                krowdLogger.info(CLASS_NAME, METHOD_NAME, " validatePasscode for user name" + userName);
                isValidOTPassword = databaseUtil.validateUserPasscode(userName, passCode);

                tempUserName = adUtil.getSamAccountName(userName, PortalConstants.SAMACCOUNTNAME);

            }

        } catch (Exception exception) {
            krowdLogger.severe(CLASS_NAME, METHOD_NAME, exception.getMessage());

        }
        krowdLogger.info(CLASS_NAME, METHOD_NAME, "Validation message " + validationMessage);
        return isValidOTPassword;
    }


    public void setValidationMessage(String validationMessage) {
        this.validationMessage = validationMessage;
    }

    public String getValidationMessage() {
        return validationMessage;
    }


    //    /**
    //     * @return String
    //     * @description returns TermsAndConditions datasource to content presenter task flow.
    //     */
    //    public String getTermsAndConditions() {
    //      CMSHelper cmsHelper = new CMSHelper();
    //        String queryString = CMSConstants.CMS_TERMS_COND_QUERY;
    //        String datasource = cmsHelper.getdatsourceSingleNode(queryString);
    //        krowdLogger.info(LoginConstants.LOGIN_LOG_GET_TNC + datasource);
    //        if (0 != cmsHelper.getDataFileCount(datasource)) {
    //            this.tNcStatus = false;
    //        } else {
    //            this.tNcStatus = true;
    //        }
    //        return datasource;
    //    }

    public void setTNcStatus(boolean tNcStatus) {
        this.tNcStatus = tNcStatus;
    }

    public boolean isTNcStatus() {
        return tNcStatus;
    }

    public void setChkTermAgmt(String chkTermAgmt) {
        this.chkTermAgmt = chkTermAgmt;
    }

    public String getChkTermAgmt() {
        return chkTermAgmt;
    }
}
