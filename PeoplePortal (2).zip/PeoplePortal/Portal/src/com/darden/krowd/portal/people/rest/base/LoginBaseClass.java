package com.darden.krowd.portal.people.rest.base;

import com.darden.krowd.common.KrowdUtility;
import com.darden.krowd.common.PortalConstants;
import com.darden.krowd.common.StringsRepoUtil;
import com.darden.krowd.common.identity.LdapHelper;
import com.darden.krowd.common.util.ADUtil;
import com.darden.krowd.common.util.MailUtil;
import com.darden.krowd.portal.people.rest.constants.LoginConstants;
import com.darden.krowd.portal.people.rest.utils.Base62Code;
import  com.darden.krowd.portal.people.rest.utils.CheckSum;


import com.darden.krowd.portal.people.rest.utils.DatabaseUtil;



import java.text.MessageFormat;

import java.util.Hashtable;
import java.util.Properties;

import javax.mail.SendFailedException;

import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import oracle.adf.share.logging.ADFLogger;

import oracle.security.idm.User;

import org.apache.commons.lang.RandomStringUtils;

//import javax.ws.rs.BadRequestException;

public class LoginBaseClass {
    protected Properties properties = KrowdUtility.getInstance().getProperties();
    protected DatabaseUtil databaseUtil = DatabaseUtil.getInstance();
    protected ADUtil adUtil = new ADUtil();
    protected StringsRepoUtil repoUtil = StringsRepoUtil.getInstance();

    /**
     * @return String
     * Method to generate and store the password reset code
     */
    public boolean processPasscodeActivation(ADFLogger logger, String CLASS_NAME, String lang, String userName) {
        final String METHOD_NAME = "processPasscode";
        logger.info(CLASS_NAME, METHOD_NAME, "Entering the method");
        try {
            boolean status = false;
            boolean checkMailSent = false;
            logger.info(CLASS_NAME, METHOD_NAME, " userName is : " + userName);

            //Password Verification Code is generated as a 6 digit alphanumeric value
            String sysGenOTP = "aaaaaa";
            char[] alphaNumberList = new char[] {
                'b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'q', 'r', 's', 't', 'v', 'w', 'x', 'y', 'z',
                'B', 'C', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'X', 'Y', 'Z',
                '0', '1', '2', '3', '4', '5', '6', '7', '8', '9'
            };
            sysGenOTP = RandomStringUtils.random(6, 0, 51, true, true, alphaNumberList);
            while (!(sysGenOTP.matches(".*\\d+.*"))) {
                sysGenOTP = RandomStringUtils.random(6, 0, 51, true, true, alphaNumberList);
            }

            //save the password verification code to database
            if (null != sysGenOTP && !sysGenOTP.isEmpty()) {
                logger.info(CLASS_NAME, METHOD_NAME,
                            "Calling generatePasscode method with username : " + userName + " and passcode : " +
                            sysGenOTP);
                String tempUserName = adUtil.getSamAccountName(userName, LoginConstants.SAMACCOUNTNAME);
                logger.info(CLASS_NAME, METHOD_NAME, "processPasscode Temp username is " + tempUserName);
                if (tempUserName != null && !tempUserName.isEmpty()) {
                    tempUserName = (tempUserName != null) ? tempUserName.trim() : tempUserName;
                    logger.info(CLASS_NAME, METHOD_NAME, "processPasscode username inside temp block is " + userName);
                    status = databaseUtil.generatePasscode(tempUserName, sysGenOTP);
                } else {
                    status = databaseUtil.generatePasscode(userName, sysGenOTP);
                }

                logger.info(CLASS_NAME, METHOD_NAME,
                            "Returning from generatePasscode method with status : " + status + " for Username : " +
                            userName);
            }
            if (status) {
                logger.info(CLASS_NAME, METHOD_NAME, "OTP is successfully saved in database for the user " + userName);
                // Call isEmailSent method to send the passcode through Email
                
               
                String mailRecipient2 = "";
                try {
                    // Sender name is stored as a constant in DB
                    String mailSender =
                        properties.getProperty(PortalConstants.MAIL_SENDER_NAME).toString();

                    // Get user's email ID from WCP_USER_PROFILE table
                    mailRecipient2 = adUtil.getUserAttribute(userName, "mail");

                    logger.info(CLASS_NAME, METHOD_NAME,
                                     "Returning from retrieveCurrentEmail method with usename: " +
                                     userName + " and mailRecipient: " +
                                     mailRecipient2);
                    // Generate temporary passcode
                    //String sysGenOTP2 = generatePasscode(userName);
                    if (sysGenOTP != null && (!sysGenOTP.equalsIgnoreCase(""))) {
                        this.sendPasscodeEmail(sysGenOTP, mailSender, mailRecipient2,userName );
                    }
                    return true;
                    
                } catch (Exception e) {
                 String message = e.getMessage();
                 logger.severe(CLASS_NAME, METHOD_NAME,
                                       "Invalid email address " + mailRecipient2 +
                                       " for " + userName + e.getMessage());
                    return false;
                }
                
                
                
                
                
                
                
                //checkMailSent = isEmailSentActivation(logger, CLASS_NAME, lang, userName, sysGenOTP);
            }
            if (!checkMailSent || !status) {
                logger.info(CLASS_NAME, METHOD_NAME, "Error while generating or sending the passcode");
                //                throw new BadRequestException("Error while generating or sending the passcode");
                return false;
            }

        } catch (Exception ex) {
            //            throw new BadRequestException("Error while generating or sending the passcode");
            ex.printStackTrace();
            return false;
        }
        return true;
    }
    
   


    /**
     * @param userName
     * @param sysGenOTP
     * @return boolean
     * Method to send password reset code through Email
     */
    private boolean isEmailSentActivation(ADFLogger logger, String CLASS_NAME, String lang, String userName,
                                          String sysGenOTP) {
        final String METHOD_NAME = "sendPasscodeEmail";
        logger.info(CLASS_NAME, METHOD_NAME,
                    "Entering the method with Username : " + userName + " and Passcode :" + sysGenOTP);
        try {
            // Sender name is stored as a constant in DB
            String mailSender = properties.getProperty(LoginConstants.MAIL_SENDER_NAME).toString();
            //Receiver email is to be fetched from database\
            String mailRecipient = null;
            logger.info(CLASS_NAME, METHOD_NAME, "Calling getUserPersonalEmail method with usename: " + userName);
            String tempUserName = adUtil.getSamAccountName(userName, LoginConstants.SAMACCOUNTNAME);
            logger.info(CLASS_NAME, METHOD_NAME, " Temp username is " + tempUserName);
            if (tempUserName != null && !tempUserName.isEmpty()) {
                userName = (tempUserName != null) ? tempUserName.trim() : tempUserName;
                logger.info(CLASS_NAME, METHOD_NAME, " username inside temp block is " + userName);
            }
            mailRecipient = adUtil.getUserAttribute(userName, "mail");
            logger.info(CLASS_NAME, METHOD_NAME,
                        "Returning from retrieveCurrentEmail method with usename: " + userName +
                        " and mailRecipient: " + mailRecipient);
            try {
                // Checking whether the recipient mail address is valid
                String domainName[] = mailRecipient.split("@");
                //Look up the MX records to find whether the domain has a valid mail server
                doLookup(logger, CLASS_NAME, lang, domainName[1]);
            } catch (Exception e) {
                logger.severe(CLASS_NAME, METHOD_NAME,
                              "Invalid email address " + mailRecipient + " for " + userName + e.getMessage());
                return false;
            }
            //Mail subject is stored as a constant in DB
            String mailSubject = properties.getProperty(LoginConstants.MAIL_SUBJECT).toString();
            //Email body is stored in db
            String emailTemplate = properties.getProperty(LoginConstants.EMAIL_BODY).toString();

            //Get the display name of the user from AD
            User user = LdapHelper.getInstance().getUser(userName);
            oracle.security.idm.UserProfile currentUserProfile = user.getUserProfile();
            String displayName = null;
            if ((String) currentUserProfile.getPropertyVal("displayName") != null) {
                displayName = (String) currentUserProfile.getPropertyVal("displayName");
            } else if ((String) currentUserProfile.getPropertyVal("cn") != null) {
                displayName = (String) currentUserProfile.getPropertyVal("cn");
            } else if ((String) currentUserProfile.getPropertyVal("name") != null) {
                displayName = (String) currentUserProfile.getPropertyVal("name");
            }
            //get mailLink from DB
         
//            String mailLink = requestObj.getScheme()
//                                        .concat("://")
//                                        .concat(requestObj.getServerName())
//                                        .concat(properties.getProperty("ACTIVATION_LINK").toString());
           
            String checkSum= CheckSum.getCheckSum(userName+sysGenOTP);
            String OptToken=userName +"|"+sysGenOTP;
            String sysGenOTPWithCheckSum=checkSum+ "|"+OptToken;
            String encodedToken=  Base62Code.encodeFromString(sysGenOTPWithCheckSum) ; 
            String decodedmailLink ="krowddev1.darden.com"+encodedToken;
            String mailLink ="krowddev1.darden.com";
            logger.info("isEmailSentActivation::checkSum:" + checkSum);
            logger.info("isEmailSentActivation::OptToken :" + OptToken);
            logger.info("isEmailSentActivation::sysGenOTPWithCheckSum" + sysGenOTPWithCheckSum);
            logger.info("isEmailSentActivation::mailLink" + mailLink);
            logger.info("isEmailSentActivation::decodeToString" +  Base62Code.decodeToString(sysGenOTPWithCheckSum));
            logger.info(CLASS_NAME, METHOD_NAME,
                        "Returning from retrieveCurrentEmail method with usename: " + userName + " and mailLink: " +
                        mailLink);
            // Drafting the Email
            MessageFormat format = new MessageFormat("");
            String[] emailDetails = new String[3];
            emailDetails[0] = displayName;
            emailDetails[1] = mailLink;
            emailDetails[2] = sysGenOTP;
            String emailBody = format.format(emailTemplate, emailDetails);
            logger.info("Email Content is :" + emailBody);
            logger.info("Mail Sender name :" + mailSender + "\t" + "Mail recipient :" + mailRecipient + "\t" +
                        "Mail Subject :" + mailSubject + "\t" + "Mail body" + emailBody);
            try {
                logger.info("Email Recipient is :" + mailRecipient);
                MailUtil mailUtil = new MailUtil();
                logger.info(CLASS_NAME, METHOD_NAME, "Sending Email....." + " for user: " + userName);

                mailUtil.sendMail(mailSender, mailRecipient, mailSubject, emailBody, null);
                //            } catch (KrowdMailException e) {
                //                logger.severe(CLASS_NAME, METHOD_NAME,
                //                              "Exception while sending the OTP email for user: " + userName + e.getMessage());
                //                return false;
            } catch (SendFailedException e) {
                logger.info("Email Recipient is :::::" + mailRecipient);
                logger.severe(CLASS_NAME, METHOD_NAME,
                              "Exception while sending the OTP email for user: Invalid email address" + userName +
                              e.getMessage());
                e.printStackTrace();
        
                return false;
            }
        } catch (Exception e) {
            logger.severe(CLASS_NAME, METHOD_NAME, e.getMessage());
            return false;
        }
        return true;
    }
    /**Send  Passcode to user through Email. Note - the existing passcode code is reused. 
    */
    private void sendPasscodeEmail(String sysGenOTP,String mailSender, String mailRecipient, String samAccountName ) throws Exception,
                                                           SendFailedException {
    final String METHOD_NAME = "sendPasscodeEmail";
    //Mail subject is stored as a constant in DB
    String mailSubject = properties.getProperty(PortalConstants.MAIL_SUBJECT).toString();
    //Email body is stored in db
    String emailTemplate = properties.getProperty(PortalConstants.EMAIL_BODY).toString();

    //Get the display name of the user from AD
    User user = LdapHelper.getInstance().getUser(samAccountName);
    oracle.security.idm.UserProfile currentUserProfile = user.getUserProfile();
    
    String displayName = user.getName();
    
    //get mailLink from DB
    //     HttpServletRequest requestObj = (HttpServletRequest)ADFContext.getCurrent().getRequest();
    
    //    requestObj.getScheme().concat("://").concat(requestObj.getServerName()).concat(properties.getProperty(PortalConstants.MAIL_LINK).toString());
     String mailLink =    ("http://krowddev1.darden.com/").concat(properties.getProperty(PortalConstants.MAIL_LINK).toString());
    // Drafting the Email
    MessageFormat format = new MessageFormat("");
    String[] emailDetails = new String[3];
    emailDetails[0] = displayName;
    emailDetails[1] = mailLink;
    emailDetails[2] = sysGenOTP;
    String emailBody = format.format(emailTemplate, emailDetails);
   
    
        MailUtil mailUtil = new MailUtil();


    
         mailUtil.sendMail(mailSender, mailRecipient, mailSubject, emailBody, null);
    
    }
    
    /**
     * @return count of mail servers
     * @description This method is used to retrieve the count of mails servers available for a mail domain
     */
    private int doLookup(ADFLogger logger, String CLASS_NAME, String lang, String hostName) throws NamingException {
        Hashtable env = new Hashtable();
        env.put("java.naming.factory.initial", "com.sun.jndi.dns.DnsContextFactory");
        DirContext ictx = new InitialDirContext(env);
        Attributes attrs = ictx.getAttributes(hostName, new String[] { "MX" });
        Attribute attr = attrs.get("MX");
        logger.info("The attribute returned is :" + attr);
        if (null == attr)
            return (0);
        logger.info("Number of mail servers available for " + hostName + ":" + attr.size());
        return (attr.size());
    }

    /**
     * @return String
     * @description This method is used to validate the user entered OTP details against the Active Directory attributes
     */
    private boolean validatePasscode(ADFLogger logger, String CLASS_NAME, String lang, String userName,
                                     String otpPassword) {
        final String METHOD_NAME = "validatePasscode";
        logger.info(CLASS_NAME, METHOD_NAME, "Username  " + userName);
        boolean isValidOTPassword;
        isValidOTPassword = false;
        try {
            String tempUserName = adUtil.getSamAccountName(userName, LoginConstants.SAMACCOUNTNAME);
            logger.info(CLASS_NAME, METHOD_NAME, " Temp username is " + tempUserName);
            if (tempUserName != null && !tempUserName.isEmpty()) {
                userName = (tempUserName != null) ? tempUserName.trim() : tempUserName;
                logger.info(CLASS_NAME, METHOD_NAME,
                            " validatePasscode for user name inside temp block is " + tempUserName);
                isValidOTPassword = databaseUtil.validateUserPasscode(tempUserName, otpPassword);
            } else {
                logger.info(CLASS_NAME, METHOD_NAME, " validatePasscode for user name" + userName);
                isValidOTPassword = databaseUtil.validateUserPasscode(userName, otpPassword);

                //                tempUserName =
                //                    adUtil.getSamAccountName((String) appScope.get("LoginUsername"), LoginConstants.SAMACCOUNTNAME);
                //                if (!isValidOTPassword && tempUserName != null && !tempUserName.isEmpty()) {
                //                    userName = (String) appScope.get("LoginUsername");
                //                }
            }

        } catch (Exception exception) {
            logger.severe(CLASS_NAME, METHOD_NAME, exception.getMessage());
        }
        return isValidOTPassword;
    }

    public Response validateOtp(ADFLogger logger, String CLASS_NAME, String lang, String userName, String otpPassword) {
        boolean isOtpValid = false;
        String returnValue = null;
        String validationMessage = "";
        try {
            if (null != userName && !userName.isEmpty() && null != otpPassword && !otpPassword.isEmpty()) {

                isOtpValid = validatePasscode(logger, CLASS_NAME, lang, userName, otpPassword);
                if (!isOtpValid) {
                    validationMessage = repoUtil.getStrings()
                                                .get(lang)
                                                .get(LoginConstants.LOGIN_OTP_VERIFICATION_FAILURE)
                                                .toString();
                    //                    throw new BadRequestException(validationMessage);
                    return Response.status(Response.Status.BAD_REQUEST)
                                   .type(MediaType.APPLICATION_JSON)
                                   .build();
                } else {
                    return Response.ok()
                                   .type(MediaType.APPLICATION_JSON)
                                   .build();
                }
            } else {
                validationMessage = repoUtil.getStrings()
                                            .get(lang)
                                            .get(LoginConstants.LOGIN_ENTER_OTP_DETAILS)
                                            .toString();
                //                throw new BadRequestException(validationMessage);
                return Response.status(Response.Status.BAD_REQUEST)
                               .type(MediaType.APPLICATION_JSON)
                               .build();
            }
        } catch (Exception exception) {
            logger.severe(CLASS_NAME, "ValidateOtp", exception.getMessage());
            //            throw new BadRequestException(exception.getMessage());
            return Response.status(Response.Status.BAD_REQUEST)
                           .type(MediaType.APPLICATION_JSON)
                           .build();

        }
    }


}
