package com.darden.krowd.portal.people.rest.utils;

import java.math.BigInteger;

/**
 * Base62 encoding/decoding.
 */

public class Base62Code {
	private Base62Code() {
		super();
	}

	public static final BigInteger base = BigInteger.valueOf(62);
	public static final String LETTERS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

	/**
	 * Encodes a number using Base62 encoding.
	 *
	 * @param bigNumber -- BigInteger -- should be positive integer
	 * @return a Base62 encoded string
	 * @throws IllegalArgumentException if input number is a negative
	 */
	public static String encode(BigInteger bigNumber) {

		StringBuilder result = new StringBuilder();

		try {
			if (bigNumber.compareTo(BigInteger.ZERO) == -1) {
				throw new IllegalArgumentException("Input number should be positive");
			}

			while (bigNumber.compareTo(BigInteger.ZERO) == 1) {
				BigInteger[] divrem = bigNumber.divideAndRemainder(base);
				bigNumber = divrem[0];
				int remainder = divrem[1].intValue();
				result.insert(0, LETTERS.charAt(remainder));
			}
			if (result.length() == 0) {
				return (LETTERS.substring(0, 1));
			} else {
				return (result.toString());
			}

		} catch (IllegalArgumentException e) {
			throw new IllegalArgumentException("Error duting Base62 Concoding: " + e);
		}

	}

	public static String encodeFromString(String strOriginal) {
		byte[] strBytes = strOriginal.getBytes();
		BigInteger strBI = new BigInteger(1, strBytes);
		return encode(strBI);
	}

	/**
	 * Decodes a string using Base62 decoding.
	 *
	 * @param encodedString a Base62 string
	 * @return a positive integer
	 * @throws IllegalArgumentException if input encodeString is empty
	 */
	public static BigInteger decode(final String encodedString) {

		try {
			if (encodedString.length() == 0) {
				throw new IllegalArgumentException("Input encodedString must not be an empty string");
			}
			BigInteger result = BigInteger.ZERO;
			int strLength = encodedString.length();
			for (int index = 0; index < strLength; index++) {
				int letter = LETTERS.indexOf(encodedString.charAt(strLength - index - 1));
				result = result.add(BigInteger.valueOf(letter).multiply(base.pow(index)));
			}
			return result;
		} catch (IllegalArgumentException e) {
			throw new IllegalArgumentException("Error duting Base62 Decoding: " + e);
		}

	}

	public static String decodeToString(final String encodedString) {
		BigInteger decodedBI = Base62Code.decode(encodedString);
		return new String(decodedBI.toByteArray());
	}

}
