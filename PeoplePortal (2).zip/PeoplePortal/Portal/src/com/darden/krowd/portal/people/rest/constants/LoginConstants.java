package com.darden.krowd.portal.people.rest.constants;

public class LoginConstants {
    public LoginConstants() {
        super();
    }
    
    //subh, CWE-259: Use of Hard-coded Password
    enum Level {
        LOGIN_REDIRECT_EXPIREDPASSWORD_MSG,
        changePwd,
        EXPIREDPASSWORDVALUE,
        KEYSTORE_PASSWORD,
        KEYSTORE_PASSWORD_PATH,
        UCM_PASSWORD,
        LDAP_PASSWORD,
        LOGIN_PASSWORD_SCREEN,
        PASSWORD_DO_NOT_MATCH,
        PASSWORD_NOTINRANGE,
        PASSWORD_EXCEPTION_MESSAGE,
        PASSWORD_OPERATION_FAILED,
        LOGIN_FAILURE_PASSWORD_RESET,
        PASSWORD_POLICY_MESSAGE,
        LOGIN_FORGOTPASSWORD_BEAN,
        LOGIN_FORGOTPASSWORD_SCCREEN,
        LOGIN_REDIRECT_EXPIREDPASSWORD,
        LOGIN_REDIRECT_FORGOTPASSWORD,
        LOGIN_PASSWORD_ENCRYPTION,
        LOGIN_PASSWORD_ATTRIBUTE,
        RESET_PASSWORD_LINK,
        RESET_PASSWORD_THROUGH_EMAIL,
        MANAGERPASSWORDEXPIRYROLES,
        LOGIN_FORGOT_PASSWORD_MSG,
        Locked1
    }
    //
    public static final String LOGIN_METHOD_ACTIVATE_PROFILE = "activateProfile";
    public static final String LOGIN_METHOD_VALIDATE_USER = "validateUser";
    public static final String LOGIN_METHOD_GET_TNC_USERNAME = "getTermsAndConditionsUserName";
    
    public static final String LOGIN_CONSTANT_INVALID_RLUSER = "RL_INVALIDUSER";
    public static final String LOGIN_CONSTANT_KROWD_ACTIVATED_USER = "KROWD_ACTIVATED_USER";
    public static final String LOGIN_CONSTANT_DARDEN_COM = ".darden.com";
    public static final String LOGIN_CONSTANT_BACKSLASH = "/";
    
    public static final String LOGIN_LOG_INVALID_USERNAME = "Username Invalid Combination";
    public static final String LOGIN_LOG_RL_USER = "RL User";
    public static final String LOGIN_LOG_ACTIVATED_USER = "User is already activated";
    public static final String LOGIN_LOG_DISABLED_USER = "User is disabled in AD";
    public static final String LOGIN_LOG_TNC_REDIRECT = "Redirecting to Terms and Conditions with username : ";
    public static final String LOGIN_LOG_EMAILID = " emailId : ";
    public static final String LOGIN_LOG_CONFIRM_EMAILID = " confirmEmailId : ";
    public static final String LOGIN_LOG_VAL_USER1 = "Calling validateUserDetails method with : 1. Initials : ";
    public static final String LOGIN_LOG_VAL_USER2 = " 2. DOB : ";
    public static final String LOGIN_LOG_VAL_USER3 = " 3. Restaurant Number : ";
    public static final String LOGIN_LOG_VAL_USER4 = " 4. POS Id : ";
    public static final String LOGIN_LOG_VAL_USER5 = " Returning from validateUserDetails method with username : ";
    public static final String LOGIN_LOG_VAL_USER6 = " Calling isDardenBusinessUnitRL method with : Username : ";
    public static final String LOGIN_LOG_VAL_USER7 = " User Attribute : ";
    public static final String LOGIN_LOG_VAL_USER8 = " Returning from isDardenBusinessUnitRL method with checkRLUser : ";
    public static final String LOGIN_LOG_VAL_USER9 = " Username from AD : ";
    public static final String LOGIN_LOG_TNC_USER1 = " Username is: " ;
    public static final String LOGIN_LOG_TNC_USER2 = " Username from Security Context: " ;
    public static final String LOGIN_LOG_TNC_USER3 = " Alias name for the username ";
    public static final String LOGIN_LOG_TNC_USER4 = " termsAndConditionsUserName is ";
    public static final String LOGIN_LOG_TNC_USER5 = " if Alias name is null";
    public static final String LOGIN_LOG_TNC_USER6 = " is ";
    public static final String LOGIN_LOG_TNC_USER7 = " termsAndConditions UserName: ";
    public static final String LOGIN_LOG_TNC_USER8 = " cookie if ";
    public static final String LOGIN_LOG_TNC_USER9 = " cookie else ";
    public static final String LOGIN_LOG_GET_TNC = " The datasource formed is :";
    public static final String LOGIN_LOG_SET_BTNTXT1 = " Calling getUserRole method with userName : ";
    public static final String LOGIN_LOG_SET_BTNTXT2 = " Returning with getUserRole method with userRole : ";
    public static final String LOGIN_LOG_SET_BTNTXT3 = " Button Text Set : ";
    
    public static final String LOGIN_REDIRECT_SETPWD = Level.changePwd.name();
    public static final String LOGIN_REDIRECT_EXPIREDPASSWORD_MSG = Level.LOGIN_REDIRECT_EXPIREDPASSWORD_MSG.name();
    
    public static final String LOGIN_DUALDIGIT_FORMAT = "LOGIN_DUALDIGIT_FORMAT"; //%02d%
    public static final String LOGIN_START_YEAR = "LOGIN_START_YEAR"; //1910
    public static final String LOGIN_END_YEAR = "LOGIN_END_YEAR"; //2005
    public static final String LOGIN_TEST_YEAR = "LOGIN_TEST_YEAR"; //9999
    
    public static final Integer LOGIN_NO_OF_DAYS = 31;
    
   
    
    //subh, CWE-259: Use of Hard-coded Password

    
    // attribute mapping
    public static final String INITIALS = "INITIALS";
    public static final String SN = "SN";
    public static final String BIRTHDATE = "BIRTHDATE";
    public static final String RESTAURANTNUMBER = "RESTAURANTNUMBER";
    public static final String POSID = "POSID";
    public static final String ACCOUNTEXPIRES = "ACCOUNTEXPIRES";
    public static final String DARDEN_BUSINESS_UNIT = "DARDEN-BUSINESS-UNIT";
    public static final String DARDEN_PS_OPRID = "Darden-PS-OPRID";
    public static final String ZIPCODE = "ZIPCODE";
    public static final String EMPLOYEEID = "EMPLOYEEID";
    public static final String EMPLOYEE_NUMBER = "EMPLOYEE-NUMBER";
    public static final String FIRSTNAME = "FIRSTNAME";
    public static final String LASTNAME = "LASTNAME";
    public static final String MIDDLENAME = "MIDDLENAME";
    public static final String DISPLAYNAME = "DISPLAYNAME";
    public static final String USERACCOUNTCONTROL = "USERACCOUNTCONTROL";
    public static final String EXPIREDPASSWORDVALUE = Level.EXPIREDPASSWORDVALUE.name();
    public static final String SAMACCOUNTNAME = "SAMACCOUNTNAME";
    public static final String  DISTINGUISHEDNAME = "DISTINGUISHEDNAME";
    public static final String  MANAGERLEVEL = "MANAGERLEVEL";
    public static final String  PEOPLESOFTID = "PEOPLESOFTID";
    public static final String  DIVISION = "DIVISION";
    
    public static final String DN_ATTRIBUTE = "distinguishedName";
    public static final String ALIAS_ATTRIBUTE = "Darden-AKA";
    public static final String PWDLASTSET = "PWDLASTSET";
    

    public static final String ALREADY_ACTIVATED = "ALREADY_ACTIVATED";
    public static final String INVALID_CREDENTIALS = "INVALID_CREDENTIALS";
    public static final String SUCCESSFUL_ACTIVATION = "SUCCESSFUL_ACTIVATION";
    public static final String SAME_SECURITYQUESTION = "SAME_SECURITYQUESTION";
    public static final String UNANSWERED_SECURITYQUESTION = "UNANSWERED_SECURITYQUESTION";
    public static final String ADPROBLEM = "ADPROBLEM";
    public static final String SELECT_SECURITYQUESTION = "SELECT_SECURITYQUESTION";
    public static final String Darden_Area = "Darden-Area";
    public static final String Darden_Region = "Darden-Region";
    public static final String PhysicalDeliveryOfficeName = "physicalDeliveryOfficeName";
    
    // AD Groups
    public static final String Portal_RSC_Emp = "Portal - RSC Emp";
    public static final String Portal_RSC_Emp_Canada = "Portal - RSC Emp � Canada";
    public static final String Portal_Hourly = "Portal � Hourly";
    
    // AD Connetion details
    public static final String INITIAL_CONTEXT_FACTORY = "INITIAL_CONTEXT_FACTORY";
    public static final String SECURITY_AUTHENTICATION = "SECURITY_AUTHENTICATION";
    public static final String SECURITY_PRINCIPAL = "SECURITY_PRINCIPAL";
    public static final String SECURITY_CREDENTIALS = "SECURITY_CREDENTIALS";
    public static final String SECURITY_PROTOCOL = "SECURITY_PROTOCOL";
    public static final String PROVIDER_URL = "PROVIDER_URL";
    public static final String BASE_NAME = "BASE_NAME";
    public static final String USER_DN = "USER_DN";
    public static final String SERVER_IP = "SERVER_IP";
    public static final String MODEL_USERNAME = "MODEL_USERNAME";
    public static final String KEYSTORE_LOCATION = "KEYSTORE_LOCATION";
    public static final String KEYSTORE_PASSWORD = Level.KEYSTORE_PASSWORD.name();
    public static final String REFERRAL = "REFERRAL";
    public static final String KEYSTORE_PATH = "KEYSTORE_PATH";
    public static final String KEYSTORE_PASSWORD_PATH = Level.KEYSTORE_PASSWORD_PATH.name();
    public static final String TRUSTSTORE_PATH = "TRUSTSTORE_PATH";
    public static final String DEBUG_PATH = "DEBUG_PATH";
    public static final String DEBUG_VALUE = "DEBUG_VALUE";

    public static final String JOB_URL = "JOB_URL";
    public static final String JOB_FRIEND_URL = "JOB_FRIEND_URL";
    public static final String ID_BADGE_RSC_URL = "ID_BADGE_RSC_URL";
    public static final String DARDEN_CAFE_RSC_URL = "DARDEN_CAFE_RSC_URL";
    public static final String ID_BADGE_NONRSC_URL = "ID_BADGE_NONRSC_URL";
    public static final String STOCKIMAGEURL = "STOCKIMAGEURL";

    public static final String UCM_IMAGE_URL = "UCM_IMAGE_URL";
    public static final String UCM_IMAGE_URL_2 = "UCM_IMAGE_URL_2";
    public static final String UCM_IDC_URL = "UCM_IDC_URL";
    public static final String UCM_USERNAME = "UCM_USERNAME";
    public static final String UCM_PASSWORD = Level.UCM_PASSWORD.name();
    public static final String IMAGE_SRC = "IMAGE_SRC";
    public static final String IMAGE_EXT = "IMAGE_EXT";
    public static final String DEFAULT_IMAGE = "DEFAULT_IMAGE";
    public static final String DEFAULT = "DEFAULT";
    public static final String WEATHER_ERROR_IMAGE = "WEATHER_ERROR_IMAGE";
    public static final String STOCK_ERROR_IMAGE = "STOCK_ERROR_IMAGE";
    public static final String DEFAULT_ZIPCODE = "DEFAULT_ZIPCODE";
    public static final String WEATHER_URL = "WEATHER_URL";

    public static final String UCM_CONNECTION_NAME = "UCM_CONNECTION_NAME";
    public static final String UCM_ANNOUNCEMENT_LIMIT = "UCM_ANNOUNCEMENT_LIMIT";
    public static final String UCM_ANNOUNCEMENT_PAGINATION_PAGESIZE = "UCM_ANNOUNCEMENT_PAGINATION_PAGESIZE";
    public static final String UCM_ANNOUNCEMENT_PAGINATION_CURRENT_PAGE = "UCM_ANNOUNCEMENT_PAGINATION_CURRENT_PAGE";
    public static final String UCM_ANNOUNCEMENT_REGION_DEFINITION = "UCM_ANNOUNCEMENT_REGION_DEFINITION";
    public static final String UCM_ANNOUNCEMENT_DETAIL_VIDEOPATH = "UCM_ANNOUNCEMENT_DETAIL_VIDEOPATH";
    public static final String UCM_ANNOUNCEMENT_PRIORITY_ROWS = "UCM_ANNOUNCEMENT_PRIORITY_ROWS";
    
    // Landing Page Constants
    public static final String KROWD_LANDINGPAGE_ACTIVITYSTREAM_FLOW_TASKFLOWID = "/WEB-INF/flows/activitystreamheader-flow.xml#activitystreamheader-flow";
    public static final String KROWD_LANDINGPAGE_ONTHEMOVEALL_FLOW_TASKFLOWID = "/WEB-INF/flows/onthemoveall-flow.xml#onthemoveall-flow";
    public static final String KROWD_LANDINGPAGE_ANNIVERSARIESALL_FLOW_TASKFLOWID = "/WEB-INF/flows/anniversariesall-flow.xml#anniversariesall-flow";
    public static final String KROWD_LANDINGPAGE_BIRTHDAYSALL_FLOW_TASKFLOWID = "/WEB-INF/flows/birthdaysall-flow.xml#birthdaysall-flow";
    public static final String KROWD_LANDINGPAGE_VIEWALLADS_FLOW_TASKFLOWID = "/WEB-INF/flows/viewAllAds-flow.xml#viewAllAds-flow";
    public static final String KROWD_LANDINGPAGE_PLACEADS_FLOW_TASKFLOWID = "/WEB-INF/flows/placeAd-flow.xml#placeAd-flow";
    public static final String KROWD_LANDINGPAGE_ALERTS_FLOW_TASKFLOWID = "/WEB-INF/flows/alerts-detail-flow.xml#alerts-detail-flow";
    public static final String KROWD_LANDINGPAGE_SPOTLIGHT_FLOW_TASKFLOWID = "/WEB-INF/flows/spotlight-detail-flow.xml#spotlight-detail-flow";
    public static final String KROWD_LANDINGPAGE_ANNOUNCEMENT_FLOW_TASKFLOWID = "/WEB-INF/flows/announcement-detail-flow.xml#announcement-detail-flow";
    public static final String KROWD_LANDINGPAGE_MANAGEPOLLS_FLOW_TASKFLOWID = "/WEB-INF/flows/managepolls-flow.xml#managepolls-flow";
    public static final String KROWD_LANDINGPAGE_EMPLOYEEBIRTHDATES = "EmployeeBirthDates";
    public static final String KROWD_LANDINGPAGE_EMPLOYEEANNIVERSARYDATES = "EmployeeAnniversaryDates";
    public static final String KROWD_LANDINGPAGE_IDCSERVICE = "IdcService"; 
    public static final String KROWD_LANDINGPAGE_GET_SEARCH_RESULTS = "GET_SEARCH_RESULTS";
    public static final String KROWD_LANDINGPAGE_DDOCNAME = "dDocName";
    public static final String KROWD_LANDINGPAGE_QUERYTEXT = "QueryText";
    public static final String KROWD_LANDINGPAGE_SEARCHRESULTS = "SearchResults";
    public static final String ALIAS_SEARCH_FILTER = "ALIAS_SEARCH_FILTER";
    public static final String LDAP_USER ="LDAP_USER";
    public static final String LDAP_PASSWORD = Level.LDAP_PASSWORD.name();
    public static final String GC_HOST = "GC_HOST";
    
    
    public static final int KROWD_LANDING_BADISPLAYROWS_INT=5;
    public static final int KROWD_ZERO = 0;
    public static final int KROWD_ONE = 1;
    public static final String BA_NUM_DAYS = "BA_NUM_DAYS";
    public static final String OTM_NUM_DAYS = "OTM_NUM_DAYS";
    public static final String KROWD_DATE_FORMAT = "yyyy-MM-dd";
    public static final String KROWD_MMDD_FORMAT = "MMdd";
    public static final String KROWD_FIRSTNAME = "firstName";
    public static final String KROWD_LASTNAME = "lastName";
    public static final String KROWD_DATE = "date";
    public static final String KROWD_NUMEROFYEAR = "numOfYears";
    public static final String KROWD_EMPLOYEEID = "employeeID";
    public static final String KROWD_LANDING_BADISPLAYROWS = "LANDING.BADISPLAYROWS";
    public static final String KROWD_RESOURCES = "resources";
    public static final String KROWD_RL = "RL";
    public static final String KROWD_BB = "BB";
    public static final String KROWD_LH = "LH";
    public static final String KROWD_EV = "EV";
    public static final String KROWD_OG = "OG";
    public static final String KROWD_YH = "YH";
    public static final String KROWD_52 = "52";
    public static final String KROWD_CG = "CG";
    
    // On the Move
    public static final String KROWD_OTM_PRO = "PRO";
    public static final String KROWD_OTM_HIR = "HIR";
    public static final String KROWD_OTM_REH = "REH";
    public static final String KROWD_OTM_XFR = "XFR";
    public static final String KROWD_OTM_RET = "RET";
    
    // Exceptions Messages
    public static final String KROWD_EXCEPTIONS_ONTHEMOVESFAULTMSG = "OnTheMovesFaultMsg";
    public static final String KROWD_EXCEPTIONS_BAFAULTMSG = "BAFaultMsg";
    public static final String KROWD_EXCEPTIONS_DATATYPECONFIGURATIONEXCEPTION = "DatatypeConfigurationException";
    public static final String KROWD_EXCEPTIONS_EXCEPTION = "Exception";
    public static final String KROWD_EXCEPTIONS_PARSEEXCEPTION = "ParseException";
    public static final String KROWD_EXCEPTIONS_ILLEGALACCESSEXCEPTION = "Illegalaccessexception";
    public static final String KROWD_EXCEPTIONS_INVOCATIONTARGETEXCEPTION = "InvocationTargetException";
    public static final String KROWD_EXCEPTIONS_NOSUCHMETHODEXCEPTION = "NoSuchMethodException";
    public static final String KROWD_EXCEPTIONS_IDCCLIENTEXCEPTION = "IdcClientException";
    public static final String KROWD_EXCEPTIONS_NULLPOINTEREXCEPTION = "NullPointerException";
    public static final String KROWD_EXCEPTIONS_REPOSITORYEXCEPTION = "RepositoryException";
    public static final String KROWD_EXCEPTIONS_JPSEXCEPTION = "JpsException";
    public static final String KROWD_EXCEPTIONS_IMEEXCEPTION = "IMException";
    public static final String KROWD_EXCEPTIONS_IOEXCEPTION = "IOException";
    public static final String KROWD_EXCEPTIONS_MALFORMEDURLEXCEPTION = "MalformedURLException";
    public static final String KROWD_EXCEPTIONS_COMMUNICATIONEXCEPTION = "CommunicationException";
    public static final String KROWD_EXCEPTIONS_NAMINGEXCEPTION = "NamingException";
    public static final String KROWD_EXCEPTIONS_NOPERMISSIONEXCEPTION = "NoPermissionException";
    public static final String KROWD_EXCEPTION_INVALIDATTRIBUTEVALUEEXCEPTION = "InvalidAttributeValueException";
    
    // Login constants
    public static final String POLLS_ROLE = "LOGIN_POLLS_ROLE";
    public static final String LOGIN_RESOURCE_BEAN = "LOGIN_RESOURCE_BEAN";
    public static final String LOGIN_USERNAME_INVALID_COMBINATION = "LOGIN.USERNAME_INVALID_COMBINATION";
    public static final String LOGIN_ALREADY_ACTIVATED = "LOGIN.ALREADY_ACTIVATED";
    public static final String LOGIN_DOB_MISMATCH = "LOGIN.DOB_MISMATCH";
    public static final String LOGIN_ACTIVATE_ACCOUNT = "LOGIN.ACTIVATE_ACCOUNT";
    public static final String LOGIN_TERM_AGREEMENT = "LOGIN_TERM_AGREEMENT";
    public static final String LOGIN_DATE_REPLACE = "LOGIN_DATE_REPLACE";
    public static final String LOGIN_USERNAME = "LOGIN_USERNAME";
    public static final String RL_RESTRICTED ="RL_RESTRICTED";
    
    public static final String LOGIN_TOTAL_QUESTION_NO = "LOGIN.TOTAL_QUESTION_NO";
    public static final String LOGIN_SECURITY_QUESTION = "LOGIN.SECURITY_QUESTION";
    public static final String LOGIN_SECURITYQUSETION1 = "LOGIN_SECURITYQUSETION1";
    public static final String LOGIN_SECURITYQUSETION2 = "LOGIN_SECURITYQUSETION2";
    public static final String LOGIN_SECURITYQUSETION3 = "LOGIN_SECURITYQUSETION3";
    public static final String LOGIN_SAME_SECURITYQUESTION = "LOGIN.SAME_SECURITYQUESTION";
    public static final String LOGIN_UNANSWERED_SECURITYQUESTION = "LOGIN.UNANSWERED_SECURITYQUESTION";
    public static final String LOGIN_SELECT_SECURITYQUESTION = "LOGIN.SELECT_SECURITYQUESTION";
    public static final String LOGIN_ADPROBLEM = "LOGIN.ADPROBLEM";
    public static final String LOGIN_ACTIVATE_PROFILE_SEC_QA_BEAN = "LOGIN_ACTIVATE_PROFILE_SEC_QA_BEAN";
    public static final String LOGIN_RSC = "LOGIN_RSC";
    public static final String LOGIN_RM = "LOGIN_RM";
    public static final String LOGIN_TM = "LOGIN_TM";
    public static final String LOGIN_EMPLOYEES = "LOGIN_EMPLOYEES";
    public static final String LOGIN_MANAGERS = "LOGIN_MANAGERS";
    public static final String LOGIN_FIELD = "LOGIN_FIELD";
    public static final String LOGIN_MANAGERLEVEL_M = "LOGIN_MANAGERLEVEL_M";
    public static final String LOGIN_MANAGERLEVEL_J = "LOGIN_MANAGERLEVEL_J";
    public static final String LOGIN_MANAGERLEVEL_G = "LOGIN_MANAGERLEVEL_G";
    public static final String LOGIN_MANAGERLEVEL_H = "LOGIN_MANAGERLEVEL_H";
    public static final String LOGIN_ACTIVATE_ACCOUNT_SUCCESS = "LOGIN_ACTIVATE_ACCOUNT_SUCCESS";
    public static final String LOGIN_PASSWORD_SCREEN = Level.LOGIN_PASSWORD_SCREEN.name();
    /*
    public static final String LOGIN_PASSWORD_DO_NOT_MATCH = "LOGIN.PASSWORD_DO_NOT_MATCH";
    public static final String LOGIN_PASSWORD_NOTINRANGE = "LOGIN.PASSWORD_NOTINRANGE";
    public static final String LOGIN_PASSWORD_EXCEPTION_MESSAGE = "LOGIN.PASSWORD_EXCEPTION_MESSAGE";
    public static final String LOGIN_PASSWORD_OPERATION_FAILED = "LOGIN.PASSWORD_OPERATION_FAILED";
    */ //commented
    public static final String LOGIN_PASSWORD_DO_NOT_MATCH = "LOGIN."+Level.PASSWORD_DO_NOT_MATCH.name();
    public static final String LOGIN_PASSWORD_NOTINRANGE = "LOGIN."+Level.PASSWORD_NOTINRANGE.name();
    public static final String LOGIN_PASSWORD_EXCEPTION_MESSAGE = "LOGIN."+Level.PASSWORD_EXCEPTION_MESSAGE.name();
    public static final String LOGIN_PASSWORD_OPERATION_FAILED = "LOGIN."+Level.PASSWORD_OPERATION_FAILED.name();
    
    public static final String LOGIN_SUCCESS = "LOGIN_SUCCESS";
    public static final String LOGIN_FAILURE = "LOGIN_FAILURE";
    public static final String LOGIN_FAILURE_PASSWORD_RESET = Level.LOGIN_FAILURE_PASSWORD_RESET.name();
    public static final String LOGIN_BACK = "LOGIN_BACK";
    public static final String LOGIN_ANSWERED_COUNT = "LOGIN_ANSWERED_COUNT";
    public static final String LOGIN_LOGINPAGE_URL = "LOGINPAGE_URL";
    public static final String LOGIN_NOTSET = "LOGIN_NOTSET";
    //public static final String LOGIN_PASSWORD_POLICY_MESSAGE = "LOGIN.PASSWORD_POLICY_MESSAGE";//commented
    public static final String LOGIN_PASSWORD_POLICY_MESSAGE = "LOGIN."+Level.PASSWORD_POLICY_MESSAGE.name();
    
    public static final String LOGIN_FORGOTPASSWORD_BEAN = Level.LOGIN_FORGOTPASSWORD_BEAN.name();
    public static final String LOGIN_SECURITYQUESTION = "LOGIN_SECURITYQUESTION";
    public static final String LOGIN_INVALID_USERNAME = "LOGIN.INVALID_USERNAME";
    public static final String LOGIN_NOTACTIVATED = "LOGIN_NOTACTIVATED";
    public static final String LOGIN_ACCOUNT_NOT_ACTIVATED = "LOGIN.ACCOUNT_NOT_ACTIVATED";
    public static final String LOGIN_NOTANSWERED = "LOGIN_NOTANSWERED";
    public static final String LOGIN_LEAST_SECURITY = "LOGIN.LEAST_SECURITY";
    public static final String LOGIN_FORGOTPASSWORD_SCCREEN = Level.LOGIN_FORGOTPASSWORD_SCCREEN.name();
    public static final String LOGIN_INVALID_CREDENTIALS = "LOGIN.INVALID_CREDENTIALS";
    public static final String LOGIN_RM_PARSE_DATEFORMAT = "LOGIN_RM_PARSE_DATEFORMAT";
    public static final String LOGIN_RM_FINALDATE = "LOGIN_RM_FINALDATE";
    public static final String LOGIN_DASH = "LOGIN_DASH";
    public static final String LOGIN_TEAM_MEMBER = "LOGIN.TEAM_MEMBER";
    public static final String LOGIN_FORGOTUSERNAME_BEAN = "LOGIN_FORGOTUSERNAME_BEAN";
    public static final String LOGIN_REDIRECT_EXPIREDPASSWORD = Level.LOGIN_REDIRECT_EXPIREDPASSWORD.name();
    public static final String LOGIN_REDIRECT_FORGOTPASSWORD = Level.LOGIN_REDIRECT_FORGOTPASSWORD.name();
    public static final String LOGIN_RSC_MEMBERS = "LOGIN.RSC_MEMBERS";
    public static final String LOGIN_NEEDHELPWITHLOGIN_BEAN="LOGIN_NEEDHELPWITHLOGIN_BEAN";
    
    public static final String LOGIN_PASSWORD_ENCRYPTION = Level.LOGIN_PASSWORD_ENCRYPTION.name();
    public static final String LOGIN_PASSWORD_ATTRIBUTE = Level.LOGIN_PASSWORD_ATTRIBUTE.name();
    public static final String LOGIN_COMMA = "LOGIN_COMMA";
    public static final String SEARCH_STARTINGPOINT_FORGOTUSERNAME_RM = "SEARCH_STARTINGPOINT_FORGOTUSERNAME_RM";
    public static final String SEARCH_STARTINGPOINT_FORGOTUSERNAME_TM = "SEARCH_STARTINGPOINT_FORGOTUSERNAME_TM";
    public static final String USERLIST_EMPTY = "USERLIST_EMPTY";
    public static final String LOGINPAGE_URL = "LOGINPAGE_URL";
    public static final String LOGIN_ACCOUNT_LOCK_INCORRECT_SECURITY_ANSWERS = "LOGIN.ACCOUNT_LOCK_INCORRECT_SECURITY_ANSWERS";
    public static final String LOGIN_STATIC_RESET_PASSWORD = Level.Locked1.name();
    public static final String WALLPOST_BANNED_WORDS="WALLPOST_BANNED_WORDS";
    public static final String PROFANITY_CHK_FAIL="PROFANITY_CHK_FAIL";
    public static final String LOGIN_EMAILID_DO_NOT_MATCH="LOGIN.EMAILID_DO_NOT_MATCH";
    public static final String LOGIN_ACTIVATION_FAILURE_MSG="LOGIN.ACTIVATION_FAILURE_MSG";
    //public static final String LOGIN_RESET_PASSWORD_LINK="LOGIN.RESET_PASSWORD_LINK";//commented
    public static final String LOGIN_RESET_PASSWORD_LINK="LOGIN."+Level.RESET_PASSWORD_LINK.name();
    
    public static final String MAIL_SENDER_NAME = "MAIL_SENDER_NAME";
    public static final String MAIL_SUBJECT = "MAIL_SUBJECT";
    public static final String MAIL_LINK = "MAIL_LINK";
    public static final String EMAIL_BODY = "EMAIL_BODY";
    public static final String RESET_PASSWORD_THROUGH_EMAIL = Level.RESET_PASSWORD_THROUGH_EMAIL.name();
    public static final String EMAIL_SENT_MESSAGE = "EMAIL_SENT_MESSAGE";
    public static final String SPACES_LINK = "SPACES_LINK";
    public static final String MANAGER_PWD_EXPIRY_ALERT1 = "MANAGER_PWD_EXPIRY_ALERT1";
    public static final String MANAGER_PWD_EXPIRY_ALERT2 = "MANAGER_PWD_EXPIRY_ALERT2";
    public static final String MANAGER_PWD_EXPIRES_TODAY_ALERT1 = "MANAGER_PWD_EXPIRES_TODAY_ALERT1";
    public static final String MANAGER_PWD_EXPIRES_TODAY_ALERT2 = "MANAGER_PWD_EXPIRES_TODAY_ALERT2";
    public static final String MANAGER_PWD_EXPIRES_TOMO_ALERT1 = "MANAGER_PWD_EXPIRES_TOMO_ALERT1";
    public static final String MANAGER_PWD_EXPIRY_RETENTIONPOLICYDAYS = "MANAGER_PWD_EXPIRY_RETENTIONPOLICYDAYS";
    public static final String MANAGER_PWD_EXPIRY_EXPIRYALERTSTARTDATE = "MANAGER_PWD_EXPIRY_EXPIRYALERTSTARTDATE";
    public static final String EMAIL_UPDATE_SUCCESSFUL = "EMAIL_UPDATE_SUCCESSFUL";
    public static final String EMAIL_UPDATE_FAILURE = "EMAIL_UPDATE_FAILURE";
    public static final String TEMP_DATE ="TEMP_DATE";
    
    
    
    // MyWork constant
    public static final String KROWD_MYWORKPAGE_VISITINGMANAGER_FLOW_TASKFLOWID = "/WEB-INF/flows/mywork-definition.xml#mywork-definition";
    // Feedback SMTP constants
    public static final String SMTP_HOST = "SMTP_HOST";
    public static final String MAIL_SENDER = "MAIL_SENDER";
    public static final String MAIL_RECIPIENT = "MAIL_RECIPIENT";
    public static final String SMTP_PORT = "SMTP_PORT";
    public static final String PHYSICALDELIVERYOFFICENAME = "PHYSICALDELIVERYOFFICENAME";
    public static final String FEEDBACK_FAILURE_MSG = "FEEDBACK_FAILURE_MSG";
    public static final String FEEDBACK_SUCCESS_MSG = "FEEDBACK_SUCCESS_MSG";
    public static final String LAST_NAME = "LAST_NAME";
    public static final String ADMIN_USER = "ADMIN_USER";
    // Submit A Story Constants
    public static final String STORY_SUCCESSFUL_UPLOAD = "StorySuccess";
    public static final String STORY_SUCCESSFUL_MAIL = "MailSuccess";
    public static final String STORY_FAILURE_UPLOAD = "StoryFailure";
    public static final String STORY_FAILURE_MAIL = "MailFailure";    
    public static final String STORY_MAIL_SUBJECT = "STORY_MAIL_SUBJECT"; 
    public static final String STORY_MAIL_SENDER = "STORY_MAIL_SENDER";
    public static final String STORY_MAIL_RECIPIENT = "STORY_MAIL_RECIPIENT";
    public static final String STORY_PHONE = "STORY_PHONE";
    public static final String STORY_EMAIL_ADDRESS = "STORY_EMAIL_ADDRESS";
    public static final String KROWD_LOGO_URL = "KROWD_LOGO_URL";
    public static final String ACTIVITY_STREAM_DEPARTMENT = "ACTIVITY_STREAM_DEPARTMENT";
    public static final String KROWD_BUILD_VERSION = "KROWD_BUILD_VERSION";
    public static final String KROWD_BUILD_VERSION_ID = "KROWD_BUILD_VERSION_ID";
    public static final String FEEDBACK_EMAIL_SUBJECT = "FEEDBACK_EMAIL_SUBJECT";
    public static final String KROWD_RSSFEED_URL="KROWD_RSSFEED_URL";
    public static final String ACTIVITYSTREAM_DATE_TODAY="ACTIVITYSTREAM_DATE_TODAY";
    public static final String COMMON_NEXT = "COMMON.NEXT";
    public static final String MYWORK_DATE = "MYWORK_DATE";
    public static final String LOGIN_OTP_VERIFICATION_FAILURE = "LOGIN_OTP_VERIFICATION_FAILURE";
    public static final String LOGIN_ENTER_OTP_DETAILS = "LOGIN_ENTER_OTP_DETAILS";
    public static final String USERACCOUNTCONTROLVAL ="USERACCOUNTCONTROLVALUE";
    public static final String USERACKCONTROL ="USERACKCONTROL";
    public static final String MANAGERPASSWORDEXPIRYROLES =Level.MANAGERPASSWORDEXPIRYROLES.name();

    /* Defect fix for 4361 */
    public static final String LOGIN_OU_RSC = "LOGIN_OU_RSC";
    public static final String LOGIN_OU_EMPLOYEES = "LOGIN_OU_EMPLOYEES";
    public static final String LOGIN_OU_MANAGERS = "LOGIN_OU_MANAGERS";
    public static final String LOGIN_OU_FIELD = "LOGIN_OU_FIELD";
    
    /*3.3 Activation Flow Restructure */
    public static final String LOGIN_WATERMARK_ANSWER = "LOGIN.WATERMARK_ANSWER";
    public static final String REDIRECT_TO_SECURITYQA = "REDIRECT_TO_SECURITYQA";
    public static final String LOGIN_FORGOT_PASSWORD_MSG = Level.LOGIN_FORGOT_PASSWORD_MSG.name();
    public static final String LOGIN_FORGOT_USERNAME_SUCCESS = "LOGIN.FORGOT_USERNAME_SUCCESS";
    public static final String LOGIN_REDIRECT_RSC = "LOGIN.REDIRECT_RSC";
    public static final String LOGIN_FORGOT_PWD_LINK = "LOGIN.FORGOT_PWD_LINK";
    public static final String LOGIN_FORGOT_USER_LINK = "LOGIN.FORGOT_USER_LINK";
    public static final String LOGIN_TERMSANDCONDITIONS_LINK = "LOGIN.TERMSANDCONDITIONS_LINK";
    public static final String LOGIN_ANONYMOUS= "LOGIN.ANONYMOUS";    
    public static final String LOGIN_WATERMARK_USERNAME= "LOGIN.WATERMARK_USERNAME";
    
    /* List of Values for disabled user in AD */
    public static final String DISABLE_ACCOUNT_FIELD = "DISABLE_ACCOUNT_FIELD";
    public static final String LOGIN_DISABLED_USER = "LOGIN.DISABLED_USER";
    
}
