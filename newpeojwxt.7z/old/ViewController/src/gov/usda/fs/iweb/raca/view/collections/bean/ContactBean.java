package gov.usda.fs.iweb.raca.view.collections.bean;

import gov.usda.fs.iweb.raca.common.view.bean.RacaBean;

import oracle.adf.controller.faces.context.FacesPageLifecycleContext;
import oracle.adf.controller.v2.lifecycle.Lifecycle;
import oracle.adf.controller.v2.lifecycle.PagePhaseEvent;
import oracle.adf.controller.v2.lifecycle.PagePhaseListener;
import org.apache.myfaces.trinidad.component.core.input.CoreInputText;

import org.apache.myfaces.trinidad.component.core.layout.CorePanelGroupLayout;

import oracle.binding.BindingContainer;

import org.apache.log4j.*;

//public class ContactBean extends RacaBean  implements PagePhaseListener{

public class ContactBean extends RacaBean{
    
    private static Logger log = LogManager.getLogger(ContactBean.class);
    private CoreInputText remarks;
    private BindingContainer bc = null;
    private CorePanelGroupLayout panelGroupContacts;

    public ContactBean() {
    }

    public void setRemarks(CoreInputText remarks) {
        this.remarks = remarks;
    }

    public CoreInputText getRemarks() {
        return remarks;
    }

//    public void afterPhase(PagePhaseEvent event) {
//        if (log.isDebugEnabled()) {          
//            log.debug("In afterPhase");
//        }
//        FacesPageLifecycleContext ctx = 
//            (FacesPageLifecycleContext)event.getLifecycleContext();
//        if (event.getPhaseId() == Lifecycle.PREPARE_RENDER_ID) {
//            bc = ctx.getBindingContainer();
//            // Add method call for after Phase
//            bc = null;
//        }
//    }
//
//    public void beforePhase(PagePhaseEvent event) {
//         if (log.isDebugEnabled()) {          
//             log.debug("In beforePhase");
//         }
//        getRequestVariables();
//        
//        FacesPageLifecycleContext ctx = 
//            (FacesPageLifecycleContext)event.getLifecycleContext();
//        if (event.getPhaseId() == Lifecycle.PREPARE_MODEL_ID) {
//            bc = ctx.getBindingContainer();
////            getRequestVariables();
////            if (getRefreshTarget() == null) {
////                getRequestVariables();
////            }
//            bc = null;
//        }
//    }
    
//    public void getRequestVariables() {
//        String local_refresh = getIWebRequestParameters().getFp4();
//        local_refresh = (String)getRequestValue("fp4");
//    }


    public void setPanelGroupContacts(CorePanelGroupLayout panelGroupContacts) {
        this.panelGroupContacts = panelGroupContacts;
    }

    /**
     * When page is called to get PanelGroup refresh the list of contacts
     * @return
     */
    public CorePanelGroupLayout getPanelGroupContacts() {
//
//        String local_refresh = getIWebRequestParameters().getFp4();
//        if (log.isDebugEnabled()) {          
//            log.debug("getPanelGroupContacts:local_refresh: " + local_refresh);
//        }
//
//        if (local_refresh != null) {
////            ContactsLinksViewImpl view = (ContactsLinksViewImpl)getApplicationModule().findViewObject("ContactsLinksView");
////            view.executeQuery();           
////            getRacaService().findViewObject("ContactsLinksView").executeQuery();
//            getRacaService().executeViewQuery("ContactsLinksView");
//            getRacaService().sync();
//        }
//        
        return panelGroupContacts;
    }
}


