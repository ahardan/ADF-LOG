package gov.usda.fs.iweb.raca.view.collections.bean;

import gov.usda.fs.iweb.raca.common.view.bean.RacaBean;

import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.AccInstrumentsViewImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.AccInstrumentsViewRowImpl;
import gov.usda.fs.nrm.gacommon.model.dataaccess.raca.RacaReqsViewImpl;

import javax.faces.event.ActionEvent;

import org.apache.myfaces.trinidad.component.core.data.CoreTable;
import org.apache.myfaces.trinidad.context.RequestContext;

import org.apache.log4j.*;

public class AIContextBean extends RacaBean{

    private static Logger log = LogManager.getLogger(AIContextBean.class);
    
    private String aiCn;
    private String objectName;

    public AIContextBean() {
    }

    public void setAiCn(String aiCn) {
        this.aiCn = aiCn;
    }

    public String getAiCn() {
        return aiCn;
    }

    public void setObjectName(String objectName) {
        this.objectName = objectName;
    }

    public String getObjectName() {
        return objectName;
    }

//    public void beforeSave(ActionEvent actionEvent) {
//         AccInstrumentsViewImpl parentView = (AccInstrumentsViewImpl)getRacaService().findViewObject("AccInstrumentsView");
//         AccInstrumentsViewRowImpl currentRow = (AccInstrumentsViewRowImpl)parentView.getCurrentRow();
//         currentRow.setCn(getAiCn());
//         currentRow.setObjName(getObjectName());
//
//        if (log.isDebugEnabled()) {
//            log.debug("Before Save");
//            log.debug("CN:" + currentRow.getCn());
//            log.debug("Type:" + currentRow.getObjName());
//        }
//    }


 //    public String refreshChild() {
 //        AccInstrumentsViewImpl parentView = (AccInstrumentsViewImpl)getRacaService().findViewObject("AccInstrumentsView");
 //        AccInstrumentsViewRowImpl currentRow = (AccInstrumentsViewRowImpl)parentView.getCurrentRow();
 //        
 //        if (log.isDebugEnabled()) {
 //            log.debug("CN:" + currentRow.getCn());
 //            log.debug("Type:" + currentRow.getObjName());            
 //            log.debug("No of Rows in child: " + getRacaService().findViewObject("RacaReqsView").getRowCount());
 //        }
 //               
 //        setAiCn(currentRow.getCn());
 //        setObjectName(currentRow.getObjName());
 //
 //        getRacaService().findViewObject("RacaReqsView").clearCache();  
 //        getRacaService().findViewObject("RacaReqsView").reset();
 //        getRacaService().findViewObject("RacaReqsView").setWhereClause("cn = '0'");
 //        getRacaService().findViewObject("RacaReqsView").executeQuery();
 //        if (log.isDebugEnabled()) {          
 //            log.debug("No of Rows in child: " + getRacaService().findViewObject("RacaReqsView").getRowCount());
 //        }
 //        
 //        AdfFacesContext adfContext = AdfFacesContext.getCurrentInstance();
 //        if(adfContext != null){
 //            adfContext.addPartialTarget(getCollectionsNavTable());
 //        }
 //        
 //        return null;
 //    }
 
}
