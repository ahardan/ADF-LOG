package gov.usda.fs.iweb.raca.common.view.utils;

import java.text.SimpleDateFormat;

import java.util.Date;

public class Utils {
    public Utils() {
    }

    /**
     * getCurrentDateAsString
     * @return
     */
    public static String getCurrentDateAsString(){
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        Date dNow = new Date();
        return sdf.format(dNow);        
    }
}
