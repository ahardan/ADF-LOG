package gov.usda.fs.iweb.raca.common.view.bean;

import gov.usda.fs.iweb.framework.binding.IWebInitialBindingContainer;
import gov.usda.fs.iweb.framework.utils.JSFUtils;
import gov.usda.fs.iweb.framework.view.IWebBaseBackingBean;

import gov.usda.fs.iweb.framework.view.utils.IWebViewUtils;
import gov.usda.fs.nrm.gacommon.model.service.common.GACommonService;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;

import javax.faces.application.NavigationHandler;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import javax.servlet.http.HttpSession;

import oracle.adf.model.binding.DCBindingContainer;

import org.apache.log4j.*;

public class RacaBean extends IWebBaseBackingBean {
    private static Logger log = LogManager.getLogger(RacaBean.class);
    
    public static final String ERROR_PAGE_URL = "../../../faces/global/validationMessages.jspx";
    public int maxRowCount;
    public boolean rowCountExceeded;
    public Hashtable errorWindowProperties;
    
    public RacaBean() {
    }
    
    /**
     * getRacaService
     * @return RacaService
     */
    public GACommonService getRacaService(){
        return (GACommonService)IWebViewUtils.getApplicationModule("RacaService");
    }

    /**
     * getBeanName
     * @param cardName
     * @param action
     * @return
     */
    public String getBeanName(String cardName, String action){
        String beanName = cardName;
        if("I".equalsIgnoreCase(action)){
            beanName = beanName + "InsertBean";                
        }else if("D".equalsIgnoreCase(action)){
            beanName = beanName + "DeleteBean";
        }else if("R".equalsIgnoreCase(action)){
            beanName = beanName + "RecursiveBean";
        }else{
            beanName = beanName + "ModifyBean";
        }
        return beanName;
    }
    
    protected void performNavigation(String outcome) {
        FacesContext context = FacesContext.getCurrentInstance();
        NavigationHandler nh = context.getApplication().getNavigationHandler();
        nh.handleNavigation(context, "", outcome);
    }

    public void setErrorWindowProperties(Hashtable errorWindowProperties) {
        this.errorWindowProperties = errorWindowProperties;
    }

    public Hashtable getErrorWindowProperties() {
        errorWindowProperties = new Hashtable();
        errorWindowProperties.put("width", "width=400");
        errorWindowProperties.put("height", "height=200");
        errorWindowProperties.put("toolbar", "toolbar=0");
        //errorWindowProperties.put("modal", "modal=1");
        errorWindowProperties.put("location",  "location=0");
        errorWindowProperties.put("menubar",   "menubar=0");
        errorWindowProperties.put("top",   "top=200");   
        return errorWindowProperties;
    }   
    
    public HttpSession getSession() {
        FacesContext context = FacesContext.getCurrentInstance();
        return (HttpSession)context.getExternalContext().getSession(true);
    }


    public void setMaxRowCount(int maxRowCount) {
        this.maxRowCount = maxRowCount;
    }

    public int getMaxRowCount() {
        return maxRowCount;
    }

    public void setRowCountExceeded(boolean rowCountExceeded) {
        this.rowCountExceeded = rowCountExceeded;
    }

    public boolean isRowCountExceeded() {
        return rowCountExceeded;
    }

    public String getRequestValue(String value) {
        FacesContext context = FacesContext.getCurrentInstance();
        ExternalContext extContext = context.getExternalContext();
        return (String)extContext.getRequestParameterMap().get(value);
    }

    /**
     * Returns true if the string is either null or empty.
     *
     * @param s The string to evaluate
     * @return  True if the string is either null or empty.
     */
    public boolean isNullOrEmpty(String s) {
      return (s == null) || s.equals("");
    }

    /**
     * refreshBindingContainer
     * @param bc
     */
    protected void refreshBindingContainer(DCBindingContainer bc)
    {
       if (bc instanceof IWebInitialBindingContainer)      
       {
          ((IWebInitialBindingContainer)bc).resetIteratorRefreshOption();
       }
    }
    
//    public void processRoles(){
//        //UserBean userRacaBean = (UserBean)getSession().getAttribute("userBean");
//        userRacaBean = (UserBean) findBean("userBean");
//        log.debug("Roles : " + userRacaBean.getRoles());  
//
//        // remove all roles in case they were set already
//        getSession().removeAttribute("II_GA_SPEC");
//        getSession().removeAttribute("II_RACA_ASC");
//        
//        ArrayList roles = new ArrayList();
//        roles = userRacaBean.getRoles();
//        Iterator iter = roles.iterator();
//        while(iter.hasNext()){
//          String sRole = (String)iter.next();
//          //log.debug("sRole : " + sRole);
//          JSFUtils.storeOnSession(sRole,sRole);
//        }
//    }
}
