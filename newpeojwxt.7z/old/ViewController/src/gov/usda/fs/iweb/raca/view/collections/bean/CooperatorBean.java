package gov.usda.fs.iweb.raca.view.collections.bean;

import gov.usda.fs.iweb.framework.utils.ADFUtils;
import gov.usda.fs.iweb.framework.utils.JSFUtils;
import gov.usda.fs.iweb.raca.common.view.bean.RacaBean;

import java.util.HashMap;
import java.util.Map;

import javax.faces.application.Application;
import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;
import javax.faces.event.ActionEvent;

import oracle.adf.model.binding.DCBindingContainer;
import org.apache.myfaces.trinidad.component.core.data.CoreTable;
import org.apache.myfaces.trinidad.component.core.input.CoreInputText;
import org.apache.myfaces.trinidad.component.core.layout.CorePanelGroupLayout;

import org.apache.myfaces.trinidad.component.core.nav.CoreCommandButton;

import org.apache.myfaces.trinidad.context.RequestContext;

import org.apache.myfaces.trinidad.event.ReturnEvent;

import oracle.jbo.Row;

import oracle.jbo.ViewObject;

import org.apache.log4j.*;

public class CooperatorBean extends RacaBean{

    private static Logger log = LogManager.getLogger(CooperatorBean.class);
    private CorePanelGroupLayout panelGroupCooperators;
    private CoreInputText ffisVendorId;

    public CooperatorBean() {
    }

    public void setPanelGroupCooperators(CorePanelGroupLayout panelGroupCooperators) {
        this.panelGroupCooperators = panelGroupCooperators;
    }

    public CorePanelGroupLayout getPanelGroupCooperators() {
//        String local_refresh = getIWebRequestParameters().getFp4();
//        if (log.isDebugEnabled()) {          
//            log.debug("getPanelGroupCooperators:local_refresh: " + local_refresh);
//        }
//
//        if (local_refresh != null) {
//            getRacaService().executeViewQuery("CooperatorsLinksView");
//            getRacaService().sync();
//        }
        return panelGroupCooperators;
    }

    public void setFfisVendorId(CoreInputText ffisVendorId) {
        this.ffisVendorId = ffisVendorId;
    }

    public CoreInputText getFfisVendorId() {
        return ffisVendorId;
    }

    protected DCBindingContainer getBindings() {
        FacesContext context = FacesContext.getCurrentInstance();
        Application app = context.getApplication();
        DCBindingContainer binding = 
            (DCBindingContainer)app.getVariableResolver().resolveVariable(context, 
                                                                          "bindings");
        return binding;
    }

    /**
     * ffisVendorIdRetListener
     * @param returnEvent
     */
    public void ffisVendorIdRetListener(ReturnEvent returnEvent) {
        if (returnEvent.getReturnValue() != null) {

            String lovVendorId = (String)returnEvent.getReturnParameters().get("vendorId");
            log.debug("lovVendorId : " + lovVendorId);

//            ViewObject view = getRacaService().findViewObject("CooperatorsLinksView");    
//            Row row = view.getCurrentRow();
//            row.setAttribute("FfisVendorId", lovVendorId);
//            view.setCurrentRow(row);
            

//            getFfisVendorId().resetValue();
//            getFfisVendorId().setValue(lovVendorId);
            getFfisVendorId().setSubmittedValue(lovVendorId);
            
//            FacesContext context = FacesContext.getCurrentInstance();
//            Application app = context.getApplication();
//            ValueBinding bind = app.createValueBinding("#{bindings.FfisVendorId.inputValue}");
//            String fVendorId = (String)bind.getValue(context);
//            log.debug("fVendorId : " + fVendorId);
//            bind.setValue(context, lovVendorId);

//            
//            //String cn = (String) JSFUtils.resolveExpression("#{bindings.Cn.inputValue}");
//            JSFUtils.setExpressionValue("#{bindings.FfisVendorId.inputValue}", lovVendorId);
//            //ADFUtils.setBoundAttributeValue("#{bindings.FfisVendorId.inputValue}", (String)returnEvent.getReturnParameters().get("vendorId"));
//            //refreshView();
//

            RequestContext adfContext = RequestContext.getCurrentInstance();
            if (adfContext != null) {
                adfContext.addPartialTarget(getFfisVendorId());
            }
        }
    }

    /**
     * selectVendorIdActListener
     * @param actionEvent
     */
    public void selectVendorIdActListener(ActionEvent actionEvent) {
        RequestContext afContext = RequestContext.getCurrentInstance();
        ViewObject view = getRacaService().findViewObject("LovFFISVendors");    
        Row row = view.getCurrentRow();

        Map values = new HashMap();
        String vendorId = (String)row.getAttribute("VendorId");
        values.put("vendorId", vendorId);

        afContext.returnFromDialog(vendorId, values);
        afContext.getProcessScope().clear();

        // reset LOV options
        //view.setsecurityId("%");
        view.executeQuery();
        view.first();
    }

    /**
     * cancelActListener
     * @param actionEvent
     */
    public void cancelActListener(ActionEvent actionEvent) {
        RequestContext.getCurrentInstance().returnFromDialog(null, null);
    }
    
    
    

}
