package gov.usda.fs.nrm.raca.view.collections.bean.raca;

import gov.usda.fs.nrm.framework.view.utils.IWebViewUtils;
import gov.usda.fs.nrm.common.view.bean.raca.RacaBean;

import javax.faces.application.FacesMessage;
import javax.faces.event.ActionEvent;

import org.apache.myfaces.trinidad.component.core.data.CoreTable;
import org.apache.myfaces.trinidad.component.core.input.CoreInputText;
import org.apache.myfaces.trinidad.component.core.layout.CorePanelButtonBar;
import org.apache.myfaces.trinidad.component.core.layout.CorePanelGroupLayout;
import org.apache.myfaces.trinidad.context.RequestContext;
import org.apache.myfaces.trinidad.event.ReturnEvent;

import org.apache.log4j.*;

public class JobCodeNotifBean extends RacaBean {

    private static Logger log = LogManager.getLogger(JobCodeNotifBean.class);
    public String jclTotalAmount;
    public String jclTotalBurden;
    public String jclTotalNetAvail;
    private CoreInputText jobCodeStatus;
    private CorePanelButtonBar jcPanelButtonBar;
    private CoreTable jobCodeLinesTable;
    private CorePanelGroupLayout jobCodePanelGroup;

    public JobCodeNotifBean() {
    }
    
    /**
     * onJCLCalculateActListener
     * It calculates Job Code Lines Totals
     * @param actionEvent
     */
    public void onJCLCalculateActListener(ActionEvent actionEvent) {
         //log.debug("onJCLCalculateActListener: " );   
         IWebViewUtils.commitNoMessage();
         setJclTotalAmount(getRacaService().calcTotal("RacaJobCodeNotifLinesView", "AgmtAmount"));
         setJclTotalBurden(getRacaService().calcTotal("RacaJobCodeNotifLinesView", "BurdenAmount"));
         setJclTotalNetAvail(getRacaService().calcTotal("RacaJobCodeNotifLinesView", "NetSpending"));         
         //AdfFacesContext.getCurrentInstance().addPartialTarget(jobCodePanelGroup);
    }
          
    /**
     * statusJobCodeSendDialogAction
     * @return
     */
    public String statusJobCodeSendDialogAction() {
        String retValue;
        retValue = "dialog:statusChange";
        
        System.out.println("Inside Job Code Notify Sent ");
        if (log.isDebugEnabled()) {          
            log.debug("statusJobCodeSendDialogAction: " + retValue);
            //log.debug("getStatusCmdId: " + getStatusCmdId());
        }  
        
        if (!IWebViewUtils.commitNoMessage())
            retValue = null;
                    
        return retValue;   
    }

    /**
     * statusJobCodeDialogReturn
     * @param returnEvent
     */
    public void statusJobCodeDialogReturn(ReturnEvent returnEvent) {
        log.debug("start statusJobCodeDialogReturn: ");
        RequestContext afContext = RequestContext.getCurrentInstance(); 
        if (returnEvent.getReturnValue() != null) {                        
            IWebViewUtils.commitNoMessage();            
            getRacaService().executeViewQuery("RacaJobCodeNotifView");
            getJobCodeStatus().resetValue();

            RequestContext adfContext = RequestContext.getCurrentInstance();
            if(adfContext != null){
                log.debug("getJobCodeStatus: " + getJobCodeStatus().getValue());
                adfContext.addPartialTarget(getJobCodeStatus());
                adfContext.addPartialTarget(getJcPanelButtonBar());              
            }
        }
    }
    
    public void setJclTotalAmount(String jclTotalAmount) {
        this.jclTotalAmount = jclTotalAmount;
    }

    public String getJclTotalAmount() {
        return jclTotalAmount;
    }

    public void setJclTotalBurden(String jclTotalBurden) {
        this.jclTotalBurden = jclTotalBurden;
    }

    public String getJclTotalBurden() {
        return jclTotalBurden;
    }

    public void setJclTotalNetAvail(String jclTotalNetAvail) {
        this.jclTotalNetAvail = jclTotalNetAvail;
    }

    public String getJclTotalNetAvail() {
        return jclTotalNetAvail;
    }

    public void setJobCodeStatus(CoreInputText jobCodeStatus) {
        this.jobCodeStatus = jobCodeStatus;
    }

    public CoreInputText getJobCodeStatus() {
        return jobCodeStatus;
    }

    public void setJcPanelButtonBar(CorePanelButtonBar jcPanelButtonBar) {
        this.jcPanelButtonBar = jcPanelButtonBar;
    }

    public CorePanelButtonBar getJcPanelButtonBar() {
        return jcPanelButtonBar;
    }

    public void setJobCodeLinesTable(CoreTable jobCodeLinesTable) {
        this.jobCodeLinesTable = jobCodeLinesTable;
    }

    public CoreTable getJobCodeLinesTable() {
        return jobCodeLinesTable;
    }

    public void setJobCodePanelGroup(CorePanelGroupLayout jobCodePanelGroup) {
        this.jobCodePanelGroup = jobCodePanelGroup;
    }

    public CorePanelGroupLayout getJobCodePanelGroup() {
        return jobCodePanelGroup;
    }

}
