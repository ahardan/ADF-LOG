package gov.usda.fs.nrm.common.view.menubar.raca;

import gov.usda.fs.nrm.framework.utils.JSFUtils;
import gov.usda.fs.nrm.framework.view.toolbar.HelpToolBarBean;

import gov.usda.fs.nrm.framework.view.utils.IWebViewUtils;
import gov.usda.fs.nrm.gacommon.model.service.common.GACommonService;

import javax.faces.context.FacesContext;

import org.apache.log4j.*;

public class HelpToolBarData extends HelpToolBarBean
{
   private static Logger log = LogManager.getLogger(HelpToolBarData.class);

    public HelpToolBarData()
    {
    }

    /**
     * getRacaService
     * @return RacaService
     */
    public GACommonService getRacaService(){
        return (GACommonService)IWebViewUtils.getApplicationModule("RacaService");
    }

    /**
     * getHelpURL
     * v3.3
     * @return
     */
    public String getHelpURL()
    {
        // String helpURL = "http://i-web.wo.fs.fed.us/support/help/raca/";   // old      
        String helpURL = getRacaService().getHelpURLValue();
        if (helpURL != null){
            helpURL = helpURL + "/raca/"; 
        }        
        //log.debug("helpURL:" + helpURL);
        return helpURL;
    }

    
//   public String getHelpURL()
//   {
//      FacesContext context = FacesContext.getCurrentInstance();
//      String viewId = context.getViewRoot().getViewId();
//      log.debug(viewId);
//      String helpURL = "http://i-web.wo.fs.fed.us/support/help/raca/";
//      log.debug("helpURL:" + helpURL);
///*      
//      if ("/riverMain.jspx".equals(viewId))
//      {
//         helpURL = helpURL + "#profile.htm";
//      }
//      if ("/riverSegments.jspx".equals(viewId))
//      {
//         helpURL = helpURL + "#segments.htm";
//      }
//      if ("/riverAuthority.jspx".equals(viewId))
//      {
//         helpURL = helpURL + "#Authority.htm";
//      }
//      if ("/riverManagement.jspx".equals(viewId))
//      {
//         helpURL = helpURL + "#management_record.htm";
//      }
//      if ("/riverWebsite.jspx".equals(viewId))
//      {
//         helpURL = helpURL + "#iwsrcc_web_site.htm";
//      }
//      if ("/candidateMain.jspx".equals(viewId))
//      {
//         helpURL = helpURL + "#river_candidate.htm";
//      }
//      if ("/candidateSegments.jspx".equals(viewId))
//      {
//         helpURL = helpURL + "#segments_candidate.htm";
//      }
//      if ("/candidateProfileReport.jspx".equals(viewId) ||
//          "/candidateRegionSummReport.jspx".equals(viewId) ||
//          "/candidateRegionStateReport.jspx".equals(viewId) ||
//          "/performanceDetailReport.jspx".equals(viewId) ||
//          "/performanceSummReport.jspx".equals(viewId) ||
//          "/profileReport.jspx".equals(viewId))
//      {
//         helpURL = helpURL + "#Reports.htm";
//      }
//  */    
//      return helpURL;
//   }
   
   public String getTargetFrame()
   {
      return "_help";
   }
}
