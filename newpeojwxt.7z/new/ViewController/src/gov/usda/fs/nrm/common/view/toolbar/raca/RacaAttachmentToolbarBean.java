
package gov.usda.fs.nrm.common.view.toolbar.raca;

import gov.usda.fs.nrm.framework.view.toolbar.AttachmentToolBarBean;

import java.io.Serializable;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
//import gov.usda.fs.nrm.namp.view.util.ViewUtil;

public class RacaAttachmentToolbarBean extends AttachmentToolBarBean implements Serializable {
    private static Logger log = LogManager.getLogger(RacaAttachmentToolbarBean.class);
    @SuppressWarnings("compatibility:5436358694296575095")
    private static final long serialVersionUID = 1L;
    private boolean visible;
    private boolean rendered;    
    private String destination;
    
    public RacaAttachmentToolbarBean() {
        super();
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getDestination() {
        //return destination;
        return returnDestination();
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    // Used for BackButtom
//    public boolean isVisible() {
//        
//        String inboxName = ViewUtil.getPageName();
//        //System.out.print(inboxName);
//        if("/subm/projLanding.jsf".equals(inboxName) || ("/projLanding".equals(inboxName)))        
//          return true;
//        else
//          return false;
//    }

    public void setRendered(boolean rendered) {
        this.rendered = rendered;
    }

    public boolean isRendered() {
          return false;
        }
    public String returnDestination() {
        return "projLanding";
    }
    
}
