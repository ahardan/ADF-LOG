package gov.usda.fs.nrm.common.view.menubar.raca;

import gov.usda.fs.nrm.framework.utils.ADFUtils;
import gov.usda.fs.nrm.framework.utils.JSFUtils;
import gov.usda.fs.nrm.framework.view.toolbar.AttachmentToolBarBean;

import oracle.jbo.server.EntityImpl;

import oracle.jbo.server.ViewRowImpl;

import org.apache.log4j.*;

public class AttachmentToolBarData  extends AttachmentToolBarBean{

    private static Logger log = LogManager.getLogger(AttachmentToolBarData.class);
    
    public AttachmentToolBarData() {
    }

    public String getCn()
    {
       Object cn = null;
       ViewRowImpl r = (ViewRowImpl)ADFUtils.findIterator("RacaAgmtViewIterator").getViewObject().getCurrentRow();   
       if(r!=null){// when the empty agreement is created
       if (r.getEntity(0).getEntityState() != EntityImpl.STATUS_NEW)
       {
           String viewId = JSFUtils.getFacesContext().getViewRoot().getViewId();
           cn = (String) JSFUtils.resolveExpression("#{bindings.CnA.inputValue}"); 
           //log.debug("getCn:" + cn);
           
       }
       }
       return (String) cn;
       
    }

    public String getObjectClass()
    {
        String viewId = JSFUtils.getFacesContext().getViewRoot().getViewId();
        Object objClass = null;
        objClass =  "ACCOMPLISHMENT_INSTRUMENT"; 
        return (String) objClass;
    }

    public String getSecurityId()
    {
       return null;
    }
/*
 * sdelucer - If the RACA record is new and had not been saved, popup the notsaved.html in a new window instead of 
 *            going to the Attachments application URL
 */
    public String getLinkAttachmentsUrl()
    {
        String url = null;
        ViewRowImpl r = (ViewRowImpl)ADFUtils.findIterator("RacaAgmtViewIterator").getViewObject().getCurrentRow();    
        if(r!=null){//when the empty agreement is created
        if (r.getEntity(0).getEntityState() == EntityImpl.STATUS_NEW || 
            r.getEntity(0).getEntityState() == EntityImpl.STATUS_INITIALIZED)
        {
            url = "/notsaved.html";  
        }
        else
        {
            url = super.getLinkAttachmentsUrl();
            
        }
        }
       // url = "/notsaved.html";  
        return url;
    }
/*
 * sdelucer - The getDisabled() method could be used to simply disable the "Link" button if the record is new 
 *
    public Boolean getDisabled()
    {
        Boolean b = super.getDisabled();
        ViewRowImpl r = (ViewRowImpl)ADFUtils.findIterator("RacaAgmtViewIterator").getViewObject().getCurrentRow();    
        if (r.getEntity(0).getEntityState() == EntityImpl.STATUS_NEW || 
            r.getEntity(0).getEntityState() == EntityImpl.STATUS_INITIALIZED)
        {
            b = Boolean.TRUE;
        }
        return b;
    }
*/

}
