package gov.usda.fs.nrm.raca.common.view.utils.raca;



import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;



public class EmailValidator implements Validator {
    public EmailValidator() {
        super();
    }

    
    public void validate(FacesContext facesContext, UIComponent uIComponent, Object object) throws ValidatorException {
        String value= (String) object;
        if(value!=null){
            String [] emails= value.split(",");
          
          
          for(int i=0; i< emails.length;i++){
            String str= emails[i];
              if( !isvalidEmail(str.trim())){
               String params ="Primary Recipient(s) value is not valid and Multiple emails should be separated by commas";
               FacesMessage message= new FacesMessage(FacesMessage.SEVERITY_ERROR,params, null );
                 throw new ValidatorException(message);
              }
          }
          }
        
      
        
    }
    
    private boolean isvalidEmail(String email) {
        String pattern =  "^([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$" ;
         return email.matches(pattern);
    }
}
