package gov.usda.fs.nrm.gacommon.model.service;

import gov.usda.fs.nrm.gacommon.model.exception.raca.RacaErrorMessages;

import oracle.jbo.DMLConstraintException;
import oracle.jbo.DMLException;
import oracle.jbo.JboException;
import oracle.jbo.server.DBTransactionImpl2;
import oracle.jbo.server.TransactionEvent;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

/**
 * Custom ADF DBTransaction implementation.
 *
 * Works in tandem with a custom DBTransactionFactory implementation
 * which returns instances of this subclass of DBTransactionImpl2
 * instead of the default one.
 */
public class RacaDBTransactionImpl extends DBTransactionImpl2 
{   
    
    private static Logger log = LogManager.getLogger(RacaDBTransactionImpl.class);
    
    

  /**
   * Overridden framework method that traps any ADF exceptions thrown
   * during the post/commit cycle, and if they happen to be wrapping
   * a database exception representing a constraint violation, it
   * rethrows a new exception with a custom error message from the
   * ErrorMessages bundle, keyed by the name of the database
   * constraint that has been raised.
   * 
   * @param te The transaction event.
   */
  public void postChanges(TransactionEvent te) 
  {
    try {
      super.postChanges(te);
    }
    catch (DMLConstraintException ex) 
    {
      log.error("DMLConstraintException: " + ex.getConstraintName() + "--" + ex.getMessage());
//      String[] params = {ex.getMessage()};
//      throw new JboException(ErrorMessages.class, ErrorMessages.DB_CONSTRAINT_VIOLATION, params);
      processDBException(ex);
    }
    catch (DMLException ex) 
    {
      log.error("DMLException: " + ex.getMessage() );
      processDBException(ex);
    }
  } 
  

  /**
   * Process DB Exceptions
   */
  public void processDBException(Exception ex)
  {
      log.error("processDBException: " + ex.getMessage());
      
      if (!(ex instanceof JboException)) 
      {
        log.error("No JboException: " + ex.getMessage());
        //ex.printStackTrace();
        throw new RuntimeException(ex);
        //return;
      }
      else
      {
        JboException jboex = (JboException) ex;
        String[] params = {jboex.getMessage()};
        
        Object[] details = jboex.getDetails();
  
        if ((details != null) && (details.length > 0)) 
        {
          for (int j = 0, count = details.length; j < count; j++) 
          {
            Exception e = (Exception) details[j];
            params[0] = e.getMessage();
            log.error(" Details " + e.toString());
  
            if (e instanceof java.sql.SQLException)
            {             
              java.sql.SQLException sqle = (java.sql.SQLException) e;
              params[0] = sqle.getMessage();
              log.error("sqle.getMessage: " + sqle.getMessage());
              //log.error("SQLException: " + sqle.getSQLState() + "--" + sqle.getMessage() + "--" +  sqle.getErrorCode() );
              if ( sqle.getMessage().indexOf("ORA-20008") >= 0 )
              {
                 if ( sqle.getMessage().indexOf("ACCINST_ACCINST2_UK") >= 0 )
                     throw new JboException(RacaErrorMessages.class,
                                                       RacaErrorMessages.AGREEMENT_UNIQUE_CONSTRAINT_VIOLATION , null);
                 else
                     throw new JboException(RacaErrorMessages.class,
                                                       RacaErrorMessages.DB_CONSTRAINT_VIOLATION, params);
              }
              else
                  throw new JboException(RacaErrorMessages.class,RacaErrorMessages.DB_CONSTRAINT_VIOLATION, params); 
            }
            else 
              throw new JboException(RacaErrorMessages.class,RacaErrorMessages.DB_CONSTRAINT_VIOLATION, params);               

          }
        }
        else 
        {
          log.error("No Details");
          throw new JboException(RacaErrorMessages.class,RacaErrorMessages.DB_CONSTRAINT_VIOLATION, params);
        }         
      }           
  }

  
}